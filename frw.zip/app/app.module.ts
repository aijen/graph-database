import { registerLocaleData } from '@angular/common';
import localeFr from '@angular/common/locales/fr';
import { LOCALE_ID, NgModule } from '@angular/core';
import { MatSnackBarConfig, MAT_SNACK_BAR_DEFAULT_OPTIONS } from '@angular/material/snack-bar';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { EffectsModule } from '@ngrx/effects';
import { ActionReducer, MetaReducer, State, StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { CoreModule } from 'core/core.module';
import { environment } from 'env/environment';
import { storeLogger } from 'ngrx-store-logger';
import { SNACKBAR_DURATION } from 'shared/constants/constants';
import { SharedModule } from 'shared/shared.module';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

registerLocaleData(localeFr, 'fr');

export function logger(reducer: ActionReducer<State<any>>): any {
  return storeLogger()(reducer);
}

export const metaReducers: MetaReducer<any, any>[] = environment.hasMetareducer ? [logger] : [];

@NgModule({
  declarations: [
    AppComponent,
  ],
  imports: [
    CoreModule,
    AppRoutingModule,
    SharedModule,
    BrowserAnimationsModule,
    StoreModule.forRoot({}, {metaReducers}),
    EffectsModule.forRoot([]),
    !environment.production ? StoreDevtoolsModule.instrument({ maxAge: 30, serialize: false }) : [],
  ],
  bootstrap: [AppComponent],
  providers: [
    { provide: LOCALE_ID, useValue: 'fr' },
    { provide: MAT_SNACK_BAR_DEFAULT_OPTIONS, useValue: { duration: SNACKBAR_DURATION, horizontalPosition: 'center' } as MatSnackBarConfig },
  ]
})
export class AppModule {}
