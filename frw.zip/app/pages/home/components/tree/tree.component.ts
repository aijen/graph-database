import { Component, Input, OnInit } from '@angular/core';
import { Leaf } from 'shared/models/leaf.model';
import { Node } from 'shared/models/node.model';

@Component({
  selector: 'cockpit-tree',
  templateUrl: './tree.component.html',
  styleUrls: ['./tree.component.scss']
})
export class TreeComponent implements OnInit {

  @Input()
  tree: Node;

  trackByNodeKey = Node.trackByKey;
  trackByLeafKey = Leaf.trackByKey;

  constructor() { }

  ngOnInit() {
  }

}
