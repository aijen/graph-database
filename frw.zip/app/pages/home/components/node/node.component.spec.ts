import { Component, Input } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { NodeComponent } from './node.component';

@Component({
  selector: 'cockpit-node-title',
  template: '',
})
class CockpitNodeTitleStubComponent {
  @Input() leaf: any;
}

@Component({
  selector: 'cockpit-tree',
  template: '',
})
class CockpitTreeStubComponent {
  @Input() tree: any;
}

describe('NodeComponent', () => {
  let context: TestCtx<NodeComponent>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      declarations: [
        NodeComponent,
        CockpitNodeTitleStubComponent,
        CockpitTreeStubComponent,
      ],
    })
  });

  beforeEach(async( async () => {
    context = await createStableTestContext(NodeComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
