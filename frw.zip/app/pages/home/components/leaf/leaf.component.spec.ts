import { Component, Input } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { LeafComponent } from './leaf.component';

@Component({
  selector: 'cockpit-node-title',
  template: '',
})
class CockpitNodeTitleStubComponent {
  @Input() leaf: any;
}

@Component({
  selector: 'cockpit-metric-details',
  template: '',
})
class CockpitMetricDetailsStubComponent {
  @Input() leaf: any;
}


describe('LeafComponent', () => {
  let context: TestCtx<LeafComponent>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      declarations: [
        LeafComponent,
        CockpitNodeTitleStubComponent,
        CockpitMetricDetailsStubComponent,
      ],
    })
  });

  beforeEach(async( async () => {
    context = await createStableTestContext(LeafComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
