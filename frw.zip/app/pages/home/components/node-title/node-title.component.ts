import { Component, ContentChild, Input, OnInit, TemplateRef } from '@angular/core';
import { fadeInOut } from 'core/animations/animations';
import { Leaf } from 'shared/models/leaf.model';
import { Node } from 'shared/models/node.model';

// Might need to refactor this with node component as they share the same logic

@Component({
  selector: 'cockpit-node-title',
  templateUrl: './node-title.component.html',
  styleUrls: ['./node-title.component.scss'],
  animations: [fadeInOut()],
})
export class NodeTitleComponent implements OnInit {
  @Input()
  set leaf( value: Leaf | Node ) {
    this._leaf   = value;
    this.isNode  = Node.isNode( value );

    // if leaf does have not a name we show a key
    const { fullname, name, key } = value;
    this.title = fullname || name || key;
  }
  get leaf() { return this._leaf; }
  private _leaf: Leaf | Node;

  isNode = false;

  get nodes()     { return this.isNode ? (this._leaf as Node).nodes : [] };
  get leaves()    { return this.isNode ? (this._leaf as Node).leaves : [] };

  title: string;

  @ContentChild(TemplateRef)
  content: TemplateRef<any>;

  constructor() {}

  ngOnInit() {
  }

}
