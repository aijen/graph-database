import { Component, Input } from '@angular/core';
import { Store } from '@ngrx/store';
import { MetasCheck } from 'core/models/leaves/leaves.model';
import { getPopulatedMetasForLeaf } from 'core/store/populated-metas/populated-metas.selectors';
import { SubscriptionAwareComponent } from 'core/utils/subscription-aware.component';
import { BehaviorSubject } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';
import { BarInfo } from 'shared/models/hatched-bar.model';
import { Leaf } from 'shared/models/leaf.model';
import { Meta } from 'shared/models/meta.model';
import { Node } from 'shared/models/node.model';
import { AppState } from 'shared/models/state.model';


@Component({
  selector: 'cockpit-metric-details',
  templateUrl: './metric-details.component.html',
  styleUrls: ['./metric-details.component.scss']
})
export class MetricDetailsComponent extends SubscriptionAwareComponent {

  @Input() set leaf( leaf: Leaf ) { this._leaf$.next(leaf) }
  get leaf() { return this._leaf$.value }
  private _leaf$ = new BehaviorSubject<Leaf>(new Leaf)

  public metas: Meta[];
  public barsInfo: BarInfo[][];
  public numBars: number;

  readonly metricTypes = [
    {
      type: 'availability',
      title: 'Disponibilité',
      lastTimeProp: 'lastTimeAvailability',
      firstTimeProp: 'firstAvailabilityTimeKO',
      KO: 'KO',
      adminMetaType: 'availability',
    },
    {
      type: 'performance',
      title: 'Performance',
      lastTimeProp: 'lastTimePerformance',
      firstTimeProp: 'firstPerformanceTimeKO',
      KO: 'KO',
      adminMetaType: 'performance',
    },
    {
      type: 'risk',
      title: 'Risque',
      lastTimeProp: 'lastTimeRisk',
      firstTimeProp: 'firstRiskTimeKO',
      NOK: 'NOK',
      adminMetaType: 'risk',
    },
    {
      type: 'user_xp',
      title: 'Ressenti',
      lastTimeProp: 'lastTimeFeeling',
      firstTimeProp: 'firstFeelingTimeKO',
      KO: 'KO',
      adminMetaType: 'userXp',
    },
  ];

  populatedMeta$ = this._leaf$.pipe( switchMap( leaf => this.store$.select(getPopulatedMetasForLeaf(leaf.key)) ) )
  breadcrumb$ = this._leaf$.pipe( map( leaf => {
    const breadcrumb = []
    let parent: Node | Leaf = leaf;

    while( parent = parent.parent ) {
      const { fullname, name, key, isLeafWrapper } = parent;
      if( !isLeafWrapper ) breadcrumb.unshift( fullname || name || key );
    }

    return breadcrumb
  } ) )

  constructor(
    private store$: Store<AppState>,
  ) {
    super();
  }

  hasMetaType(metaType: string, metas: MetasCheck) {
    return metas && metas[metaType];
  }

}
