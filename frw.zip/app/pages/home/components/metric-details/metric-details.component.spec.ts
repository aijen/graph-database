import { Component, Input } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { configureTestSuite, createTestContext, TestCtx } from 'ng-bullet';
import { Observable } from 'rxjs';
import { HatchedBarService } from 'shared/components/hatched-bar/hatched-bar.service';
import { AppState } from 'shared/models/state.model';
import { MetricDetailsComponent } from './metric-details.component';

@Component({
  selector: 'pit-hatched-bar',
  template: '',
})
class CockpitHatchedBarStubComponent {
  @Input() metas: any;
  @Input() showTime: any;
  @Input() populatedMeta: any;
}

describe('MetricDetailsComponent', () => {
  let context: TestCtx<MetricDetailsComponent>;
  let actions: Observable<any>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
      ],
      declarations: [
        MetricDetailsComponent,
        CockpitHatchedBarStubComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: {} }),
        provideMockActions(() => actions),
        { provide: HatchedBarService, useFactory: () => jasmine.createSpyObj('HatchedBarService', ['initHatchedBar', 'initHatchedBarWithEndDate'] as Array<keyof HatchedBarService>) },
      ],
    })
  });

  beforeEach(async( async () => {
    context = await createTestContext(MetricDetailsComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
