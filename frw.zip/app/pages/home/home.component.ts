import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { select, Store } from '@ngrx/store';
import { getGroups } from 'core/store/groups/groups.selectors';
import { SetTemplate } from 'core/store/hierarchy/hierarchy.actions';
import { Template } from 'core/store/templates/templates.model';
import { getTemplates } from 'core/store/templates/templates.selectors';
import { SubscriptionAwareComponent } from 'core/utils/subscription-aware.component';
import { trackByIndex } from 'core/utils/trackByIndex';
import { combineLatest, Observable } from 'rxjs';
import { Node } from 'shared/models/node.model';
import { AppState } from 'shared/models/state.model';
import { getPositionedNodes } from '../../core/store/hierarchy/hierarchy.selectors';

@Component({
  selector: 'cockpit-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent extends SubscriptionAwareComponent implements OnInit {

  trackByNodeKey = Node.trackByKey;
  trackByIndex = trackByIndex;

  leafsCols$: Observable<Node[][]> = this.store$.pipe( select( getPositionedNodes ) );

  constructor(
    private store$: Store<AppState>,
    private activatedRoute: ActivatedRoute,
  ) {
    super();

    const params$ = this.activatedRoute.params;
    const groups$ = this.store$.select(getGroups);
    const templates$ = this.store$.select(getTemplates);

    this.subscription.add(

      combineLatest([params$, groups$, templates$]).subscribe(([params, groups, templates]) => {
        const { group } = params;

        if(group === undefined) {
          this.resetTemplate();
        }
        else {
          const findedGroup = groups.find(g => g.name === group);

          if(findedGroup && findedGroup.defaultTemplate) {
            const template = templates.find(t => t.id === findedGroup.defaultTemplate);

            if(template) {
              this.store$.dispatch(new SetTemplate({ template }));
            }
          }
        }
      })
    );
  }

  ngOnInit() {
  }

  private resetTemplate() {
    const template: Template = {
      id: undefined,
      name: undefined,
      nodesPosition: undefined,
      type: undefined,
      nodes: [],
      hiddenNodes: [],
    };
    this.store$.dispatch(new SetTemplate({ template }));
  }
}
