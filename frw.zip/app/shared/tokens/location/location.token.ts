import { InjectionToken } from '@angular/core';

export const LocationToken = new InjectionToken('Location', {
  providedIn: 'root',
  factory: () => window.location
} );
