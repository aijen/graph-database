import { inject } from '@angular/core/testing';
import { LocationToken } from './location.token';

describe('LocationToken', () => {

  it('should inject window.location', inject([LocationToken], (locationToken) => {

    expect(locationToken).toBe(window.location);

  }))

})
