import { AfterContentChecked, Component, ContentChild, ElementRef, Input, OnChanges, OnInit, TemplateRef } from '@angular/core';

@Component({
  selector: 'pit-virtual-scrolling',
  templateUrl: './virtual-scrolling.component.html',
  styleUrls: ['./virtual-scrolling.component.scss']
})
export class VirtualScrollingComponent<T> implements OnInit, AfterContentChecked, OnChanges {

  @Input() items: T[]
  @Input() itemSize: number
  @ContentChild(TemplateRef) template: TemplateRef<any>
  elementHeight = 0
  elementScroll = 0
  displayItems: T[] = []
  startIndex = 0
  totalHeight = 0

  constructor(
    private elementRef: ElementRef<HTMLElement>
  ) { }

  ngOnInit() {
  }

  ngOnChanges() {
    this.updateView()
  }

  ngAfterContentChecked() {
    if(this.elementRef && this.elementRef.nativeElement) {
      const { offsetHeight, scrollTop } = this.elementRef.nativeElement
      if( (offsetHeight !== this.elementHeight) || (scrollTop !== this.elementScroll) ) {
        this.elementHeight = offsetHeight
        this.elementScroll = scrollTop
        this.updateView()
      }
    }
  }

  updateView() {
    if( !this.items ) {
      this.displayItems = []
      this.totalHeight = 0
      return
    }

    const length = this.items.length
    const startIndex = this.startIndex = Math.max(0, Math.floor((this.elementScroll - this.itemSize) / this.itemSize))
    const endIndex = Math.min(length, Math.ceil((this.elementHeight + this.elementScroll) / this.itemSize))
    this.displayItems = this.items.slice(startIndex, endIndex)
    this.totalHeight = length * this.itemSize
  }

  trackByIndex( index: number ) {
    return index
  }

}
