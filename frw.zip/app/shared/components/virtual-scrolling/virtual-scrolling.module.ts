import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { VirtualScrollingComponent } from './virtual-scrolling.component';

@NgModule({
  declarations: [
    VirtualScrollingComponent,
  ],
  exports: [
    VirtualScrollingComponent,
  ],
  imports: [
    CommonModule
  ]
})
export class VirtualScrollingModule { }
