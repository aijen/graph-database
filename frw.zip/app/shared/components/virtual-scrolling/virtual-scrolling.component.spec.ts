import { async, TestBed } from '@angular/core/testing';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { VirtualScrollingComponent } from './virtual-scrolling.component';

describe('VirtualScrollingComponent', () => {
  let context: TestCtx<VirtualScrollingComponent<any>>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
      ],
      declarations: [
        VirtualScrollingComponent,
      ],
    })
  });

  beforeEach(async( async () => {
    context = await createStableTestContext(VirtualScrollingComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
