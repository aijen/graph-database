import { Injectable } from '@angular/core';
import { MetasCheck } from 'core/models/leaves/leaves.model';
import { META_TYPE } from 'core/store/notifications/notifications.model';
import moment from 'moment';
import { BarInfo, BarInfos } from 'shared/models/hatched-bar.model';
import { Meta, MetaState, Timebox } from 'shared/models/meta.model';

const defaultPopulatedMeta = {
  availability: false,
  performance:  false,
  risk:         false,
  userXp:       false,
}

@Injectable({
  providedIn: 'root'
})
export class HatchedBarService {
  /** seconds */
  public static TIME_TO_AVOID_GREY_BARS = 300;
  private barInfos = new WeakMap<Meta[], BarInfos & { populatedMeta: MetasCheck }>();
  private metasByType = new WeakMap<Meta[], {
    [META_TYPE.AVAILABILITY]: Meta[],
    [META_TYPE.PERFORMANCE]:  Meta[],
    [META_TYPE.RISK]:         Meta[],
    [META_TYPE.USER_XP]:      Meta[],
  }>();

  public getDefaultEndDate() {
    return moment().subtract(HatchedBarService.TIME_TO_AVOID_GREY_BARS, 'seconds')
  }

  public initHatchedBar(
    metas: Meta[], metaType: META_TYPE | 'all', barCount: number,
    {
      endDate = this.getDefaultEndDate(),
      barUnit = 1,
      populatedMeta = defaultPopulatedMeta,
    }: {
      endDate?: moment.Moment,
      barUnit?: number,
      populatedMeta?: MetasCheck,
    } = {}
  ) {
    const barsInfo = this.getBarInfos( metas, metaType, populatedMeta )
    const metasByType = this.getMetasByType( metas )
    const startDate = endDate.clone().startOf('minute').subtract(barCount * barUnit, 'minutes');
    let startIndex = 0

    if( barsInfo.length ) {
      const diff = startDate.diff( moment.unix( barsInfo[0].begin ), 'minutes' )
      if( diff < 0 ) barsInfo.splice( 0, 0, ...Array(-diff).fill(null) )
      else startIndex = diff
    }

    for (let i = 0; i < barCount; i++) {
      const index = i + startIndex
      if(barsInfo[index]) continue;

      const begin = startDate.clone().add(i *  barUnit, 'minutes')
      const end = startDate.clone().add((i+1) *  barUnit, 'minutes')
      const beginUnix = begin.unix()
      const endUnix = end.unix()

      barsInfo[index] = new BarInfo( beginUnix, endUnix, MetaState.DISABLED, 0 );

      const metatypes = metaType === 'all' ? [
        META_TYPE.AVAILABILITY,
        META_TYPE.PERFORMANCE,
        META_TYPE.RISK,
        META_TYPE.USER_XP,
      ] : [metaType]

      const isWithinTimebox = ( timebox: Timebox ): boolean => timebox.startDate <= beginUnix && timebox.endDate >= endUnix

      for(const metatype of metatypes) {
        if(
          metatype === META_TYPE.AVAILABILITY && populatedMeta.availability === false
          || metatype === META_TYPE.PERFORMANCE && populatedMeta.performance === false
          || metatype === META_TYPE.RISK && populatedMeta.risk === false
          || metatype === META_TYPE.USER_XP && populatedMeta.userXp === false
        ) continue
        const result = this.findIndexDichotomy( metasByType[metatype], meta => isWithinTimebox(meta.timeBox) ? 0 : meta.timeBox.startDate - beginUnix )
        const metaIndex = result.index
        if(result.found) {
          const meta = metasByType[metatype][metaIndex]
          if (this.shouldProcessState(meta.state, barsInfo[index]))
            barsInfo[index] = new BarInfo( beginUnix, endUnix, meta.state, meta.timeBox.resolution, meta );
        } else {
          const before = metasByType[metatype][metaIndex]
          const after = metasByType[metatype][metaIndex - 1]
          if(
            before && after
            && ((after.timeBox.startDate - before.timeBox.endDate) <= (35 * 60))
            || before && (Date.now() - before.timeBox.endDate * 1000) <= (35 * 60 * 1000)
            // || after && (Date.now() - after.date) <= (35 * 60 * 1000)
          ) {
            if( this.shouldProcessState( MetaState.NO, barsInfo[index] ) )
              barsInfo[index] = new BarInfo( beginUnix, endUnix, MetaState.NO, 0 );
          } else if( this.shouldProcessState( MetaState.STARVE, barsInfo[index] ) ) {
            barsInfo[index] = new BarInfo( beginUnix, endUnix, MetaState.STARVE, 0 );
          }
        }
      }

    }
    return barsInfo.slice( startIndex, startIndex + barCount );
  }

  private getMetasByType( metas: Meta[] ) {
    if( !this.metasByType.has( metas ) ) {
      const metasByType =  {
        [META_TYPE.AVAILABILITY]: [],
        [META_TYPE.PERFORMANCE]:  [],
        [META_TYPE.RISK]:         [],
        [META_TYPE.USER_XP]:      [],
      }
      for(const meta of metas) metasByType[meta.metaType].push(meta)
      this.metasByType.set( metas, metasByType )
    }

    return this.metasByType.get( metas )
  }

  private getBarInfos( metas: Meta[], metaType: META_TYPE | 'all', populatedMeta: MetasCheck ) {
    let barinfos = this.barInfos.get( metas );

    if( !barinfos || (barinfos.populatedMeta !== populatedMeta) ) {
      barinfos = {
        AVAILABILITY: [],
        PERFORMANCE:  [],
        RISK:         [],
        USER_XP:      [],
        all:          [],
        populatedMeta,
      }
      this.barInfos.set(metas, barinfos)
    }

    return barinfos[metaType]
  }

  private findIndexDichotomy<T>( array: T[], compare: ( item: T ) => number ): { found: boolean, index: number } {
    let min = 0
    let max = array.length
    let diff: number

    while( (diff = max - min) > 0 ) {
      const semidiff = diff / 2
      const cursor = Math.floor( min + semidiff )
      const comp = compare( array[cursor] )
      if( comp === 0 ) return { found: true, index: cursor }
      if( comp > 0 ) min = cursor + 1
      else max = cursor
    }

    return { found: false, index: min }
  }

  private shouldProcessState(state : MetaState, barinfo: BarInfo): boolean {
    if( state === barinfo.state ) return false
    const states = [ MetaState.KO, MetaState.NOK, MetaState.OK, MetaState.STARVE, MetaState.NO, MetaState.DISABLED ]
    const metaStateIndex = states.indexOf(state)
    const barinfoStateIndex = states.indexOf(barinfo.state)
    return metaStateIndex < barinfoStateIndex
  }
}
