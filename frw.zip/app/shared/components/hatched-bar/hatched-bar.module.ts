import { OverlayModule } from '@angular/cdk/overlay';
import { PortalModule } from '@angular/cdk/portal';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MomentModule } from 'ngx-moment';
import { HatchedBarComponent } from './hatched-bar.component';

@NgModule({
  declarations: [
    HatchedBarComponent
  ],
  exports: [
    HatchedBarComponent
  ],
  imports: [
    CommonModule,
    PortalModule,
    OverlayModule,
    MomentModule,
  ]
})
export class HatchedBarModule { }
