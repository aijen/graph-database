import { OverlayModule } from '@angular/cdk/overlay';
import { PortalModule } from '@angular/cdk/portal';
import { Component, NgZone, ViewChild } from '@angular/core';
import { fakeAsync, TestBed } from '@angular/core/testing';
import { META_TYPE } from 'core/store/notifications/notifications.model';
import moment from 'moment';
import { configureTestSuite, createTestContext, TestCtx } from 'ng-bullet';
import { MomentModule } from 'ngx-moment';
import { BarInfo } from 'shared/models/hatched-bar.model';
import { Meta, MetaState } from 'shared/models/meta.model';
import { HatchedBarComponent } from './hatched-bar.component';
import { HatchedBarService } from './hatched-bar.service';

const customMatchers = {
  toBeCanvasEqual( util, customEqualityTesters ) {
    return {
      compare(actual: HTMLCanvasElement, expected: HTMLCanvasElement) {
        // const result = {
        //   pass: actual === expected,
        //   message: ''
        // }

        const compareThreshold = 255 * 1/100

        const actualContext = actual.getContext('2d')
        const expectedContext = expected.getContext('2d')

        const actualData = actualContext.getImageData(0, 0, actual.width, actual.height)
        const expectedData = expectedContext.getImageData(0, 0, expected.width, expected.height)

        const width = Math.max(actualData.width, expectedData.width)
        const height = Math.max(actualData.height, expectedData.height)

        const getPixel = (x: number, y: number, data: ImageData) => {
          const offset = data.width * y * 4 + x * 4
          return data.data.slice(offset, offset + 4)
        }
        const almost = ( value1, value2, threshold ) => value1 >= (value2 - threshold) && value1 <= (value2 + threshold)
        const comparePixel = ( pixel1: Uint8ClampedArray, pixel2: Uint8ClampedArray ) =>
          almost(pixel1[0], pixel2[0], compareThreshold) &&
          almost(pixel1[1], pixel2[1], compareThreshold) &&
          almost(pixel1[2], pixel2[2], compareThreshold) // &&
          // almost(pixel1[3], pixel2[3], compareThreshold)

        const findDiff = ( data1: ImageData, data2: ImageData, startX = -1, startY = 0 ) => {
          startX += 1
          while(startX >= width) {
            startX -= width
            startY += 1
          }
          let x: number, y: number
          for(y = startY; y < height; y++) {
            for(x = startX, startX = 0; x < width; x++) {
              const isError =
                x >= actualData.width ||
                x >= expectedData.width ||
                y >= actualData.height ||
                y >= expectedData.height ||
                !comparePixel( getPixel(x, y, actualData), getPixel(x, y, expectedData) )

              if(isError) {
                return {x, y}
              }
            }
          }
        }

        let diff = findDiff(actualData, expectedData)

        if(!diff) return { pass: true }

        const canvas = document.createElement('canvas')
        const context = canvas.getContext('2d')
        const randomId = Math.random().toString(32).replace('0.', '#')
        let top = 0
        canvas.width = width
        canvas.height = height + actualData.height + expectedData.height + 40
        if((typeof document !== 'undefined')) {
          canvas.setAttribute('data-actual', actual.toDataURL())
          canvas.setAttribute('data-expected', expected.toDataURL())
          document.body.append(canvas)
        }

        context.font = '10px'
        context.textBaseline = 'top'

        context.fillText(randomId, 0, 0)
        top += 10

        context.fillText(`actual (${actualData.width}x${actualData.height})`, 0, top)
        top += 10
        context.drawImage(actual, 0, top)
        top += actualData.height

        context.fillText(`expected (${expectedData.width}x${expectedData.height})`, 0, top)
        top += 10
        context.drawImage(expected, 0, top)
        top += expectedData.height

        context.fillText(`difference (${width}x${height})`, 0, top)
        top += 10

        context.drawImage(actual, 0, top)
        context.drawImage(expected, 0, top)

        context.fillStyle = 'red'
        let x: number, y: number
        do {
          ;({ x, y } = diff)
          context.fillRect(x, y + top, 1, 1)
        } while( diff = findDiff(actualData, expectedData, x, y) )

        return { pass: false, message: `Expected canvas to be equal. See difference ${randomId}` }

      }
    }
  }
}

async function getCanvas( base64Url: string ) {
  const canvas = document.createElement('canvas')
  const context = canvas.getContext('2d')
  const img = document.createElement('img')
  const loaded = new Promise(res => img.onload = res)
  img.src = base64Url
  await loaded
  canvas.width = img.width
  canvas.height = img.height
  context.drawImage(img, 0, 0)
  return canvas
}

describe('HatchedBarComponent', () => {

  @Component({
    template: `
    <div [ngStyle]="{ width: _width, background: 'black' }">
      <pit-hatched-bar></pit-hatched-bar>
    </div>
    `,
    providers: [
      { provide: NgZone, useFactory: () => {
        const spy: jasmine.SpyObj<NgZone> = jasmine.createSpyObj('NgZone', ['runOutsideAngular'] as Array<keyof NgZone>)
        spy.runOutsideAngular.and.callFake((fn: Function) => fn())
        return spy
      } }
    ],
  })
  class TestComponent {

    @ViewChild(HatchedBarComponent)
    hatchedBar: HatchedBarComponent

    set width( width: number ) { this._width = `${width}px` }
    private _width = '200px'

  }

  let context: TestCtx<TestComponent>
  let hatchedBar: HatchedBarComponent
  let canvas: HTMLCanvasElement

  const createMeta = ( meta?: Partial<Meta> ): Meta => ({
    metaType: 'metaType',
    value:    1,
    date:     2,
    state:    MetaState.NO,
    source:   [],
    weight:   3,
    timeBox:  {
      startDate:  4,
      endDate:    5,
      resolution: 6,
    },
    ...meta,
  })

  function constructMetas( marbles: string, time: moment.Moment, metaType: META_TYPE ) {
    const KO = metaType === META_TYPE.RISK ? MetaState.NOK : MetaState.KO;
    marbles = marbles.replace( /(\d+)(.)/g, (_, times, type) => Array(Number(times)).fill(type).join('') );
    marbles = marbles.replace( /\s+/g, '' );
    time.subtract(HatchedBarService.TIME_TO_AVOID_GREY_BARS, 'seconds');
    time.subtract(marbles.length, 'minutes');
    return marbles.split('').map( marble => {
      const dateInfos = { timeBox: { startDate: time.unix(), endDate: time.add(1, 'minute').unix(), resolution: 1 }, date: time.valueOf() };
      switch(marble) {
        case 'r': return createMeta({ metaType, state: KO,           ...dateInfos });
        case 'g': return createMeta({ metaType, state: MetaState.OK, ...dateInfos });
      }
    } ).filter( meta => Boolean(meta) );
  }

  // at this point the meta should be sorted by date descending
  function sortMetas( metaA: Meta, metaB: Meta ) {
    return metaB.date - metaA.date
  }

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        MomentModule,
        PortalModule,
        OverlayModule,
      ],
      declarations: [
        HatchedBarComponent,
        TestComponent,
      ],
    })
  });

  beforeEach(fakeAsync(() => {
    context = createTestContext(TestComponent);
    context.detectChanges()
    hatchedBar = context.component.hatchedBar
    canvas = hatchedBar.canvas.nativeElement
    jasmine.addMatchers(customMatchers)
  } ));

  afterEach(() => {
    jasmine.clock().uninstall()
  })

  it('should create', () => {
    expect(context.component).toBeTruthy();
    expect(hatchedBar).toBeTruthy();
    expect(canvas).toBeDefined()
  });

  it('should only display hashed bars when there is no meta', async () => {
    // 200x30: 50 hashed bars
    const result = await getCanvas('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAAeCAYAAABpP1GsAAACcUlEQVR4Xu1cMW7CMBS11yCVvT1H2Fq4AHvDBCxhC0fIETySJRJbMnMBaKccpOxUIqsrg4xQ4iQ0jhRhPzYLBfs///f/f98mlOADBIBAJQIU2AABIFCNAAgC7wACNQjQg+OElJCAUrp9P5/XxXEURSEhJOCcb1er1Vp33DSf+P7XdYMfz+tkPrHeYZYFb2mqtA/2Yn/r/Jt+OQ6XBPrI89v45LpkejjQKIpu3/u+33o8zDLyGceV84k1iPl34zE/zmaXJenMJ59Plkv+miSX37u3rziGvXp4m7q/SocVziKctAsHFQQT4AknrXNQ6bBdEVISpCoA3BME9l5DZNv9Nnl/SwRBBNfLmMhYZlUkJYIggusRBBmrTJBnztDQHNBYrTSmqZqjmCAuBHlmhhcNQgQ3K4L3vb/oGmlmEGgOszRHKYNAc0BzyDb/I10s2zJ063ONYlvQlppUBhTYqz5XMq0L2glBTO6DqzIs7L3mHNW5lmkViTZBUIObXYPbvr/aBLGtJoW9dnXJWhMENbgdNXhTQDBNcxTtbUUQ1OD21OBNBDFNc2gTxPaaFLefryWWLbef/51BmiIKTub1zlVw+1nd9OjrtvfDBIHmgOaw8f86DxEEmgOao68I3ndF0kgQaA6cc9ikOaSEkBqrkSDQHHb1/VX7bfNt70qCQHNAc9ioOYrnOkqCQHNAc9iqOUrX3TebDaOUzgkhzPf9MFks2GuazjkhbJzn4fdgwDjnpfFpNGLT/T4sPt92/JJlzIvjyvnkenaTCTt63m29beeDvdjfe/+u8me8OA6vTQMCdS+OAzpAAAhUI4AMAu8AAjUI/AEIppRaJka14wAAAABJRU5ErkJggg==')
    fakeAsync(() => {
      jasmine.clock().install()
      jasmine.clock().mockDate( moment('2000-07-15', 'YYYY-MM-DD').toDate() )

      hatchedBar.metas = []
      hatchedBar.populatedMeta = {
        availability: true,
        performance: true,
        risk: true,
        userXp: true,
      }

      hatchedBar.ngOnChanges()
      jasmine.clock().tick(32)

      ;(expect(canvas) as any).toBeCanvasEqual(result)
    })()
  })

  it('should display bars of the appropriate color when there is meta (OK = green, KO = red, NOK = orange, STARVE = hashed, NO = grey, DISABLED = dark grey)', async () => {
    // 200x30: 30 hashed bars, 5 green bars, 5 grey bars, 5 orange bars, 5 red bars
    const result = await getCanvas('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAAeCAYAAABpP1GsAAADAUlEQVR4Xu2czW7aQBSFz90Sqdmnz2F2LXmB7EvYkKSS2eFHmEeYZSw1SCyQYJ0XCO3KzXM0+1QK26lMhIvMX/AdYwsOuyvk+bm+3zkzDBoBP8wAM7AxA8LcMAPMwOYMEBBWBzOwJQMybTSMAH0RGX55e4vycRzHBkDfOTfs9XqRNt7VX/r93yDo/2m3vfSXjvc8SfqfJ5O18zv2+eL5Yf7+4NwQze+RNjbGvLcHDI0xkTZ2Ixg49CEYSgeROgay8QkQOWUsPxsNtwDo62yWxa9BgKvpVOI4zr4Pw7BwfJ4k+DYYbOwvHUPa/2Or5V6ur+dD0vS3eH58e+suxuN5e8vzy8fHOl88P2TvD8GdaGNjTNaeMUa0sRsha086EHWMpfYAccp4bcGmxZIWqY8CTQFL4UiLdFuBLgrWF5ALQDYJwDIgxzxfLRD557VA5J9XA5EHTAlEHqgVQKjgOsesm2MREJ2jrABCBdcBUjfHIiCeADnWNfip77EIiAdAjnkNvg6QU5ovAVECwj2HbklVtz1HXhAIiBIQ7jl0gNRtz0FAdECs/IrlCxCec6w/Z6naoekgOmAKH/wtH+TxnOP9qHXdOY8vASp6rkNAKgak7mvwqhXcFyBFHZqAVAxI3dfgvgq0qIL76F/j0ASkIkCKKpq2YOhY+/13joBUAIhG0bSA0LFWAdl2rkNADgwIFXw/BS8qCL4cmoAcGBAq+H4KXgQQnw5NQA4EiC9F27dg6Fg6xyIgBwDEp6LtCwgdS+dYBKRkQKjgOgX/qCCU5dAEpGRAqOA6Bf8IIGU6NAEpCZCyFG1XwdCx/DoWASkBkDIVbRcgdCy/jkVAlIDc399bEekCsGEYmvHNjb2YTLoOsK3ZzPw6O7POuZX4tdm0V09PJv980fhTktj2YLCxv8V4Hi8v7Uu7nY23aH+nMl/8/mEh6AJiEdwZbWyMmdeDiNj0yh9t7EawQDo+WOnAqGMstQekV7D8b79AzIvjeG0aM7Dt4jhmhxlgBnj1KGuAGSiUgX+jjtktiT/WmgAAAABJRU5ErkJggg==')
    fakeAsync(() => {
      jasmine.clock().install()
      jasmine.clock().mockDate( moment('2000-07-15', 'YYYY-MM-DD').toDate() )

      hatchedBar.metas = [
        ...constructMetas('30- 5g 5- 5- 5r', moment(), META_TYPE.AVAILABILITY),
        ...constructMetas('30- 5g 5- 5- 5r', moment(), META_TYPE.PERFORMANCE),
        ...constructMetas('30- 5g 5- 5r 5-', moment(), META_TYPE.RISK),
        ...constructMetas('30- 5g 5- 5- 5r', moment(), META_TYPE.USER_XP),
      ].sort(sortMetas)
      hatchedBar.populatedMeta = {
        availability: true,
        performance: true,
        risk: true,
        userXp: true,
      }

      hatchedBar.ngOnChanges()
      jasmine.clock().tick(32)

      ;(expect(canvas) as any).toBeCanvasEqual(result)
    })()
  })

  it('should display grey bars when there is no data for less than 35 minutes', async () => {
    // 200x30: 5 green bars, 35 grey bars, 10 green bars
    const result = await getCanvas('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAAeCAYAAABpP1GsAAABaUlEQVR4Xu3csW1CQRAE0L2ioB4knJsStoRfAA5oxxR1FkIQIP4FvkXG0iPb4K/QaIaZP5yuhQ8EILCKQIMNBCCwjgCBYAcEBgi0OH9lRHxG76fYfhxm58y87os4ZebBDI8RH2b59urnLwLpdwFt9tNzZt73ZWYzw+PGr2d8qOZf9b5pQTx+IYIgiJEgHvlRTejqfQTC8f7U8asJXb2PQAiEQG6W9+QVg0AIhEAI5IqA0uD9SpPqSFS9j4NwEA7CQTjIuzpo9S9+9T4OwkE4CAfhIBwkIn7xRzgH4SAchINwEA7CQdS4//DsW/VLdfU+EUvEErFELBFLxBKxRCwRqzwRlS903N1xd8fdB5mNQAiEQAjE4ceiw5/VrVP1PhFLi6XF0mJpsbRYWiwtlharPBG1+D4u0WIX0ZbY7HN2zsyl975rrS2XK3/M8BjxYZZvr37exXGuTYPA8OI48EAAAqsIcBDkgMAAgR/O3UQtM/cBlwAAAABJRU5ErkJggg==')
    fakeAsync(() => {
      jasmine.clock().install()
      jasmine.clock().mockDate( moment('2000-07-15', 'YYYY-MM-DD').toDate() )

      hatchedBar.metas = [
        ...constructMetas('10g35-10g', moment(), META_TYPE.AVAILABILITY),
      ].sort(sortMetas)
      hatchedBar.metaType = META_TYPE.AVAILABILITY
      hatchedBar.populatedMeta = {
        availability: true,
        performance: true,
        risk: true,
        userXp: true,
      }

      hatchedBar.ngOnChanges()
      jasmine.clock().tick(32)

      ;(expect(canvas) as any).toBeCanvasEqual(result)
    })()
  })

  it('should display hashed bars when there is no data for more than 35 minutes', async () => {
    // 200x30: 4 green bars, 36 hashed bars, 10 green bars
    const result = await getCanvas('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAAeCAYAAABpP1GsAAAC9ElEQVR4Xu1csW7bMBA9rg7Q7Ol3yFvr/ED2KpOTFJA3+xP0CRwtoDXgzZ7zA3E7qf2OZk+BeGUhG3IDWRRJny6ApZeNoO5IHt/j3YtFKcIfIoAIWCOgEBtEABGwRwAEAToQgYYIKPr9PSWiKRmzpOHXWWg7y7KdvTFmOZlMZq72ZjBIFdFUKbX89Po6q2v/jaLpnzj28ucar+i/zPPpx/XaOt7b+fj4w3rt+x26v6F4e+/nC4KYA4Gih+B2lmUH+yRJlK19mef0ZbFQPwaDw/Oft9uj9uNoZJ5vb3dTavLn27+6vzdXq9XOX9145XxeoohuNhvr/H3HK9eP9dbHu7q/XPxJ2wcTojohH4IUYClA2gTQEsA+/kpC+xDIRciivyBHQUoffz7zw3r3O1S339X4SQOc61+cIDjB6zMmMta+QuACWNqePUHXiYoT/JggyFj7DNNrgqAG96vBXQeMq//cM7R0BuD6F8kgqMH9a3AXAVz9556huQCWtm+dIOd+orkAWe3HenkaSxrgXP+tE+TcT7RQgmC9PI3FBbC0fWsEgeaA5ij+rRv6O5Y0wLn+WyEINAc0x6m/Y3EBLG3PJghqcF4N7lvSdTVDSwOc659NENTgvBrchyBdztBcAEvbixMktCZ1AQYZq1sZSxrgXP/iBHEBPrQfGatbGYsLYGl7MYLgXSPe28hd1Ry9e1mx7kTHu0b/3zUKzZDF813WHL0nCDSH3/0Y2/2Svmks6RKJ67/1EuuUE7Ppfgc0R7c0R28zCDQHNEfIhbNSY3FPeGn7VjIINAc0R8iV5LcaSxrgXP9sgkBzQHOEXIGuaiwugKXt2QSB5uARpO8aSxrgXP+Kfn3TpGhMpDRFD2loez6fa6XUmIh0kiTpqe0Pea7jxSL9eXGhjTFjQ6RH2+1R+/H6Wj/HMXu8cr6ruzt9tV5bxyvn8zIc6punp5PXV40P1rvf31C8vffz+HAcPpuGCDR+OA7hQQQQAWsEkEEADkSgIQL/AAoyrTw0fI54AAAAAElFTkSuQmCC')
    fakeAsync(() => {
      jasmine.clock().install()
      jasmine.clock().mockDate( moment('2000-07-15', 'YYYY-MM-DD').toDate() )

      hatchedBar.metas = [
        ...constructMetas('10g36-10g', moment(), META_TYPE.AVAILABILITY),
      ].sort(sortMetas)
      hatchedBar.metaType = META_TYPE.AVAILABILITY
      hatchedBar.populatedMeta = {
        availability: true,
        performance: true,
        risk: true,
        userXp: true,
      }

      hatchedBar.ngOnChanges()
      jasmine.clock().tick(32)

      ;(expect(canvas) as any).toBeCanvasEqual(result)
    })()
  })

  it('should display dark grey bars when the meta is not populated', async () => {
    // 200x30: 50 dark gey bars
    const result = await getCanvas('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAAeCAYAAABpP1GsAAABJUlEQVR4Xu3cQQrCMBCF4ckl26030CP0CL2Cy/SSEVGpCC1EZpHF5y5QsviZx5vfQkv4IYDAIYGCDQIIHBMQENOBwAmBMk3TEhHXUsq91npzxsM87Hko8zy3T4Bqrc54mId3IJ55EAiBEIivQPwWhoAIiIAIyIuAFdIK3asUGkSDaBANokE06H8bhAbRIBpEg2gQDaJBSLj3WOkbUfqFvf8SeN6L2pFfVAsIB+EgHISDcBAOwkE4SPpGlH4hp+AUIztF73wKCAfhIByEg3AQDsJBOEj6RpR+Ye+O53nOMrKzCAgH4SAchINwEA7CQThI+kaUfiGn4BQjO0XvfD4DsrbWLhGxbtu2OONhHvY8+HCcz6YhcPbhOHQQQOCYgAYxHQicEHgAwQy7PFqStFgAAAAASUVORK5CYII=')
    fakeAsync(() => {
      jasmine.clock().install()
      jasmine.clock().mockDate( moment('2000-07-15', 'YYYY-MM-DD').toDate() )

      hatchedBar.metas = []
      hatchedBar.metaType = META_TYPE.AVAILABILITY
      hatchedBar.populatedMeta = {
        availability: false,
        performance: true,
        risk: true,
        userXp: true,
      }

      hatchedBar.ngOnChanges()
      jasmine.clock().tick(32)

      ;(expect(canvas) as any).toBeCanvasEqual(result)
    })()
  })

  it('should display hashed bars when there is no data for more than 35 minutes on one meta type and no data for less than 35 minutes on another meta type', async () => {
    // 200x30: 30 green bars, 10 hashed bars, 10 green bars
    const result = await getCanvas('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAAeCAYAAABpP1GsAAACY0lEQVR4Xu2cv27CMBDGz2uQ2p33CFvLE7AXJv5UChs8Qh7BI5HaSGww9wWgnWifo92pBKsrIwVFJsFqQuBifWwni1z0+fv5fLYUQfhBASiQq4CANlAACuQrAEDgDihwRgFBX68hEU1IqTm1nqeI3dJj7XmhIJoIIeYPu93UjKMoOsy/Umo+Ho+nZWNbPj3+6/uT7273kI+73zQg6giQP0LsmB7vnnec38f9XiTx1veps16LKIqO40EQFI7vNxt6iuPj87Wn0vmS+K3dVj+93sFyOh93/7F/Qe4Ccn+/LEA0HNqkZYBIDK4B03A0F4tMIMz8JpDc9QMgjlUM03CmQc0VvGwFWQyHSsORVzFsFQuAOG5A7hNsW8HLApK3hUsDc65icdcPFcRxgG0reFFAivYc2GI5bjjuK17WFotTzwFAAAirU0FuPQcAASCsACm6hUqfUiXXAPrUq2zPAUAAiJOAXKrnACAAxDlAytxz2CoY954Op1iOA20zqG287D2H7fkAxHEDcp9gm0Ft45fuObDFAhBObLGq6jkACACpPSBV9hwABIDUGpCqew4AAkBqDUjVPQcAASC1BORaPQcAASC1A+SaPQcAASC1AuTaPUcCSFKxuB+T46LQcaBvfc+RlT9dsQCI4wbkPsF5gNyq5zArFnf9UEEcB9i2gttOrWwV6L/jZj7+gHy+SBLUJxKS/FFIiJ3SYzabSSFEn4hkEAThYjCQzeWyr4hke78PPxoNqZQ6ibetluysVqH5/6Lx3WYju3F8ko+73/DhOHw2DQqc/XAc5IECUADf5oUHoEARBf4AH5UqDw5+hUEAAAAASUVORK5CYII=')
    fakeAsync(() => {
      jasmine.clock().install()
      jasmine.clock().mockDate( moment('2000-07-15', 'YYYY-MM-DD').toDate() )

      hatchedBar.metas = [
        ...constructMetas('10g36-10g', moment(), META_TYPE.AVAILABILITY),
        ...constructMetas('30g10-10g', moment(), META_TYPE.PERFORMANCE),
        ...constructMetas('30g10-10g', moment(), META_TYPE.RISK),
        ...constructMetas('30g10-10g', moment(), META_TYPE.USER_XP),
      ].sort(sortMetas)
      hatchedBar.metaType = 'all'
      hatchedBar.populatedMeta = {
        availability: true,
        performance: true,
        risk: true,
        userXp: true,
      }

      hatchedBar.ngOnChanges()
      jasmine.clock().tick(32)

      ;(expect(canvas) as any).toBeCanvasEqual(result)
    })()
  })

  it('should update its canvas width to the available space (if it changed) when drawing', async () => {
    // 100x30: 25 hashed bars
    const result = await getCanvas('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAAAeCAYAAADaW7vzAAACGklEQVRoQ+1asZKCMBDdtDhz9t53YHenP2AvVmqDHX4Cn5BSGmbsoPYH5K7iQ87em5E2N/EGxwlwQBIgB7HbycTdt+9lNwlBoH9KZQApFY0OBjQhiokARYbhIgAHIXR8u932rO15ngsADiHkuNvt9qJ2mT86/m2azpdlSfFH4x3HsfMahrn4VMOLPgyDpCJ5T5KHfTVNWEQR8jzvMW7bNrc9jmNY+n6hPxoD9X+azchltbqHJOIvnR9st2QSBPf/e8bH2qrgzU0QDY4mRUZCKKGUDJqUvxKSJkiWAFJCigT3TIhKeDOEDF2hooIQXZEZQkQDYuf/N4WK4hfFq3uGYj3yTohKNbRrhfL4l9kjB7+r4SEg3ZXSTY9oz2D9c29ji7alojWUJ0EyFVrXv2y80gjR54z8c07dXasUQvqk0CorpEm8woTIrqFVEkLLZV9XpDAhsmtoFUKaVGiZ/6bxchPSV4UWEdIWXi5C+qzQPELaxFubEN0zmr0dr01I0zW0a4V2fRdXmZC2aiibkKGtyEqEtFlDu1Zo199vSgkZmkK7xltKiO4Z2Sbe5O14ISG6Z8i5myo7aLIrMpcQ3TN+L9jz3gCUJbjuOFuB0OFwwAihNQBg27bdYLPBkzBcEwA8SxL3czTChJCMfZ1O8eJ8dtn5vPZLHGPL9wv9pfGc5nN8saxHvLz+VMWrH8qp9lBOsXgGH45eIYpJ4Adfe8K1cCfzgAAAAABJRU5ErkJggg==')
    fakeAsync(() => {
      jasmine.clock().install()
      jasmine.clock().mockDate( moment('2000-07-15', 'YYYY-MM-DD').toDate() )

      hatchedBar.metas = []
      hatchedBar.populatedMeta = {
        availability: true,
        performance: true,
        risk: true,
        userXp: true,
      }

      const spy = spyOnProperty(canvas, 'width', 'set').and.callThrough()

      hatchedBar.ngOnChanges()
      jasmine.clock().tick(32)

      expect(spy).toHaveBeenCalledTimes(1)

      context.component.width = 100
      context.detectChanges()

      hatchedBar.ngOnChanges()
      jasmine.clock().tick(32)

      expect(spy).toHaveBeenCalledTimes(2)

      hatchedBar.ngOnChanges()
      jasmine.clock().tick(32)

      expect(spy).toHaveBeenCalledTimes(2)

      ;(expect(canvas) as any).toBeCanvasEqual(result)
    })()
  })

  it('should redraw on window resize if the canvas available space changed', async () => {
    // 200x30: empty transparent
    const emptyCanvas = await getCanvas('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAAeCAYAAABpP1GsAAAA20lEQVR4Xu3VsRHAMAzEsHj/pTOBXbB9pFchyLycz0eAwFXgsCFA4C4gEK+DwENAIJ4HAYF4AwSagD9IczM1IiCQkUNbswkIpLmZGhEQyMihrdkEBNLcTI0ICGTk0NZsAgJpbqZGBAQycmhrNgGBNDdTIwICGTm0NZuAQJqbqREBgYwc2ppNQCDNzdSIgEBGDm3NJiCQ5mZqREAgI4e2ZhMQSHMzNSIgkJFDW7MJCKS5mRoREMjIoa3ZBATS3EyNCAhk5NDWbAICaW6mRgQEMnJoazYBgTQ3UyMCPw0pAB/FTWyzAAAAAElFTkSuQmCC')
    // 100x30: 25 hashed bars
    const result = await getCanvas('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAAAeCAYAAADaW7vzAAACGklEQVRoQ+1asZKCMBDdtDhz9t53YHenP2AvVmqDHX4Cn5BSGmbsoPYH5K7iQ87em5E2N/EGxwlwQBIgB7HbycTdt+9lNwlBoH9KZQApFY0OBjQhiokARYbhIgAHIXR8u932rO15ngsADiHkuNvt9qJ2mT86/m2azpdlSfFH4x3HsfMahrn4VMOLPgyDpCJ5T5KHfTVNWEQR8jzvMW7bNrc9jmNY+n6hPxoD9X+azchltbqHJOIvnR9st2QSBPf/e8bH2qrgzU0QDY4mRUZCKKGUDJqUvxKSJkiWAFJCigT3TIhKeDOEDF2hooIQXZEZQkQDYuf/N4WK4hfFq3uGYj3yTohKNbRrhfL4l9kjB7+r4SEg3ZXSTY9oz2D9c29ji7alojWUJ0EyFVrXv2y80gjR54z8c07dXasUQvqk0CorpEm8woTIrqFVEkLLZV9XpDAhsmtoFUKaVGiZ/6bxchPSV4UWEdIWXi5C+qzQPELaxFubEN0zmr0dr01I0zW0a4V2fRdXmZC2aiibkKGtyEqEtFlDu1Zo199vSgkZmkK7xltKiO4Z2Sbe5O14ISG6Z8i5myo7aLIrMpcQ3TN+L9jz3gCUJbjuOFuB0OFwwAihNQBg27bdYLPBkzBcEwA8SxL3czTChJCMfZ1O8eJ8dtn5vPZLHGPL9wv9pfGc5nN8saxHvLz+VMWrH8qp9lBOsXgGH45eIYpJ4Adfe8K1cCfzgAAAAABJRU5ErkJggg==')
    fakeAsync(() => {
      jasmine.clock().install()
      jasmine.clock().mockDate( moment('2000-07-15', 'YYYY-MM-DD').toDate() )

      hatchedBar.metas = []
      hatchedBar.populatedMeta = {
        availability: true,
        performance: true,
        risk: true,
        userXp: true,
      }

      hatchedBar.ngOnChanges()
      jasmine.clock().tick(32)

      canvas.width = canvas.width // clearing the canvas, resulting in an empty trnasparant canvas
      const spy = spyOn(hatchedBar, 'draw').and.callThrough()

      window.dispatchEvent( new Event('resize') )
      jasmine.clock().tick(32)

      expect(spy).toHaveBeenCalledTimes(1)
      ;(expect(canvas) as any).toBeCanvasEqual(emptyCanvas) // should still be an empty canvas as it should not have redraw

      context.component.width = 100
      context.detectChanges()

      window.dispatchEvent( new Event('resize') )
      jasmine.clock().tick(32)

      expect(spy).toHaveBeenCalledTimes(2)
      ;(expect(canvas) as any).toBeCanvasEqual(result)
    })()
  })

  it('should show time ticks every 30mn when showTime = true', async () => {
    // 200x40: 50 hashed bars, from 23:20 to 00:10, with time ticks at 23:30 and 00:00
    const result = await getCanvas('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAAoCAYAAAC7HLUcAAAEaUlEQVR4Xu1cPWzTQBT+3sKQSnRiaRcmBphTqUNJhVjLiEgRqC2gFCGUioWfAUUswIIsIUQjIFJBSMnchQGhlkqgrEiwsLC0e0HNwHLoXLtc7Uvj2u7F9r1ul/j8fr/33nd2QzD4J4Q4B+AtgHFP7Bsiui6EeA3gmvfZDyI6o6oV2PcXwFMieiiEeATgLoBjAEL7DJrGojwPCCG+AzgN4FBxirvvqB1PRy0gkOgf5ZqIzgshrgB4DOAdgAsAngDYBPAKwHsJAH+vB6CT3j4JpkkAt9VrPQd/lYAzaRPL+u8BL06TssB5xesygBcAbvkx1cUp7j4TvjcKEE1XeC6BQUQSJPA6hQsQ71rp4BtE9CkAFgkQCah7EijyexVEJhzHMsIeEELIAvjLmwrktCDjuwFgKhgnAF8AuPEF8CDqPlkkTfp+KABRRqYPfsVXxiztqKTsOSFHLAA/NQBxq5dJB7KsfR0kCBBZ7L4BOBUAyL44aYAVaZ8J3xsHiDdaPQPwUh2jdOOUzgEeUPpWJtMVxkSQ8iLjMB1EjVPcfSb8YhQg3lx6E8AdZazyuch9+ZnnLJenKKDpx10uHjTbmnAgy2AOkloOKCcV/j3/eASuopxiSaJ+FcC0MqPK63WnX3yKlVp00rlR1NMohcS7HDPqvnS0jH4Xox0kulp8JXsgGx7INECEEIKIMq1jNsKYTy3yEN9MJ18eHJjP1MyG1nmILwMkG7lipRYMkIRhz4MDE5po9fY8xDfTHcTq7GHjM+EBWi+VGgTUiWhlamdnKbhuNpsNAHUhxMri4uJS0vUgefL73+VyfbNaTUWe1He0262Pdzpa+9heju9B+U2fSyXhQ/Vsr7e33i6XMbO+Ts1mc+/7Wq0Wez3a7eJSq9VXntRByl+tVMTW7KyrUhJ5/v72woIYa7fd+6n2BddsbzJ/FzW+2oSVySKTNI0ElQCTzpNJelCC+gmbFiB9gPQrACpA2N7dEhk33kWObwggXMGTdUzuWMWaSEIA4QqeDCDcscIAyXOHZs7BHCsWxywq5wg2CBcgeUZ40CCu4MWq4MOOL58aJewgzDmKxTlCHYQ5B3MO/5g/yimWbR069nON4LGgLTOpX1DYXv1zpaKdgqYCkCKfg+s6LNu723N0z7WKNpEkBgjP4MWewW2Pb2KA2DaTsr12nZLFBgjP4HbM4IMKQtE4R9DeWADhGdyeGXwQQIrGORIDxPaZlN9+3h2xbHn7+dAdZFBF4SfzyZ6r8NvP+kOPYb3tHRkgzDmYc9j4/zqRAMKcgznHsCr4sCeSgQBhzsHPOWziHD6F8DnWQIAw57Dr3F8Xb5vf9u4LEOYczDls5BzB5zpagDDnYM5hK+cIve6+vLzsENEcAKdWqzXa8/POWKczJwCn0us1NkZGHCFEaL09MeHMrK01gvvjro93u0611eorz9dndXra2apW9/SNK4/t5fiq+d0vn/mH4zLx82SsRFY9wADJamRYr0x4gAGSiTCwEln1wD8w1hKCeU1hiQAAAABJRU5ErkJggg==')
    fakeAsync(() => {
      jasmine.clock().install()
      jasmine.clock().mockDate( moment('2000-07-15 00:15:00', 'YYYY-MM-DD HH:mm:ss').toDate() )

      hatchedBar.metas = []
      hatchedBar.showTime = true
      hatchedBar.populatedMeta = {
        availability: true,
        performance: true,
        risk: true,
        userXp: true,
      }

      hatchedBar.ngOnChanges()
      jasmine.clock().tick(32)

      ;(expect(canvas) as any).toBeCanvasEqual(result)
    })()
  })

  it('should push back the time tick text if the text would overflow outside the canvas', async () => {
    // 121x40: 30 hashed bars, from 23:30 to 00:00, with time ticks at 23:30 and 00:00
    const result = await getCanvas('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHkAAAAoCAYAAADaKFUbAAADoUlEQVR4Xu2aP2hTURTGv7M4pENdHLSLk4OubaFDTRHXOkobUUJUUhFpcfHPIMFFXSQgYoPaEkXM3sVBpLGgbUdBFxcX6yhFmsHlyHl5L9y+3tR3XzK825wszU3ueffc8zv3fOe9hpj5DIBXAEbQfr0koivM/ALA5fCzb0R0Knwf/InZ/QXwiIjuMfN9ALcAHAKwx868hr5vR4CZvwI4CcApjkntiJnfy0JEdJaZLwJ4AOA1gHMAHgL4CeA5gDcCMQITJsHx0E4SYgLADXNu6MRnSRoFao9AGMcJOUThAbkA4CmA61HMbXF0srOczicCl4gEdHRiA8jhXHHiKhF9iAEXyJIUtwW2fG8mgkLuClkO2Y+wekpVlfivAZiMxxHAJwBB/AHcTWpHBqiobL+LTp5Rsq1l1yjZR6RcA/hugRxkqUJODFkO1BcAJ2KQd8UxrMBmcnS3C0+rlOnHAJ6ZJdlWmm2uhrC7ZqCUdIWcGHKiOFogd7cLdeAagJtGiY60+Y58Zuq2Ab6blp/fT0sU9u4IOGmr0ds42RkdWrT6n1D080Z3Lc3XJQBThibIfFtXrt21YyYn7ZKNxizoiZLadTTZ0S+d7lEE5BaKiUhhewTNxdWAr0J2CZl/cxWyf8ycPVbIziHzzyCA7J/b6rFrBALIzVyuQsA8EdUnd3YWovH2+Hh9enV1oVarVQDMM3N9bm4u9Xh4fb0+s7zcuX58vWi8MjVV2Zqd7Xm9yN+3pVJlpNHYs79B2W8A+WMux1F2nG61SMbbY2PYKhRQLpepVqt1vk87Ht7YwLFGA9H14+uZ436sF11P/LXtb5D2a4W8ks+zAJZXWqhmkBulEgtgee0HWRJrutnsS1LJWpJYM0tL/4V80PdrhawnqbfKlbXKsQuynqTeKldWK0cHsmpwW2DSylOWe44A8kHXpHj5HLT9BpBVgw+WBseTuq+Qs6pJ0aYHtefoG+Qsa9Kg3/f3BbLeB+99mCQymJXK0RfIWbsvjPsz6D1HT5BVg+1P8LLWvaeGrBrcvq+2PabNWuVIBVk1ONsaHE+yVJBVg/36r50TZNVgPzQ49UlWDfZHg1NBVg32S4NTQVYN9kuDnSCrBvupwYkhqwb7q8GJIKsG+63BVsiLi4tVIioCqJbL5cra0FCVmYsMVPOtlnX8e3S0+KtQCObH7dOMD29uFo82Gl3XM/1Jc31zf4O2X/1xvesv1T2cr5A9hObqskJ2jZiH8/8BXvBvYTwJNUMAAAAASUVORK5CYII=')
    fakeAsync(() => {
      jasmine.clock().install()
      jasmine.clock().mockDate( moment('2000-07-15 00:05:00', 'YYYY-MM-DD HH:mm:ss').toDate() )

      hatchedBar.metas = []
      hatchedBar.showTime = true
      hatchedBar.populatedMeta = {
        availability: true,
        performance: true,
        risk: true,
        userXp: true,
      }
      context.component.width = 121
      context.detectChanges()

      hatchedBar.ngOnChanges()
      jasmine.clock().tick(32)

      ;(expect(canvas) as any).toBeCanvasEqual(result)
    })()
  })

  it('should display a tooltip on mouseover', async () => {
    // 200x30: 50 hashed bars, last hashed bar hovered
    const lastBarHovered = await getCanvas('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAAeCAYAAABpP1GsAAACo0lEQVR4Xu1csW7CMBC1V5DKTr8Dhkot/AB7wwQsYYMvQBFfkJEsSGww8wPQDlU+pOxUgtWVQUFgO4Q4qBW+182i2Lk7v7v3fCac4Q8egAdOHhiNXgLG2IAxMRuPv4YcvoEHKHsgiqIDIIQQs36/P4yiSCT+8H2fAyCUdwdB25fNZrDxvFRAaABZl0oBZ2zAOZ+97nZDdWxAmIq4XOOs9eTnP7Xa4NvzEkTnmt/0vJU4HjwvFkb7YK+WQQv5+wHie1EhVEBoAPkolU5feNvveTLe1mqstV7zrAlu/bwSx+x9Oj3NL5PX+XrJeNloiE27fchtssTdOn/a/897PVGdzw/zmdaDvZeUwtbfrsbXuGElOOQmvccGlQ6XzpOb9NoGTTawbYDSAJKWAM4BA3uPXMs23i7HVwMIMnixjIqK5RYj0QCCDF4MIKhYOkAeuUJDcyjHerYJwlUOnuYPKvYeAPLICFcDiAzuVgb/7/hyaI5ilAqawy3NoR3z2lIKnBodT31QsdyuWIX7DAnAqHBS2GuuGK72se4CEJfPwU0VFvYe+yamvpZrjKQwQMDB3ebg1ONbGCDg4G5zcOrxtQYINAfukkmK5fopqBVAwMHpcPCsCuKa5lDtzQ0Q6pwUt5+PlJLKbe/cAMnKKOjMF2s84vbz9WPkv65YNwMEmgOag4LmsKJY0BzQHFR/r5NZQaA50OegpDnUX5hmAgSaA30Oyre9UwECzQHNQVFzqH0dI0CgOaA5qGoO7br7ZDIJOecdxljo+34w73bD6mLREYyFjf0++CyXQyGENt7W62FrtQrU79uOn+I49KbT1PWS51k2m+HG807Pa7se7KUZ37x9LLw4juDL0yibrCb8rL4dAEJ5t8B2pjISvHoUmwIeuOIBlbL/Ao/Cw1p/t35+AAAAAElFTkSuQmCC')
    // 200x30: 50 hashed bars, bar before last hashed bar hovered
    const barBeforeLastBarHovered = await getCanvas('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAAeCAYAAABpP1GsAAACwElEQVR4Xu1cO07DQBCdbYMEPZwjFEgQLpAeUwGN0yUnQBYncBk3kdIlNRcgUCAfBHqQSLtoHRzhsZ31J1LknZduZWXXMzvvzbxZ24rwgwcEe+Dx8SIgojGRnj89vU+4K5Rg38B0gR5Y9XrBd78//vC8+Wg0mkRRpFM3+L6voihKAKO1Tq4DIAKDRJLJBhCKaKyUml/+/EyeBwP9eXubuOAPEBwgmbHiE/AxR1TbsW29AoRnEN1k/ZM4Hp8tl4mDbOs3mf8/4/D/29aDvVnGbuL/Xfv72uttA/5qvTYZYicg+HXFJ0jHX/0+DVer2hOW3cBJHNPNbFa6nkG0MaAuwm0GLx4e9OlikTCGmR/2bgIG+1sxgxQFjHGeSUNVUpAtQM11Aw4TpLsCNA3gKvOxmnEnI5QB4j9gYO/Go0332+X9zTEqGLxeCuaARsbKljRdr0hyAAGDtwMIMlYeIF3O0FuAoCZtXmKY8gQaq1jjdb0iSQDSZYTzjAcGd4vBD72/6BrVbPtBc8jqCu6tjZt2QcDgYHCXKpK9AQQ1uJs1eJoxpe7vXgDich+8qKsHezfnJkXnWq51QVsDBH1/t/r+0FhZjdUaINAc0BwuaQ4ez40BIrUmtRFC1/v+0jXHXgCCGlxODW4jBNc0R2uAQHNAc0h6Grh2iWVjFJzMt3uWC08/FxPQoZ72rgwQaA6cc0h8X6cSQKA5oDkOxeCHrkisAIHmgOaQpDn4+ytWgEBz4JzD5XMO2xu1pQCB5oDmkKg5+DlWIUCgOaA5pGqO3FdNptNpqJS6I6LQ9/1gcX8fni6Xd5ooHKzXwdvRUai1zo2/zs/D4ctLwP/fdHwcx6E3m5Wul97P8/V1+Ol52/ttuh7sFbK/Lb9qgw/HSfqKmkBbOcHbNEcugwj0GUwW7AEOGK45eEWCDCI4WGA6EQcE98kve0fVWt7IJ8UAAAAASUVORK5CYII=')
    fakeAsync(() => {
      jasmine.clock().install()
      jasmine.clock().mockDate( moment('2000-07-15 00:00:00', 'YYYY-MM-DD HH:mm:ss').toDate() )

      hatchedBar.metas = []
      hatchedBar.populatedMeta = {
        availability: true,
        performance: true,
        risk: true,
        userXp: true,
      }
      const lastGreyBar: Partial<BarInfo> = {
        begin: moment('2000-07-14 23:54:00', 'YYYY-MM-DD HH:mm:ss').unix(),
        end:   moment('2000-07-14 23:55:00', 'YYYY-MM-DD HH:mm:ss').unix(),
        state: MetaState.STARVE,
      }
      const beforeLastGreyBar: Partial<BarInfo> = {
        begin: moment('2000-07-14 23:53:00', 'YYYY-MM-DD HH:mm:ss').unix(),
        end:   moment('2000-07-14 23:54:00', 'YYYY-MM-DD HH:mm:ss').unix(),
        state: MetaState.STARVE,
      }

      hatchedBar.ngOnChanges()
      jasmine.clock().tick(32)

      hatchedBar.mouseenter({ ...new MouseEvent('mouseenter'), offsetX: 199 })
      context.detectChanges()
      jasmine.clock().tick(32)

      expect(hatchedBar.tooltipBarInfo).toEqual(jasmine.objectContaining<BarInfo>(lastGreyBar))
      ;(expect(canvas) as any).toBeCanvasEqual(lastBarHovered)
      hatchedBar.mouseleave()
      jasmine.clock().tick(32)

      hatchedBar.mouseenter({ ...new MouseEvent('mouseenter'), offsetX: 198 })
      context.detectChanges()
      jasmine.clock().tick(32)

      expect(hatchedBar.tooltipBarInfo).toEqual(jasmine.objectContaining<BarInfo>(lastGreyBar))
      ;(expect(canvas) as any).toBeCanvasEqual(lastBarHovered)
      hatchedBar.mouseleave()
      jasmine.clock().tick(32)

      hatchedBar.mouseenter({ ...new MouseEvent('mouseenter'), offsetX: 197 })
      context.detectChanges()
      jasmine.clock().tick(32)

      expect(hatchedBar.tooltipBarInfo).toEqual(jasmine.objectContaining<BarInfo>(lastGreyBar))
      ;(expect(canvas) as any).toBeCanvasEqual(lastBarHovered)
      hatchedBar.mouseleave()
      jasmine.clock().tick(32)

      hatchedBar.mouseenter({ ...new MouseEvent('mouseenter'), offsetX: 196 })
      context.detectChanges()
      jasmine.clock().tick(32)

      expect(hatchedBar.tooltipBarInfo).toEqual(jasmine.objectContaining<BarInfo>(lastGreyBar))
      ;(expect(canvas) as any).toBeCanvasEqual(lastBarHovered)
      hatchedBar.mouseleave()
      jasmine.clock().tick(32)

      hatchedBar.mouseenter({ ...new MouseEvent('mouseenter'), offsetX: 195 })
      context.detectChanges()
      jasmine.clock().tick(32)

      expect(hatchedBar.tooltipBarInfo).toEqual(jasmine.objectContaining<BarInfo>(beforeLastGreyBar))
      ;(expect(canvas) as any).toBeCanvasEqual(barBeforeLastBarHovered)
      hatchedBar.mouseleave()
      jasmine.clock().tick(32)
    })()
  })

  it('should update its height on showTime toggle', async () => {
    // 200x40: 50 hashed bars
    const resultShowTime = await getCanvas('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAAoCAYAAAC7HLUcAAAD7ElEQVR4Xu1csW4TQRB901A4EqlokoYaakdKERwh2lAiHARKAshBCDmiARpk0QANOomCWIClgJDsOg0FQgkpkD8AGuqkDyguaAatcxetzuc43Pnsy+1Ltz7vzcy+fTvzdjcW8C+1EVDVywA+AJj2jbwXkTuq+g7Abf+znyJy0XYi1O8vgJci8lRVnwF4BOAMgJ5+qQXi8IvF4dhTD11VvxgjInJFVW8CeA7gI4CrAF4A2AXwFsAnQ4DAIZ9A5/1+hkyzAB7Y31XVHwC+G8KlHojDBkiQEYHvZ4XXhhgiYkgC/7MuQXw3bgC4KyJfQ2QxBDGEemyIYp7bJBpRCE6aIUFGALtVMn0OVnyrzIoslaw+50yJBeBXBEFmw+XZCMJxygQJkjLcfmn1CsAbu4yKKqeiXLEyzw6AOWaQlAELvZ4ESXG8fVF9D8BDq6wKtMgT85mtUyzS9NMu1wK9Qg2SInDWq0mQFMfZn8QXLBN/ANwHULJ2sYxQvwVgHkBXg/jfj9r94i5WinhFvZoEGfGA09zpGgESJEN4qaqKCDHJECYEI0NgkCAZAsN3hQTJECYkSIbAIEGyBwYJkj1MmEGyhwk9ytAIyHahUBOgKiIbcwcHa+F2vV6vAaiq6sbq6upa0vYge+b572KxulsuD8We8Xey3a5Ot1qR8TFe4nvc/JZvhYIGhL3U6Ry194tFLGxvS71eP3peqVRityfbbVxvNPraMz4Y+5ulku4tLnZdSmIv6N9cWdGpZrP7Pju+cJvxJhvvvOIbOWHNZDGTdBgT1BDMDJ6ZpMdN0GDCDouQAUH6LQA2QRjv4RIZF+8849tDEK7gyTImM1a+KpIegnAFT0YQZqxegpzmDE3NQY0VS2PmVXOEE0SXIKeZ4eGAuILnawUfN77cNUqYQag58qU5ejIINQc1R7DNf5JdLNcydOxzjfC2oCs1abCgMN7oc6W87YIOhSB53gePyrCM9zDnRJ1r5a0iSUwQ1uD5rsFdxzcxQVyrSRmvW7tksQnCGtyNGnzQgpA3zRGONxZBWIO7U4MPIkjeNEdigrhek/L282GJ5crt5//OIINWFJ7MJztX4e3n6E2Pcd32PjFBqDmoOVz8f50TEYSag5pjXCv4uCuSgQSh5uA5h0uaI5AQgcYaSBBqDrf2/aPwdvm2d1+CUHNQc7ioOcLnOpEEoeag5nBVc/Rcd19fX/dEZAmAV6lUas3lZW+q1VpSwCt1OrWdiQlPVXva+zMz3sLWVi3cP277bLvtlRuNvvYCfzbn5729cvnI37j2GC/xted3v/nMH47L0I+U0ZXsjQAJkj1M6FGGRoAEyRAYdCV7I/APqPk9c27nKnAAAAAASUVORK5CYII=')
    // 200x30: 50 hashed bars
    const result = await getCanvas('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAAeCAYAAABpP1GsAAACcUlEQVR4Xu1cMW7CMBS11yCVvT1H2Fq4AHvDBCxhC0fIETySJRJbMnMBaKccpOxUIqsrg4xQ4iQ0jhRhPzYLBfs///f/f98mlOADBIBAJQIU2AABIFCNAAgC7wACNQjQg+OElJCAUrp9P5/XxXEURSEhJOCcb1er1Vp33DSf+P7XdYMfz+tkPrHeYZYFb2mqtA/2Yn/r/Jt+OQ6XBPrI89v45LpkejjQKIpu3/u+33o8zDLyGceV84k1iPl34zE/zmaXJenMJ59Plkv+miSX37u3rziGvXp4m7q/SocVziKctAsHFQQT4AknrXNQ6bBdEVISpCoA3BME9l5DZNv9Nnl/SwRBBNfLmMhYZlUkJYIggusRBBmrTJBnztDQHNBYrTSmqZqjmCAuBHlmhhcNQgQ3K4L3vb/oGmlmEGgOszRHKYNAc0BzyDb/I10s2zJ063ONYlvQlppUBhTYqz5XMq0L2glBTO6DqzIs7L3mHNW5lmkViTZBUIObXYPbvr/aBLGtJoW9dnXJWhMENbgdNXhTQDBNcxTtbUUQ1OD21OBNBDFNc2gTxPaaFLefryWWLbef/51BmiIKTub1zlVw+1nd9OjrtvfDBIHmgOaw8f86DxEEmgOao68I3ndF0kgQaA6cc9ikOaSEkBqrkSDQHHb1/VX7bfNt70qCQHNAc9ioOYrnOkqCQHNAc9iqOUrX3TebDaOUzgkhzPf9MFks2GuazjkhbJzn4fdgwDjnpfFpNGLT/T4sPt92/JJlzIvjyvnkenaTCTt63m29beeDvdjfe/+u8me8OA6vTQMCdS+OAzpAAAhUI4AMAu8AAjUI/AEIppRaJka14wAAAABJRU5ErkJggg==')
    fakeAsync(() => {
      jasmine.clock().install()
      jasmine.clock().mockDate( moment('2000-07-15', 'YYYY-MM-DD').toDate() )

      hatchedBar.metas = []
      hatchedBar.populatedMeta = {
        availability: true,
        performance: true,
        risk: true,
        userXp: true,
      }

      hatchedBar.showTime = true
      hatchedBar.ngOnChanges()
      jasmine.clock().tick(32)

      ;(expect(canvas) as any).toBeCanvasEqual(resultShowTime)
      expect(canvas.height).toBe(40)

      hatchedBar.showTime = false
      hatchedBar.ngOnChanges()
      jasmine.clock().tick(32)

      ;(expect(canvas) as any).toBeCanvasEqual(result)
      expect(canvas.height).toBe(30)
    })()
  })

  it('should not throw if trying to draw before being initialized', async () => {
    // 300x30: empty transparent
    const result = await getCanvas('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAAAeCAYAAACWuCNnAAAA9ElEQVR4Xu3UAQkAAAwCwdm/9HI83BLIOdw5AgQIRAQWySkmAQIEzmB5AgIEMgIGK1OVoAQIGCw/QIBARsBgZaoSlAABg+UHCBDICBisTFWCEiBgsPwAAQIZAYOVqUpQAgQMlh8gQCAjYLAyVQlKgIDB8gMECGQEDFamKkEJEDBYfoAAgYyAwcpUJSgBAgbLDxAgkBEwWJmqBCVAwGD5AQIEMgIGK1OVoAQIGCw/QIBARsBgZaoSlAABg+UHCBDICBisTFWCEiBgsPwAAQIZAYOVqUpQAgQMlh8gQCAjYLAyVQlKgIDB8gMECGQEDFamKkEJEHgSxgAf4wzHdAAAAABJRU5ErkJggg==')
    fakeAsync(() => {
      context = createTestContext(TestComponent);
      hatchedBar = context.component.hatchedBar
      canvas = hatchedBar.canvas.nativeElement

      jasmine.clock().install()
      jasmine.clock().mockDate( moment('2000-07-15', 'YYYY-MM-DD').toDate() )

      hatchedBar.metas = []
      hatchedBar.populatedMeta = {
        availability: true,
        performance: true,
        risk: true,
        userXp: true,
      }

      hatchedBar.draw()
      jasmine.clock().tick(32)

      ;(expect(canvas) as any).toBeCanvasEqual(result)
    })()
  })

  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});


describe('HatchedBarComponent.queueDraw', () => {

  @Component({
    template: `
    <div style="width: 200px; background: black;">
      <pit-hatched-bar #bar1></pit-hatched-bar>
      <pit-hatched-bar #bar2></pit-hatched-bar>
    </div>
    `,
    providers: [
      { provide: NgZone, useFactory: () => {
        const spy: jasmine.SpyObj<NgZone> = jasmine.createSpyObj('NgZone', ['runOutsideAngular'] as Array<keyof NgZone>)
        spy.runOutsideAngular.and.callFake((fn: Function) => fn())
        return spy
      } }
    ],
  })
  class TestComponent {

    @ViewChild('bar1', { read: HatchedBarComponent })
    hatchedBar1: HatchedBarComponent

    @ViewChild('bar2', { read: HatchedBarComponent })
    hatchedBar2: HatchedBarComponent

  }

  let context: TestCtx<TestComponent>
  let hatchedBar1: HatchedBarComponent
  let hatchedBar2: HatchedBarComponent
  let canvas1: HTMLCanvasElement
  let canvas2: HTMLCanvasElement

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        MomentModule,
        PortalModule,
        OverlayModule,
      ],
      declarations: [
        HatchedBarComponent,
        TestComponent,
      ],
    })
  });

  beforeEach(fakeAsync(() => {
    context = createTestContext(TestComponent);
    context.detectChanges()
    hatchedBar1 = context.component.hatchedBar1
    hatchedBar2 = context.component.hatchedBar2
    canvas1 = hatchedBar1.canvas.nativeElement
    canvas2 = hatchedBar2.canvas.nativeElement
    jasmine.addMatchers(customMatchers)
  } ));

  afterEach(() => {
    jasmine.clock().uninstall()
  })

  it('should call requestAnimationFrame only once per frame', async () => {
    // 200x30: 50 hashed bars
    const result = await getCanvas('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAAeCAYAAABpP1GsAAACcUlEQVR4Xu1cMW7CMBS11yCVvT1H2Fq4AHvDBCxhC0fIETySJRJbMnMBaKccpOxUIqsrg4xQ4iQ0jhRhPzYLBfs///f/f98mlOADBIBAJQIU2AABIFCNAAgC7wACNQjQg+OElJCAUrp9P5/XxXEURSEhJOCcb1er1Vp33DSf+P7XdYMfz+tkPrHeYZYFb2mqtA/2Yn/r/Jt+OQ6XBPrI89v45LpkejjQKIpu3/u+33o8zDLyGceV84k1iPl34zE/zmaXJenMJ59Plkv+miSX37u3rziGvXp4m7q/SocVziKctAsHFQQT4AknrXNQ6bBdEVISpCoA3BME9l5DZNv9Nnl/SwRBBNfLmMhYZlUkJYIggusRBBmrTJBnztDQHNBYrTSmqZqjmCAuBHlmhhcNQgQ3K4L3vb/oGmlmEGgOszRHKYNAc0BzyDb/I10s2zJ063ONYlvQlppUBhTYqz5XMq0L2glBTO6DqzIs7L3mHNW5lmkViTZBUIObXYPbvr/aBLGtJoW9dnXJWhMENbgdNXhTQDBNcxTtbUUQ1OD21OBNBDFNc2gTxPaaFLefryWWLbef/51BmiIKTub1zlVw+1nd9OjrtvfDBIHmgOaw8f86DxEEmgOao68I3ndF0kgQaA6cc9ikOaSEkBqrkSDQHHb1/VX7bfNt70qCQHNAc9ioOYrnOkqCQHNAc9iqOUrX3TebDaOUzgkhzPf9MFks2GuazjkhbJzn4fdgwDjnpfFpNGLT/T4sPt92/JJlzIvjyvnkenaTCTt63m29beeDvdjfe/+u8me8OA6vTQMCdS+OAzpAAAhUI4AMAu8AAjUI/AEIppRaJka14wAAAABJRU5ErkJggg==')
    fakeAsync(() => {
      jasmine.clock().install()
      jasmine.clock().mockDate( moment('2000-07-15', 'YYYY-MM-DD').toDate() )

      const requestAnimationFrameSpy = spyOn(window, 'requestAnimationFrame').and.callThrough()

      hatchedBar1.metas = []
      hatchedBar1.populatedMeta = {
        availability: true,
        performance: true,
        risk: true,
        userXp: true,
      }
      hatchedBar2.metas = []
      hatchedBar2.populatedMeta = {
        availability: true,
        performance: true,
        risk: true,
        userXp: true,
      }

      hatchedBar1.ngOnChanges()
      hatchedBar2.ngOnChanges()
      expect(requestAnimationFrameSpy).toHaveBeenCalledTimes(1)
      jasmine.clock().tick(16)
      expect(requestAnimationFrameSpy).toHaveBeenCalledTimes(2)
      jasmine.clock().tick(16)

      ;(expect(canvas1) as any).toBeCanvasEqual(result)
      ;(expect(canvas2) as any).toBeCanvasEqual(result)
    })()
  })


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
})
