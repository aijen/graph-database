import { ConnectedPosition, FlexibleConnectedPositionStrategy, Overlay, OverlayRef } from '@angular/cdk/overlay';
import { CdkPortal } from '@angular/cdk/portal';
import { Component, ElementRef, Input, NgZone, OnChanges, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MetasCheck } from 'core/models/leaves/leaves.model';
import { META_TYPE } from 'core/store/notifications/notifications.model';
import { SubscriptionAwareComponent } from 'core/utils/subscription-aware.component';
import moment from 'moment';
import { fromEvent } from 'rxjs';
import { tap } from 'rxjs/operators';
import { BarInfo } from 'shared/models/hatched-bar.model';
import { Meta, MetaState } from 'shared/models/meta.model';
import { HatchedBarService } from './hatched-bar.service';

// hash image setup
// var canvas = document.createElement('canvas')
// document.body.append(canvas)
// var ctx = canvas.getContext('2d')
// canvas.width = 60
// canvas.height = 30
// ctx.fillStyle = 'hsl(0, 0%, 60%)'
// ctx.fillRect(0, 0, 30, 30)
// ctx.fillStyle = 'hsl(0, 90%, 40%)'
// ctx.beginPath()
// ctx.moveTo(0, 30)
// ctx.lineTo(30, 0)
// ctx.lineTo(30, 10)
// ctx.lineTo(10, 30)
// ctx.closePath()
// ctx.moveTo(0, 0)
// ctx.lineTo(0, 10)
// ctx.lineTo(10, 0)
// ctx.closePath()
// ctx.fill()
// ctx.drawImage(canvas, 0, 0, 30, 30, 30, 0, 30, 30)
// canvas.toDataURL()


@Component({
  selector: 'pit-hatched-bar',
  templateUrl: './hatched-bar.component.html',
  styleUrls: ['./hatched-bar.component.scss']
})
export class HatchedBarComponent extends SubscriptionAwareComponent implements OnInit, OnChanges, OnDestroy {

  private static batch = new Map<HatchedBarComponent, () => void>()
  private static raf: number

  private static hash: HTMLImageElement
  private static hash$ = new Promise((res, rej) => {
    const hash = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAAeCAYAAABwmH1PAAAA3UlEQVRYR+XYsQmAMBAF0KS1sXcPa/ewdKtskN4N7FzE3gkiCSKIxjuNIveTNgfHgwv5nB6KwinizHWtpralytj35Tiqylqy/ou+mgJ/0fQvrO97CUbD+pGKghGxUTAq9hSMjD2A0bE7cA7YDZwLNoD7pnEooYLzv2tjDJm0yEi0FvyZoDhYP8mvgSVg/SS/ApaCDW84daQlYZPB0rBJYInYx2Cp2EdgydjbYOnYW2AELBuMgmWBkbAkGA17CUbERsGo2FMwMvYARsfuwDlgN3Au2AC2Xee46xGE3dcCL7qsRIix6dIAAAAASUVORK5CYII='
    const img = document.createElement('img')
    img.addEventListener('load', () => {HatchedBarComponent.hash = img; res(img)} )
    img.addEventListener('error', rej )
    img.src = hash
  })

  private static queueDraw(component: HatchedBarComponent, cb: () => void) {
    if(!this.raf) this.raf = requestAnimationFrame(() => this.executeDraw() )
    this.batch.set( component, cb )
  }
  private static unqueueDraw(component: HatchedBarComponent) {
    this.batch.delete(component)
  }
  private static executeDraw() {
    const batch = [...this.batch]
    this.raf = 0
    this.batch.clear()
    batch.forEach( ([comp, cb]) => cb() )
  }

  @Input() public metaType: META_TYPE | 'all' = 'all';
  private _showTime = false
  @Input() public set showTime( showTime: boolean ) {
    this._showTime = showTime
    this.updateHeightDimension()
  };
  @Input() public metas: Meta[];
  @Input() public endDate: moment.Moment
  private _endDate: moment.Moment
  @Input() public populatedMeta: MetasCheck

  @ViewChild('wrapper') wrapper: ElementRef<HTMLDivElement>
  @ViewChild('canvas') canvas: ElementRef<HTMLCanvasElement>
  private context: CanvasRenderingContext2D

  private mapMetaTypesToLabel = {
    AVAILABILITY: 'Disponibilité',
    PERFORMANCE: 'Performance',
    USER_XP: 'Ressenti',
    RISK:  'Risques',
    all: 'Indicateurs'
  };
  public label = 'Indicateurs';
  public tooltipBarInfo: BarInfo

  @ViewChild(CdkPortal) tooltipPortal: CdkPortal
  private overlayRef: OverlayRef
  private positionConfig: ConnectedPosition = {
    offsetX: 0,
    offsetY: -3,
    originX: 'start',
    originY: 'top',
    overlayX: 'center',
    overlayY: 'bottom',
    panelClass: '',
    weight: 0,
  }

  MetaState = MetaState

  private scrollWidth = 0
  private barsInfo: BarInfo[] = []

  constructor(
    private zone: NgZone,
    private hatchedBarService: HatchedBarService,
    private overlay: Overlay,
  ) {
    super()
  }

  ngOnInit() {
    this.context = this.canvas.nativeElement.getContext('2d')
    this.label = this.mapMetaTypesToLabel[this.metaType];
    this.zone.runOutsideAngular(() => {
      this.subscription.add(
        fromEvent(window, 'resize').pipe(
          tap(() => this.draw({ lazy: true }))
        ).subscribe()
      )
    })
  }

  ngOnDestroy() {
    super.ngOnDestroy()
    HatchedBarComponent.unqueueDraw(this)
    if(this.overlayRef) this.overlayRef.dispose();
  }

  ngOnChanges() {
    this._endDate = this.endDate || this.hatchedBarService.getDefaultEndDate()
    this.zone.runOutsideAngular(() => {
      HatchedBarComponent.queueDraw(this, () => this.draw())
    })
  }

  mousemove($event: MouseEvent) {
    const { offsetX } = $event
    this.zone.runOutsideAngular(() => {
      this.draw({ pointer: { offsetX } })
    })

    const [barinfo] = this.getBarInfo( Math.floor(( this.scrollWidth - 1 - offsetX ) / 4) )
    this.tooltipBarInfo = barinfo

    const positionStrategy = this.overlayRef.getConfig().positionStrategy as FlexibleConnectedPositionStrategy
    positionStrategy.withPositions([{ ...this.positionConfig, offsetX }])
    this.overlayRef.updatePosition()
  }
  mouseenter($event: MouseEvent) {
    if(!this.overlayRef) {
      const positionStrategy = this.overlay.position().flexibleConnectedTo(this.canvas).withPositions([this.positionConfig]).withFlexibleDimensions(false)
      this.overlayRef = this.overlay.create({ positionStrategy })
    }

    this.tooltipPortal.attach(this.overlayRef)
    this.mousemove( $event )
  }
  mouseleave() {
    this.tooltipPortal.detach()
    this.zone.runOutsideAngular(() => {
      this.draw()
    })
  }

  getBarInfo( offset: number, length = this.barsInfo.length): [BarInfo, number] {
    const index = length - offset - 1
    const barinfo = this.barsInfo[ index ]
    return [barinfo, index]
  }

  updateWidthDimension( offsetWidth: number ) {
    const canvas = this.canvas.nativeElement
    if( this.scrollWidth !== offsetWidth ) {
      this.scrollWidth = canvas.width = offsetWidth
      return true
    }
    return false
  }

  updateHeightDimension() {
    const canvas = this.canvas.nativeElement
    const { height } = canvas
    const { _showTime } = this

    if( _showTime && height !== 40 ) {
      canvas.height = 40
    }
    else if( !_showTime && height !== 30 ) {
      canvas.height = 30
    }
  }

  draw( options: { pointer?: { offsetX: number }, lazy?: boolean } = { lazy: false } ) {
    if(!this.context) return

    const { offsetWidth } = this.wrapper.nativeElement

    const barWidth = 3
    const boxWidth = barWidth + 1
    const barCount = Math.ceil(offsetWidth / boxWidth)

    this.barsInfo = this.hatchedBarService.initHatchedBar(this.metas, this.metaType, barCount, { endDate: this._endDate, populatedMeta: this.populatedMeta })

    HatchedBarComponent.queueDraw(this, () => {
      // updating canvas width and clearing context
      const ctx = this.context
      if( !this.updateWidthDimension( offsetWidth ) ) {
        if( options.lazy ) return
        ctx.clearRect(0, 0, this.scrollWidth, 40)
      }
      const totalWidth = this.scrollWidth

      const length = this.barsInfo.length
      let fillStyle = ctx.fillStyle = 'grey'
      const setFillStyle = color => { if(color !== fillStyle) fillStyle = ctx.fillStyle = color }
      const indexPointer = options.pointer ? length - Math.floor(( totalWidth - 1 - options.pointer.offsetX ) / 4) - 1 : 0

      const w = barWidth               // width
      const w2 = w/2                   // demi-width
      const t = this._showTime ? 11 : 1 // top margin
      const f = w2 - Math.floor(w2)    // fractional part of width / 2
      const bars = {
        red:      [] as { x: number, y: number, h: number}[],
        orange:   [] as { x: number, y: number, h: number}[],
        green:    [] as { x: number, y: number, h: number}[],
        purple:   [] as { x: number, y: number, h: number}[],
        grey:     [] as { x: number, y: number, h: number}[],
        darkgrey: [] as { x: number, y: number, h: number}[],
      }

      for(let width = 0; width < totalWidth; width += boxWidth) {
        const [barinfo, index] = this.getBarInfo( width / boxWidth, length )
        const x = totalWidth - width - boxWidth
        const y = options.pointer ? Math.min(3, Math.abs(index - indexPointer)) : 3
        const h = 28 - 2*y

        switch(barinfo.state) {
          case MetaState.KO: {
            bars.red.push({x,y,h})
            break;
          }
          case MetaState.NOK: {
            bars.orange.push({x,y,h})
            break;
          }
          case MetaState.OK: {
            bars.green.push({x,y,h})
            break;
          }
          case MetaState.STARVE: {
            bars.purple.push({x,y,h})
            break;
          }
          case MetaState.DISABLED: {
            bars.darkgrey.push({x,y,h})
            break;
          }
          default: {
            bars.grey.push({x,y,h})
            break;
          }
        }
      }

      const drawBar = ( {x,y,h}: { x: number, y: number, h: number} ) => {
        ctx.moveTo(x+w2, y+t)
        ctx.arc(x+w2, y+t+f,   w2, 0, 2 * Math.PI);
        ctx.arc(x+w2, y+t+h-f, w2, 0, 2 * Math.PI);
        ctx.rect(x, y+t, w, h)
      }


      if(bars.purple.length) {
        ctx.beginPath();
        setFillStyle('rgb(126, 126, 58)')
        for(const purple of bars.purple) drawBar(purple)
        ctx.fill();

        const hash = HatchedBarComponent.hash
        if(hash) {
          ctx.save()
          ctx.globalCompositeOperation = 'source-atop'
          const hw = hash.width / 2
          const hh = hash.height
          for(const purple of bars.purple) {
            const {x,y,h} = purple
            ctx.drawImage(hash, x%hw, 0, w, hh, x, t, w, hh)
          }
          ctx.restore()
        }
      }
      if(bars.red.length) {
        ctx.beginPath();
        setFillStyle('red')
        for(const red of bars.red) drawBar(red)
        ctx.fill();
      }
      if(bars.orange.length) {
        ctx.beginPath();
        setFillStyle('orange')
        for(const orange of bars.orange) drawBar(orange)
        ctx.fill();
      }
      if(bars.green.length) {
        ctx.beginPath();
        setFillStyle('rgb(0,203,157)')
        for(const green of bars.green) drawBar(green)
        ctx.fill();
      }
      if(bars.grey.length) {
        ctx.beginPath();
        setFillStyle('grey')
        for(const grey of bars.grey) drawBar(grey)
        ctx.fill();
      }
      if(bars.darkgrey.length) {
        ctx.beginPath();
        setFillStyle('rgb(87,87,87)')
        for(const darkgrey of bars.darkgrey) drawBar(darkgrey)
        ctx.fill();
      }

      if( this._showTime ) {
        ctx.strokeStyle = 'white'
        ctx.fillStyle = 'white'
        ctx.textAlign = 'center'
        ctx.font = `10px 'Open Sans', sans-serif`
        ctx.beginPath();
        const lw = 1
        const lw2 = lw / 2
        ctx.lineWidth = lw
        const flw = lw2 - Math.floor(lw2)    // fractional part of lineWidth / 2
        const tw = boxWidth * 29
        for(let width = 0; width < totalWidth; width += boxWidth) {
          const [barinfo] = this.getBarInfo( width / boxWidth, length )
          const x = totalWidth - width - boxWidth
          const y = 2
          const is30th = !(Math.floor(barinfo.end / 60) % 30)

          if(is30th) {
            const time = moment(barinfo.end * 1000).format('HH:mm')
            const timelength = ctx.measureText(time).width / 2
            const xline = x+barWidth+flw
            let xtext = xline
            if(xtext+timelength > totalWidth) xtext -= xtext+timelength - totalWidth
            if(xtext-timelength < 0)          xtext -= xtext-timelength

            ctx.fillText(time, xtext, y+5)
            ctx.moveTo(xline, t+y-1)
            ctx.lineTo(xline, t-y-1)
            width += tw
          }
        }
        ctx.stroke()
      }
    })
  }

}
