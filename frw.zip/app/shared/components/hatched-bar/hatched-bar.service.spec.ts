import { TestBed } from '@angular/core/testing';
import { META_TYPE } from 'core/store/notifications/notifications.model';
import moment from 'moment';
import { configureTestSuite } from 'ng-bullet';
import { BarInfo } from 'shared/models/hatched-bar.model';
import { Meta, MetaState } from 'shared/models/meta.model';
import { HatchedBarService } from './hatched-bar.service';

describe('HatchedBarService', () => {
  let service: HatchedBarService;

  const DATE_FORMAT = 'YYYY-MM-DD HH:mm:ss.SSS'
  function dateFormat( date: string ) {
    return moment( date, DATE_FORMAT )
  }

  const createMeta = ( meta?: Partial<Meta> ): Meta => Object.assign<Meta, Partial<Meta>>(new Meta, {
    metaType: 'metaType',
    value:    1,
    date:     2,
    state:    MetaState.NO,
    source:   [],
    weight:   3,
    timeBox:  {
      startDate:  4,
      endDate:    5,
      resolution: 6,
    },
    ...meta,
  })

  function constructMetas( marbles: string, time: moment.Moment, metaType: META_TYPE ) {
    const KO = metaType === META_TYPE.RISK ? MetaState.NOK : MetaState.KO;
    marbles = marbles.replace( /(\d+)(.)/g, (_, times, type) => Array(Number(times)).fill(type).join('') );
    marbles = marbles.replace( /\s+/g, '' );
    // time.subtract(HatchedBarService.TIME_TO_AVOID_GREY_BARS, 'seconds');
    time.subtract(marbles.length, 'minutes');
    return marbles.split('').map( marble => {
      const dateInfos = { timeBox: { startDate: time.unix(), endDate: time.add(1, 'minute').unix(), resolution: 1 }, date: time.valueOf() };
      switch(marble) {
        case 'r': return createMeta({ metaType, state: KO,           ...dateInfos });
        case 'g': return createMeta({ metaType, state: MetaState.OK, ...dateInfos });
      }
    } ).filter( meta => Boolean(meta) );
  }

  function constructAllMetas( marbles: {
    [META_TYPE.AVAILABILITY] ?: string,
    [META_TYPE.PERFORMANCE]  ?: string,
    [META_TYPE.RISK]         ?: string,
    [META_TYPE.USER_XP]      ?: string,
  }, time: moment.Moment) {
    return [
      ...constructMetas( marbles[META_TYPE.AVAILABILITY] || '', time.clone(), META_TYPE.AVAILABILITY ),
      ...constructMetas( marbles[META_TYPE.PERFORMANCE]  || '', time.clone(), META_TYPE.PERFORMANCE  ),
      ...constructMetas( marbles[META_TYPE.RISK]         || '', time.clone(), META_TYPE.RISK         ),
      ...constructMetas( marbles[META_TYPE.USER_XP]      || '', time.clone(), META_TYPE.USER_XP      ),
    ].sort(sortMetas)
  }

  // at this point the meta should be sorted by date descending
  function sortMetas( metaA: Meta, metaB: Meta ) {
    return metaB.date - metaA.date
  }

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [
        HatchedBarService,
      ],
    })
  });

  beforeEach(() => {
    jasmine.clock().install();
    jasmine.clock().mockDate(dateFormat('2000-07-15').toDate());
    service = TestBed.get(HatchedBarService);
  } );

  afterEach(() => {
    jasmine.clock().uninstall();
  });

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  describe('#initHatchedBar', () => {

    it('should return an empty array for `barCount` less than or equal to 0', () => {
      const endDate = dateFormat('2000-07-15 00:00:00');

      expect(service.initHatchedBar([], 'all', 0, { endDate })).toEqual([]);
      expect(service.initHatchedBar([], 'all', -1, { endDate })).toEqual([]);
    });

    it('should return an array of `BarInfo` with `barCount` items', () => {
      const endDate = dateFormat('2000-07-15 00:00:00');
      const result = service.initHatchedBar([], 'all', 5, { endDate, populatedMeta: {
        availability: true,
        performance: true,
        risk: true,
        userXp: true,
      } });

      expect(result).toEqual([
        new BarInfo( dateFormat('2000-07-14 23:55:00').unix(), dateFormat('2000-07-14 23:56:00').unix(), MetaState.STARVE, 0 ),
        new BarInfo( dateFormat('2000-07-14 23:56:00').unix(), dateFormat('2000-07-14 23:57:00').unix(), MetaState.STARVE, 0 ),
        new BarInfo( dateFormat('2000-07-14 23:57:00').unix(), dateFormat('2000-07-14 23:58:00').unix(), MetaState.STARVE, 0 ),
        new BarInfo( dateFormat('2000-07-14 23:58:00').unix(), dateFormat('2000-07-14 23:59:00').unix(), MetaState.STARVE, 0 ),
        new BarInfo( dateFormat('2000-07-14 23:59:00').unix(), dateFormat('2000-07-15 00:00:00').unix(), MetaState.STARVE, 0 ),
      ]);
    });

    it('should fill each `BarInfo` with data from the `metas` provided if the meta is of type `metatype` and start and end within the `BarInfo` range', () => {
      const endDate = dateFormat('2000-07-15 00:00:00');
      const meta = createMeta({ metaType: META_TYPE.AVAILABILITY, state: MetaState.OK, date: dateFormat('2000-07-15 00:00:00').valueOf(), timeBox: { startDate: dateFormat('2000-07-14 23:59:00').unix(), endDate: dateFormat('2000-07-15 00:00:00').unix(), resolution: 1 } });
      const result = service.initHatchedBar(constructAllMetas({
        AVAILABILITY: 'g',
        PERFORMANCE:  'g'
      }, endDate), META_TYPE.AVAILABILITY, 2, { endDate, populatedMeta: {
        availability: true,
        performance: true,
        risk: true,
        userXp: true,
      } });

      expect(result).toEqual([
        new BarInfo( dateFormat('2000-07-14 23:58:00').unix(), dateFormat('2000-07-14 23:59:00').unix(), MetaState.STARVE, 0 ),
        new BarInfo( dateFormat('2000-07-14 23:59:00').unix(), dateFormat('2000-07-15 00:00:00').unix(), MetaState.OK, 1, createMeta(meta) ),
      ]);
    });

    it('should fill each `BarInfo` with data from the `metas` provided when `metatype` === "all", if metas are colliding, the one with highest precedence is used ( KO > NOK > OK > STARVE > NO > DISABLED )', () => {
      const startDate = dateFormat('2000-07-14 23:59:00').unix();
      const endDate   = dateFormat('2000-07-15 00:00:00').unix();
      const metaT0 = createMeta({ state: MetaState.OK, date: dateFormat('2000-07-15 00:00:00').valueOf(), timeBox: { startDate, endDate, resolution: 1 } });

      // NO > DISABLED
      expect(service.initHatchedBar(
      constructAllMetas({
        AVAILABILITY: 'g-',
        PERFORMANCE : 'g-',
        RISK        : '--',
        USER_XP     : '--',
      }, moment.unix(endDate)), 'all', 1, { endDate: moment.unix(endDate), populatedMeta: {
        availability: true,
        performance: true,
        risk: false,
        userXp: false,
      } })).toEqual([
        new BarInfo( startDate, endDate, MetaState.NO, 0 )
      ]);

      // STARVE > NO
      expect(service.initHatchedBar(
      constructAllMetas({
        AVAILABILITY: '  g -',
        PERFORMANCE : '35- -',
        RISK        : '35- -',
        USER_XP     : '35- -',
      }, moment.unix(endDate)), 'all', 1, { endDate: moment.unix(endDate), populatedMeta: {
        availability: true,
        performance: true,
        risk: true,
        userXp: true,
      } })).toEqual([
        new BarInfo( startDate, endDate, MetaState.STARVE, 0 )
      ]);

      // OK > STARVE
      expect(service.initHatchedBar(
      constructAllMetas({
        AVAILABILITY: '  g',
        PERFORMANCE : '36-',
        RISK        : '36-',
        USER_XP     : '36-',
      }, moment.unix(endDate)), 'all', 1, { endDate: moment.unix(endDate), populatedMeta: {
        availability: true,
        performance: true,
        risk: true,
        userXp: true,
      } })).toEqual([
        new BarInfo( startDate, endDate, MetaState.OK, 1, createMeta({ ...metaT0, state: MetaState.OK, metaType: META_TYPE.AVAILABILITY }) )
      ]);

      // NOK > OK
      expect(service.initHatchedBar(
      constructAllMetas({
        AVAILABILITY: 'g',
        RISK:         'r',
      }, moment.unix(endDate)), 'all', 1, { endDate: moment.unix(endDate), populatedMeta: {
        availability: true,
        performance: true,
        risk: true,
        userXp: true,
      } })).toEqual([
        new BarInfo( startDate, endDate, MetaState.NOK, 1, createMeta({ ...metaT0, state: MetaState.NOK, metaType: META_TYPE.RISK }) ),
      ]);

      // KO > NOK
      expect(service.initHatchedBar(
      constructAllMetas({
        PERFORMANCE:  'r',
        RISK:         'r',
      }, moment.unix(endDate)), 'all', 1, { endDate: moment.unix(endDate), populatedMeta: {
        availability: true,
        performance: true,
        risk: true,
        userXp: true,
      } })).toEqual([
        new BarInfo( startDate, endDate, MetaState.KO, 1, createMeta({ ...metaT0, state: MetaState.KO, metaType: META_TYPE.PERFORMANCE }) ),
      ]);
    });

  });

  describe('cache optimization', () => {

    it('should only compute a range of barsInfo once for the same metas array input', () => {
      // hence, references to the objects in the returned array should be EQUAL across multiple calls
      const endDate = dateFormat('2000-07-15 00:00:00');
      const metas = []
      const populatedMeta = {
        availability: true,
        performance: true,
        risk: true,
        userXp: true,
      }

      const result  = service.initHatchedBar(metas, 'all', 20, { endDate, populatedMeta })
      const result2 = service.initHatchedBar(metas, 'all', 20, { endDate, populatedMeta })
      for(let index = 0; index < 20; index++) {
        expect( result[index] ).toBe( result2[index] )
      }
    })

    it('should only compute the difference (for the same metas) if the range change between calls', () => {
      const meta1 = createMeta({ metaType: META_TYPE.AVAILABILITY, timeBox: { startDate: dateFormat('2000-07-14 23:57:00').unix(), endDate: dateFormat('2000-07-14 23:58:00').unix(), resolution: 1 } })
      const meta2 = createMeta({ metaType: META_TYPE.AVAILABILITY, timeBox: { startDate: dateFormat('2000-07-14 23:58:00').unix(), endDate: dateFormat('2000-07-14 23:59:00').unix(), resolution: 1 } })
      const meta3 = createMeta({ metaType: META_TYPE.AVAILABILITY, timeBox: { startDate: dateFormat('2000-07-14 23:59:00').unix(), endDate: dateFormat('2000-07-15 00:00:00').unix(), resolution: 1 } })
      const spyMetaState1 = jasmine.createSpy('meta1.state').and.returnValue('OK')
      const spyMetaState2 = jasmine.createSpy('meta2.state').and.returnValue('OK')
      const spyMetaState3 = jasmine.createSpy('meta3.state').and.returnValue('OK')
      Object.defineProperty(meta1, 'state', { get: spyMetaState1 })
      Object.defineProperty(meta2, 'state', { get: spyMetaState2 })
      Object.defineProperty(meta3, 'state', { get: spyMetaState3 })
      const metas = [
        meta3,
        meta2,
        meta1,
      ]
      const populatedMeta = {
        availability: true,
        performance: true,
        risk: true,
        userXp: true,
      }

      service.initHatchedBar(metas, 'all', 1, { endDate: dateFormat('2000-07-14 23:59:00'), populatedMeta })

      expect(spyMetaState1).not.toHaveBeenCalled()
      expect(spyMetaState2).toHaveBeenCalled()
      expect(spyMetaState3).not.toHaveBeenCalled()

      spyMetaState1.calls.reset()
      spyMetaState2.calls.reset()
      spyMetaState3.calls.reset()

      service.initHatchedBar(metas, 'all', 2, { endDate: dateFormat('2000-07-14 23:59:00'), populatedMeta })

      expect(spyMetaState1).toHaveBeenCalled()
      expect(spyMetaState2).not.toHaveBeenCalled()
      expect(spyMetaState3).not.toHaveBeenCalled()

      spyMetaState1.calls.reset()
      spyMetaState2.calls.reset()
      spyMetaState3.calls.reset()

      service.initHatchedBar(metas, 'all', 3, { endDate: dateFormat('2000-07-15 00:00:00'), populatedMeta })

      expect(spyMetaState1).not.toHaveBeenCalled()
      expect(spyMetaState2).not.toHaveBeenCalled()
      expect(spyMetaState3).toHaveBeenCalled()

    })

  })


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
