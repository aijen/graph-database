export enum Hierarchy {
  Tree = 'tree',
  Node = 'node',
  Leaf = 'leaf'
}

export const GREEN_LINE = {
  backgroundColor: 'transparent',
  borderColor: 'rgba(50, 160, 50, 1)',
  pointBackgroundColor: 'rgba(50, 160, 50, 1)',
  pointBorderColor: 'rgba(50, 160, 50, 1)',
  pointHoverBackgroundColor: 'rgba(50, 160, 50, 1)',
  pointHoverBorderColor: 'rgba(50, 160, 50, 1)',
  borderDash: [3, 3],
  pointRadius: 2,
  borderWidth: 2,
};

export const RED = {
  backgroundColor: 'transparent',
  borderColor: 'rgba(199, 85, 85, 1)',
  pointBackgroundColor: 'rgba(199, 85, 85, 1)',
  pointBorderColor: 'rgba(199, 85, 85, 1)',
  pointHoverBackgroundColor: 'rgba(199, 85, 85, 1)',
  pointHoverBorderColor: 'rgba(199, 85, 85, 1)',
  borderDash: [10, 10],
  pointRadius: 2,
  borderWidth: 2,
};

export const BLUE = {
  backgroundColor: 'transparent',
  borderColor: '#5cbcff',
  pointBackgroundColor: '#5cbcff',
  pointBorderColor: '#5cbcff',
  pointHoverBackgroundColor: '#5cbcff',
  pointHoverBorderColor: '#5cbcff',
  borderWidth: 2,
  pointRadius: 2
};

export const USER_XP = 'USER_XP';

export const SCROLL_INTERVAL = 10000;
export const SCROLL_DURATION = 1000;

export const SNACKBAR_DURATION = 2500;

export const SNACKBAR_ERROR_DURATION = 60000;

export const LOW_IMPORTANCE = 10;
export const MEDIUM_IMPORTANCE = 100;
export const HIGH_IMPORTANCE = 1000;

export const MAX_TREE_DEPTH = 5;
