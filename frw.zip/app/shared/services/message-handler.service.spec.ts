import { async, TestBed } from '@angular/core/testing';
import { MatSnackBarConfig, MatSnackBarModule } from '@angular/material/snack-bar';
import { configureTestSuite } from 'ng-bullet';
import { SNACKBAR_ERROR_DURATION } from 'shared/constants/constants';
import { MessageHandler } from './messageHandler.service';

const generateMessage = (message: Partial<{ message: string, action: string, config: MatSnackBarConfig, weight: number, isError: boolean, id: string }>) => {
  return {
    message: 'message',
    action: 'OK',
    config: new MatSnackBarConfig(),
    weight: 1,
    isError: false,
    id: 'id',
    ...message,
  }
}

describe('MessageHandler', () => {
  let service: MessageHandler;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        MatSnackBarModule,
      ],
      providers: [
        MessageHandler,
      ],
    })
  });

  beforeEach(() => {
    service = TestBed.get(MessageHandler);
  });

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  describe('show', () => {

    it('should display a message box', async(async () => {
      const open = spyOn((service as any).snackbar, 'open');

      service.show(generateMessage({}));

      expect(open).toHaveBeenCalled();
    }));

  });

  describe('getWeight', () => {

    it('should return a weight', () => {
      expect((service as any).getWeight(generateMessage({}))).toEqual(10);
      expect((service as any).getWeight(generateMessage({ weight: undefined }))).toEqual(10);
      expect((service as any).getWeight(generateMessage({ isError: true }))).toEqual(100);
    });

  });

  describe('getConfig', () => {

    it('should return the config', () => {
      const normalMessage = generateMessage({});
      const errorMessage = generateMessage({ isError: true });

      expect((service as any).getConfig(normalMessage)).toEqual(normalMessage.config);
      expect((service as any).getConfig(errorMessage)).toEqual({ duration: SNACKBAR_ERROR_DURATION, panelClass: 'badge-danger', ...errorMessage.config });
    });

  });

  describe('getHeavier', () => {

    it('should return the most priority message', () => {
      const message1 = generateMessage({weight: 150});
      const message2 = generateMessage({weight: 300});
      const message3 = generateMessage({weight: 450});

      expect((service as any).getHeavier(undefined, message1)).toEqual(message1);
      expect((service as any).getHeavier(message1, message2)).toEqual(message2);
      expect((service as any).getHeavier(message3, message2)).toEqual(message3);
    });

  });

  describe('ngOnDestroy', () => {

    it('should unsubscribe', () => {
      const unsubscribe = spyOn((service as any).sub, 'unsubscribe');

      service.ngOnDestroy();

      expect(unsubscribe).toHaveBeenCalled();
    });

  })

  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for (const style of styles) head.removeChild(style);
  }
  afterAll(cleanStylesFromDom);
});
