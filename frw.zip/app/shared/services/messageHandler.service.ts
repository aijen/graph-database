import { Injectable, OnDestroy } from '@angular/core';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material/snack-bar';
import { Subject } from 'rxjs';
import { distinctUntilChanged, map, mapTo, scan, startWith, switchMap } from 'rxjs/operators';
import { LOW_IMPORTANCE, MEDIUM_IMPORTANCE, SNACKBAR_ERROR_DURATION } from 'shared/constants/constants';

interface MessageBox {
  message: string,
  action?: string,
  config?: MatSnackBarConfig,
  weight?: number,
  isError?: boolean,
  id?: string,
}

@Injectable({
  providedIn: 'root'
})
export class MessageHandler implements OnDestroy {

  private messageBox$ = new Subject<Partial<MessageBox>>();

  private dismiss$ = new Subject<void>();

  private sub = this.dismiss$.pipe(
    startWith(null),
    switchMap( () => this.messageBox$.pipe(
      map( box => ({ ...box, weight: this.getWeight( box )}) ),
      scan( this.getHeavier, { weight: -Infinity } as Partial<MessageBox> ),
      distinctUntilChanged(),
      map( box => ({ ...box, config: this.getConfig(box) }) ),
      switchMap( ({ message, action, config }) => this.snackbar.open( message, action, config ).afterDismissed() ),
      mapTo(null),
    ) )
  ).subscribe(this.dismiss$);

  constructor(
    private snackbar: MatSnackBar,
  ) {}

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  show( box: MessageBox ) {
    this.messageBox$.next( box );
  }

  private getWeight( { weight = 1, isError }: Partial<MessageBox> ) {
    const importance = isError ? MEDIUM_IMPORTANCE : LOW_IMPORTANCE;
    return importance * weight;
  }

  private getConfig( { isError, config }: Partial<MessageBox> ) {
    if(!isError) return config;
    return { duration: SNACKBAR_ERROR_DURATION, panelClass: 'badge-danger', ...config };
  }

  private getHeavier( box1: Partial<MessageBox>, box2: Partial<MessageBox> ) {
    if(box1 === undefined || box1.id !== box2.id) return box2;
    return box1.weight > box2.weight ? box1 : box2;
  }

}
