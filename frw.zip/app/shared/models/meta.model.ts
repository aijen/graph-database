export enum UnitsMetricType {
  NB_REQUEST = 'nombre',
  CODE_RETOUR = 'nombre',
  SUIVI_CONSO = 'nombre',
  NB_ERROR = 'nombre',
  PERCENTILE_RESPONSE_TIME = 'ms',
  AVERAGE_RESPONSE_TIME = 'ms',
  ART = 'ms',
  T01 = 'OK / KO',
  T02 = 'OK / KO'
}

export enum MetaType {
  availability = 'disponibilité',
  performance = 'performance',
  user_xp = 'ressenti',
  risk =  'risque'
}

export enum MetaState {
  OK = 'OK',
  KO = 'KO',
  NOK = 'NOK',
  NO = 'NO',
  STARVE = 'STARVE',
  DISABLED = 'DISABLED',
}

export interface TimeboxDTO {
  startDate: string;
  endDate: string;
  resolution: number;
}

export class Timebox {

  public static fromJSON( data: TimeboxDTO ): Timebox {
    if( !data ) return;
    const timebox = new Timebox();

    timebox.startDate = data.startDate && new Date(data.startDate).valueOf() / 1000;
    timebox.endDate = data.endDate && new Date(data.endDate).valueOf() / 1000;
    timebox.resolution = data.resolution;

    return timebox;
  }

  public static fromJSONCollection( data: TimeboxDTO[] ): Timebox[] {
    if(!Array.isArray(data)) return data;

    return data.map( Timebox.fromJSON );
  }

  startDate: number;
  /** seconds */
  endDate: number;
  resolution: number;

}

export interface MetricDTO {
  metricDate: string;
  metricType: string;
  metricValue: number;
  timeBox: TimeboxDTO;
}

export class Metric {

  public static fromJSON( data: MetricDTO ): Metric {
    if( !data ) return;
    const metric = new Metric();

    metric.metricDate = data.metricDate && new Date(data.metricDate).valueOf();
    metric.metricType = data.metricType;
    metric.metricValue = data.metricValue;
    metric.timeBox = Timebox.fromJSON(data.timeBox);

    return metric;
  }

  public static fromJSONCollection( data: MetricDTO[] ): Metric[] {
    if(!Array.isArray(data)) return [];

    return data.map( Metric.fromJSON );
  }

  metricDate: number;
  metricType: string;
  metricValue: number;
  timeBox: Timebox;

}

export interface MetaDTO {
  metaType: string;
  value: number;
  date: string;
  state: MetaState;
  source: MetricDTO[];
  weight: number;
  timeBox: TimeboxDTO;
}

export class Meta {

  public static fromJSON( data: MetaDTO ): Meta {
    if( !data ) return;
    const meta = new Meta();

    meta.metaType = data.metaType;
    meta.value =    data.value;
    meta.date =     data.date && new Date(data.date).valueOf();
    meta.state =    data.state;
    // meta.Enum =     data.Enum;
    meta.source =   Metric.fromJSONCollection(data.source);
    meta.weight =   data.weight;
    meta.timeBox =  Timebox.fromJSON(data.timeBox);

    return meta;
  }

  public static fromJSONCollection( data: MetaDTO[] ): Meta[] {
    if(!Array.isArray(data)) return [];

    return data.map( Meta.fromJSON ).sort((a, b) => b.date - a.date);
  }

  metaType: string;
  value: number;
  /** milliseconds */
  date: number;
  state: MetaState;
  // Enum: string;
  source: Metric[];
  weight: number;
  timeBox: Timebox;

}
