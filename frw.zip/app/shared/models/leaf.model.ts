import { MetasCheck, metasCheckState } from 'core/models/leaves/leaves.model';
import { Hierarchy } from 'shared/constants/constants';
import { Meta, MetaDTO } from './meta.model';
import { Node } from './node.model';

export interface LeafDTO {
  leafId: string;
  key: string;
  name: string;
  metas: MetaDTO[];
  fullname: string;
  description: string;
  weight: number;
  technicalKey: string
}

export class Leaf {

  public static fromJSON( data: LeafDTO, parent: Node = null, noMeta: boolean = false ): Leaf {
    return new Leaf(
      data.leafId,
      data.key,
      data.name,
      noMeta ? [] : Meta.fromJSONCollection( data.metas ),
      data.fullname,
      data.description,
      data.weight,
      parent,
      data.technicalKey,
      parent && parent.readOnly,
    )
  }

  public static fromJSONCollection( data: LeafDTO[], parent: Node = null, noMeta: boolean = false ): Leaf[] {
    if(!data) return [];

    return data.map( d => Leaf.fromJSON(d, parent, noMeta) );
  }

  public static toJSON( leaf: Leaf ): LeafDTO {
    return {
      leafId:       leaf.leafId || null,
      key:          leaf.key,
      name:         leaf.name,
      metas:        [],
      fullname:     leaf.fullname,
      description:  leaf.description,
      weight:       leaf.weight || null,
      technicalKey: leaf.technicalKey || '',
    }
  }

  public static toJSONCollection( leaves: Leaf[] ): LeafDTO[] {
    return leaves.map( Leaf.toJSON );
  }

  public static trackByKey( index: number, leaf: Leaf ) {
    return leaf ? leaf.key : undefined;
  }

  public static clone( leaf: Leaf, parent: Node = null ): Leaf {
    return Object.assign(new Leaf, {
      ...leaf,
      technicalKey: Node.randomKey(),
      parent,
      readOnly: false,
    });
  }

  public static isLeaf( nodeOrLeaf: Node | Leaf ): nodeOrLeaf is Leaf {
    return nodeOrLeaf.type === Hierarchy.Leaf;
  }

  type: Hierarchy.Leaf = Hierarchy.Leaf;
  lastTimeAvailability: Meta = undefined;
  lastTimePerformance: Meta = undefined;
  lastTimeFeeling: Meta = undefined;
  lastTimeRisk: Meta = undefined;
  firstAvailabilityTimeKO = 0;
  firstPerformanceTimeKO = 0;
  firstFeelingTimeKO = 0;
  firstRiskTimeKO = 0;
  hasAlert = false;

  constructor(
    public leafId: string = null,
    public key: string = '',
    public name: string = '',
    public metas: Meta[] = [],
    public fullname?: string,
    public description?: string,
    public weight?: number,
    public parent: Node = null,
    public technicalKey?: string,
    public readOnly = false,
    public title?: string,
    public isHiddenOnTree: boolean = false,
    public isAllBarGraphKO: MetasCheck = { ...metasCheckState },
  ) {}

}
