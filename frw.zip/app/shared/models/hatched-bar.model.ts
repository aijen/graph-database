import { META_TYPE } from 'core/store/notifications/notifications.model';
import { Meta, MetaState } from './meta.model';

export class BarInfo {

  constructor(
    /* seconds */
    public begin: number,
    /* seconds */
    public end: number,
    public state: MetaState,
    public resolution: number,
    public meta?: Meta,
  ) {}
}

export interface BarInfos {
  [META_TYPE.AVAILABILITY]: BarInfo[],
  [META_TYPE.PERFORMANCE]:  BarInfo[],
  [META_TYPE.RISK]:         BarInfo[],
  [META_TYPE.USER_XP]:      BarInfo[],
  all:                      BarInfo[],
}
export class HatchedBarEvent {
  event: HatchedBarMouseEvent;
  bar: BarInfo;
}

export class HatchedBarMouseEvent extends MouseEvent {
  srcElement: HTMLElement;
}
