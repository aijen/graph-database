import { Hierarchy } from 'shared/constants/constants';
import { Leaf, LeafDTO } from './leaf.model';
import { Meta } from './meta.model';

export interface NodeDTO {
  nodeId: string,
  isLeafWrapper: boolean;
  key: string;
  name: string;
  fullname: string;
  description: string;
  nodes: NodeDTO[];
  leaves: LeafDTO[];
  readOnly: boolean;
  technicalKey: string;
  weight: number;
}

export class Node {

  public static fromJSON( data: NodeDTO, parent: Node = null ): Node {
    const node = new Node();

    node.nodeId           = data.nodeId;
    node.isLeafWrapper    = data.isLeafWrapper;
    node.isNew            = false;
    node.parent           = parent;
    node.name             = data.name;
    node.fullname         = data.fullname;
    node.key              = data.key;
    node.description      = data.description;
    node.weight           = data.weight;
    node.isHiddenOnTree   = false;
    node.technicalKey     = data.technicalKey;
    node.readOnly         = data.readOnly || parent && parent.readOnly;
    node.nodes            = Node.fromJSONCollection( data.nodes, node );
    node.leaves           = Leaf.fromJSONCollection( data.leaves, node, true );

    return node;
  }

  public static fromJSONCollection( data: NodeDTO[], parent: Node = null ): Node[] {
    if(!data) return [];

    return data.map( d => Node.fromJSON(d, parent) );
  }

  public static toJSON( node: Node ): NodeDTO {
    return {
      nodeId:        node.nodeId || null,
      description:   node.description || '',
      fullname:      node.fullname || '',
      isLeafWrapper: node.isLeafWrapper,
      key:           node.key,
      leaves:        Leaf.toJSONCollection(node.leaves),
      name:          node.name || '',
      nodes:         Node.toJSONCollection(node.nodes),
      readOnly:      node.readOnly,
      technicalKey:  node.technicalKey || '',
      weight:        node.weight || null,
    };
  }

  public static toJSONCollection( nodes: Node[] ): NodeDTO[] {
    return nodes.map( Node.toJSON );
  }

  public static trackByKey( index, node ) {
    return node ? node.key : undefined;
  }

  public static randomKey() {
    return (Date.now()+Math.random()).toString(36);
  }

  public static clone( node: Node, parent: Node = null ): Node {
    const key = Node.randomKey();
    node = Object.assign( new Node(), {
      ...node,
      key,
      technicalKey: key,
      parent,
      readOnly: false,
    } );
    node.nodes = node.nodes.map( childNode => Node.clone(childNode, node) );
    node.leaves = node.leaves.map( childLeaf => Leaf.clone(childLeaf, node) );
    return node;
  }

  public static isNode( nodeOrLeaf: Node | Leaf ): nodeOrLeaf is Node {
    return nodeOrLeaf.type === Hierarchy.Node;
  }

  nodeId: string = null;
  name = '';
  fullname = '';
  key = '';
  description = '';
  type: Hierarchy.Node = Hierarchy.Node;
  weight = 0;
  nodes: Node[] = [];
  leaves: Leaf[] = [];
  totalAvailiblity = 0;
  totalPerformance = 0;
  totalRisk = 0;
  totalFeeling = 0;
  okAvailiblity = 0;
  okPerformance = 0;
  okRisk = 0;
  okFeeling = 0;
  nbAlert = 0;
  metas: Meta[] = [];
  parent: Node = null;
  isHiddenOnTree = false;
  technicalKey = '';
  readOnly = false;
  isLeafWrapper = false;
  isNew = true;

  constructor( options: { assignRandomKey?: boolean, isLeafWrapper?: boolean, isNew?: boolean } = {} ) {
    const { assignRandomKey = false, isLeafWrapper = false, isNew = true } = options;

    if( assignRandomKey ) {
      this.key = this.technicalKey = Node.randomKey();
    }
    this.isLeafWrapper = isLeafWrapper;
    this.isNew = isNew;
  }

}
