import { NodeDTO } from 'shared/models/node.model';

export interface HierarchyInterface {
  nodes: NodeDTO[];
}
