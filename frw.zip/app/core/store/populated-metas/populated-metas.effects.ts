import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { tap } from 'rxjs/operators';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { LoadPopulatedMetasError, PopulatedMetasActionTypes } from './populated-metas.actions';

@Injectable()
export class PopulatedMetasEffects {

  public static messages = {
    loadError: `
      Une erreur est survenue pendant le chargement des metas peuplés : certaines fonctionnalités seront desactivées
    `,
  }

  constructor(
    private actions$: Actions,
    private snackbar: MessageHandler,
  ) {}

  @Effect({ dispatch: false })
  loadPopulatedMetasError$ = this.actions$.pipe(
    ofType<LoadPopulatedMetasError>(PopulatedMetasActionTypes.LoadPopulatedMetasError),
    tap( action => { console.error(action.payload.error); this.snackbar.show( { message: PopulatedMetasEffects.messages.loadError, action: 'OK', isError: true, id: action.type } ) } ),
  )

}
