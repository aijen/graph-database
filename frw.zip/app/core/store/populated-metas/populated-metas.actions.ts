import { HttpErrorResponse } from '@angular/common/http';
import { Action } from '@ngrx/store';
import { PopulatedMetasValue } from './populated-metas.model';

export enum PopulatedMetasActionTypes {
  LoadPopulatedMetas = '[CockPit] Load Populated Metas',
  LoadPopulatedMetasSuccess = '[CockPit] Load Populated Metas Success',
  LoadPopulatedMetasError = '[CockPit] Load Populated Metas Error',
}

export class LoadPopulatedMetas implements Action {
  readonly type = PopulatedMetasActionTypes.LoadPopulatedMetas;
  constructor() {}
}

export class LoadPopulatedMetasSuccess implements Action {
  readonly type = PopulatedMetasActionTypes.LoadPopulatedMetasSuccess;
  constructor(public payload: { populatedMetas: PopulatedMetasValue[] }) {}
}

export class LoadPopulatedMetasError implements Action {
  readonly type = PopulatedMetasActionTypes.LoadPopulatedMetasError;
  constructor(public payload: { error: HttpErrorResponse }) {}
}

export type PopulatedMetasActionsUnion =
  | LoadPopulatedMetas
  | LoadPopulatedMetasSuccess
  | LoadPopulatedMetasError
;
