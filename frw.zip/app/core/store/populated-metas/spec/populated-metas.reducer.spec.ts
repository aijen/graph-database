import { HttpErrorResponse } from '@angular/common/http';
import { metasCheckState } from 'core/models/leaves/leaves.model';
import { AppState } from 'shared/models/state.model';
import { LoadPopulatedMetas, LoadPopulatedMetasError, LoadPopulatedMetasSuccess } from '../populated-metas.actions';
import { populatedMetasReducer, populatedMetasState } from '../populated-metas.reducer';

// necessary to avoid the error :
// Invalid module name in augmentation, module 'shared/models/state.model' cannot be found.
let happy_compiler: AppState; // tslint:disable-line

describe('Snooze Reducer', () => {

  describe('undefined action', () => {

    it('should return the default state', () => {
      const action = { type: null, payload: null };
      const state = populatedMetasReducer( undefined, action );

      expect(state).toBe(populatedMetasState);
    });

  });

  describe('LoadPopulatedMetas action', () => {

    it('should be loading but not loaded', () => {
      const action = new LoadPopulatedMetas();
      const state = populatedMetasReducer(populatedMetasState, action);

      expect(state.isLoading).toBe(true);
      expect(state.isLoaded).toBe(false);
    });

  });

  describe('LoadPopulatedMetasSuccess action', () => {

    it('should set config and be loaded but not loading', () => {
      const populatedMetas = [{ leafKey: 'leafKey', metas: metasCheckState }];
      const action = new LoadPopulatedMetasSuccess({ populatedMetas });
      const state = populatedMetasReducer(populatedMetasState, action);

      expect(state.populatedMetas).toEqual(populatedMetas);
      expect(state.isLoaded).toBe(true);
      expect(state.isLoading).toBe(false);
    });

  });

  describe('LoadPopulatedMetasError action', () => {

    it('should not be loading', () => {
      const error = new HttpErrorResponse({});
      const action = new LoadPopulatedMetasError({ error });
      const state = populatedMetasReducer(populatedMetasState, action);

      expect(state.isLoading).toBe(false);
    });

  });

} );
