import { PopulatedMetasActionsUnion, PopulatedMetasActionTypes } from './populated-metas.actions';
import { PopulatedMetasState } from './populated-metas.model';

export const populatedMetasState: PopulatedMetasState = {
  populatedMetas: [],
  isLoading: false,
  isLoaded: false,
};

export function populatedMetasReducer(
  state = populatedMetasState,
  action: PopulatedMetasActionsUnion
): PopulatedMetasState {

  switch( action.type ) {

    case PopulatedMetasActionTypes.LoadPopulatedMetas: {
      return {
        ...state,
        isLoading: true,
      };
    }
    case PopulatedMetasActionTypes.LoadPopulatedMetasSuccess: {
      const { populatedMetas } = action.payload;

      return {
        ...state,
        populatedMetas,
        isLoading: false,
        isLoaded: true,
      };
    }
    case PopulatedMetasActionTypes.LoadPopulatedMetasError: {
      return {
        ...state,
        isLoading: false,
      };
    }

    default: {
      return state;
    }
  }
}
