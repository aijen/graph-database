import { MetasCheck, MetasCheckDTO } from 'core/models/leaves/leaves.model';

declare module 'shared/models/state.model' {
  export interface AppState {
    readonly populatedMetas: PopulatedMetasState;
  }
}
export interface PopulatedMetasValue {
  leafKey: string;
  metas: MetasCheck;
}

export interface PopulatedMetasDTO {
  leafKey: string;
  metas: MetasCheckDTO;
}

export interface PopulatedMetasState {
  populatedMetas: PopulatedMetasValue[];
  isLoading: boolean;
  isLoaded: boolean;
}
