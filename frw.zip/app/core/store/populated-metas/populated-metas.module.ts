import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { PopulatedMetasEffects } from './populated-metas.effects';
import { populatedMetasReducer } from './populated-metas.reducer';

@NgModule({
  declarations: [],
  imports: [
    StoreModule.forFeature('populatedMetas', populatedMetasReducer),
    EffectsModule.forFeature([PopulatedMetasEffects]),
  ]
})
export class PopulatedMetasStoreModule { }
