import { createFeatureSelector, createSelector } from '@ngrx/store';
import { PopulatedMetasState } from './populated-metas.model';

export const populatedMetasStateSelector = createFeatureSelector<PopulatedMetasState>(
  'populatedMetas'
);

export const getPopulatedMetas = createSelector(
  populatedMetasStateSelector,
  state => state.populatedMetas,
);

export const isPopulatedMetasLoading = createSelector(
  populatedMetasStateSelector,
  state => state.isLoading,
);

export const isPopulatedMetasLoaded = createSelector(
  populatedMetasStateSelector,
  state => state.isLoaded,
);

export const getPopulatedMetasForLeaf = ( leafKey: string ) => createSelector(
  getPopulatedMetas,
  populatedMetas => {
    const populatedMeta = populatedMetas.find( _populatedMeta => _populatedMeta.leafKey === leafKey )
    return populatedMeta && populatedMeta.metas
  }
)
