import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { concat, of } from 'rxjs';
import { catchError, map, switchMap, tap } from 'rxjs/operators';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { GroupsActionTypes, LoadGroups, LoadGroupsError, LoadGroupsSuccess } from './groups.actions';
import { GroupsService } from './groups.service';

@Injectable()
export class GroupsEffects {

  public static messages = {
    loadError: `
      Une erreur est survenue pendant le chargement de la configuration 'Groups': Veuillez réessayer
    `,
  }

  constructor(
    private actions$: Actions,
    private groupsService: GroupsService,
    private snackbar: MessageHandler,
  ) { }

  @Effect()
  load$ = this.actions$.pipe(
    ofType<LoadGroups>(GroupsActionTypes.LoadGroups),
    switchMap(() => this.groupsService.load()),
    map(groups => new LoadGroupsSuccess({ groups })),
    catchError((error, caught) => concat(of(new LoadGroupsError({ error })), caught)),
  );

  @Effect({ dispatch: false })
  loadError$ = this.actions$.pipe(
    ofType<LoadGroupsError>(GroupsActionTypes.LoadGroupsError),
    tap(action => { console.error(action.payload.error); this.snackbar.show({ message: GroupsEffects.messages.loadError, action: 'OK', isError: true }) }),
  );

}
