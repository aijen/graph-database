
declare module 'shared/models/state.model' {
  export interface AppState {
    readonly groups: GroupsState;
  }
}

export interface GroupsValue {
  readonly id: string;
  name: string;
  description: string;
  users: string[];
  admins: string[];
  defaultTemplate: string;
}

export interface GroupsValueDTO {
  readonly id: string;
  name: string;
  description: string;
  users?: string[];
  admins?: string[];
  defaultTemplate?: string;
}

export interface GroupsState {
  groups: GroupsValue[];
  isLoading: boolean;
}
