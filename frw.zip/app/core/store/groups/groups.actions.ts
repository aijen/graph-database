import { Action } from '@ngrx/store';
import { GroupsValue } from './groups.model';

export enum GroupsActionTypes {
  LoadGroups = '[Groups] Load',
  LoadGroupsSuccess = '[Groups] LoadSuccess',
  LoadGroupsError = '[Groups] LoadError',
}

export class LoadGroups implements Action {
  readonly type = GroupsActionTypes.LoadGroups;
  constructor() {}
}

export class LoadGroupsSuccess implements Action {
  readonly type = GroupsActionTypes.LoadGroupsSuccess;
  constructor( public payload: { groups: GroupsValue[] } ) {}
}

export class LoadGroupsError implements Action {
  readonly type = GroupsActionTypes.LoadGroupsError;
  constructor( public payload: { error: Error } ) {}
}

export type GroupsActionUnion =
  | LoadGroups
  | LoadGroupsSuccess
  | LoadGroupsError
  ;
