import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LOAD_GROUPS_URL } from 'core/services/http/http-client.service';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { GroupsValue, GroupsValueDTO } from './groups.model';

const fromJson = (groupsDto: GroupsValueDTO[]): GroupsValue[] => {
  return groupsDto.map(groupDto => ({
    ...groupDto,
    users: groupDto.users || [],
    admins: groupDto.admins || [],
    defaultTemplate: groupDto.defaultTemplate || '',
  }));
};

@Injectable({
  providedIn: 'root'
})
export class GroupsService {

  constructor(
    private http: HttpClient,
  ) { }

  load(): Observable<GroupsValue[]> {
    return this.http.get<GroupsValueDTO[]>(LOAD_GROUPS_URL).pipe(map(fromJson));
  }

}
