import { createFeatureSelector, createSelector } from '@ngrx/store';
import { GroupsState } from './groups.model';

export const groupsStateSelector = createFeatureSelector<GroupsState>(
  'groups'
);

export const getGroups = createSelector(
  groupsStateSelector,
  state => state.groups,
);

export const isGroupsLoading = createSelector(
  groupsStateSelector,
  state => state.isLoading,
);
