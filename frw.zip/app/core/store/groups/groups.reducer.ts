import { GroupsActionTypes, GroupsActionUnion } from './groups.actions';
import { GroupsState } from './groups.model';

export const groupsState: GroupsState = {
  groups: [],
  isLoading: false,
};

export function groupsReducer(
  state = groupsState,
  action: GroupsActionUnion
): GroupsState {

  switch( action.type ) {
    case GroupsActionTypes.LoadGroups: {
      return {
        ...state,
        isLoading: true,
      };
    }
    case GroupsActionTypes.LoadGroupsSuccess: {
      const { groups } = action.payload;

      return {
        ...state,
        groups,
        isLoading: false,
      };
    }
    case GroupsActionTypes.LoadGroupsError: {
      return {
        ...state,
        isLoading: false,
      };
    }

    default: {
      return state;
    }
  }
}
