import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { GroupsEffects } from './groups.effects';
import { groupsReducer } from './groups.reducer';

@NgModule({
  declarations: [],
  imports: [
    StoreModule.forFeature('groups', groupsReducer),
    EffectsModule.forFeature([GroupsEffects]),
  ]
})
export class GroupsStoreModule { }
