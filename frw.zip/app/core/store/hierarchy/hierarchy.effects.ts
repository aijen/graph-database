import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { ApiNodesService } from 'core/services/api/api.nodes';
import { HierarchyService } from 'core/services/hierarchy/hierarchy.service';
import { INTERVAL, PULLER_INTERVAL } from 'core/services/http/http-client.service';
import { SnoozeService } from 'core/store/snooze/snooze.service';
import { retryStrategy } from 'core/utils/retryStrategy';
import { combineLatest, of } from 'rxjs';
import { TimerObservable } from 'rxjs/observable/TimerObservable';
import { catchError, concatMap, map, retryWhen, switchMap, tap, withLatestFrom } from 'rxjs/operators';
import { Leaf, LeafDTO } from 'shared/models/leaf.model';
import { Node } from 'shared/models/node.model';
import { AppState } from 'shared/models/state.model';
import { LoadGroups } from '../groups/groups.actions';
import { PopulatedMetasService } from '../populated-metas/populated-metas.service';
import { LoadTemplates } from '../templates/templates.actions';
import { GetHierarchy, GetHierarchyError, GetHierarchySuccess, GetNodes, GetNodesSuccess, HierarchyActionsUnion, HierarchyActionTypes, InitPuller, InitPullerSuccess, PullHierarchy, PullHierarchyrError, Ready, SetIndicatorsPercents, SetTemplate } from './hierarchy.actions';
import { HierarchyState } from './hierarchy.model';
import { getHierarchyState } from './hierarchy.selectors';


@Injectable({providedIn: 'root'})
export class HierarchyEffects {

  hierarchyState$ = this.store$.select(getHierarchyState);

  @Effect()
  GetHierarchy$ = this.actions$.pipe(
    ofType<GetHierarchy>(HierarchyActionTypes.GET_HIERARCHY),
    switchMap(() => this.apiNodesService.getNodes().pipe(retryWhen(retryStrategy()))),
    concatMap(({ nodes }) => ([
      new GetHierarchySuccess({ nodes: Node.fromJSONCollection(nodes) }),
      new LoadTemplates(),
      new LoadGroups(),
    ])),
    catchError((error: Error) =>
      of(new GetHierarchyError({ error }))
    )
  );

  // get leaves and metas, init puller
  @Effect()
  GetHierarchySuccess = this.actions$.pipe(
    ofType<GetHierarchySuccess>(HierarchyActionTypes.GET_HIERARCHY_SUCCESS),
    withLatestFrom(this.hierarchyState$),
    concatMap(([, state]) => ([
      new PullHierarchy({ periodTime: 300, leaves: this.hierarchyService.getLeavesKeys(state.nodes).join(',') }),
      new InitPuller(),
    ])),
  );

  @Effect()
  InitPuller = this.actions$.pipe(
    ofType<InitPuller>(HierarchyActionTypes.INIT_PULLER),
    switchMap(() => {
      return TimerObservable.create(PULLER_INTERVAL, INTERVAL).pipe(
        withLatestFrom(this.hierarchyState$),
        concatMap(([, state]) => {
          const actions: HierarchyActionsUnion[] = [
            new PullHierarchy({ periodTime: 300, leaves: this.hierarchyService.getLeavesKeys(state.nodes).join(',') })
          ];

          if (!state.isPullerLaunched) {
            actions.push(new InitPullerSuccess(true));
          }

          return actions;
        })
      );
    }),
  );



  @Effect()
  PullHierachy = this.actions$.pipe(
    ofType<PullHierarchy>(HierarchyActionTypes.PULL_HIERARCHY),
    map(({ payload: { periodTime, leaves } }) => this.hierarchyService.getLeavesUrl(leaves, periodTime)),
    switchMap(leavesUrl =>
      combineLatest(
        this.httpClient.get<LeafDTO[]>(leavesUrl).pipe(
          retryWhen(retryStrategy()),
          map((leaves) => Leaf.fromJSONCollection(leaves)),
        ),
        this.snoozeService.config$,
        this.populatedMetasService.populatedMetas$,
      )
    ),
    tap(() => this.store$.dispatch(new Ready(true))),
    map(([leaves, config, populatedMetas]) => new GetNodes({ leaves, config, populatedMetas })),
    catchError((error: Error) => {
      console.log(HierarchyActionTypes.PULL_HIERARCHY_ERROR + ': ', error);
      return of(new PullHierarchyrError({ error }));
    })
  );

  // affect leaves and metas to nodes
  @Effect()
  GetNodes = this.actions$.pipe(
    ofType<GetNodes>(HierarchyActionTypes.GET_NODES),
    withLatestFrom(this.hierarchyState$),
    map(([{ payload: { leaves, config, populatedMetas } }, { nodes }]: [GetNodes, HierarchyState]) => ({
      nodes,
      leaves,
      config,
      populatedMetas,
    })),
    concatMap(({ nodes, leaves, config, populatedMetas }) => {
      const nds = this.hierarchyService.populateMetas(nodes, leaves, config, populatedMetas);
      this.hierarchyService.calculateNodesAlerts(nodes, config);
      const percent = this.hierarchyService.calculatePercents(nodes);
      return [
        new GetNodesSuccess(nds),
        new SetIndicatorsPercents(percent),
      ];
    }),
  );

  @Effect()
  setTemplate = this.actions$.pipe(
    ofType<SetTemplate>(HierarchyActionTypes.SetTemplate),
    withLatestFrom(this.hierarchyState$),
    map(([action, { nodes }]) => new PullHierarchy({ periodTime: 300, leaves: this.hierarchyService.getLeavesKeys(nodes).join(',') }),),
  );

  constructor(
    private actions$: Actions,
    private store$: Store<AppState>,
    private httpClient: HttpClient,
    private hierarchyService: HierarchyService,
    private apiNodesService: ApiNodesService,
    private snoozeService: SnoozeService,
    private populatedMetasService: PopulatedMetasService,
  ) {}
}
