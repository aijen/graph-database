import { Node } from 'shared/models/node.model';

declare module 'shared/models/state.model' {
  export interface AppState {
    readonly hierarchy: HierarchyState;
  }
}

export interface IndicatorsPercent {
  availibiltyPercent: number;
  performancePercent: number;
  riskPercent: number;
  feelingPercent: number;
}

export class HierarchyState {
  constructor(
    public nodes: Node[] = [],
    public isPullerLaunched: boolean = false,
    public availibiltyPercent = -1,
    public performancePercent = -1,
    public riskPercent = -1,
    public feelingPercent = -1,
    public progressLoaded = 0,
    public progressTotal = Infinity,
    public ready = false,
    public hierarchyError = null,
    public hiddenNodes: string[] = [],
  ) {}
}
