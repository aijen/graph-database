import { Action } from '@ngrx/store';
import { SnoozeConfig } from 'core/store/snooze/snooze.model';
import { Leaf } from 'shared/models/leaf.model';
import { Node } from 'shared/models/node.model';
import { PopulatedMetasValue } from '../populated-metas/populated-metas.model';
import { Template } from '../templates/templates.model';
import { IndicatorsPercent } from './hierarchy.model';

export enum HierarchyActionTypes {
  GET_HIERARCHY = '[COCKPIT] Get Hierarchy',
  GET_HIERARCHY_SUCCESS = '[COCKPIT] Get Hierarchy Success',
  GET_HIERARCHY_ERROR = '[COCKPIT] Get Hierarchy Error',
  GET_NODES = '[COCKPIT] Get Nodes',
  GET_NODES_SUCCESS = '[COCKPIT] Get Nodes Success',
  INIT_PULLER = '[COCKPIT] Init Puller',
  INIT_PULLER_SUCCESS = '[COCKPIT] Init Puller Success',
  PULL_HIERARCHY = '[COCKPIT] Pull Hierarchy',
  PULL_HIERARCHY_ERROR = '[COCKPIT] Pull Hierarchy Error',
  SET_INDICATORS_PERCENT = '[COCKPIT] Set Indicators Percent',
  LOADING = '[CockPit] Loading',
  READY = '[CockPit] Ready',
  SetTemplate = '[Hierarchy] SetTemplate',
}

export class GetHierarchy implements Action {
  readonly type = HierarchyActionTypes.GET_HIERARCHY;
  constructor() {}
}
export class GetHierarchySuccess implements Action {
  readonly type = HierarchyActionTypes.GET_HIERARCHY_SUCCESS;
  constructor(public payload: { nodes: Node[] }) {}
}

export class GetHierarchyError implements Action {
  readonly type = HierarchyActionTypes.GET_HIERARCHY_ERROR;
  constructor(public payload: { error: Error }) {}
}
export class GetNodes implements Action {
  readonly type = HierarchyActionTypes.GET_NODES;
  constructor(public payload: { leaves: Leaf[], config: SnoozeConfig, populatedMetas: PopulatedMetasValue[] }) {}
}
export class GetNodesSuccess implements Action {
  readonly type = HierarchyActionTypes.GET_NODES_SUCCESS;
  constructor(public payload: Node[]) {}
}

export class InitPuller implements Action {
  readonly type = HierarchyActionTypes.INIT_PULLER;
}
export class InitPullerSuccess implements Action {
  readonly type = HierarchyActionTypes.INIT_PULLER_SUCCESS;
  constructor(public payload: boolean) {}
}

export class SetIndicatorsPercents implements Action {
  readonly type = HierarchyActionTypes.SET_INDICATORS_PERCENT;
  constructor(public payload: IndicatorsPercent) {}
}

export class PullHierarchy implements Action {
  readonly type = HierarchyActionTypes.PULL_HIERARCHY;
  constructor(public payload: {periodTime: number, leaves: string}) {}
}

export class PullHierarchyrError implements Action {
  readonly type = HierarchyActionTypes.PULL_HIERARCHY_ERROR;
  constructor(public payload: { error: Error }) {}
}

export class Loading implements Action {
  readonly type = HierarchyActionTypes.LOADING;
  constructor(public loaded: number, public total: number = Infinity) {}
}

export class Ready implements Action {
  readonly type = HierarchyActionTypes.READY;
  constructor(public payload: boolean) {}
}

export class SetTemplate implements Action {
  readonly type = HierarchyActionTypes.SetTemplate;
  constructor(public payload: { template: Template }) {}
}


export type HierarchyActionsUnion =
  | GetHierarchy
  | GetHierarchySuccess
  | GetHierarchyError
  | GetNodes
  | GetNodesSuccess
  | InitPuller
  | InitPullerSuccess
  | PullHierarchy
  | PullHierarchyrError
  | SetIndicatorsPercents
  | Loading
  | Ready
  | SetTemplate
  ;
