import { createFeatureSelector, createSelector } from '@ngrx/store';
import { Leaf } from 'shared/models/leaf.model';
import { Node } from 'shared/models/node.model';
import { HierarchyState } from './hierarchy.model';

export const getHierarchyState = createFeatureSelector<HierarchyState>(
  'hierarchy'
);

export const getNodes = createSelector(
  getHierarchyState,
  (state: HierarchyState) => state.nodes
);

const getLeavesWithAlert = (rootNodes: Node[]) => {

  const findLeavesWithAlert = (node: Node): Set<Leaf> => {
    const { leaves, nodes } = node;
    let { nbAlert } = node;
    let leavesWithAlert = new Set<Leaf>();

    if( !nbAlert ) return leavesWithAlert;

    for( const leaf of leaves ) {
      if( leaf.hasAlert ) {
        leavesWithAlert.add(leaf);
        nbAlert -= 1;
      }
      if( !nbAlert ) break;
    }

    for( const childNode of nodes ) {
      if( !nbAlert ) break;
      leavesWithAlert = new Set([ ...leavesWithAlert, ...findLeavesWithAlert(childNode) ]);
      nbAlert -= childNode.nbAlert;
    }

    return leavesWithAlert;
  }

  return rootNodes.map( node => {
    const leaves = [...findLeavesWithAlert( node )];
    return { ...node, leaves, nodes: [] } as Node;
  });

}

const sortLeavesByAlertStartTime = (node : Node) => {

  const leaves = [...node.leaves];

  leaves.sort( (leafA, leafB) => {
    const firstTimeA = Math.max(
      leafA.firstAvailabilityTimeKO || 0,
      leafA.firstFeelingTimeKO      || 0,
      leafA.firstPerformanceTimeKO  || 0,
      leafA.firstRiskTimeKO         || 0,
    );
    const firstTimeB = Math.max(
      leafB.firstAvailabilityTimeKO || 0,
      leafB.firstFeelingTimeKO      || 0,
      leafB.firstPerformanceTimeKO  || 0,
      leafB.firstRiskTimeKO         || 0,
    );
    return firstTimeB - firstTimeA;
  })

  return { ...node, leaves };

}

export const isPullerLaunched = createSelector(
  getHierarchyState,
  (state: HierarchyState) => state.isPullerLaunched
);

export const getAvailabilityPercent = createSelector(
  getHierarchyState,
  (state: HierarchyState) => state.availibiltyPercent
);

export const getPerformancePercent = createSelector(
  getHierarchyState,
  (state: HierarchyState) => state.performancePercent
);
export const getRiskPercent = createSelector(
  getHierarchyState,
  (state: HierarchyState) => state.riskPercent
);
export const getFeelingPercent = createSelector(
  getHierarchyState,
  (state: HierarchyState) => state.feelingPercent
);

export const getProgressLoaded = createSelector(
  getHierarchyState,
  ({progressLoaded}) => progressLoaded
);
export const getProgressTotal = createSelector(
  getHierarchyState,
  ({progressTotal}) => progressTotal
);
export const getProgress = createSelector(
  getProgressLoaded,
  getProgressTotal,
  (loaded, total) => ({ loaded, total, progress: loaded / total })
);
export const getReady = createSelector(
  getHierarchyState,
  (state: HierarchyState) => state.ready
);
export const getHierarchyError = createSelector(
  getHierarchyState,
  (state: HierarchyState) => state.hierarchyError
);

export const getPositionedNodes = createSelector(
  getHierarchyState,
  ({ nodes, hiddenNodes }): Node[][] => {
    if( !nodes.length ) return [];

    const positionedNodes: Node[][] = [[], []];
    nodes = getLeavesWithAlert( nodes ).map( sortLeavesByAlertStartTime );
    nodes = hiddenNodes.length > 0 ? nodes.filter(n => !hiddenNodes.includes(n.technicalKey)) : nodes;
    nodes.forEach(node => hideNodes(node, hiddenNodes));

    for(let i in nodes) {
      if((parseInt(i) % 2) === 0) {
        positionedNodes[0].push(nodes[i]);
      }
      else {
        positionedNodes[1].push(nodes[i]);
      }
    }

    return positionedNodes;
  }
);

const hideNodes = (node: Node, hiddenNodes: string[]) => {
  node.nodes = node.nodes.filter(n => !hiddenNodes.includes(n.technicalKey));
  node.leaves = node.leaves.filter(l => !hiddenNodes.includes(l.technicalKey));

  node.nodes.forEach(n => hideNodes(n, hiddenNodes));
};
