import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { HierarchyEffects } from './hierarchy.effects';
import { hierarchyReducer } from './hierarchy.reducer';

@NgModule({
  declarations: [],
  imports: [
    StoreModule.forFeature('hierarchy', hierarchyReducer),
    EffectsModule.forFeature([HierarchyEffects]),
  ]
})
export class HierarchyStoreModule { }
