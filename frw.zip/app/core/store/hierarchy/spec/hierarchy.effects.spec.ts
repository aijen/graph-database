import { HttpErrorResponse } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { fakeAsync, TestBed, tick } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { ApiNodesService } from 'core/services/api/api.nodes';
import { HierarchyService } from 'core/services/hierarchy/hierarchy.service';
import { LEAVES_METAS_URL } from 'core/services/http/http-client.service';
import { PopulatedMetasValue } from 'core/store/populated-metas/populated-metas.model';
import { PopulatedMetasService } from 'core/store/populated-metas/populated-metas.service';
import { SnoozeConfig } from 'core/store/snooze/snooze.model';
import { SnoozeService } from 'core/store/snooze/snooze.service';
import merge from 'lodash/merge';
import { configureTestSuite } from 'ng-bullet';
import { Observable, of, throwError } from 'rxjs';
import { marbles } from 'rxjs-marbles/jasmine';
import { switchMap, take, tap } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';
import { GetHierarchy, GetHierarchyError, GetHierarchySuccess, GetNodes, GetNodesSuccess, InitPuller, InitPullerSuccess, PullHierarchy, PullHierarchyrError, Ready, SetIndicatorsPercents } from '../hierarchy.actions';
import { HierarchyEffects } from '../hierarchy.effects';
import { HierarchyState, IndicatorsPercent } from '../hierarchy.model';

describe('HierarchyEffects', () => {
  let service: HierarchyEffects;
  let httpTestingController: HttpTestingController;
  let actions: Observable<any>;
  let config$: Observable<SnoozeConfig>;
  let populatedMetas$: Observable<PopulatedMetasValue[]>;
  let apiNodesService: jasmine.SpyObj<ApiNodesService>;
  let hierarchyService: jasmine.SpyObj<HierarchyService>;
  let populatedMetasService: jasmine.SpyObj<PopulatedMetasService>;
  let store: MockStore<Partial<AppState>>;
  const initialState = { hierarchy: new HierarchyState() };

  function setPartialState( partialState: DeepPartial<AppState> ) {
    const state = merge({}, initialState, partialState);
    store.setState(state);
    return state;
  }

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
      ],
      providers: [
        HierarchyEffects,
        provideMockStore<Partial<AppState>>({ initialState }),
        provideMockActions(() => actions),
        { provide: HierarchyService, useFactory: () => jasmine.createSpyObj('HierarchyService', ['resetComputedMetadataLeaf', 'resetComputedMetadata', 'hideNodeOnTree', 'getLeavesKeys', 'extractLeavesKeysFromNode', 'populateLeaves', 'populateLeavesFromNode', 'populateMetas', 'populateMetasFromNode', 'computeBarsInfosForAllMetaTypesAndAll', 'getLeavesUrl', 'checkIsAlert', 'setLeafFirstTimeKOByMetaType', 'checkAvailiblity', 'checkPerformance', 'checkRisk', 'checkFeeling', 'calculatePercents', 'calculateNodesAlerts', 'calculateNodeAlerts', 'sortMetaByDateDesc'] as Array<keyof HierarchyService>) },
        { provide: ApiNodesService, useFactory: () => jasmine.createSpyObj('ApiNodesService', ['getNodes', 'getUserNodes', 'saveNodes', 'getLeavesByGivenCriteria', 'hideNodeFromTree', 'restoreDefaultsNodes'] as Array<keyof ApiNodesService>) },
        { provide: PopulatedMetasService, useFactory: () => ({ populatedMetas$: of(null).pipe( switchMap( () => populatedMetas$) ) }) },
        { provide: SnoozeService, useFactory: () => ({ config$: of(null).pipe( switchMap( () => config$) ) }) },
      ],
    })
  });

  beforeEach( () => {
    store = TestBed.get(Store);
    apiNodesService = TestBed.get(ApiNodesService);
    hierarchyService = TestBed.get(HierarchyService);
    populatedMetasService = TestBed.get(PopulatedMetasService);
    service = TestBed.get(HierarchyEffects);
    httpTestingController = TestBed.get(HttpTestingController);
  } );

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  describe('GetHierarchy$', () => {

    it('should dispatch a GetHierarchySuccess Action with the user nodes', marbles(m => {
      const nodes = [];
      apiNodesService.getNodes.and.returnValue( of({ nodes }) );

      actions =        m.hot('a', { a: new GetHierarchy });
      const expected = m.hot('a', { a: new GetHierarchySuccess( { nodes } ) });

      m.expect(service.GetHierarchy$).toBeObservable(expected);
    }));

    it('should try 3 times before failing and dispatching an error Action', marbles(m => {
      const error = new Error();
      const spy = jasmine.createSpy('subscribeSpy', () => throwError(error));
      const subscribeSpy = of(null).pipe( switchMap( spy ) );
      apiNodesService.getNodes.and.returnValue( subscribeSpy );

      actions =        m.hot('a', { a: new GetHierarchy });
      const expected = m.hot('20s (a|)', { a: new GetHierarchyError( {error} ) });
      const completeExpectation = tap( () => expect(spy).toHaveBeenCalledTimes(3) );

      m.expect(service.GetHierarchy$.pipe( completeExpectation )).toBeObservable(expected);
    }));

  });

  describe('GetHierarchySuccess', () => {

    it('should dispatch a PullHierachy Action every minutes', marbles(m => {
      const nodes = [];
      hierarchyService.getLeavesKeys.and.returnValue([]);

      actions =        m.hot('a',    { a: new GetHierarchySuccess( { nodes } ) });
      const expected = m.hot('(hi)', { h: new PullHierarchy( { periodTime: 300, leaves: '' } ), i: new InitPuller });

      m.expect( service.GetHierarchySuccess ).toBeObservable(expected);
    }));

    it('should dispatch a PullHierachy Action every minutes (cont.)', marbles(m => {
      hierarchyService.getLeavesKeys.and.returnValue([]);

      actions =        m.hot('i',         { i: new InitPuller });
      const expected = m.hot('60s (hs|)', { h: new PullHierarchy( { periodTime: 300, leaves: '' } ), s: new InitPullerSuccess(true) });

      m.expect( service.InitPuller.pipe( take( 2 ) ) ).toBeObservable(expected);
    }));

    it('should dispatch a PullHierachy Action every minutes (cont.)', marbles(m => {
      hierarchyService.getLeavesKeys.and.returnValue([]);
      setPartialState({ hierarchy: { isPullerLaunched: true } });

      actions =        m.hot('i',                    { i: new InitPuller });
      const expected = m.hot('60s h 999ms 59s (h|)', { h: new PullHierarchy( { periodTime: 300, leaves: '' } ) });

      m.expect( service.InitPuller.pipe( take( 2 ) ) ).toBeObservable(expected);
    }));

  });

  describe('PullHierachy', () => {

    it('should dispatch a GetNodes Action with the leaves and snoozeconfig', () => {
      hierarchyService.getLeavesUrl.and.returnValue(LEAVES_METAS_URL);
      actions = of(new PullHierarchy( { periodTime: 300, leaves: '' } ));
      config$ = of({ leaves: {} });
      populatedMetas$ = of([]);
      const spy = jasmine.createSpy('subscribe');
      const dispatch = spyOn(store, 'dispatch');

      const sub = service.PullHierachy.subscribe(spy);
      httpTestingController.expectOne(LEAVES_METAS_URL).flush([]);

      expect(dispatch).toHaveBeenCalled();
      expect(dispatch.calls.allArgs()).toEqual( [ [ new Ready(true) ] ] );
      expect(spy).toHaveBeenCalled();
      expect(spy.calls.allArgs()).toEqual( [ [ new GetNodes({leaves: [], config: { leaves: {} }, populatedMetas: []}) ] ] );

      sub.unsubscribe();
    });

    it('should try 3 times before failing and dispatching an error Action', fakeAsync(() => {
      hierarchyService.getLeavesUrl.and.returnValue(LEAVES_METAS_URL);
      actions = of(new PullHierarchy( { periodTime: 300, leaves: '' } ));
      config$ = of({ leaves: {} });
      populatedMetas$ = of([]);
      const spy = jasmine.createSpy('subscribe');

      const sub = service.PullHierachy.subscribe(spy);
      httpTestingController.expectOne(LEAVES_METAS_URL).flush(null, new HttpErrorResponse({ status: 500 }));
      tick(10000);
      httpTestingController.expectOne(LEAVES_METAS_URL).flush(null, new HttpErrorResponse({ status: 500 }));
      tick(10000);
      httpTestingController.expectOne(LEAVES_METAS_URL).flush(null, new HttpErrorResponse({ status: 500 }));

      expect(spy).toHaveBeenCalled();
      expect(spy.calls.mostRecent().args[0]).toEqual( jasmine.any(PullHierarchyrError) );

      sub.unsubscribe();
    }));

  });

  describe('GetNodes', () => {

    it('should populate and update the hierarchy with the leaves data', marbles(m => {
      hierarchyService.populateMetas.and.returnValue([]);
      hierarchyService.calculatePercents.and.returnValue({});

      actions =        m.hot('a', { a: new GetNodes( { leaves: [], config: { leaves: {} }, populatedMetas: [] } ) });
      const expected = m.hot('(ab)', {
        a: new GetNodesSuccess( [] ),
        b: new SetIndicatorsPercents( {} as IndicatorsPercent ),
      });
      const completeExpectation = tap( () => {
        expect(hierarchyService.populateMetas).toHaveBeenCalled();
        expect(hierarchyService.calculateNodesAlerts).toHaveBeenCalled();
        expect(hierarchyService.calculatePercents).toHaveBeenCalled();
      });

      m.expect(service.GetNodes.pipe( completeExpectation )).toBeObservable(expected);
    }));

  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
