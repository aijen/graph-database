import merge from 'lodash/merge';
import { Leaf } from 'shared/models/leaf.model';
import { Node } from 'shared/models/node.model';
import { HierarchyState } from '../hierarchy.model';
import { hierarchyState } from '../hierarchy.reducer';
import { getAvailabilityPercent, getFeelingPercent, getHierarchyError, getNodes, getPerformancePercent, getPositionedNodes, getProgress, getProgressLoaded, getProgressTotal, getReady, getRiskPercent, isPullerLaunched } from '../hierarchy.selectors';

describe('Hierarchy Selectors', () => {

  const createNode = ( node?: Partial<Node>, options: { asObject?: boolean, skipUpdateChildrenParent?: boolean } = {} ): Node => {
    const newNode = merge(new Node, { isNew: false, ...node });
    if(!options.skipUpdateChildrenParent) {
      newNode.nodes.forEach( child => child.parent = newNode);
      newNode.leaves.forEach( child => child.parent = newNode);
    }
    return options.asObject ? { ...newNode } : newNode;
  }
  const createLeaf = ( leaf?: Partial<Leaf> ): Leaf => merge(new Leaf, leaf);
  function getState( partialState: DeepPartial<HierarchyState> = {} ) {
    return merge({}, hierarchyState, partialState);
  }

  describe('getNodes', () => {

    it('should return the nodes', () => {
      expect(getNodes.projector(getState())).toEqual([])
    })

  })

  describe('isPullerLaunched', () => {

    it('should return the isPullerLaunched state', () => {
      expect(isPullerLaunched.projector(getState())).toEqual(false)
    })

  })

  describe('getAvailabilityPercent', () => {

    it('should return the availibility percent', () => {
      expect(getAvailabilityPercent.projector(getState())).toEqual(-1)
    })

  })

  describe('getPerformancePercent', () => {

    it('should return the performance percent', () => {
      expect(getPerformancePercent.projector(getState())).toEqual(-1)
    })

  })

  describe('getRiskPercent', () => {

    it('should return the risk percent', () => {
      expect(getRiskPercent.projector(getState())).toEqual(-1)
    })

  })

  describe('getFeelingPercent', () => {

    it('should return the feeling percent', () => {
      expect(getFeelingPercent.projector(getState())).toEqual(-1)
    })

  })

  describe('getProgressLoaded', () => {

    it('should return the progress loaded', () => {
      expect(getProgressLoaded.projector(getState())).toEqual(0)
    })

  })

  describe('getProgressTotal', () => {

    it('should return the progress total', () => {
      expect(getProgressTotal.projector(getState())).toEqual(Infinity)
    })

  })

  describe('getProgress', () => {

    it('should return the progress', () => {
      expect(getProgress.projector(0, Infinity)).toEqual({ loaded: 0, total: Infinity, progress: 0 })
      expect(getProgress.projector(5, 10)).toEqual({ loaded: 5, total: 10, progress: 0.5 })
    })

  })

  describe('getReady', () => {

    it('should return the ready state', () => {
      expect(getReady.projector(getState())).toEqual(false)
    })

  })

  describe('getHierarchyError', () => {

    it('should return the hierarchy error', () => {
      expect(getHierarchyError.projector(getState())).toEqual(null)
    })

  })

  describe('getPositionedNodes', () => {

    it('should return an empty array if nodes is empty', () => {
      const nodes = []
      const expected = []
      expect(getPositionedNodes.projector( nodes )).toEqual(expected)
    })

    it('should return the root nodes with only the leaf in alerts', () => {
      const leaf1 = createLeaf({ key: 'leaf1', hasAlert: true })
      const leaf2 = createLeaf({ key: 'leaf2', hasAlert: false })
      const nodes = [
        createNode({ technicalKey: 'node1', nbAlert: 1,
          nodes: [
            createNode({ technicalKey: 'node5', nbAlert: 1, leaves: [ leaf1, leaf2 ], }),
            createNode({ technicalKey: 'node4', nbAlert: 0 }),
          ]
        }),
        createNode({ technicalKey: 'node2' }),
      ]
      const expected = [
        [createNode({ technicalKey: 'node1', nbAlert: 1, leaves: [ leaf1 ] }, { asObject: true, skipUpdateChildrenParent: true })],
        [createNode({ technicalKey: 'node2' }, { asObject: true })],
      ]
      expect(getPositionedNodes.projector( nodes )).toEqual(expected)
    })

  })

} );
