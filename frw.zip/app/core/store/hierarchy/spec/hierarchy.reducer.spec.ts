import merge from 'lodash/merge';
import { Leaf } from 'shared/models/leaf.model';
import { Node } from 'shared/models/node.model';
import { AppState } from 'shared/models/state.model';
import { GetHierarchyError, GetHierarchySuccess, GetNodesSuccess, InitPullerSuccess, Loading, PullHierarchyrError, Ready, SetIndicatorsPercents } from '../hierarchy.actions';
import { HierarchyState } from '../hierarchy.model';
import { hierarchyReducer, hierarchyState } from '../hierarchy.reducer';

// necessary to avoid the error :
// Invalid module name in augmentation, module 'shared/models/state.model' cannot be found.
let happy_compiler: AppState; // tslint:disable-line

describe('Hierarchy Reducer', () => {

  const createNode = ( node?: Partial<Node> ): Node => {
    const newNode = merge(new Node, { isNew: false, ...node });
    newNode.nodes.forEach( child => child.parent = newNode);
    newNode.leaves.forEach( child => child.parent = newNode);
    return newNode;
  }
  const createLeaf = ( leaf?: Partial<Leaf> ): Leaf => merge(new Leaf, leaf);
  function getState( partialState: DeepPartial<HierarchyState> ) {
    return merge({}, hierarchyState, partialState);
  }

  describe('undefined action', () => {

    it('should return the default state', () => {
      const action = { type: null, payload: null };
      const state = hierarchyReducer( undefined, action );

      expect(state).toBe(hierarchyState);
    })

  });

  describe('GET_HIERARCHY_SUCCESS', () => {

    it('should save the nodes', () => {
      const action = new GetHierarchySuccess( {
        nodes: [ createNode({ technicalKey: 'BDDF' }) ],
      } );
      const state = hierarchyReducer( undefined, action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        nodes: [ createNode({ technicalKey: 'BDDF' }) ],
      }));
    });

  });

  describe('GET_NODES_SUCCESS', () => {

    it('should save the nodes in the state', () => {
      const action = new GetNodesSuccess( [ createNode({}), ] );
      const state = hierarchyReducer( undefined, action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        nodes: [ createNode({}), ],
      }));
    });

  });

  describe('PULL_HIERARCHY_ERROR', () => {

    it('should save the error message in the state', () => {
      const action = new PullHierarchyrError( { error: new Error('error message') } );
      const state = hierarchyReducer( undefined, action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        hierarchyError: 'error message',
      }));
    });

  });

  describe('GET_HIERARCHY_ERROR', () => {

    it('should save the error message in the state', () => {
      const action = new GetHierarchyError( { error: new Error('error message') } );
      const state = hierarchyReducer( undefined, action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        hierarchyError: 'error message',
      }));
    });

  });

  describe('INIT_PULLER_SUCCESS', () => {

    it('should save the init puller success in the state', () => {
      const action = new InitPullerSuccess( true );
      const state = hierarchyReducer( undefined, action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        isPullerLaunched: true,
      }));
    });

  });

  describe('SET_INDICATORS_PERCENT', () => {

    it('should save the percent in the state', () => {
      const action = new SetIndicatorsPercents( {
        availibiltyPercent: 1,
        performancePercent: 2,
        riskPercent: 3,
        feelingPercent: 4,
      } );
      const state = hierarchyReducer( undefined, action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        availibiltyPercent: 1,
        performancePercent: 2,
        riskPercent: 3,
        feelingPercent: 4,
      }));
    });

    it('should check for NaN values', () => {
      const action = new SetIndicatorsPercents( {
        availibiltyPercent: NaN,
        performancePercent: NaN,
        riskPercent: NaN,
        feelingPercent: NaN,
      } );
      const state = hierarchyReducer( undefined, action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        availibiltyPercent: undefined,
        performancePercent: undefined,
        riskPercent: undefined,
        feelingPercent: undefined,
      }));
    })

  });

  describe('LOADING', () => {

    it('should save the loading state', () => {
      {
        const action = new Loading( 1, 2 );
        const state = hierarchyReducer( undefined, action );

        expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
          progressLoaded: 1,
          progressTotal: 2,
        }));
      }
      {
        const action = new Loading( 1 );
        const state = hierarchyReducer( undefined, action );

        expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
          progressLoaded: 1,
          progressTotal: Infinity,
        }));
      }
    });

  });

  describe('READY', () => {

    it('should save the ready state', () => {
      const action = new Ready( true );
      const state = hierarchyReducer( getState({ ready: false }), action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        ready: true
      }));
    });

  });

} );
