import uniqBy from 'lodash/uniqBy';
import { Node } from 'shared/models/node.model';
import { HierarchyActionsUnion, HierarchyActionTypes } from './hierarchy.actions';
import { HierarchyState } from './hierarchy.model';

export const hierarchyState: HierarchyState = new HierarchyState();

export function hierarchyReducer(
  state: HierarchyState = hierarchyState,
  action: HierarchyActionsUnion
): HierarchyState {
  switch (action.type) {
    case HierarchyActionTypes.GET_HIERARCHY_SUCCESS: {
      let { nodes } = action.payload;
      /* remove duplicates from nodes (because sometimes, shit happens) */
      nodes = uniqBy( nodes, ({ technicalKey }) =>  technicalKey)

      return {
        ...state,
        nodes,
      };
    }
    case HierarchyActionTypes.GET_NODES_SUCCESS: {
      const nodes = action.payload;
      return {
        ...state,
        nodes,
      };
    }
    case HierarchyActionTypes.PULL_HIERARCHY_ERROR:
    case HierarchyActionTypes.GET_HIERARCHY_ERROR:
      return {
        ...state,
        hierarchyError: action.payload.error.message,
      }
    case HierarchyActionTypes.INIT_PULLER_SUCCESS:
      return {
        ...state,
        isPullerLaunched: action.payload
      };
    case HierarchyActionTypes.SET_INDICATORS_PERCENT:
      return {
        ...state,
        availibiltyPercent: isNaN(action.payload.availibiltyPercent)
          ? undefined
          : action.payload.availibiltyPercent,
        performancePercent: isNaN(action.payload.performancePercent)
          ? undefined
          : action.payload.performancePercent,
        riskPercent: isNaN(action.payload.riskPercent)
          ? undefined
          : action.payload.riskPercent,
        feelingPercent: isNaN(action.payload.feelingPercent)
          ? undefined
          : action.payload.feelingPercent
      };
    case HierarchyActionTypes.LOADING:
      return {
        ...state,
        progressLoaded: action.loaded,
        progressTotal: action.total,
      };
    case HierarchyActionTypes.READY:
      return {
        ...state,
        ready: action.payload,
      };

      case HierarchyActionTypes.SetTemplate: {
        const { template } = action.payload;
        const nodes = [...state.nodes.filter(n => n.name !== 'Liste Personnalisée')];
        const customList = new Node();

        customList.name = 'Liste Personnalisée';
        customList.nodes = Node.fromJSONCollection(template.nodes, customList);
        if(customList.nodes.length > 0) {
          nodes.push(customList);
        }

        return {
          ...state,
          nodes,
          hiddenNodes: template.hiddenNodes,
        };
      }

    default:
      return state;
  }
}
