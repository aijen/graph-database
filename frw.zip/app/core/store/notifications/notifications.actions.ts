import { Action } from '@ngrx/store';
import { CockpitNotification } from './notifications.model';

export enum NotificationsActionTypes {
  GetNotifications = '[COCKPIT] Get Notifications',
  GetNotificationsSuccess = '[COCKPIT] Get Notifications Success',
  GetNotificationsError = '[COCKPIT] Get Notifications Error',
  StartNotificationPuller = '[COCKPIT] Start Puller',
  StartNotificationPullerError = '[COCKPIT] Start Puller Notification Error',
  StopNotificationPuller = '[COCKPIT] Stop Puller',
}

export class GetNotifications implements Action {
  readonly type = NotificationsActionTypes.GetNotifications;
  constructor(public from: number, public to: number) {}
}
export class GetNotificationsSuccess implements Action {
  readonly type = NotificationsActionTypes.GetNotificationsSuccess;
  constructor(public manual: CockpitNotification[], public auto: CockpitNotification[]) {}
}

export class GetNotificationsError implements Action {
  readonly type = NotificationsActionTypes.GetNotificationsError;
  constructor(public error: Error) {}
}

export class StartNotificationPuller implements Action {
  readonly type = NotificationsActionTypes.StartNotificationPuller;
}

export class StartNotificationPullerError implements Action {
  readonly type = NotificationsActionTypes.StartNotificationPullerError;
  constructor(public error: Error) {}
}

export class StopNotificationPuller implements Action {
  readonly type = NotificationsActionTypes.StopNotificationPuller;
}

export type NotificationsActions =
  | GetNotifications
  | GetNotificationsSuccess
  | GetNotificationsError
  | StartNotificationPuller
  | StartNotificationPullerError
  | StopNotificationPuller
;
