import { HttpErrorResponse } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import merge from 'lodash/merge';
import moment from 'moment';
import { configureTestSuite } from 'ng-bullet';
import { Observable, of, throwError } from 'rxjs';
import { marbles } from 'rxjs-marbles/jasmine';
import { take } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { GetNotifications, GetNotificationsError, GetNotificationsSuccess, StartNotificationPuller, StopNotificationPuller } from '../notifications.actions';
import { NotificationsEffects } from '../notifications.effects';
import { CockpitNotification, SEVERITY } from '../notifications.model';
import { NotificationsService } from '../notifications.service';


describe('NotificationsEffects', () => {
  let service: NotificationsEffects;
  let notificationsService: jasmine.SpyObj<NotificationsService>;
  let actions: Observable<any>;

  const generateNotification = ( notification?: Partial<CockpitNotification> ) => merge( new CockpitNotification(SEVERITY.ERROR, 'title', false), notification )

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [
        NotificationsEffects,
        provideMockStore<Partial<AppState>>({ initialState: {} }),
        provideMockActions(() => actions),
        { provide: MessageHandler, useFactory: () => jasmine.createSpyObj('MessageHandler', ['ngOnDestroy', 'show']) },
        { provide: NotificationsService, useFactory: () => jasmine.createSpyObj('NotificationsService', ['load', 'save', 'update', 'delete'] as Array<keyof NotificationsService>) },
      ],
    })
  });

  beforeEach(() => {
    jasmine.clock().install()
    jasmine.clock().mockDate( new Date(2000, 6, 15) )
    service = TestBed.get(NotificationsEffects);
    notificationsService = TestBed.get(NotificationsService);
  } );

  afterEach(() => {
    jasmine.clock().uninstall()
  });

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  describe('StartNotificationPuller', () => {

    it('should emit GetNotifications Action every minute', marbles(m => {
      actions = m.hot('a', { a: new StartNotificationPuller })
      const expected = m.hot('a 999ms 59s b 999ms 59s (c|)', {
        a: new GetNotifications(
          moment('2000/07/14 00:01:00', 'YYYY/MM/DD HH:mm:ss').unix(),
          moment('2000/07/15 00:01:00', 'YYYY/MM/DD HH:mm:ss').unix()
        ),
        b: new GetNotifications(
          moment('2000/07/14 00:01:00', 'YYYY/MM/DD HH:mm:ss').unix(),
          moment('2000/07/15 00:01:00', 'YYYY/MM/DD HH:mm:ss').unix()
        ),
        c: new GetNotifications(
          moment('2000/07/14 00:01:00', 'YYYY/MM/DD HH:mm:ss').unix(),
          moment('2000/07/15 00:01:00', 'YYYY/MM/DD HH:mm:ss').unix()
        ),
      })

      m.expect(service.StartNotificationPuller.pipe(take(3))).toBeObservable(expected)
    }))

    it('should stop emitting after a StopNotificationPuller Action is dispatched', marbles(m => {
      actions = m.hot('a b', { a: new StartNotificationPuller, b: new StopNotificationPuller() })
      const expected = m.hot('(a) 5m -', {
        a: new GetNotifications(
          moment('2000/07/14 00:01:00', 'YYYY/MM/DD HH:mm:ss').unix(),
          moment('2000/07/15 00:01:00', 'YYYY/MM/DD HH:mm:ss').unix()
        ),
      })

      m.expect(service.StartNotificationPuller).toBeObservable(expected)
    }))

  })

  describe('GetNotifications', () => {

    it('should fetch the notifications', marbles(m => {
      const baseNotification = generateNotification({
        severity: CockpitNotification.SEVERITY.INFO,
        title: 'title',
        auto: false,
        message: 'message',
        user: { firstName: 'firstName', name: 'name' },
        metaType: null,
      })
      const response: CockpitNotification[] = [
        generateNotification({
          ...baseNotification,
          date: new Date(2000, 6, 15),
          id: 'id1',
        }),
        generateNotification({
          ...baseNotification,
          date: new Date(2000, 6, 15, 1),
          id: 'id2',
        }),
        generateNotification({
          ...baseNotification,
          auto: true,
          message: null,
          metaType: CockpitNotification.META_TYPE.AVAILABILITY,
          date: new Date(2000, 6, 15),
          id: 'id3',
        }),
        generateNotification({
          ...baseNotification,
          auto: true,
          message: null,
          metaType: CockpitNotification.META_TYPE.AVAILABILITY,
          date: new Date(2000, 6, 15, 1),
          id: 'id4',
        }),
      ]
      const result = new GetNotificationsSuccess( [
        generateNotification({
          ...baseNotification,
          date: new Date(2000, 6, 15, 1),
          id: 'id2',
        }),
        generateNotification({
          ...baseNotification,
          date: new Date(2000, 6, 15),
          id: 'id1',
        }),
      ], [
        generateNotification({
          ...baseNotification,
          auto: true,
          message: null,
          metaType: CockpitNotification.META_TYPE.AVAILABILITY,
          date: new Date(2000, 6, 15, 1),
          id: 'id4',
        }),
        generateNotification({
          ...baseNotification,
          auto: true,
          message: null,
          metaType: CockpitNotification.META_TYPE.AVAILABILITY,
          date: new Date(2000, 6, 15),
          id: 'id3',
        }),
      ] )
      const from = moment('2000/07/14 00:01:00', 'YYYY/MM/DD HH:mm:ss').unix()
      const to = moment('2000/07/15 00:01:00', 'YYYY/MM/DD HH:mm:ss').unix()

      actions = m.hot('a', { a: new GetNotifications(from, to) })
      const expected = m.hot('a', { a: result })

      notificationsService.load.and.returnValues( of(response) )
      m.expect(service.GetNotifications).toBeObservable(expected)

    }))

    it('should dispatch a GetNotificationsError Action when failing', marbles(m => {
      spyOn(console, 'log')
      actions = m.hot('a', { a: new GetNotifications(0, 0) })
      const expected = m.hot('a', { a: new GetNotificationsError( new HttpErrorResponse({ status: 500 }) ) })

      notificationsService.load.and.returnValue( throwError( new HttpErrorResponse({ status: 500 }) ) )
      m.expect(service.GetNotifications).toBeObservable(expected)
    }))

  })


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
