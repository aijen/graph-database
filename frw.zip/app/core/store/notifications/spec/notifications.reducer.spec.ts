import merge from 'lodash/merge';
import { AppState } from 'shared/models/state.model';
import { GetNotificationsSuccess } from '../notifications.actions';
import { CockpitNotification, NotificationsState, SEVERITY } from '../notifications.model';
import { initialState, notificationsReducer } from '../notifications.reducer';

// necessary to avoid the error :
// Invalid module name in augmentation, module 'shared/models/state.model' cannot be found.
let happy_compiler: AppState; // tslint:disable-line


const generateNotification = ( notification?: Partial<CockpitNotification> ) => merge( new CockpitNotification(SEVERITY.ERROR, 'title', false), notification )

describe('Notifications Reducer', () => {

  function getState( partialState: DeepPartial<NotificationsState> = {} ) {
    return merge({}, initialState, partialState);
  }

  describe('undefined action', () => {

    it('should return the default state', () => {
      const action = { type: null, payload: null };
      const state = notificationsReducer( undefined, action );

      expect(state).toBe(initialState);
    })

  });

  describe('GetNotificationsSuccess', () => {

    it('should save the notifications in the state', () => {
      const action = new GetNotificationsSuccess([
        generateNotification()
      ], [
        generateNotification({ auto: true })
      ]);
      const state = notificationsReducer( initialState, action );

      expect(state).toEqual(jasmine.objectContaining<NotificationsState>({
        notifications: [
          generateNotification()
        ],
        monitoringNotifications: [
          generateNotification({ auto: true })
        ]
      }));
    })

  })

} );
