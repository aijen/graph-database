import merge from 'lodash/merge';
import { CockpitNotification, NotificationsState } from '../notifications.model';
import { initialState } from '../notifications.reducer';
import { getMonitoringNotifications, getNotifications } from '../notifications.selectors';

describe('Notifications Selectors', () => {

  function getState( partialState: DeepPartial<NotificationsState> = {} ) {
    return merge({}, initialState, partialState);
  }

  describe('getNotifications', () => {

    it('should return the notifications', () => {
      const state = getState({
        notifications: [
          new CockpitNotification( CockpitNotification.SEVERITY.INFO, 'title', false )
        ]
      })
      const expected = [
        new CockpitNotification( CockpitNotification.SEVERITY.INFO, 'title', false )
      ]
      expect(getNotifications.projector( state )).toEqual(expected)
    })

  })

  describe('getMonitoringNotifications', () => {

    it('should return the monitoringNotifications of the user hierarchy', () => {
      const state = getState({
        monitoringNotifications: [
          new CockpitNotification( CockpitNotification.SEVERITY.INFO, 'title', true, null, null, null, null, null, 'leaf' )
        ]
      })
      const expected = [
        new CockpitNotification( CockpitNotification.SEVERITY.INFO, 'title', true, null, null, null, null, null, 'leaf' )
      ]
      expect(getMonitoringNotifications.projector( state, [] )).toEqual(expected)
    })

  })

} );
