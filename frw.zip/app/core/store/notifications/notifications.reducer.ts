import { NotificationsActions, NotificationsActionTypes } from './notifications.actions';
import { NotificationsState } from './notifications.model';

export const initialState: NotificationsState = {
  notifications: [],
  monitoringNotifications: [],
};

export function notificationsReducer(
  state: NotificationsState = initialState,
  action: NotificationsActions
): NotificationsState {
  switch (action.type) {
    case NotificationsActionTypes.GetNotificationsSuccess: {
      return {
        ...state,
        notifications: action.manual,
        monitoringNotifications: action.auto
      };
    }
    default:
      return state;
  }
}
