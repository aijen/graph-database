import { createFeatureSelector, createSelector } from '@ngrx/store';
import { NotificationsState } from './notifications.model';

export const getNotificationsState = createFeatureSelector<NotificationsState>(
  'notifications'
);

export const getNotifications = createSelector(
  getNotificationsState,
  (state: NotificationsState) => state.notifications
);

export const getMonitoringNotifications = createSelector(
  getNotificationsState,
  state => state.monitoringNotifications
);
