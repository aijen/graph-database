import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { INTERVAL } from 'core/services/http/http-client.service';
import { combineSortStrategies, sortByPropStrategy, sortDateStrategy, SORT_DIRECTION } from 'core/utils/sortStrategies';
import moment from 'moment';
import { concat } from 'rxjs';
import { of } from 'rxjs/observable/of';
import { TimerObservable } from 'rxjs/observable/TimerObservable';
import { catchError, map, switchMap, takeUntil } from 'rxjs/operators';
import { GetNotifications, GetNotificationsError, GetNotificationsSuccess, NotificationsActions, NotificationsActionTypes } from './notifications.actions';
import { NotificationsService } from './notifications.service';

@Injectable({providedIn: 'root'})
export class NotificationsEffects {

  constructor(
    private actions$: Actions<NotificationsActions>,
    private notificationsService: NotificationsService,
  ) {}

  @Effect()
  StartNotificationPuller = this.actions$.pipe(
    ofType(NotificationsActionTypes.StartNotificationPuller),
    switchMap(() => {
      return TimerObservable.create(0, INTERVAL).pipe(
        map(() => {
          const to = moment().unix() + 60;
          const from = to - 24 * 60 * 60;
          return new GetNotifications(from, to);
        }),
        takeUntil(this.actions$.pipe(ofType(NotificationsActionTypes.StopNotificationPuller)))
      );
    }),
  );

  @Effect()
  GetNotifications = this.actions$.pipe(
    ofType(NotificationsActionTypes.GetNotifications),
    switchMap((action) => this.notificationsService.load(action)),
    map(
      (notifications) =>
        new GetNotificationsSuccess(
          notifications.filter(notif => !notif.auto).sort( combineSortStrategies([ [ sortByPropStrategy('date', sortDateStrategy), SORT_DIRECTION.DESCENDING] ] ) ),
          notifications.filter(notif =>  notif.auto).sort( combineSortStrategies([ [ sortByPropStrategy('date', sortDateStrategy), SORT_DIRECTION.DESCENDING] ] ) )
        )
    ),
    catchError((error: Error, caught) => {
      console.log(NotificationsActionTypes.GetNotificationsError, ' :', error);
      return concat(of(new GetNotificationsError(error)), caught);
    })
  );
}
