import { NodeDTO } from 'shared/models/node.model';

declare module 'shared/models/state.model' {
  export interface AppState {
    readonly templates: TemplatesState;
  }
}

export enum TemplateType {
  PUBLIC = 'PUBLIC',
  USER = 'USER',
  GROUP = 'GROUP',
}

export type NODE_KEYS_COLUMN = string[];
export type NODE_KEYS_POSITION = [NODE_KEYS_COLUMN, NODE_KEYS_COLUMN, NODE_KEYS_COLUMN, NODE_KEYS_COLUMN];
export type HiddenNodes = { [index:string]: string[] };

export interface Template {
  readonly id: string;
  name: string;
  type: TemplateType;
  owner?: string;
  nodes: NodeDTO[];
  hiddenNodes: string[];
  nodesPosition: NODE_KEYS_POSITION;
}

export interface TemplateDTO {
  readonly id: string;
  name: string;
  type: TemplateType;
  owner?: string;
  nodes?: NodeDTO[];
  hiddenNodes?: HiddenNodes;
  nodesPosition?: NODE_KEYS_POSITION;
}

export interface TemplatesState {
  templates: Template[];
  isLoading: boolean;
}
