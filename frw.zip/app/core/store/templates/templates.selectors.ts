import { createFeatureSelector, createSelector } from '@ngrx/store';
import { TemplatesState } from './templates.model';

export const templatesStateSelector = createFeatureSelector<TemplatesState>(
  'templates'
);

export const isTemplatesLoading = createSelector(
  templatesStateSelector,
  state => state.isLoading,
);

export const getTemplates = createSelector(
  templatesStateSelector,
  state => state.templates
);
