import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { concat, of } from 'rxjs';
import { catchError, map, switchMap, tap } from 'rxjs/operators';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { LoadTemplates, LoadTemplatesError, LoadTemplatesSuccess, TemplatesActionTypes } from './templates.actions';
import { TemplatesService } from './templates.service';

@Injectable()
export class TemplatesEffects {

  public static messages = {
    loadError: `
      Une erreur est survenue pendant le chargement de la configuration 'Templates': Veuillez réessayer
    `,
  }

  constructor(
    private actions$: Actions,
    private templatesService: TemplatesService,
    private snackbar: MessageHandler,
  ) { }

  @Effect()
  load$ = this.actions$.pipe(
    ofType<LoadTemplates>(TemplatesActionTypes.LoadTemplates),
    switchMap(() => this.templatesService.load()),
    map(templates => new LoadTemplatesSuccess({ templates })),
    catchError((error, caught) => concat(of(new LoadTemplatesError({ error })), caught)),
  );

  @Effect({ dispatch: false })
  loadError$ = this.actions$.pipe(
    ofType<LoadTemplatesError>(TemplatesActionTypes.LoadTemplatesError),
    tap(action => { console.error(action.payload.error); this.snackbar.show({ message: TemplatesEffects.messages.loadError, action: 'OK', isError: true }) }),
  );

}
