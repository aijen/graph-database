import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LOAD_TEMPLATES_URL } from 'core/services/http/http-client.service';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HiddenNodes, NODE_KEYS_POSITION, Template, TemplateDTO } from './templates.model';

const fromJson = (dtos: TemplateDTO[]): Template[] => {
  return dtos.map(dto => ({
      ...dto,
      nodes: Boolean(dto.nodes) ? dto.nodes : [],
      hiddenNodes: Boolean(dto.hiddenNodes) ? convertHiddenNodes(dto.hiddenNodes) : [],
      nodesPosition: Boolean(dto.nodesPosition) ? dto.nodesPosition : [[], [], [], []] as NODE_KEYS_POSITION,
    }));
};

const convertHiddenNodes = (dto: HiddenNodes): string[] => {
  const hiddenNodes: string[] = [];

  Object.keys(dto).forEach(key => hiddenNodes.push(...dto[key]));

  return hiddenNodes;
};

@Injectable({
  providedIn: 'root'
})
export class TemplatesService {

  constructor(
    private http: HttpClient,
  ) { }

  load(): Observable<Template[]> {
    return this.http.get<TemplateDTO[]>(LOAD_TEMPLATES_URL).pipe(map(fromJson));
  }

}
