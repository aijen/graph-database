import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { TemplatesEffects } from './templates.effects';
import { templatesReducer } from './templates.reducer';

@NgModule({
  declarations: [],
  imports: [
    StoreModule.forFeature('templates', templatesReducer),
    EffectsModule.forFeature([TemplatesEffects]),
  ]
})
export class TemplatesStoreModule { }
