import { TemplatesActionTypes, TemplatesActionUnion } from './templates.actions';
import { TemplatesState } from './templates.model';

export const templatesState: TemplatesState = {
  templates: [],
  isLoading: false,
};

export function templatesReducer(
  state = templatesState,
  action: TemplatesActionUnion
): TemplatesState {

  switch( action.type ) {

    case TemplatesActionTypes.LoadTemplates: {
      return {
        ...state,
        isLoading: true,
      };
    }
    case TemplatesActionTypes.LoadTemplatesError: {
      return {
        ...state,
        isLoading: false,
      };
    }
    // Optimistic save, assumes no change were done on the server between saves
    case TemplatesActionTypes.LoadTemplatesSuccess: {
      const { templates } = action.payload;

      return {
        ...state,
        templates,
        isLoading: false,
      };
    }

    default: {
      return state;
    }
  }
}
