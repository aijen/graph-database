import { Action } from '@ngrx/store';
import { Template } from './templates.model';

export enum TemplatesActionTypes {
  LoadTemplates = '[Templates] Load',
  LoadTemplatesSuccess = '[Templates] LoadSuccess',
  LoadTemplatesError = '[Templates] LoadError',
}

export class LoadTemplates implements Action {
  readonly type = TemplatesActionTypes.LoadTemplates;
  constructor() {}
}

export class LoadTemplatesSuccess implements Action {
  readonly type = TemplatesActionTypes.LoadTemplatesSuccess;
  constructor( public payload: { templates: Template[] } ) {}
}

export class LoadTemplatesError implements Action {
  readonly type = TemplatesActionTypes.LoadTemplatesError;
  constructor( public payload: { error: Error } ) {}
}

export type TemplatesActionUnion =
  | LoadTemplates
  | LoadTemplatesSuccess
  | LoadTemplatesError
  ;
