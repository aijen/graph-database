import { HttpErrorResponse } from '@angular/common/http';
import { AppState } from 'shared/models/state.model';
import { LoadSnooze, LoadSnoozeError, LoadSnoozeSuccess } from '../snooze.actions';
import { snoozeLeavesState } from '../snooze.model';
import { snoozeReducer, snoozeState } from '../snooze.reducer';

// necessary to avoid the error :
// Invalid module name in augmentation, module 'shared/models/state.model' cannot be found.
let happy_compiler: AppState; // tslint:disable-line

describe('Snooze Reducer', () => {

  describe('undefined action', () => {

    it('should return the default state', () => {
      const action = { type: null, payload: null };
      const state = snoozeReducer( undefined, action );

      expect(state).toBe(snoozeState);
    });

  });

  describe('LoadSnooze action', () => {

    it('should be loading but not loaded', () => {
      const action = new LoadSnooze();
      const state = snoozeReducer(snoozeState, action);

      expect(state.isLoading).toBe(true);
      expect(state.isLoaded).toBe(false);
    });

  });

  describe('LoadSnoozeSuccess action', () => {

    it('should set config and be loaded but not loading', () => {
      const config = { leaves: snoozeLeavesState };
      const action = new LoadSnoozeSuccess({ config });
      const state = snoozeReducer(snoozeState, action);

      expect(state.config).toEqual(config);
      expect(state.isLoaded).toBe(true);
      expect(state.isLoading).toBe(false);
    });

  });

  describe('LoadSnoozeError action', () => {

    it('should not be loading', () => {
      const error = new HttpErrorResponse({});
      const action = new LoadSnoozeError({ error });
      const state = snoozeReducer(snoozeState, action);

      expect(state.isLoading).toBe(false);
    });

  });

} );
