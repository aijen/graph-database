import { snoozeLeavesState, SnoozeState } from '../snooze.model';
import { snoozeState } from '../snooze.reducer';
import { isSnoozeLoaded, isSnoozeLoading, selectSnoozeConfig } from '../snooze.selectors';

const generateSnoozeState = (state: Partial<SnoozeState>) => {
  return {
    config: { leaves: { ...snoozeLeavesState } },
    isLoading: false,
    isLoaded: false,
    ...state,
  };
};

describe('Snooze Selectors', () => {
  let afterLoadState: SnoozeState = generateSnoozeState({ config: { leaves: {} }, isLoading: true });
  let afterLoadSuccessState: SnoozeState = generateSnoozeState({ isLoaded: true });

  describe('isSnoozeLoading', () => {

    it('should return the loading state', () => {
      expect(isSnoozeLoading.projector(snoozeState)).toBe(false);
      expect(isSnoozeLoading.projector(afterLoadState)).toBe(true);
      expect(isSnoozeLoading.projector(afterLoadSuccessState)).toBe(false);
    });

  });

  describe('isSnoozeLoaded', () => {

    it('should return the loaded state', () => {
      expect(isSnoozeLoaded.projector(snoozeState)).toBe(false);
      expect(isSnoozeLoaded.projector(afterLoadState)).toBe(false);
      expect(isSnoozeLoaded.projector(afterLoadSuccessState)).toBe(true);
    });

  });

  describe('selectSnoozeConfig', () => {

    it('should return the config', () => {
      expect(selectSnoozeConfig.projector(snoozeState)).toEqual(snoozeState.config);
      expect(selectSnoozeConfig.projector(afterLoadState)).toEqual(afterLoadState.config);
      expect(selectSnoozeConfig.projector(afterLoadSuccessState)).toEqual(afterLoadSuccessState.config);
    });

  });

});
