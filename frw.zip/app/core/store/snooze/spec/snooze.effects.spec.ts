import { HttpErrorResponse } from '@angular/common/http';
import { async, TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { LOAD_SNOOZE_URL } from 'core/services/http/http-client.service';
import { hierarchyState } from 'core/store/hierarchy/hierarchy.reducer';
import { PopulatedMetasValue } from 'core/store/populated-metas/populated-metas.model';
import { PopulatedMetasService } from 'core/store/populated-metas/populated-metas.service';
import { configureTestSuite } from 'ng-bullet';
import { Observable, of, Subject } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { LoadSnoozeError } from '../snooze.actions';
import { SnoozeEffects } from '../snooze.effects';
import { snoozeState } from '../snooze.reducer';

describe('SnoozeEffects', () => {
  let service: SnoozeEffects;
  let actions: Observable<any>;
  let populatedMetas$: Observable<PopulatedMetasValue[]>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [
        SnoozeEffects,
        provideMockStore<Partial<AppState>>({ initialState: { snooze: snoozeState, hierarchy: hierarchyState } }),
        provideMockActions(() => actions),
        { provide: MessageHandler, useFactory: () => jasmine.createSpyObj('MessageHandler', ['ngOnDestroy', 'show']) },
        { provide: PopulatedMetasService, useFactory: () => ({ populatedMetas$: of(null).pipe( switchMap( () => populatedMetas$) ) }) },
      ],
    })
  });

  beforeEach(async(async () => {
    service = TestBed.get(SnoozeEffects);
    populatedMetas$ = of([])
  }));

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  describe('LoadSnoozeError action', () => {

    it('should display an error message', () => {
      spyOn(console, 'error');
      const error = new HttpErrorResponse({ error: 'Service unavailable', status: 503, statusText: 'KO', url: LOAD_SNOOZE_URL });
      const snackbar = TestBed.get(MessageHandler);
      const subject = actions = new Subject();
      const next = jasmine.createSpy('next');
      const sub = service.loadSnoozeError.subscribe(next);
      subject.next(new LoadSnoozeError({ error }));

      expect(console.error).toHaveBeenCalled();
      expect(snackbar.show).toHaveBeenCalled();

      sub.unsubscribe();
    });

  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for (const style of styles) head.removeChild(style);
  }
  afterAll(cleanStylesFromDom);
});
