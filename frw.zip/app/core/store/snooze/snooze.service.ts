import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { LOAD_SNOOZE_URL } from 'core/services/http/http-client.service';
import { of } from 'rxjs';
import { catchError, share, switchMap, switchMapTo, tap } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';
import { LoadSnooze, LoadSnoozeError, LoadSnoozeSuccess } from './snooze.actions';
import { SnoozeConfig } from './snooze.model';
import { isSnoozeLoaded, selectSnoozeConfig } from './snooze.selectors';

@Injectable({
  providedIn: 'root'
})
export class SnoozeService {

  constructor(
    private store$: Store<AppState>,
    private http: HttpClient,
  ) {}

  private getConfig$ = () => this.http.get<SnoozeConfig>(LOAD_SNOOZE_URL);

  private require$ = of<void>(null).pipe(
    tap( () => this.store$.dispatch( new LoadSnooze() ) ),
    switchMap(() => this.getConfig$() ),
    tap( config => this.store$.dispatch( new LoadSnoozeSuccess( { config } ) ) ),
    catchError( error => (this.store$.dispatch( new LoadSnoozeError( { error } ) ), of<void>(null)) ),
    share(),
  );

  private selectConfig$ = this.store$.pipe( select( selectSnoozeConfig ) );

  private getAndSelectConfig$ = this.require$.pipe( switchMapTo( this.selectConfig$ ) );

  config$ = this.store$.pipe(
    select( isSnoozeLoaded ),
    switchMap( loaded => loaded ? this.selectConfig$ : this.getAndSelectConfig$ ),
  );
}
