import { HttpErrorResponse } from '@angular/common/http';
import { Action } from '@ngrx/store';
import { SnoozeConfig } from './snooze.model';

export enum SnoozeActionTypes {
  LoadSnooze = '[CockPit] Snooze Load',
  LoadSnoozeSuccess = '[CockPit] Snooze LoadSuccess',
  LoadSnoozeError = '[CockPit] Snooze LoadError',
}

export class LoadSnooze implements Action {
  readonly type = SnoozeActionTypes.LoadSnooze;
  constructor() {}
}

export class LoadSnoozeSuccess implements Action {
  readonly type = SnoozeActionTypes.LoadSnoozeSuccess;
  constructor( public payload: { config: SnoozeConfig } ) {}
}

export class LoadSnoozeError implements Action {
  readonly type = SnoozeActionTypes.LoadSnoozeError;
  constructor( public payload: { error: HttpErrorResponse } ) {}
}

export type SnoozeActionsUnion =
  | LoadSnooze
  | LoadSnoozeSuccess
  | LoadSnoozeError
;
