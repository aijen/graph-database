import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { tap } from 'rxjs/operators';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { LoadSnoozeError, SnoozeActionTypes } from './snooze.actions';

@Injectable({providedIn: 'root'})
export class SnoozeEffects {

  public static messages = {
    loadError: `
      Une erreur est survenue pendant le chargement de la configuration 'snooze': les alertes ne seront pas désactivées
    `,
  }

  constructor(
    private actions$: Actions,
    private snackbar: MessageHandler,
  ) {}

  @Effect({ dispatch: false })
  loadSnoozeError = this.actions$.pipe(
    ofType<LoadSnoozeError>(SnoozeActionTypes.LoadSnoozeError),
    tap( action => { console.error(action.payload.error); this.snackbar.show( { message: SnoozeEffects.messages.loadError, action: 'OK', isError: true, id: action.type } ) } ),
  )

}
