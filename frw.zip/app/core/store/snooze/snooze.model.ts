
declare module 'shared/models/state.model' {
  export interface AppState {
    readonly snooze: SnoozeState;
  }
}

export interface SnoozeMetaCheck {
  enabled: boolean;
  admin: boolean;
}

export interface SnoozeLeaf {
  leafId: string;
  name: string;
  availability: SnoozeMetaCheck;
  performance: SnoozeMetaCheck;
  risk: SnoozeMetaCheck;
  userXp: SnoozeMetaCheck;
  selected: boolean;
}

export interface SnoozeLeavesState {
  [index:string]: SnoozeLeaf[],
  BDDF?: SnoozeLeaf[],
  CDN?: SnoozeLeaf[],
}

export const snoozeLeavesState: SnoozeLeavesState = {
  BDDF: [],
  CDN: [],
}

export interface SnoozeConfig {
  readonly id?: string;
  readonly userId?: string;
  leaves: SnoozeLeavesState;
}

export interface SnoozeState {
  config?: SnoozeConfig;
  isLoading: boolean;
  isLoaded: boolean;
}

export type BANK = Extract<keyof SnoozeLeavesState, string>;
