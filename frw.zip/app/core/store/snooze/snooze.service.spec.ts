import { HttpErrorResponse, HttpParams, HttpRequest } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { async, TestBed } from '@angular/core/testing';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { LOAD_SNOOZE_URL } from 'core/services/http/http-client.service';
import isEqual from 'lodash/isEqual';
import { configureTestSuite } from 'ng-bullet';
import { BehaviorSubject, Subject } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { LoadSnoozeError, LoadSnoozeSuccess } from './snooze.actions';
import { SnoozeConfig, SnoozeLeaf } from './snooze.model';
import { snoozeState } from './snooze.reducer';
import { SnoozeService } from './snooze.service';

const generateSnoozeLeaf = (leaf?: Partial<SnoozeLeaf>) => {
  return {
    leafId: 'leafId',
    name: 'name',
    availability: { enabled: false, admin: false },
    performance: { enabled: false, admin: false },
    risk: { enabled: false, admin: false },
    userXp: { enabled: false, admin: false },
    selected: false,
    ...leaf,
  };
};

describe('SnoozeService', () => {
  const config = {
    leaves: {
      BDDF: [
        generateSnoozeLeaf({ leafId: 'depotPJ', name: 'depotPJ - Mes demandes' }),
        generateSnoozeLeaf({ leafId: 'HARMONIE', name: 'HARMONIE - Socle d’orchestration et pilotage des processus' }),
        generateSnoozeLeaf({ leafId: 'IPPI', name: 'IPPI - Instruction prêts personnels immobiliers' }),
      ],
      CDN: [
        generateSnoozeLeaf({ leafId: 'GED', name: 'GED - Gestion Electronique de Document' }),
        generateSnoozeLeaf({ leafId: 'MCL', name: 'MCL - composants V3 (AWT )' }),
        generateSnoozeLeaf({ leafId: 'PIA', name: 'PIA - Plate-forme Intégration Automates' }),
      ]
    }
  };

  let service: SnoozeService;
  let httpTestingController: HttpTestingController;
  let store: MockStore<Partial<AppState>>;

  function fromHttpParams(params: HttpParams) {
    return params.keys()
      .map(k => ({ [k]: params.get(k) }))
      .reduce((acc, value) => ({ ...acc, ...value }), {});
  }

  function isParamsEqual(params: HttpParams, comp: any) {
    return isEqual(fromHttpParams(params), comp);
  }

  function isRequest(matcher: { url?: string, method?: string, params?: any, body?: any }) {
    return (req: HttpRequest<any>) =>
      (!matcher.url || req.url === matcher.url)
      && (!matcher.method || req.method === matcher.method)
      && (!matcher.params || isParamsEqual(req.params, matcher.params))
      && (!matcher.body || isEqual(req.body, matcher.body));
  }

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
      ],
      providers: [
        SnoozeService,
        provideMockStore<Partial<AppState>>({ initialState: { snooze: snoozeState } }),
      ],
    })
  });

  beforeEach(async(async () => {
    service = TestBed.get(SnoozeService);
    httpTestingController = TestBed.get(HttpTestingController);
    store = TestBed.get(Store);
  }));

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  describe('load snooze config', () => {

    it('should dispatch LoadSnoozeSuccess action', () => {
      const dispatchSpy = spyOn(TestBed.get(Store), 'dispatch');
      const subject = new Subject();
      const next = jasmine.createSpy('next');

      let sub = service.config$.subscribe(next);
      subject.next(null);

      httpTestingController.expectOne(isRequest({
        url: LOAD_SNOOZE_URL,
        method: 'GET',
      })).flush(config);

      expect(dispatchSpy).toHaveBeenCalledWith(new LoadSnoozeSuccess({ config }));

      sub.unsubscribe();
    });

    it('should dispatch LoadSnoozeError action', () => {
      const dispatchSpy = spyOn(TestBed.get(Store), 'dispatch');
      const subject = new Subject();
      const next = jasmine.createSpy('next');

      let sub = service.config$.subscribe(next);
      subject.next(null);

      httpTestingController.expectOne(isRequest({
        url: LOAD_SNOOZE_URL,
        method: 'GET',
      })).flush(null, new HttpErrorResponse({ status: 500 }));

      expect(dispatchSpy).toHaveBeenCalledWith( jasmine.any(LoadSnoozeError) );

      sub.unsubscribe();
    })

    it('should select snooze config', () => {
      const dispatchSpy = spyOn(TestBed.get(Store), 'dispatch');
      const result = new BehaviorSubject<SnoozeConfig>(null);
      const subject = new Subject();

      store.setState({ snooze: { config, isLoading: false, isLoaded: true } });

      let sub = service.config$.subscribe(result);
      subject.next(null);

      httpTestingController.expectNone(LOAD_SNOOZE_URL);

      expect(dispatchSpy).not.toHaveBeenCalled();
      expect(result.value).toEqual(config);

      sub.unsubscribe();
    })

  });

  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for (const style of styles) head.removeChild(style);
  }
  afterAll(cleanStylesFromDom);
});
