import { SnoozeActionsUnion, SnoozeActionTypes } from './snooze.actions';
import { snoozeLeavesState, SnoozeState } from './snooze.model';

export const snoozeState: SnoozeState = {
  config: { leaves: snoozeLeavesState },
  isLoading: false,
  isLoaded: false,
};

export function snoozeReducer(
  state: SnoozeState = snoozeState,
  action: SnoozeActionsUnion
): SnoozeState {

  switch (action.type) {
    case SnoozeActionTypes.LoadSnooze: {
      return {
        ...state,
        isLoading: true,
        isLoaded: false,
      };
    }
    case SnoozeActionTypes.LoadSnoozeSuccess: {
      return {
        ...state,
        config: action.payload.config,
        isLoading: false,
        isLoaded: true,
      };
    }
    case SnoozeActionTypes.LoadSnoozeError: {
      return {
        ...state,
        isLoading: false,
      };
    }

    default:
      return state;
  }

}
