import { Component, Input } from '@angular/core';
import { CockpitNotification } from 'core/store/notifications/notifications.model';

@Component({
  selector: 'cockpit-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.scss']
})
export class NotificationComponent {
  @Input()
  notification: CockpitNotification;

  constructor() {}
}
