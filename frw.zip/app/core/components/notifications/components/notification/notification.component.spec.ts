import { Component, Input, ViewChild } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatMenuModule } from '@angular/material/menu';
import { provideMockStore } from '@ngrx/store/testing';
import { CockpitNotification, SEVERITY } from 'core/store/notifications/notifications.model';
import { configureTestSuite } from 'ng-bullet';
import { AppState } from 'shared/models/state.model';
import { NotificationComponent } from './notification.component';

const generateNotification = (notification: Partial<CockpitNotification>) => {
  return {
    ...new CockpitNotification(SEVERITY.ERROR, 'title', false),
    ...notification,
  }
};

@Component({
  selector: `host-component`,
  template: `<cockpit-notification></cockpit-notification>`
})
class TestHostComponent {
  @ViewChild(NotificationComponent)
  public notificationComponent: NotificationComponent;
}

@Component({
  selector: 'pit-notification-menu',
  template: '',
})
class PitNotificationMenuStubComponent {
  @Input() notification: any;
}

describe('NotificationComponent', () => {
  let testHostFixture: ComponentFixture<TestHostComponent>;
  let testHostComponent: TestHostComponent;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        MatMenuModule,
      ],
      declarations: [
        TestHostComponent,
        NotificationComponent,
        PitNotificationMenuStubComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: {} }),
      ],
    })
  });

  beforeEach(() => {
    testHostFixture = TestBed.createComponent(TestHostComponent);
    testHostComponent = testHostFixture.componentInstance;
    testHostComponent.notificationComponent.notification = generateNotification({ user: { userId: 'X123456' } });
    testHostFixture.detectChanges();
  });

  it('should create', () => {
    expect(testHostComponent).toBeTruthy();
    expect(testHostComponent.notificationComponent).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for (const style of styles) head.removeChild(style);
  }
  afterAll(cleanStylesFromDom);
});
