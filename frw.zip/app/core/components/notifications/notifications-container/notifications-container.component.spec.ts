import { Component, Directive, EventEmitter, Input, Output } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { MatTabsModule } from '@angular/material/tabs';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { provideMockActions } from '@ngrx/effects/testing';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { hierarchyState } from 'core/store/hierarchy/hierarchy.reducer';
import { StartNotificationPuller } from 'core/store/notifications/notifications.actions';
import { initialState as initialNotificationsState } from 'core/store/notifications/notifications.reducer';
import { configureTestSuite, createTestContext, TestCtx } from 'ng-bullet';
import { Observable } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { NotificationContainerComponent } from './notifications-container.component';

@Component({
  selector: 'pit-date-picker',
  template: '',
})
class PitDatePickerStubComponent {
  @Input() selectedDate: any;
  @Input() displayType: any;
  @Input() pitIcon: any;
  @Input() toggleClasses: any;
  @Output() dateChange = new EventEmitter<any>();
}

@Component({
  selector: 'cockpit-notification',
  template: '',
})
class CockpitNotificationStubComponent {
  @Input() notification: any;
}

@Component({
  selector: 'cockpit-monitoring-notification',
  template: '',
})
class CockpitMonitoringNotificationStubComponent {
  @Input() notification: any;
}

@Component({
  selector: 'cockpit-notification-form',
  template: '',
})
class CockpitNotificationFormStubComponent {
  @Output() notifSaved = new EventEmitter<any>();
}

@Component({
  selector: 'pit-virtual-scrolling',
  template: '',
})
class VirtualScrollingStubComponent {
  @Input() items: any;
  @Input() itemSize: any;
}

@Directive({
  selector: '[cockpitAutoScroll]',
})
class CockpitAutoScrollStubDirective {
  @Input() cockpitAutoScroll: any;
  @Input() autoScrollTo: any;
}

describe('NotificationContainerComponent', () => {
  let context: TestCtx<NotificationContainerComponent>;
  let actions: Observable<any>;
  let store: MockStore<Partial<AppState>>;
  const initialState = { notifications: initialNotificationsState, hierarchy: hierarchyState };

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      declarations: [
        NotificationContainerComponent,
        PitDatePickerStubComponent,
        CockpitNotificationStubComponent,
        CockpitMonitoringNotificationStubComponent,
        CockpitNotificationFormStubComponent,
        VirtualScrollingStubComponent,
        CockpitAutoScrollStubDirective,
      ],
      imports: [
        MatTabsModule,
        NoopAnimationsModule,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState }),
        provideMockActions(() => actions),
      ],
    })
  });

  beforeEach(() => {
    jasmine.clock().install();
    jasmine.clock().mockDate(new Date(2000, 1, 1));
    store = TestBed.get(Store);
    spyOn(store, 'dispatch').and.callThrough();
    context = createTestContext(NotificationContainerComponent);
  });

  afterEach(() => {
    jasmine.clock().uninstall();
  })

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });

  it('should start the notificationPuller', () => {
    expect(store.dispatch).toHaveBeenCalledWith(new StartNotificationPuller());
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
