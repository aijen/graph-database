import { Component } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { StartNotificationPuller } from 'core/store/notifications/notifications.actions';
import { getMonitoringNotifications, getNotifications } from 'core/store/notifications/notifications.selectors';
import { AppState } from 'shared/models/state.model';

@Component({
  selector: 'cockpit-notifications-container',
  templateUrl: './notifications-container.component.html',
  styleUrls: ['./notifications-container.component.scss']
})
export class NotificationContainerComponent {
  notifications$ = this.store$.pipe(select(getNotifications));
  monitoringNotifications$ = this.store$.pipe(select(getMonitoringNotifications));

  constructor(private store$: Store<AppState>) {
    this.store$.dispatch(new StartNotificationPuller());
  }
}
