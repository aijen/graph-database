import { Component, Directive } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import moment from 'moment';
import { configureTestSuite, createTestContext, TestCtx } from 'ng-bullet';
import { marbles } from 'rxjs-marbles/jasmine';
import { take, tap } from 'rxjs/operators';
import { NavBarComponent } from './nav-bar.component';

@Component({
  selector: 'cockpit-gauges',
  template: '',
})
class CockpitGaugesStubComponent {}

@Component({
  selector: 'pit-search',
  template: '',
})
class PitSearchStubComponent {}

@Component({
  selector: 'cockpit-nav-icons',
  template: '',
})
class CockpitNavIconsStubComponent {}

@Directive({
  selector: '[lazyLoadDisabled]'
}) class ImgLazyloadStubDirective {}

describe('NavBarComponent', () => {
  let context: TestCtx<NavBarComponent>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      declarations: [
        NavBarComponent,
        CockpitGaugesStubComponent,
        PitSearchStubComponent,
        CockpitNavIconsStubComponent,
        ImgLazyloadStubDirective,
      ],
    })
  });

  beforeEach(() => {
    jasmine.clock().install();
    jasmine.clock().mockDate(new Date(2000, 0, 1));
    context = createTestContext(NavBarComponent);
  });

  afterEach(() => {
    jasmine.clock().uninstall();
  });

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });

  it('should refresh the date every 300ms', marbles(m => {
    const expected = m.cold(' 300ms 0 299ms (1|) ', [ moment(), moment().add(300, 'milliseconds') ]);

    m.expect(context.component.currentDate.pipe(
      take(2), // currentDate is an infinite observable, the test would never complete without the take operator.
      tap(() => jasmine.clock().tick(300)), // simulating the passage of time for moment
    )).toBeObservable(expected);
  }));


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
