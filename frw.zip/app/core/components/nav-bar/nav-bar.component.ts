import { Component } from '@angular/core';
import moment from 'moment';
import { interval } from 'rxjs';
import { map } from 'rxjs/operators';

@Component({
  selector: 'cockpit-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.scss']
})
export class NavBarComponent {

  currentDate = interval(300).pipe( map( () => moment() ) );

  constructor() {}
}
