import { Component, Input } from '@angular/core';

const UPPER_INCLUDED = true;

@Component({
  selector: 'cockpit-alert-indicator',
  templateUrl: './alert-indicator.component.html',
  styleUrls: ['./alert-indicator.component.scss']
})
export class AlertIndicatorComponent {
  @Input() type: string;
  @Input() title: string;
  @Input() set percent(value: number) {
    this.percentToShow = value;
    let numOfIndicator = 5;
    this.errorType = 'noop';
    if (Number.isFinite(value)) {
      switch (true) {
        case this.isBetween(0, 80, value): {
          this.errorType = 'error';
          numOfIndicator = 1;
          break;
        }
        case this.isBetween(80, 90, value): {
          this.errorType = 'error';
          numOfIndicator = 2;
          break;
        }
        case this.isBetween(90, 95, value): {
          this.errorType = 'warn';
          numOfIndicator = 3;
          break;
        }
        case this.isBetween(95, 98, value): {
          this.errorType = 'info';
          numOfIndicator = 4;
          break;
        }
        case this.isBetween(98, 100, value, UPPER_INCLUDED): {
          this.errorType = 'info';
          numOfIndicator = 5;
          break;
        }
      }
    }
    this.indicators = Array(numOfIndicator).fill(this.errorType);
  }

  percentToShow: number;
  errorType: 'noop' | 'error' | 'warn' | 'info' = 'noop';
  indicators: string[] = Array(5).fill(this.errorType);
  isToolTipDisplayed = false;

  constructor() {}

  private isBetween(lower: number, upper: number, value: number, upperIncluded = false) {
    const roundedValue = parseFloat(value.toFixed(3));
    return (
      lower <= roundedValue
    ) && (
      upperIncluded
      ? roundedValue <= upper
      : roundedValue < upper
    );
  }
}
