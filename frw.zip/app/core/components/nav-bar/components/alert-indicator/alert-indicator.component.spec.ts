import { async, TestBed } from '@angular/core/testing';
import { NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { snoozeLeavesState, SnoozeState } from 'core/store/snooze/snooze.model';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { AppState } from 'shared/models/state.model';
import { AlertIndicatorComponent } from './alert-indicator.component';

const generateSnoozeState = (state: Partial<SnoozeState>) => {
  return {
    config: { leaves: snoozeLeavesState },
    isLoading: false,
    isLoaded: false,
    ...state,
  }
}

describe('AlertIndicatorComponent', () => {
  let context: TestCtx<AlertIndicatorComponent>;
  let store: MockStore<Partial<AppState>>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [ NgbTooltipModule ],
      declarations: [
        AlertIndicatorComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: { snooze: generateSnoozeState({}) } }),
      ],
    })
  });

  beforeEach(async( async () => {
    context = await createStableTestContext(AlertIndicatorComponent);
    store = TestBed.get(Store);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });

  describe('@Input percent', () => {

    it('should update the number of bars and their color', () => {
      const component = context.component;

      expect(component.errorType).toEqual('noop');
      expect(component.indicators).toEqual(['noop', 'noop', 'noop', 'noop', 'noop']);

      component.percent = 0;

      expect(component.errorType).toEqual('error');
      expect(component.indicators).toEqual(['error']);

      component.percent = 80;

      expect(component.errorType).toEqual('error');
      expect(component.indicators).toEqual(['error', 'error']);

      component.percent = 90;

      expect(component.errorType).toEqual('warn');
      expect(component.indicators).toEqual(['warn', 'warn', 'warn']);

      component.percent = 95;

      expect(component.errorType).toEqual('info');
      expect(component.indicators).toEqual(['info', 'info', 'info', 'info']);

      component.percent = 98;

      expect(component.errorType).toEqual('info');
      expect(component.indicators).toEqual(['info', 'info', 'info', 'info', 'info']);

      component.percent = 100;

      expect(component.errorType).toEqual('info');
      expect(component.indicators).toEqual(['info', 'info', 'info', 'info', 'info']);

      component.percent = Number.POSITIVE_INFINITY;

      expect(component.errorType).toEqual('noop');
      expect(component.indicators).toEqual(['noop', 'noop', 'noop', 'noop', 'noop']);

    })

  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
