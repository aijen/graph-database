import { Observable, Subject } from 'rxjs';
import { finalize } from 'rxjs/operators';
import { SubscriptionAwareComponent } from './subscription-aware.component';

describe('subscription-aware.component', () => {

  class TestComponent extends SubscriptionAwareComponent {
    getSubscription() {
      return this.subscription
    }

    addObservable( observable: Observable<any> ) {
      this.subscription.add( observable.subscribe() )
    }
  }

  let testComponent: TestComponent

  beforeEach(() => {
    testComponent = new TestComponent()
  })

  it('should unsubscribe from all observables added to the subscription on destroy', () => {

    const observable = new Subject()
    let closed = false

    testComponent.addObservable(observable.pipe( finalize(() => closed = true) ))

    expect(testComponent.getSubscription().closed).toBe(false)
    expect(closed).toBe(false)

    testComponent.ngOnDestroy()

    expect(testComponent.getSubscription().closed).toBe(true)
    expect(closed).toBe(true)

  })

})
