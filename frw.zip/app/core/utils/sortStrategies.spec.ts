import { combineSortStrategies, sortByPropStrategy, sortDateStrategy, sortFromOrderedListStrategy, sortNumberStrategy, sortStringCaseInsensitiveStrategy, SORT_DIRECTION } from './sortStrategies';

describe('sortStrategies', () => {

  describe('sortStringCaseInsensitiveStrategy', () => {

    it('should sort the array by string case insensitive', () => {
      const actual   = [ 'C', 'E', 'A', 'b', 'E', 'd' ]
      const expected = [ 'A', 'b', 'C', 'd', 'E', 'E' ]

      expect( actual.sort( sortStringCaseInsensitiveStrategy ) ).toEqual(expected)
    })

  })

  describe('sortNumberStrategy', () => {

    it('should sort the array by numerical values', () => {
      const actual   = [ 3, 5, 1, 2, 4 ]
      const expected = [ 1, 2, 3, 4, 5 ]

      expect( actual.sort( sortNumberStrategy ) ).toEqual(expected)
    })

  })

  describe('sortDateStrategy', () => {

    it('should sort the array by date', () => {
      const actual   = [ new Date(2000, 6, 16), new Date(2000, 6, 14), new Date(2000, 6, 15) ]
      const expected = [ new Date(2000, 6, 14), new Date(2000, 6, 15), new Date(2000, 6, 16) ]

      expect( actual.sort( sortDateStrategy ) ).toEqual(expected)
    })

  })

  describe('sortFromOrderedListStrategy', () => {

    it('should sort the array to have the elements in the same order as the provided list', () => {

      const patron = [ 'C', 'E', 'A', 'b', 'd' ]

      const actual   = [ 'A', 'C', 'd', 'E' ]
      const expected = [ 'C', 'E', 'A', 'd' ]

      expect( actual.sort( sortFromOrderedListStrategy( patron ) ) ).toEqual(expected)
    })

  })

  describe('sortByPropStrategy', () => {

    it('should sort the array by a given prop of the items', () => {
      const actual   = [ { value: 'c' }, { value: 'a' }, { value: 'b' } ]
      const expected = [ { value: 'a' }, { value: 'b' }, { value: 'c' } ]

      expect( actual.sort( sortByPropStrategy('value') ) ).toEqual(expected)
    })

    it('should sort the array by a given mapper of the items', () => {
      const actual   = [ { value: 'c' }, { value: 'a' }, { value: 'b' } ]
      const expected = [ { value: 'a' }, { value: 'b' }, { value: 'c' } ]

      expect( actual.sort( sortByPropStrategy(( item ) => item.value )) ).toEqual(expected)
    })

    it('should accept a sort strategy as a second argument', () => {
      const actual   = [ [1,2,3], [1], [1,2] ]
      const expected = [ [1], [1,2], [1,2,3] ]

      expect( actual.sort( sortByPropStrategy(( item ) => item.length, sortNumberStrategy)) ).toEqual(expected)
    })

  })

  describe('combineSortStrategies', () => {

    it('should combine provided sort strategies', () => {
      const actual   = [ { stringValue: 'b', numberValue: 1 }, { stringValue: 'a', numberValue: 2 }, { stringValue: 'a', numberValue: 1 } ]
      const expected = [ { stringValue: 'a', numberValue: 1 }, { stringValue: 'a', numberValue: 2 }, { stringValue: 'b', numberValue: 1 } ]

      expect( actual.sort( combineSortStrategies([ [sortByPropStrategy('stringValue')], [sortByPropStrategy('numberValue', sortNumberStrategy)] ]) ) ).toEqual(expected)

    })

    it('should sorted strategies can have an optional direction', () => {
      const actual   = [ { stringValue: 'a', numberValue: 1 }, { stringValue: 'a', numberValue: 2 }, { stringValue: 'b', numberValue: 1 } ]
      const expected = [ { stringValue: 'b', numberValue: 1 }, { stringValue: 'a', numberValue: 2 }, { stringValue: 'a', numberValue: 1 } ]

      expect( actual.sort( combineSortStrategies([
        [sortByPropStrategy('stringValue'), SORT_DIRECTION.DESCENDING],
        [sortByPropStrategy('numberValue', sortNumberStrategy), SORT_DIRECTION.DESCENDING]
      ]) ) ).toEqual(expected)

    })

  })

})
