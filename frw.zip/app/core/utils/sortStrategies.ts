
export enum SORT_DIRECTION {
  ASCENDING = 1,
  DESCENDING = -1,
}

export const sortStringCaseInsensitiveStrategy = ( stringA: string, stringB: string ): number =>  {
  stringA = stringA.toLowerCase();
  stringB = stringB.toLowerCase();

  switch(true) {
    case stringA > stringB: return 1;
    case stringA < stringB: return -1;
    default: return 0;
  }
}

export const sortNumberStrategy = ( numberA: number, numberB: number ): number => {
  return numberA - numberB;
}

export const sortDateStrategy = ( dateA: Date, dateB: Date ): number => {
  return (+dateA) - (+dateB)
}

export const sortFromOrderedListStrategy = <T>( list: T[] ) => ( itemA: T, itemB: T ): number => list.indexOf(itemA) - list.indexOf(itemB);

export const sortByPropStrategy =
  <T extends { [P: string]: any }, S extends sortStrategy<R>, R = S extends sortStrategy<infer U> ? U : string>( prop: (( item: T ) => R) | keysOfType<T, R>, strategy: S = sortStringCaseInsensitiveStrategy as any ) => {
    const mapper: ( item: T ) => R = typeof prop === 'function' ? prop : item => item[prop];
    return ( itemA: T, itemB: T ): number =>
      strategy( mapper(itemA), mapper(itemB) );
  }

export type sortStrategy<T> = (A: T, B: T) => number;
export type sortStrategyWithDirection<T> = [ sortStrategy<T>, SORT_DIRECTION? ];

export const combineSortStrategies =
  <T>( strategies: sortStrategyWithDirection<T>[] ) =>
    ( itemA: T, itemB: T ): number =>
      strategies.reduce(
        ( acc, [strategy, direction = SORT_DIRECTION.ASCENDING]) =>
          acc || (strategy( itemA, itemB ) * direction)
        , 0
      );
