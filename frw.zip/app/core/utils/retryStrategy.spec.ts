import { marbles } from 'rxjs-marbles/jasmine';
import { retryWhen } from 'rxjs/operators';
import { retryStrategy } from './retryStrategy';

describe('retryStrategy', () => {

  it('should retry the source observable in case of error ( by default 3 times with a 10s delay )', marbles(m => {
    const actual   = m.hot('-a- #')
    const expected = m.hot('-a- 20s #')

    m.expect(actual.pipe( retryWhen(retryStrategy()) )).toBeObservable(expected)
  }))

})
