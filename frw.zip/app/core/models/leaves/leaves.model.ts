
export interface MetasCheck {
  availability: boolean;
  performance: boolean;
  risk: boolean;
  userXp: boolean;
}

export interface MetasCheckDTO {
  AVAILABILITY: boolean;
  PERFORMANCE: boolean;
  RISK: boolean;
  USER_XP: boolean;
}

export const metasCheckState: MetasCheck = {
  availability: false,
  performance: false,
  risk: false,
  userXp: false,
}
