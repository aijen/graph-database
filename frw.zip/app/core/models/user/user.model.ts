export interface UserName {
  userId?: string;
  firstName?: string;
  name?: string;
}
