import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { HierarchyInterface } from 'shared/models/Hierarchy.interface';
import { LOAD_USER_ARBORESCENCE_URL } from '../http/http-client.service';


@Injectable({providedIn: 'root'})
export class ApiNodesService {

  constructor(
    private httpClient: HttpClient,
  ) {}

  public getNodes() {
    return this.httpClient.get<HierarchyInterface>(LOAD_USER_ARBORESCENCE_URL);
  }
}
