import { Injectable } from '@angular/core';
import moment from 'moment';

/** DEPRECATED please just use moment
 * @deprecated
 */
export enum UnitDateTime {
  DAYS = 'days',
  HOURS = 'hours',
  MINUTES = 'minutes',
  SECONDS = 'seconds'
}

/** DEPRECATED please just use moment
 * @deprecated
 */
@Injectable({providedIn: 'root'})
export class DateTimeService {

  /** DEPRECATED please just use moment
   * @deprecated
   */
  getNowUnix(): number {
    return  moment().unix();
  }

  /** DEPRECATED please just use moment
   * @deprecated
   */
  getNow(): number {
    return moment.now();
  }

  /** DEPRECATED please just use moment
   * @deprecated
   */
  getMomentInstance(): moment.Moment {
    return moment();
  }

  /** DEPRECATED please just use moment
   * @deprecated
   */
  subtractFromUnixTime(startTimeUnix: number, amountOfTime: number, unitTime: UnitDateTime): number {
    return this.applyOperation(startTimeUnix, amountOfTime, unitTime, 'subtract');
  }

  /** DEPRECATED please just use moment
   * @deprecated
   */
  addFromUnixTime(startTimeUnix: number, amountOfTime: number, unitTime: UnitDateTime): number {
    return this.applyOperation(startTimeUnix, amountOfTime, unitTime, 'add');
  }

  /** DEPRECATED please just use moment
   * @deprecated
   */
  getRoundedTimeDownInMinutes(date: moment.Moment = moment(), reducer: number = 5, unitTime: UnitDateTime = UnitDateTime.MINUTES) {
    return date.subtract(date.minute() % reducer, unitTime).second(0);
  }

  /** DEPRECATED please just use moment
   * @deprecated
   */
  isDurationGreaterThanInMinutes(start: number, end: number, step = 5) {
    return Math.abs(moment.duration(moment(start).diff(moment(end))).asMinutes()) > step;
  }

  /** DEPRECATED please just use moment
   * @deprecated
   */
  getAmountOfTimeInMinutes(amount: number = 1): number {
    return 1000 * 60 * amount;
  }

  private applyOperation(startTimeUnix: number, amountOfTime: number, unitTime: UnitDateTime, operation: string): number {
    return  moment.unix(startTimeUnix).clone().set({ second:0, millisecond:0 })[operation](amountOfTime, unitTime).unix()
  }
}
