import { environment } from 'env/environment';

export const LEAVES_METAS_URL = environment.API_URL + '/api/leaves/metas/';
export const LEAVES_ARCHIVED_METAS_URL = environment.API_URL + '/api/leaves/metas/history';
export const LOAD_POPULATED_METAS_URL = environment.API_URL + '/api/leaves/metas/populated';

export const LOAD_NOTIFICATIONS_URL = environment.API_URL + '/api/notifications';

export const LOAD_SNOOZE_URL = environment.API_URL + '/api/snooze';

export const LOAD_USER_ARBORESCENCE_URL = environment.API_URL + '/api/nodes/config';

export const LOAD_GROUPS_URL = environment.API_URL + '/api/usergroups';

export const LOAD_TEMPLATES_URL = environment.API_URL + '/api/templates';

export const INTERVAL = 60000; // 60 * 1000
export const PULLER_INTERVAL = 60000;
