import { TestBed } from '@angular/core/testing';
import { META_TYPE } from 'core/store/notifications/notifications.model';
import { SnoozeLeaf } from 'core/store/snooze/snooze.model';
import merge from 'lodash/merge';
import moment from 'moment';
import { configureTestSuite } from 'ng-bullet';
import { HatchedBarService } from 'shared/components/hatched-bar/hatched-bar.service';
import { Leaf } from 'shared/models/leaf.model';
import { Meta, MetaState } from 'shared/models/meta.model';
import { Node } from 'shared/models/node.model';
import { ApiNodesService } from '../api/api.nodes';
import { LEAVES_METAS_URL } from '../http/http-client.service';
import { HierarchyService } from './hierarchy.service';

describe('HierarchyService', () => {
  let service: HierarchyService;

  const createNode = ( node?: Partial<Node> ): Node => merge(new Node, node);
  const createLeaf = ( leaf?: Partial<Leaf> ): Leaf => merge(new Leaf, leaf);
  const createMeta = ( meta?: Partial<Meta> ): Meta => ({
    metaType: 'metaType',
    value:    1,
    date:     2,
    state:    MetaState.NO,
    source:   [],
    weight:   3,
    timeBox:  {
      startDate:  4,
      endDate:    5,
      resolution: 6,
    },
    ...meta,
  })

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [
        HierarchyService,
        { provide: ApiNodesService, useFactory: () => ({}) },
        // { provide: DateTimeService, useFactory: () => jasmine.createSpyObj('DateTimeService', ['getNowUnix', 'getNow', 'getMomentInstance', 'subtractFromUnixTime', 'addFromUnixTime', 'getRoundedTimeDownInMinutes', 'isDurationGreaterThanInMinutes', 'getAmountOfTimeInMinutes']) },
        // { provide: HatchedBarService, useFactory: () => jasmine.createSpyObj('HatchedBarService', ['initHatchedBar', 'initHatchedBarWithEndDate']) },
      ],
    })
  });

  beforeEach(() => {
    jasmine.clock().install();
    jasmine.clock().mockDate(new Date(2000, 6, 15));
    service = TestBed.get(HierarchyService);
  } );

  afterEach(() => {
    jasmine.clock().uninstall();
  })

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  describe('#getLeavesKeys', () => {

    it('should return the keys of all the leaves in the provided nodes and their descendants', () => {
      const nodes = [
        createNode({
          key: 'rootNode1',
          nodes: null,
          leaves: null,
        }),
        createNode({
          key: 'rootNode2',
          nodes: [ createNode({
            key: 'innerNode',
            leaves: [
              createLeaf({
                key: 'innerLeaf1',
              }),
              createLeaf({
                key: 'innerLeaf2',
              }),
            ]
          }) ],
          leaves: [
            createLeaf({
              key: 'rootLeaf',
            })
          ]
        })
      ];

      const keys = service.getLeavesKeys(nodes);

      expect(keys).toEqual(jasmine.arrayWithExactContents(['innerLeaf1', 'innerLeaf2', 'rootLeaf']));
    });

    it('should return a list of unique values', () => {
      const nodes = [
        createNode({
          leaves: [
            createLeaf({ key: 'leaf' }),
            createLeaf({ key: 'leaf' }),
            createLeaf({ key: 'leaf2' }),
          ]
        })
      ];

      const keys = service.getLeavesKeys(nodes);

      expect(keys).toEqual(jasmine.arrayWithExactContents(['leaf', 'leaf2']));
    });

  });

  describe('#populateMetas', () => {

    it('should copy the metas from the leaves provided to the leaves of the nodes provided', () => {
      const nodes = [
        createNode({
          nodes: [
            createNode({
              leaves: [ createLeaf({ key: 'leaf' }) ],
            }),
          ],
        }),
      ];
      const leaves = [ createLeaf({
        key: 'leaf',
        metas: [ createMeta() ],
      }) ];

      service.populateMetas( nodes, leaves, { leaves: {} }, [] );

      expect(nodes).toEqual([
        createNode({
          nodes: [
            createNode({
              leaves: [ createLeaf({
                key: 'leaf',
                metas: [ createMeta() ],
              }) ],
            }),
          ],
        }),
      ]);
    });

    it('should reset the metadata of all nodes', () => {
      const nodes = [
        createNode({
          nbAlert: 1,
          nodes: [
            createNode({ nbAlert: 1 }),
          ]
        }),
      ];

      service.populateMetas( nodes, [], { leaves: {} }, [] );

      expect(nodes).toEqual([
        createNode({
          nbAlert: 0,
          nodes: [
            createNode({ nbAlert: 0 }),
          ]
        }),
      ]);
    });

    it('should update the metadata of all leaves with metas', () => {
      const nodes = [
        createNode({
          leaves: [
            createLeaf({
              lastTimeAvailability: createMeta(),
              lastTimePerformance: createMeta(),
              lastTimeFeeling: createMeta(),
              lastTimeRisk: createMeta(),
              firstAvailabilityTimeKO: 1,
              firstPerformanceTimeKO: 1,
              firstFeelingTimeKO: 1,
              firstRiskTimeKO: 1,
              hasAlert: true,
              metas: [ createMeta() ],
            }),
          ],
        }),
      ];

      service.populateMetas( nodes, [], { leaves: {} }, [] );

      expect(nodes).toEqual([
        createNode({
          leaves: [
            createLeaf({
              metas: [ createMeta() ],
            }),
          ]
        }),
      ]);
    });

    it('should update the metadata of all leaves with no more meta', () => {
      const nodes = [
        createNode({
          leaves: [
            createLeaf({
              key: 'leaf',
              lastTimeAvailability: createMeta(),
              lastTimePerformance: createMeta(),
              lastTimeFeeling: createMeta(),
              lastTimeRisk: createMeta(),
              firstAvailabilityTimeKO: 1,
              firstPerformanceTimeKO: 1,
              firstFeelingTimeKO: 1,
              firstRiskTimeKO: 1,
              hasAlert: true,
              metas: [ createMeta() ],
            }),
          ],
        }),
      ];
      const leaves = [ createLeaf({ key: 'leaf' }) ];

      service.populateMetas( nodes, leaves, { leaves: {} }, [] );

      expect(nodes).toEqual([
        createNode({
          leaves: [
            createLeaf({ key: 'leaf' }),
          ]
        }),
      ]);
    });

    it('should update the lastTime[metatype] metadata with the most recent meta of type [metatype] within the last 35 minutes included', () => {
      jasmine.clock().mockDate(new Date(2000, 6, 15));
      const endTime = new Date(2000, 6, 15).valueOf();
      const minutes35 = 35 * 60 * 1000;
      const nodes = [
        createNode({
          leaves: [
            createLeaf({ key: 'leaf' }),
          ],
        }),
      ];
      const leaves = [
        createLeaf({
          key: 'leaf',
          metas: [
            createMeta({ metaType: META_TYPE.AVAILABILITY, date: endTime }),
            createMeta({ metaType: META_TYPE.PERFORMANCE , date: endTime }),
            createMeta({ metaType: META_TYPE.USER_XP     , date: endTime }),
            createMeta({ metaType: META_TYPE.RISK        , date: endTime }),
          ]
        })
      ];

      service.populateMetas( nodes, leaves, { leaves: {} }, [] );

      expect(nodes).toEqual([
        createNode({
          leaves: [
            createLeaf({
              key: 'leaf',
              lastTimeAvailability: createMeta({ metaType: META_TYPE.AVAILABILITY, date: endTime }),
              lastTimePerformance:  createMeta({ metaType: META_TYPE.PERFORMANCE , date: endTime }),
              lastTimeFeeling:      createMeta({ metaType: META_TYPE.USER_XP     , date: endTime }),
              lastTimeRisk:         createMeta({ metaType: META_TYPE.RISK        , date: endTime }),
              metas: [
                createMeta({ metaType: META_TYPE.AVAILABILITY, date: endTime }),
                createMeta({ metaType: META_TYPE.PERFORMANCE , date: endTime }),
                createMeta({ metaType: META_TYPE.USER_XP     , date: endTime }),
                createMeta({ metaType: META_TYPE.RISK        , date: endTime }),
              ]
            }),
          ],
        }),
      ]);

      jasmine.clock().tick( minutes35 - 1 );
      service.populateMetas( nodes, leaves, { leaves: {} }, [] );

      expect(nodes).toEqual([
        createNode({
          leaves: [
            createLeaf({
              key: 'leaf',
              lastTimeAvailability: createMeta({ metaType: META_TYPE.AVAILABILITY, date: endTime }),
              lastTimePerformance:  createMeta({ metaType: META_TYPE.PERFORMANCE , date: endTime }),
              lastTimeFeeling:      createMeta({ metaType: META_TYPE.USER_XP     , date: endTime }),
              lastTimeRisk:         createMeta({ metaType: META_TYPE.RISK        , date: endTime }),
              metas: [
                createMeta({ metaType: META_TYPE.AVAILABILITY, date: endTime }),
                createMeta({ metaType: META_TYPE.PERFORMANCE , date: endTime }),
                createMeta({ metaType: META_TYPE.USER_XP     , date: endTime }),
                createMeta({ metaType: META_TYPE.RISK        , date: endTime }),
              ]
            }),
          ],
        }),
      ]);

      jasmine.clock().tick( 1 );
      service.populateMetas( nodes, leaves, { leaves: {} }, [] );

      expect(nodes).toEqual([
        createNode({
          leaves: [
            createLeaf({
              key: 'leaf',
              metas: [
                createMeta({ metaType: META_TYPE.AVAILABILITY, date: endTime }),
                createMeta({ metaType: META_TYPE.PERFORMANCE , date: endTime }),
                createMeta({ metaType: META_TYPE.USER_XP     , date: endTime }),
                createMeta({ metaType: META_TYPE.RISK        , date: endTime }),
              ]
            }),
          ],
        }),
      ]);

    });

    describe('should update the first[metatype]TimeKO metadata with the startdate of the first meta of the last series of KO meta if the last known meta that ended in the last 35 minutes is KO', () => {

      // The detection starts (HatchedBarService.TIME_TO_AVOID_GREY_BARS seconds = 5 minutes) before the current time.
      // Therefore, all constructed metas and expected dates are offsetted by this amount.

      function constructMetas( marbles: string, time: moment.Moment, metaType: META_TYPE ) {
        const KO = metaType === META_TYPE.RISK ? MetaState.NOK : MetaState.KO;
        marbles = marbles.replace( /(\d+)(.)/g, (_, times, type) => Array(Number(times)).fill(type).join('') );
        marbles = marbles.replace( /\s+/g, '' );
        time.subtract(HatchedBarService.TIME_TO_AVOID_GREY_BARS, 'seconds');
        time.subtract(marbles.length, 'minutes');
        return marbles.split('').map( marble => {
          const dateInfos = { timeBox: { startDate: time.unix(), endDate: time.add(1, 'minute').unix(), resolution: 1 }, date: time.valueOf() };
          switch(marble) {
            case 'r': return createMeta({ metaType, state: KO,           ...dateInfos });
            case 'g': return createMeta({ metaType, state: MetaState.OK, ...dateInfos });
          }
        } ).filter( meta => Boolean(meta) );
      }

      // at this point the meta should be sorted by date descending
      function sortMetas( metaA: Meta, metaB: Meta ) {
        return metaB.date - metaA.date
      }

      // LEGEND :
      // [       : start of meta detection
      // ]       : end of meta detection
      // -       : NO meta
      // r       : KO meta
      // g       : OK meta
      // 0-9     : repeater, prefix a meta, repeat that meta the number of times specified
      //           ex: `3r` is equivalent to `rrr`
      // (space) : no meanings, can be used to space things for readability
      // ^       : prefix the meta that should be selected for putting its startdate in first[metatype]TimeKO
      //           if it prefix a repeater, the selected meta is the first of the series
      //           ex: `--^3r-` is equivalent to `--^rrr` and the first `r` is marked as selected
      // ->      : indicates that the set of data generated by the metas on the left of the arrow are used as
      //           starting values for the set of data generated by the meta on the right of the arrow
      //
      // (note: bars can be placed outside the range delimited by `[` and `]`. This means that the meta
      // represented by the bar is outside the range of metas that barsInfos represent)

      it('[]----r -> []r should set the metadata to 0 if the last and only series of KO meta is within the last 5 minutes', () => {
        jasmine.clock().mockDate(new Date(2000, 6, 15));
        const nodes = [
          createNode({
            leaves: [
              createLeaf({
                key: 'leaf',
              }),
            ],
          }),
        ];
        const leaves = [
          createLeaf({
            key: 'leaf',
            metas: [
              ...constructMetas('r', moment().add(5, 'minutes'), META_TYPE.AVAILABILITY),
              ...constructMetas('r', moment().add(5, 'minutes'), META_TYPE.PERFORMANCE),
              ...constructMetas('r', moment().add(5, 'minutes'), META_TYPE.USER_XP),
              ...constructMetas('r', moment().add(5, 'minutes'), META_TYPE.RISK),
            ].sort(sortMetas),
          })
        ]

        // []----r
        service.populateMetas( nodes, leaves, { leaves: {} }, [ { leafKey: 'leaf', metas: { availability: true, performance: true, risk: true, userXp: true } } ] );

        expect(nodes[0].leaves[0]).toEqual(jasmine.objectContaining<Leaf>({
          firstAvailabilityTimeKO: 0,
          firstFeelingTimeKO:      0,
          firstPerformanceTimeKO:  0,
          firstRiskTimeKO:         0,
        }));

        jasmine.clock().tick( 5 * 60 * 1000 - 1 );
        // []r
        service.populateMetas( nodes, leaves, { leaves: {} }, [ { leafKey: 'leaf', metas: { availability: true, performance: true, risk: true, userXp: true } } ] );

        expect(nodes[0].leaves[0]).toEqual(jasmine.objectContaining<Leaf>({
          firstAvailabilityTimeKO: 0,
          firstFeelingTimeKO:      0,
          firstPerformanceTimeKO:  0,
          firstRiskTimeKO:         0,
        }));

        jasmine.clock().tick( 1 );
        // [r]
        service.populateMetas( nodes, leaves, { leaves: {} }, [ { leafKey: 'leaf', metas: { availability: true, performance: true, risk: true, userXp: true } } ] );

        expect(nodes[0].leaves[0]).not.toEqual(jasmine.objectContaining<Leaf>({
          firstAvailabilityTimeKO: 0,
          firstFeelingTimeKO:      0,
          firstPerformanceTimeKO:  0,
          firstRiskTimeKO:         0,
        }));
      });

      it('[r 30-] should leave the metadata to 0 if the last KO meta is not within the last 35 minutes', () => {
        jasmine.clock().mockDate(new Date(2000, 6, 15));
        const nodes = [
          createNode({
            leaves: [
              createLeaf({
                key: 'leaf',
              }),
            ],
          }),
        ];
        const leaves = [
          createLeaf({
            key: 'leaf',
            metas: [
              ...constructMetas('r 30-', moment(), META_TYPE.AVAILABILITY),
              ...constructMetas('r 30-', moment(), META_TYPE.PERFORMANCE),
              ...constructMetas('r 30-', moment(), META_TYPE.USER_XP),
              ...constructMetas('r 30-', moment(), META_TYPE.RISK),
            ].sort(sortMetas),
          })
        ]

        service.populateMetas( nodes, leaves, { leaves: {} }, [ { leafKey: 'leaf', metas: { availability: true, performance: true, risk: true, userXp: true } } ] );

        expect(nodes[0].leaves[0]).toEqual(jasmine.objectContaining<Leaf>({
          firstAvailabilityTimeKO: 0,
          firstFeelingTimeKO:      0,
          firstPerformanceTimeKO:  0,
          firstRiskTimeKO:         0,
        }));
      });

      it('[rg] -> [rg-] should leave the metadata to 0 if the last known meta is OK', () => {
        jasmine.clock().mockDate(new Date(2000, 6, 15));
        const nodes = [
          createNode({
            leaves: [
              createLeaf({
                key: 'leaf',
              }),
            ],
          }),
        ];
        const leaves = [
          createLeaf({
            key: 'leaf',
            metas: [
              ...constructMetas('rg', moment(), META_TYPE.AVAILABILITY),
              ...constructMetas('rg', moment(), META_TYPE.PERFORMANCE),
              ...constructMetas('rg', moment(), META_TYPE.USER_XP),
              ...constructMetas('rg', moment(), META_TYPE.RISK),
            ].sort(sortMetas),
          })
        ]

        service.populateMetas( nodes, leaves, { leaves: {} }, [ { leafKey: 'leaf', metas: { availability: true, performance: true, risk: true, userXp: true } } ] );

        expect(nodes[0].leaves[0]).toEqual(jasmine.objectContaining<Leaf>({
          firstAvailabilityTimeKO: 0,
          firstFeelingTimeKO:      0,
          firstPerformanceTimeKO:  0,
          firstRiskTimeKO:         0,
        }));

        jasmine.clock().tick( 1 * 60 * 1000 );
        service.populateMetas( nodes, leaves, { leaves: {} }, [ { leafKey: 'leaf', metas: { availability: true, performance: true, risk: true, userXp: true } } ] );

        expect(nodes[0].leaves[0]).toEqual(jasmine.objectContaining<Leaf>({
          firstAvailabilityTimeKO: 0,
          firstFeelingTimeKO:      0,
          firstPerformanceTimeKO:  0,
          firstRiskTimeKO:         0,
        }));
      });

      it('[^300r] -> [^271r 29-] if all metas are KO, should set the isAllBarGraphKO flag to true and set the metadata to the first KO meta known', () => {
        jasmine.clock().mockDate(new Date(2000, 6, 15));
        const nodes = [
          createNode({
            leaves: [
              createLeaf({
                key: 'leaf',
              }),
            ],
          }),
        ];
        const leaves = [
          createLeaf({
            key: 'leaf',
            metas: [
              ...constructMetas('300r', moment(), META_TYPE.AVAILABILITY),
              ...constructMetas('300r', moment(), META_TYPE.PERFORMANCE),
              ...constructMetas('300r', moment(), META_TYPE.USER_XP),
              ...constructMetas('300r', moment(), META_TYPE.RISK),
            ].sort(sortMetas),
          })
        ];

        service.populateMetas( nodes, leaves, { leaves: {} }, [ { leafKey: 'leaf', metas: { availability: true, performance: true, risk: true, userXp: true } } ] );

        expect(nodes[0].leaves[0]).toEqual(jasmine.objectContaining<Leaf>({
          isAllBarGraphKO: { availability: true, performance: true, risk: true, userXp: true },
          firstAvailabilityTimeKO: new Date(2000, 6, 15, 0, -300, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstFeelingTimeKO:      new Date(2000, 6, 15, 0, -300, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstPerformanceTimeKO:  new Date(2000, 6, 15, 0, -300, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstRiskTimeKO:         new Date(2000, 6, 15, 0, -300, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
        }));

        jasmine.clock().tick( 29 * 60 * 1000 );
        service.populateMetas( nodes, leaves, { leaves: {} }, [ { leafKey: 'leaf', metas: { availability: true, performance: true, risk: true, userXp: true } } ] );

        expect(nodes[0].leaves[0]).toEqual(jasmine.objectContaining<Leaf>({
          isAllBarGraphKO: { availability: true, performance: true, risk: true, userXp: true },
          firstAvailabilityTimeKO: new Date(2000, 6, 15, 0, -271, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstFeelingTimeKO:      new Date(2000, 6, 15, 0, -271, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstPerformanceTimeKO:  new Date(2000, 6, 15, 0, -271, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstRiskTimeKO:         new Date(2000, 6, 15, 0, -271, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
        }));
      });

      it('[^300r] -> [270r 30-] if all metas are KO but no new data comes for the next 30 minutes, should reset the metadata and the isAllBarGraphKO flag', () => {
        jasmine.clock().mockDate(new Date(2000, 6, 15));
        const nodes = [
          createNode({
            leaves: [
              createLeaf({
                key: 'leaf',
              }),
            ],
          }),
        ];
        const leaves = [
          createLeaf({
            key: 'leaf',
            metas: [
              ...constructMetas('300r', moment(), META_TYPE.AVAILABILITY),
              ...constructMetas('300r', moment(), META_TYPE.PERFORMANCE),
              ...constructMetas('300r', moment(), META_TYPE.USER_XP),
              ...constructMetas('300r', moment(), META_TYPE.RISK),
            ].sort(sortMetas),
          })
        ];

        service.populateMetas( nodes, leaves, { leaves: {} }, [ { leafKey: 'leaf', metas: { availability: true, performance: true, risk: true, userXp: true } } ] );

        expect(nodes[0].leaves[0]).toEqual(jasmine.objectContaining<Leaf>({
          isAllBarGraphKO: { availability: true, performance: true, risk: true, userXp: true },
          firstAvailabilityTimeKO: new Date(2000, 6, 15, 0, -300, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstFeelingTimeKO:      new Date(2000, 6, 15, 0, -300, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstPerformanceTimeKO:  new Date(2000, 6, 15, 0, -300, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstRiskTimeKO:         new Date(2000, 6, 15, 0, -300, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
        }));

        jasmine.clock().tick( 30 * 60 * 1000 );
        service.populateMetas( nodes, leaves, { leaves: {} }, [ { leafKey: 'leaf', metas: { availability: true, performance: true, risk: true, userXp: true } } ] );

        expect(nodes[0].leaves[0]).toEqual(jasmine.objectContaining<Leaf>({
          isAllBarGraphKO: { availability: false, performance: false, risk: false, userXp: false },
          firstAvailabilityTimeKO: 0,
          firstFeelingTimeKO:      0,
          firstPerformanceTimeKO:  0,
          firstRiskTimeKO:         0,
        }));
      });

      it('[-^r] -> [-^r-] should set the metadata to the first KO meta of the last series of KO meta if some meta are KO', () => {
        jasmine.clock().mockDate(new Date(2000, 6, 15));
        const nodes = [
          createNode({
            leaves: [
              createLeaf({
                key: 'leaf',
              }),
            ],
          }),
        ];
        const leaves = [
          createLeaf({
            key: 'leaf',
            metas: [
              ...constructMetas('r', moment(), META_TYPE.AVAILABILITY),
              ...constructMetas('r', moment(), META_TYPE.PERFORMANCE),
              ...constructMetas('r', moment(), META_TYPE.USER_XP),
              ...constructMetas('r', moment(), META_TYPE.RISK),
            ].sort(sortMetas),
          })
        ];

        service.populateMetas( nodes, leaves, { leaves: {} }, [ { leafKey: 'leaf', metas: { availability: true, performance: true, risk: true, userXp: true } } ] );

        expect(nodes[0].leaves[0]).toEqual(jasmine.objectContaining<Leaf>({
          firstAvailabilityTimeKO: new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstFeelingTimeKO:      new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstPerformanceTimeKO:  new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstRiskTimeKO:         new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
        }));

        jasmine.clock().tick( 1 * 60 * 1000 );
        service.populateMetas( nodes, leaves, { leaves: {} }, [ { leafKey: 'leaf', metas: { availability: true, performance: true, risk: true, userXp: true } } ] );

        expect(nodes[0].leaves[0]).toEqual(jasmine.objectContaining<Leaf>({
          firstAvailabilityTimeKO: new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstFeelingTimeKO:      new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstPerformanceTimeKO:  new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstRiskTimeKO:         new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
        }));
      });

      it('[g-^r] -> [g-^r-] should set the metadata to the first KO meta of the last series of KO meta if some meta are KO', () => {
        jasmine.clock().mockDate(new Date(2000, 6, 15));
        const nodes = [
          createNode({
            leaves: [
              createLeaf({
                key: 'leaf',
              }),
            ],
          }),
        ];
        const leaves = [
          createLeaf({
            key: 'leaf',
            metas: [
              ...constructMetas('g-r', moment(), META_TYPE.AVAILABILITY),
              ...constructMetas('g-r', moment(), META_TYPE.PERFORMANCE),
              ...constructMetas('g-r', moment(), META_TYPE.USER_XP),
              ...constructMetas('g-r', moment(), META_TYPE.RISK),
            ].sort(sortMetas),
          })
        ];

        service.populateMetas( nodes, leaves, { leaves: {} }, [ { leafKey: 'leaf', metas: { availability: true, performance: true, risk: true, userXp: true } } ] );

        expect(nodes[0].leaves[0]).toEqual(jasmine.objectContaining<Leaf>({
          firstAvailabilityTimeKO: new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstFeelingTimeKO:      new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstPerformanceTimeKO:  new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstRiskTimeKO:         new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
        }));

        jasmine.clock().tick( 1 * 60 * 1000 );
        service.populateMetas( nodes, leaves, { leaves: {} }, [ { leafKey: 'leaf', metas: { availability: true, performance: true, risk: true, userXp: true } } ] );

        expect(nodes[0].leaves[0]).toEqual(jasmine.objectContaining<Leaf>({
          firstAvailabilityTimeKO: new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstFeelingTimeKO:      new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstPerformanceTimeKO:  new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstRiskTimeKO:         new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
        }));
      });

      it('[-g^r] -> [-g^r-] should set the metadata to the first KO meta of the last series of KO meta if some meta are KO', () => {
        jasmine.clock().mockDate(new Date(2000, 6, 15));
        const nodes = [
          createNode({
            leaves: [
              createLeaf({
                key: 'leaf',
              }),
            ],
          }),
        ];
        const leaves = [
          createLeaf({
            key: 'leaf',
            metas: [
              ...constructMetas('gr', moment(), META_TYPE.AVAILABILITY),
              ...constructMetas('gr', moment(), META_TYPE.PERFORMANCE),
              ...constructMetas('gr', moment(), META_TYPE.USER_XP),
              ...constructMetas('gr', moment(), META_TYPE.RISK),
            ].sort(sortMetas),
          })
        ];

        service.populateMetas( nodes, leaves, { leaves: {} }, [ { leafKey: 'leaf', metas: { availability: true, performance: true, risk: true, userXp: true } } ] );

        expect(nodes[0].leaves[0]).toEqual(jasmine.objectContaining<Leaf>({
          firstAvailabilityTimeKO: new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstFeelingTimeKO:      new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstPerformanceTimeKO:  new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstRiskTimeKO:         new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
        }));

        jasmine.clock().tick( 1 * 60 * 1000 );
        service.populateMetas( nodes, leaves, { leaves: {} }, [ { leafKey: 'leaf', metas: { availability: true, performance: true, risk: true, userXp: true } } ] );

        expect(nodes[0].leaves[0]).toEqual(jasmine.objectContaining<Leaf>({
          firstAvailabilityTimeKO: new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstFeelingTimeKO:      new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstPerformanceTimeKO:  new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstRiskTimeKO:         new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
        }));
      });

      it('[299g^r] -> [298g^r-] should set the metadata to the first KO meta of the last series of KO meta if some meta are KO', () => {
        jasmine.clock().mockDate(new Date(2000, 6, 15));
        const nodes = [
          createNode({
            leaves: [
              createLeaf({
                key: 'leaf',
              }),
            ],
          }),
        ];
        const leaves = [
          createLeaf({
            key: 'leaf',
            metas: [
              ...constructMetas('299gr', moment(), META_TYPE.AVAILABILITY),
              ...constructMetas('299gr', moment(), META_TYPE.PERFORMANCE),
              ...constructMetas('299gr', moment(), META_TYPE.USER_XP),
              ...constructMetas('299gr', moment(), META_TYPE.RISK),
            ].sort(sortMetas),
          })
        ];

        service.populateMetas( nodes, leaves, { leaves: {} }, [ { leafKey: 'leaf', metas: { availability: true, performance: true, risk: true, userXp: true } } ] );

        expect(nodes[0].leaves[0]).toEqual(jasmine.objectContaining<Leaf>({
          firstAvailabilityTimeKO: new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstFeelingTimeKO:      new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstPerformanceTimeKO:  new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstRiskTimeKO:         new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
        }));

        jasmine.clock().tick( 1 * 60 * 1000 );
        service.populateMetas( nodes, leaves, { leaves: {} }, [ { leafKey: 'leaf', metas: { availability: true, performance: true, risk: true, userXp: true } } ] );

        expect(nodes[0].leaves[0]).toEqual(jasmine.objectContaining<Leaf>({
          firstAvailabilityTimeKO: new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstFeelingTimeKO:      new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstPerformanceTimeKO:  new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstRiskTimeKO:         new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
        }));
      });

      it('[298g-^r] -> [297g-^r-] should set the metadata to the first KO meta of the last series of KO meta if some meta are KO', () => {
        jasmine.clock().mockDate(new Date(2000, 6, 15));
        const nodes = [
          createNode({
            leaves: [
              createLeaf({
                key: 'leaf',
              }),
            ],
          }),
        ];
        const leaves = [
          createLeaf({
            key: 'leaf',
            metas: [
              ...constructMetas('298g-r', moment(), META_TYPE.AVAILABILITY),
              ...constructMetas('298g-r', moment(), META_TYPE.PERFORMANCE),
              ...constructMetas('298g-r', moment(), META_TYPE.USER_XP),
              ...constructMetas('298g-r', moment(), META_TYPE.RISK),
            ].sort(sortMetas),
          })
        ];

        service.populateMetas( nodes, leaves, { leaves: {} }, [ { leafKey: 'leaf', metas: { availability: true, performance: true, risk: true, userXp: true } } ] );

        expect(nodes[0].leaves[0]).toEqual(jasmine.objectContaining<Leaf>({
          firstAvailabilityTimeKO: new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstFeelingTimeKO:      new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstPerformanceTimeKO:  new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstRiskTimeKO:         new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
        }));

        jasmine.clock().tick( 1 * 60 * 1000 );
        service.populateMetas( nodes, leaves, { leaves: {} }, [ { leafKey: 'leaf', metas: { availability: true, performance: true, risk: true, userXp: true } } ] );

        expect(nodes[0].leaves[0]).toEqual(jasmine.objectContaining<Leaf>({
          firstAvailabilityTimeKO: new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstFeelingTimeKO:      new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstPerformanceTimeKO:  new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
          firstRiskTimeKO:         new Date(2000, 6, 15, 0, -1, -HatchedBarService.TIME_TO_AVOID_GREY_BARS).valueOf(),
        }));
      });

    });

    it('[]----r -> [r 30-] should set the hasAlert flag if a meta is KO within the last 35 minutes included', () => {
      jasmine.clock().mockDate(new Date(2000, 6, 15));
      const startDate = new Date(2000, 6, 15, 0, -1).valueOf() / 1000;
      const endDate = new Date(2000, 6, 15, 0, 0).valueOf() / 1000;
      const minutes35 = 35 * 60 * 1000;
      const nodes = [
        createNode({
          leaves: [
            createLeaf({ key: META_TYPE.AVAILABILITY }),
            createLeaf({ key: META_TYPE.PERFORMANCE  }),
            createLeaf({ key: META_TYPE.USER_XP      }),
            createLeaf({ key: META_TYPE.RISK         }),
          ],
        }),
      ];
      const leaves = [
        createLeaf({
          key: META_TYPE.AVAILABILITY,
          metas: [
            createMeta({ metaType: META_TYPE.AVAILABILITY, date: endDate * 1000, timeBox: { startDate, endDate, resolution: 1 }, state: MetaState.KO  }),
          ]
        }),
        createLeaf({
          key: META_TYPE.PERFORMANCE,
          metas: [
            createMeta({ metaType: META_TYPE.PERFORMANCE , date: endDate * 1000, timeBox: { startDate, endDate, resolution: 1 }, state: MetaState.KO  }),
          ]
        }),
        createLeaf({
          key: META_TYPE.USER_XP,
          metas: [
            createMeta({ metaType: META_TYPE.USER_XP     , date: endDate * 1000, timeBox: { startDate, endDate, resolution: 1 }, state: MetaState.KO  }),
          ]
        }),
        createLeaf({
          key: META_TYPE.RISK,
          metas: [
            createMeta({ metaType: META_TYPE.RISK        , date: endDate * 1000, timeBox: { startDate, endDate, resolution: 1 }, state: MetaState.NOK }),
          ]
        }),
      ];

      service.populateMetas( nodes, leaves, { leaves: {} }, [ { leafKey: 'leaf', metas: { availability: true, performance: true, risk: true, userXp: true } } ] );

      expect(nodes[0].leaves.map( ({key, hasAlert}) => ({key, hasAlert}) )).toEqual(jasmine.arrayWithExactContents([
        { key: META_TYPE.AVAILABILITY, hasAlert: true },
        { key: META_TYPE.PERFORMANCE , hasAlert: true },
        { key: META_TYPE.USER_XP     , hasAlert: true },
        { key: META_TYPE.RISK        , hasAlert: true },
      ]));

      jasmine.clock().tick( minutes35 - 1 );
      service.populateMetas( nodes, leaves, { leaves: {} }, [ { leafKey: 'leaf', metas: { availability: true, performance: true, risk: true, userXp: true } } ] );

      expect(nodes[0].leaves.map( ({key, hasAlert}) => ({key, hasAlert}) )).toEqual(jasmine.arrayWithExactContents([
        { key: META_TYPE.AVAILABILITY, hasAlert: true },
        { key: META_TYPE.PERFORMANCE , hasAlert: true },
        { key: META_TYPE.USER_XP     , hasAlert: true },
        { key: META_TYPE.RISK        , hasAlert: true },
      ]));

      jasmine.clock().tick( 1 );
      service.populateMetas( nodes, leaves, { leaves: {} }, [ { leafKey: 'leaf', metas: { availability: true, performance: true, risk: true, userXp: true } } ] );

      expect(nodes[0].leaves.map( ({key, hasAlert}) => ({key, hasAlert}) )).toEqual(jasmine.arrayWithExactContents([
        { key: META_TYPE.AVAILABILITY, hasAlert: false },
        { key: META_TYPE.PERFORMANCE , hasAlert: false },
        { key: META_TYPE.USER_XP     , hasAlert: false },
        { key: META_TYPE.RISK        , hasAlert: false },
      ]));

    });

    it('[]----r -> [r 30-] should not set the hasAlert flag if a meta is KO within the last 35 minutes included when the leaf is snoozed', () => {
      jasmine.clock().mockDate(new Date(2000, 6, 15));
      const startDate = new Date(2000, 6, 15, 0, -1).valueOf() / 1000;
      const endDate = new Date(2000, 6, 15, 0, 0).valueOf() / 1000;
      const minutes35 = 35 * 60 * 1000;
      const nodes = [
        createNode({
          leaves: [
            createLeaf({ key: 'leaf' }),
          ],
        }),
      ];
      const leaves = [
        createLeaf({
          key: 'leaf',
          metas: [
            createMeta({ metaType: META_TYPE.AVAILABILITY, date: endDate * 1000, timeBox: { startDate, endDate, resolution: 1 }, state: MetaState.KO }),
            createMeta({ metaType: META_TYPE.PERFORMANCE, date: endDate * 1000, timeBox: { startDate, endDate, resolution: 1 }, state: MetaState.KO }),
            createMeta({ metaType: META_TYPE.RISK, date: endDate * 1000, timeBox: { startDate, endDate, resolution: 1 }, state: MetaState.NOK }),
            createMeta({ metaType: META_TYPE.USER_XP, date: endDate * 1000, timeBox: { startDate, endDate, resolution: 1 }, state: MetaState.KO }),
          ]
        }),
      ];

      service.populateMetas( nodes, leaves, { leaves: { _: [{
        availability: { enabled: true, admin: false }, performance: { enabled: true, admin: false },
        risk: { enabled: true, admin: false }, userXp: { enabled: true, admin: false }, leafId: 'leaf' } as SnoozeLeaf] } }, [ { leafKey: 'leaf', metas: { availability: true, performance: true, risk: true, userXp: true } } ] );

      expect(nodes[0].leaves.map( ({key, hasAlert}) => ({key, hasAlert}) )).toEqual(jasmine.arrayWithExactContents([
        { key: 'leaf', hasAlert: false },
      ]));

      jasmine.clock().tick( minutes35 - 1 );

      service.populateMetas( nodes, leaves, { leaves: { _: [{
        availability: { enabled: true, admin: true }, performance: { enabled: true, admin: false },
        risk: { enabled: true, admin: false }, userXp: { enabled: true, admin: false }, leafId: 'leaf' } as SnoozeLeaf] } }, [ { leafKey: 'leaf', metas: { availability: true, performance: true, risk: true, userXp: true } } ] );

      expect(nodes[0].leaves.map( ({key, hasAlert}) => ({key, hasAlert}) )).toEqual(jasmine.arrayWithExactContents([
        { key: 'leaf', hasAlert: false },
      ]));
    })

  });

  describe('#getLeavesUrl', () => {

    it('should return the url for fetching the leaf of the provided leaveskeys in the time period provided', () => {
      jasmine.clock().mockDate(new Date(2000, 6, 15));

      const url = service.getLeavesUrl('leaf', 60);
      const from = Math.ceil(new Date(2000, 6, 15, 0, -5 -60 -35).valueOf() / 1000);
      const to = Math.ceil(new Date(2000, 6, 15, 0, -5 +35).valueOf() / 1000);

      expect(url).toBe(`${LEAVES_METAS_URL}?leafIds=leaf&from=${from}&to=${to}&interval=1`);

      const urlWithInterval = service.getLeavesUrl('leaf', 60, 5);
      const fromWithInterval = Math.ceil(new Date(2000, 6, 15, 0, -5 -60 -35).valueOf() / 1000);
      const toWithInterval = Math.ceil(new Date(2000, 6, 15, 0, -5 +35).valueOf() / 1000);

      expect(urlWithInterval).toBe(`${LEAVES_METAS_URL}?leafIds=leaf&from=${fromWithInterval}&to=${toWithInterval}&interval=5`);
    });

  });

  describe('#calculatePercents', () => {

    it('should return an object representing the percentage of OK leaf in the nodes provided', () => {
      const nodes = [
        createNode({
          okAvailiblity: 5,
          okPerformance: 5,
          okRisk: 5,
          okFeeling: 5,
          totalAvailiblity: 10,
          totalPerformance: 10,
          totalRisk: 10,
          totalFeeling: 10,
        }),
        createNode({
          okAvailiblity: 5,
          okPerformance: 5,
          okRisk: 5,
          okFeeling: 5,
          totalAvailiblity: 30,
          totalPerformance: 30,
          totalRisk: 30,
          totalFeeling: 30,
        }),
      ];

      expect(service.calculatePercents(nodes)).toEqual({
        availibiltyPercent: 25,
        performancePercent: 25,
        riskPercent: 25,
        feelingPercent: 25,
      })
    });

  });

  describe('#calculateNodesAlerts', () => {

    it('should recursively update all nodes metadata with their leaf metadata', () => {
      const nodes = [
        createNode({
          nodes: [
            createNode({
              leaves: [
                createLeaf({
                  key: 'leaf1',
                  hasAlert: false,
                  lastTimeAvailability: createMeta({ state: MetaState.OK }),
                  lastTimePerformance: createMeta({ state: MetaState.OK }),
                  lastTimeFeeling: createMeta({ state: MetaState.OK }),
                  lastTimeRisk: createMeta({ state: MetaState.OK }),
                })
              ],
            }),
            createNode({
              leaves: [
                createLeaf({
                  key: 'leaf2',
                  hasAlert: true,
                  lastTimeAvailability: createMeta({ state: MetaState.KO }),
                  lastTimePerformance: createMeta({ state: MetaState.KO }),
                  lastTimeFeeling: createMeta({ state: MetaState.KO }),
                  lastTimeRisk: createMeta({ state: MetaState.NOK }),
                }),
                createLeaf({
                  key: 'leaf3',
                }),
              ],
            }),
          ],
        }),
      ];

      service.calculateNodesAlerts(nodes, { leaves: {} });

      expect(nodes[0]).toEqual(jasmine.objectContaining<Node>({
        nbAlert: 1,
        okAvailiblity: 1,
        okPerformance: 1,
        okRisk: 1,
        okFeeling: 1,
        totalAvailiblity: 2,
        totalPerformance: 2,
        totalRisk: 2,
        totalFeeling: 2,
      }));

      expect(nodes[0].nodes[0]).toEqual(jasmine.objectContaining<Node>({
        nbAlert: 0,
        okAvailiblity: 1,
        okPerformance: 1,
        okRisk: 1,
        okFeeling: 1,
        totalAvailiblity: 1,
        totalPerformance: 1,
        totalRisk: 1,
        totalFeeling: 1,
      }));

      expect(nodes[0].nodes[1]).toEqual(jasmine.objectContaining<Node>({
        nbAlert: 1,
        okAvailiblity: 0,
        okPerformance: 0,
        okRisk: 0,
        okFeeling: 0,
        totalAvailiblity: 1,
        totalPerformance: 1,
        totalRisk: 1,
        totalFeeling: 1,
      }));
    });

    it('should only update metatype metadata once per leaf', () => {
      const nodes = [
        createNode({
          leaves: [
            createLeaf({
              key: 'leaf',
              hasAlert: true,
              lastTimeAvailability: createMeta({ state: MetaState.KO }),
              lastTimePerformance: createMeta({ state: MetaState.KO }),
              lastTimeFeeling: createMeta({ state: MetaState.KO }),
              lastTimeRisk: createMeta({ state: MetaState.NOK }),
            }),
            createLeaf({
              key: 'leaf',
              hasAlert: true,
              lastTimeAvailability: createMeta({ state: MetaState.KO }),
              lastTimePerformance: createMeta({ state: MetaState.KO }),
              lastTimeFeeling: createMeta({ state: MetaState.KO }),
              lastTimeRisk: createMeta({ state: MetaState.NOK }),
            }),
          ],
        }),
      ];

      service.calculateNodesAlerts(nodes, { leaves: {} });

      expect(nodes[0]).toEqual(jasmine.objectContaining<Node>({
        nbAlert: 2, // TODO: check if this behavior is correct (to be fair, a node should not have the same leaf twice as direct children)
        okAvailiblity: 0,
        okPerformance: 0,
        okRisk: 0,
        okFeeling: 0,
        totalAvailiblity: 1,
        totalPerformance: 1,
        totalRisk: 1,
        totalFeeling: 1,
      }));
    });

    it('should not update metadata if the leaf is snoozed', () => {
      const nodes = [
        createNode({
          leaves: [
            createLeaf({
              key: 'leaf',
              hasAlert: true,
              lastTimeAvailability: createMeta({ state: MetaState.KO }),
              lastTimePerformance: createMeta({ state: MetaState.KO }),
              lastTimeFeeling: createMeta({ state: MetaState.KO }),
              lastTimeRisk: createMeta({ state: MetaState.NOK }),
            }),
          ],
        }),
      ];

      service.calculateNodesAlerts(nodes, { leaves: { _ : [ {
        leafId: 'leaf',
        availability: { enabled: true, admin: false },
        performance: { enabled: true, admin: false },
        userXp: { enabled: true, admin: false },
        risk: { enabled: true, admin: false },
      } as SnoozeLeaf ]  } });

      expect(nodes[0]).toEqual(jasmine.objectContaining<Node>({
        nbAlert: 1, // TODO: check if this behavior is correct (to be fair, the hasAlert should not be set on the leaf if it is snoozed)
        okAvailiblity: 0,
        okPerformance: 0,
        okRisk: 0,
        okFeeling: 0,
        totalAvailiblity: 0,
        totalPerformance: 0,
        totalRisk: 0,
        totalFeeling: 0,
      }));
    });

    it('should not update metadata if the node is hidden', () => {
      const nodes = [
        createNode({
          isHiddenOnTree: true,
          leaves: [
            createLeaf({
              key: 'leaf',
              hasAlert: true,
              lastTimeAvailability: createMeta({ state: MetaState.KO }),
              lastTimePerformance: createMeta({ state: MetaState.KO }),
              lastTimeFeeling: createMeta({ state: MetaState.KO }),
              lastTimeRisk: createMeta({ state: MetaState.NOK }),
            }),
          ],
        }),
      ];

      service.calculateNodesAlerts(nodes, { leaves: {} });

      expect(nodes[0]).toEqual(jasmine.objectContaining<Node>({
        nbAlert: 0,
        okAvailiblity: 0,
        okPerformance: 0,
        okRisk: 0,
        okFeeling: 0,
        totalAvailiblity: 0,
        totalPerformance: 0,
        totalRisk: 0,
        totalFeeling: 0,
      }));
    });

  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
