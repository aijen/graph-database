import { Injectable } from '@angular/core';
import { MetasCheck, metasCheckState } from 'core/models/leaves/leaves.model';
import { LEAVES_METAS_URL } from 'core/services/http/http-client.service';
import { META_TYPE } from 'core/store/notifications/notifications.model';
import { PopulatedMetasValue } from 'core/store/populated-metas/populated-metas.model';
import { BANK, SnoozeConfig, SnoozeLeaf } from 'core/store/snooze/snooze.model';
import moment from 'moment';
import { HatchedBarService } from 'shared/components/hatched-bar/hatched-bar.service';
import { Leaf } from 'shared/models/leaf.model';
import { MetaState } from 'shared/models/meta.model';
import { Node } from 'shared/models/node.model';

interface NodeLike {
  nodes?: NodeLike[],
  leaves?: Array<{
    key?: string
  }>;
}

@Injectable({providedIn: 'root'})
export class HierarchyService {

  private static resetComputedMetadataLeaf(leaf: Leaf) {
    leaf.firstAvailabilityTimeKO = 0;
    leaf.firstPerformanceTimeKO = 0;
    leaf.firstFeelingTimeKO = 0;
    leaf.firstRiskTimeKO = 0;
    leaf.isAllBarGraphKO = { ...metasCheckState };
  }

  private static resetComputedMetadata(node: Node) {
    node.nbAlert = 0;
    node.totalAvailiblity = 0;
    node.okAvailiblity = 0;
    node.totalPerformance = 0;
    node.okPerformance = 0;
    node.totalRisk = 0;
    node.okRisk = 0;
    node.totalFeeling = 0;
    node.okFeeling = 0;

    return node;
  }

  private MAX_TIME_RANGE = 300;
  private MAX_TIME_RANGE_TO_CHECK = 35;

  constructor(
    private hatchedBarService: HatchedBarService,
  ){}

  getLeavesKeys<T extends NodeLike>(nodes: T[]): string[] {
    const leavesKeys = new Set<string>();
    nodes.forEach(node => this.extractLeavesKeysFromNode(node, leavesKeys));
    return [...leavesKeys];
  }

  private extractLeavesKeysFromNode<T extends NodeLike>(node: T, leavesIds: Set<string>) {
    if (node.leaves) {
      node.leaves
        .filter(leaf => leaf.key)
        .forEach(leaf => leavesIds.add(leaf.key));
    }
    if (node.nodes) {
      for (let j = 0; j < node.nodes.length; j++) {
        this.extractLeavesKeysFromNode(node.nodes[j], leavesIds);
      }
    }
  }

  populateMetas(nodes: Node[], leaves: Leaf[], config: SnoozeConfig, populatedMetas: PopulatedMetasValue[]): Node[] {
    const snoozeLeaves = (Object.keys( config.leaves ) as BANK[]).reduce( (acc, bank) => [ ...acc, ...config.leaves[bank] ], [] as SnoozeLeaf[] );

    for( const node of nodes )
      this.populateMetasFromNode(node, leaves, snoozeLeaves, node.isHiddenOnTree, populatedMetas)

    return nodes.slice()
  }

  private populateMetasFromNode(node: Node, leaves: Leaf[], snoozeLeaves: SnoozeLeaf[], isHidden: boolean, populatedMetas: PopulatedMetasValue[]) {
    HierarchyService.resetComputedMetadata(node);
    const { leaves: nodeLeaves, nodes: nodeNodes } = node;

    for (const childleaf of nodeLeaves) {
      const leaf = leaves.find(({key}: Leaf) => key === childleaf.key);
      const populatedMeta = populatedMetas.find( _populatedMetas => _populatedMetas.leafKey === childleaf.key )

      if (leaf) {
        childleaf.metas = leaf.metas;
      }

      this.checkIsAlert(childleaf, snoozeLeaves, isHidden || childleaf.isHiddenOnTree, populatedMeta && populatedMeta.metas)
    }

    for (const childnode of nodeNodes)
      this.populateMetasFromNode(childnode, leaves, snoozeLeaves, childnode.isHiddenOnTree || isHidden, populatedMetas);
  }

  getLeavesUrl(leavesKeys: string, /** minutes */ periodTime: number, interval: number=1): string {
    const toDate = moment().subtract(5, 'minutes')
    const fromDate = moment().subtract(5, 'minutes').subtract( periodTime, 'minutes' ).subtract(35, 'minutes')
    return `${LEAVES_METAS_URL}?leafIds=${leavesKeys}&from=${fromDate.unix()}&to=${toDate.unix()}&interval=${interval}`;
  }

  private checkIsAlert(leaf: Leaf, snoozeLeaves: SnoozeLeaf[], isHidden: boolean, populatedMeta: MetasCheck): boolean {
    const snoozeLeaf = snoozeLeaves.find( ( snooze ) => snooze.leafId === leaf.key );
    const timeRange = moment().subtract(this.MAX_TIME_RANGE_TO_CHECK, 'minutes').unix()
    const copyMetasOfLastMinutes = leaf.metas.filter(meta => (meta.date/1000) > timeRange);

    leaf.lastTimeAvailability = copyMetasOfLastMinutes.find(meta => meta.metaType === 'AVAILABILITY');
    leaf.lastTimePerformance = copyMetasOfLastMinutes.find(meta => meta.metaType === 'PERFORMANCE');
    leaf.lastTimeFeeling = copyMetasOfLastMinutes.find(meta => meta.metaType === 'USER_XP');
    leaf.lastTimeRisk = copyMetasOfLastMinutes.find(meta => meta.metaType === 'RISK');

    leaf.hasAlert = Boolean(
        (leaf.lastTimeAvailability && leaf.lastTimeAvailability.state === MetaState.KO && (snoozeLeaf ? !snoozeLeaf.availability.enabled : true) && !isHidden) ||
        (leaf.lastTimePerformance && leaf.lastTimePerformance.state === MetaState.KO && (snoozeLeaf ? !snoozeLeaf.performance.enabled : true) && !isHidden) ||
        (leaf.lastTimeRisk && leaf.lastTimeRisk.state === MetaState.NOK && (snoozeLeaf ? !snoozeLeaf.risk.enabled : true) && !isHidden) ||
        (leaf.lastTimeFeeling && leaf.lastTimeFeeling.state === MetaState.KO && (snoozeLeaf ? !snoozeLeaf.userXp.enabled : true) && !isHidden)
      );

    HierarchyService.resetComputedMetadataLeaf(leaf);

    if (leaf.lastTimeAvailability && leaf.lastTimeAvailability.state === MetaState.KO) {
      leaf.firstAvailabilityTimeKO = this.setLeafFirstTimeKOByMetaType(leaf, META_TYPE.AVAILABILITY, populatedMeta);
    }

    if (leaf.lastTimePerformance && leaf.lastTimePerformance.state === MetaState.KO) {
      leaf.firstPerformanceTimeKO = this.setLeafFirstTimeKOByMetaType(leaf, META_TYPE.PERFORMANCE, populatedMeta);
    }

    if (leaf.lastTimeFeeling && leaf.lastTimeFeeling.state === MetaState.KO) {
      leaf.firstFeelingTimeKO = this.setLeafFirstTimeKOByMetaType(leaf, META_TYPE.USER_XP, populatedMeta);
    }

    if (leaf.lastTimeRisk && leaf.lastTimeRisk.state === MetaState.NOK) {
      leaf.firstRiskTimeKO = this.setLeafFirstTimeKOByMetaType(leaf, META_TYPE.RISK, populatedMeta);
    }

    return leaf.hasAlert;
  }

  private setLeafFirstTimeKOByMetaType(leaf: Leaf, metaType: META_TYPE, populatedMeta: MetasCheck): number {

    let timeKO = Number.MAX_VALUE;
    const barsInfos = this.hatchedBarService.initHatchedBar(leaf.metas, metaType, this.MAX_TIME_RANGE, { populatedMeta }).reverse();


    const green = barsInfos.find(info => info.state === MetaState.OK);
    const grey = barsInfos.find(info => info.state === MetaState.NO || info.state === MetaState.STARVE);
    const red = barsInfos.find(info => info.state === MetaState.KO || info.state === MetaState.NOK);

    // no red at all
    if(red == null) {
      timeKO = Number.MAX_VALUE;
    }
    // all red
    else if(green == null && grey == null) {
      leaf.isAllBarGraphKO[this.metaTypeToAdminLeafMetaType(metaType)] = true;
      timeKO = barsInfos[barsInfos.length - 1].begin;
    }
    // (no green) OR (grey after green)
    else if(green == null || (grey != null && grey.begin > green.begin)) {
      if(grey.begin > red.begin) {
        const secondGreyZone = barsInfos.find(info => (info.state === MetaState.NO || info.state === MetaState.STARVE) && info.begin < red.begin);

        if(secondGreyZone == null) {
          leaf.isAllBarGraphKO[this.metaTypeToAdminLeafMetaType(metaType)] = (green == null);
          timeKO = (green == null) ? barsInfos[barsInfos.length - 1].begin : green.end;
        }
        else if(green == null) {
          timeKO = secondGreyZone.end;
        }
        else {
          timeKO = green.begin > secondGreyZone.begin ? green.end : secondGreyZone.end;
        }
      }
      else {
        timeKO = grey.end
      }
    }
    // (no grey) OR (green after grey)
    else {
      timeKO = green.end;
    }

    return timeKO === Number.MAX_VALUE ? 0 : timeKO * 1000;
  }

  private metaTypeToAdminLeafMetaType(metaType: META_TYPE): string {
    switch(metaType) {
      case META_TYPE.AVAILABILITY:
        return 'availability';
      case META_TYPE.PERFORMANCE:
        return 'performance';
      case META_TYPE.RISK:
        return 'risk';
      case META_TYPE.USER_XP:
        return 'userXp';
    }
  }

  private checkAvailiblity(leaf: Leaf, node: Node, snooze: boolean) {
    if (leaf.lastTimeAvailability && !snooze) {
      node.totalAvailiblity++;
      node.okAvailiblity += Number(leaf.lastTimeAvailability.state === MetaState.OK);
    }
  }

  private checkPerformance(leaf: Leaf, node: Node, snooze: boolean) {
    if (leaf.lastTimePerformance && !snooze) {
      node.totalPerformance++;
      node.okPerformance += Number(leaf.lastTimePerformance.state === MetaState.OK);
    }
  }

  private checkRisk(leaf: Leaf, node: Node, snooze: boolean) {
    if (leaf.lastTimeRisk && !snooze) {
      node.totalRisk++;
      node.okRisk += Number(leaf.lastTimeRisk.state === MetaState.OK);
    }
  }

  private checkFeeling(leaf: Leaf, node: Node, snooze: boolean) {
    if (leaf.lastTimeFeeling && !snooze) {
      node.totalFeeling++;
      node.okFeeling += Number(leaf.lastTimeFeeling.state === MetaState.OK);
    }
  }

  calculatePercents(nodes: Node[]) {
    let totalAvailiblity = 0;
    let okAvailiblity = 0;
    let totalPerformance = 0;
    let okPerformance = 0;
    let totalRisk = 0;
    let okRisk = 0;
    let totalFeeling = 0;
    let okFeeling = 0;

    nodes.forEach(node => {
      totalAvailiblity += node.totalAvailiblity;
      okAvailiblity += node.okAvailiblity;
      totalPerformance += node.totalPerformance;
      okPerformance += node.okPerformance;
      totalRisk += node.totalRisk;
      okRisk += node.okRisk;
      totalFeeling += node.totalFeeling;
      okFeeling += node.okFeeling;
    });

    return {
      availibiltyPercent: (okAvailiblity / totalAvailiblity) * 100,
      performancePercent: (okPerformance / totalPerformance) * 100,
      riskPercent: (okRisk / totalRisk) * 100,
      feelingPercent: (okFeeling / totalFeeling) * 100
    };
  }

  calculateNodesAlerts(nodes: Node[], config: SnoozeConfig) {
    const contabilizedLeaf = new Set<string>();
    const snoozeLeaves = (Object.keys( config.leaves ) as BANK[]).reduce( (acc, bank) => [ ...acc, ...config.leaves[bank] ], [] as SnoozeLeaf[] );
    nodes.filter(nd => nd).forEach(node => this.calculateNodeAlerts(node, snoozeLeaves, contabilizedLeaf));
  }

  private calculateNodeAlerts(node: Node, snoozeLeaves: SnoozeLeaf[], contabilizedLeaf: Set<string>) {
    const { nodes, leaves } = node;
    HierarchyService.resetComputedMetadata(node);

    if(node.isHiddenOnTree) return;

    for(const leaf of leaves) {
      if( leaf.hasAlert ) node.nbAlert++;

      const snoozeLeaf = snoozeLeaves.find( ( snooze ) => snooze.leafId === leaf.key );

      if (!contabilizedLeaf.has(leaf.key)) {
        this.checkAvailiblity(leaf, node, snoozeLeaf && snoozeLeaf.availability.enabled);
        this.checkPerformance(leaf, node, snoozeLeaf && snoozeLeaf.performance.enabled);
        this.checkRisk(leaf, node, snoozeLeaf && snoozeLeaf.risk.enabled);
        this.checkFeeling(leaf, node, snoozeLeaf && snoozeLeaf.userXp.enabled);
        contabilizedLeaf.add(leaf.key);
      }
    }

    for(const childNode of nodes) {
      this.calculateNodeAlerts( childNode, snoozeLeaves, contabilizedLeaf );
      node.nbAlert += childNode.nbAlert;
      node.totalAvailiblity += childNode.totalAvailiblity;
      node.okAvailiblity += childNode.okAvailiblity;
      node.totalPerformance += childNode.totalPerformance;
      node.okPerformance += childNode.okPerformance;
      node.totalRisk += childNode.totalRisk;
      node.okRisk += childNode.okRisk;
      node.totalFeeling += childNode.totalFeeling;
      node.okFeeling += childNode.okFeeling;
    }
  }
}
