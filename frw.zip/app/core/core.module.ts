import { HttpClientModule } from '@angular/common/http';
import { NgModule, Optional, SkipSelf } from '@angular/core';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { SharedModule } from 'shared/shared.module';
import { LoadingComponent } from './components/loading/loading.component';
import { AlertIndicatorComponent } from './components/nav-bar/components/alert-indicator/alert-indicator.component';
import { GaugesComponent } from './components/nav-bar/components/gauges/gauges.component';
import { NavBarComponent } from './components/nav-bar/nav-bar.component';
import { MonitoringNotificationComponent } from './components/notifications/components/monitoring-notification/monitoring-notification.component';
import { NotificationComponent } from './components/notifications/components/notification/notification.component';
import { NotificationContainerComponent } from './components/notifications/notifications-container/notifications-container.component';
import { GroupsStoreModule } from './store/groups/groups.module';
import { HierarchyStoreModule } from './store/hierarchy/hierarchy.module';
import { NotificationsEffects } from './store/notifications/notifications.effects';
import { notificationsReducer } from './store/notifications/notifications.reducer';
import { PopulatedMetasStoreModule } from './store/populated-metas/populated-metas.module';
import { SnoozeEffects } from './store/snooze/snooze.effects';
import { snoozeReducer } from './store/snooze/snooze.reducer';
import { TemplatesStoreModule } from './store/templates/templates.module';


@NgModule({
  declarations: [
    NavBarComponent,
    AlertIndicatorComponent,
    GaugesComponent,
    LoadingComponent,
    NotificationComponent,
    NotificationContainerComponent,
    MonitoringNotificationComponent,
  ],
  imports: [
    SharedModule,
    HttpClientModule,
    MatSnackBarModule,
    StoreModule.forFeature('notifications', notificationsReducer),
    EffectsModule.forFeature([NotificationsEffects]),
    HierarchyStoreModule,
    StoreModule.forFeature('snooze', snoozeReducer),
    EffectsModule.forFeature([SnoozeEffects]),
    PopulatedMetasStoreModule,
    TemplatesStoreModule,
    GroupsStoreModule,
  ],
  exports: [NavBarComponent, LoadingComponent, NotificationContainerComponent],
})
export class CoreModule {
  constructor(@Optional() @SkipSelf() coreModule: CoreModule) {
    if (coreModule) {
      throw new Error('Core Module is already imported');
    }
  }
}
