import { Component } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { HierarchyState } from 'core/store/hierarchy/hierarchy.model';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { Observable } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { AppComponent } from './app.component';
/* import { NgbTooltipConfig } from '@ng-bootstrap/ng-bootstrap'; */

@Component({
  selector: 'cockpit-nav-bar',
  template: '',
})
class CockpitNavBarStubComponent {}

@Component({
  selector: 'cockpit-notifications-container',
  template: '',
})
class CockpitNotificationsContainerStubComponent {}

@Component({
  selector: 'cockpit-loading',
  template: '',
})
class CockpitLoadingStubComponent {}

describe('AppComponent', () => {
  let context: TestCtx<AppComponent>;
  let actions: Observable<any>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
      ],
      declarations: [
        AppComponent,
        CockpitNavBarStubComponent,
        CockpitNotificationsContainerStubComponent,
        CockpitLoadingStubComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: { hierarchy: new HierarchyState() } }),
        provideMockActions(() => actions),
        /* { provide: NgbTooltipConfig, useFactory: () => jasmine.createSpyObj('NgbTooltipConfig', [] as Array<keyof NgbTooltipConfig>) }, */
      ],
    })
  });

  beforeEach(async( async () => {
    context = await createStableTestContext(AppComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
