declare type Omit<T, K> = Pick<T, Exclude<keyof T, K>>;

declare type keysOfType<T, U> = {
  [P in keyof T]: T[P] extends U ? P : never;
}[keyof T];

declare type DeepPartial<T> = {
  [P in keyof T]?: DeepPartial<T[P]>;
};
