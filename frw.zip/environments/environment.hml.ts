export const environment = {
  production: true,
  sgSignIn: false,
  API_URL: '/central',
  hmr: false,
  hasMetareducer: false,
  enableTracing: false,
};
