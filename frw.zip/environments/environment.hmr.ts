export const environment = {
  production: false,
  sgSignIn: false,
  API_URL: '',
  hmr: true,
  hasMetareducer: true,
  enableTracing: false,
};
