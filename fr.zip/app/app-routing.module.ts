import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { environment } from 'env/environment';
import { AuthGuard } from 'shared/guards/auth/auth.guard';
import { OnDemandPreloadStrategy } from 'shared/services/onDemandPreloadStrategy';

const routes: Routes = [
  {
    path: 'leaf-detail/:id',
    loadChildren: './pages/details/details.module#DetailsModule',
  },
  {
    path: 'leaf-detail/:id/:graph',
    loadChildren: './pages/details/details.module#DetailsModule',
  },
  {
    path: 'admin',
    loadChildren: './pages/admin/admin.module#AdminModule',
    canActivate: [AuthGuard],
    data: {
      preload: [AuthGuard],
    },
  },
  {
    path: 'synthesis',
    loadChildren: './pages/synthesis/synthesis.module#SynthesisModule',
  },
  {
    path: '',
    loadChildren: './pages/home/home.module#HomeModule',
  },
  {
    path: '**',
    redirectTo: ''
  }
];
@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true, enableTracing: environment.enableTracing, preloadingStrategy: OnDemandPreloadStrategy })],
  exports: [RouterModule],
})
export class AppRoutingModule {}
