import { NgModule } from '@angular/core';
import { Chart } from 'chart.js';
@NgModule({
  imports: [],
  exports: []
})
export class ConfigModule {
  constructor() {
    Chart.helpers.extend(Chart.Scale.prototype, {
      _autoSkip(ticks) {
        let skipRatio;
        const me = this;
        const isHorizontal = me.isHorizontal();
        const optionTicks = me.options.ticks.minor;
        const tickCount = ticks.length;
        const labelRotationRadians = me.labelRotation * (Math.PI / 180);
        const cosRotation = Math.cos(labelRotationRadians);
        const longestRotatedLabel = me.longestLabelWidth * cosRotation;
        const result = [];
        let i, tick, shouldSkip;
        if (isHorizontal) {
          skipRatio = false;
          if (
            (longestRotatedLabel + optionTicks.autoSkipPadding) * tickCount >
            me.width - (me.paddingLeft + me.paddingRight)
          ) {
            skipRatio =
              1 +
              Math.floor(
                ((longestRotatedLabel + optionTicks.autoSkipPadding) *
                  tickCount) /
                  (me.width - (me.paddingLeft + me.paddingRight))
              );
          }
        }
        for (i = 0; i < tickCount; i++) {
          tick = ticks[i];
          shouldSkip = skipRatio > 1 && i % skipRatio > 0;
          if (shouldSkip) {
            delete tick.label;
          }
          result.push(tick);
        }
        return result;
      }
    });
  }
}
