import { Component, OnDestroy, OnInit } from '@angular/core';
import { NgbTooltipConfig } from '@ng-bootstrap/ng-bootstrap';
import { select, Store } from '@ngrx/store';
import { GetUser } from 'core/store/auth/auth.actions';
import { GetHierarchy } from 'core/store/hierarchy/hierarchy.actions';
import { getIsSupervising, isPullerLaunched } from 'core/store/hierarchy/hierarchy.selectors';
import { SubscriptionAwareComponent } from 'core/utils/subscription-aware.component';
import { filter, tap } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';

@Component({
  selector: 'cockpit-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: [NgbTooltipConfig]
})
export class AppComponent extends SubscriptionAwareComponent implements OnInit, OnDestroy {

  public isSupervising$ = this.store$.pipe(select(getIsSupervising));


  constructor(
    private store$: Store<AppState>,
    private config: NgbTooltipConfig
  ) {
    super();
    this.store$.dispatch(new GetUser());
    this.configToolTip();
  }

  ngOnInit(): void {
    this.subscription.add(
      this.store$
      .pipe(
        select(isPullerLaunched),
        filter((isPullerLaunched: boolean) => !isPullerLaunched),
        tap(() => this.onLauchPuller())
      ).subscribe()
    );
  }

  private onLauchPuller(): void {
    this.store$.dispatch(new GetHierarchy());
  }

  private configToolTip() {
    this.config.placement = 'bottom';
    this.config.container = 'body';
  }

}
