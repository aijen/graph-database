import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { select, Store } from '@ngrx/store';
import { FaqComponent } from 'core/components/faq/faq.component';
import { hasAdminScreenAccess } from 'core/store/auth/auth.selectors';
import { AddNode } from 'core/store/hierarchy/hierarchy.actions';
import { getIsSupervising } from 'core/store/hierarchy/hierarchy.selectors';
import { ToggleNotifications } from 'core/store/notifications/notifications.actions';
import { getNotificationOpen } from 'core/store/notifications/notifications.selectors';
import { Node } from 'shared/models/node.model';
import { AppState } from 'shared/models/state.model';

@Component({
  selector: 'cockpit-nav-icons',
  templateUrl: './nav-icons.component.html',
  styleUrls: ['./nav-icons.component.scss']
})
export class NavIconsComponent implements OnInit {

  dropdownIsOpen = false;
  notifOpen$ = this.store$.pipe( select( getNotificationOpen ) );
  isSupervising$ = this.store$.pipe( select( getIsSupervising ) );
  isAdmin$ = this.store$.select(hasAdminScreenAccess);

  constructor(
    public dialog: MatDialog,
    private store$: Store<AppState>,
  ) { }

  ngOnInit() {
  }

  openFAQ() {
    const config = new MatDialogConfig();
    config.width = "80vw";
    config.maxHeight = "100vh";
    config.disableClose = true;

    this.dialog.open(FaqComponent, config);
  }

  toggleDropdown( state = !this.dropdownIsOpen ) {
    this.dropdownIsOpen = state;
  }

  toggleNotifications( state?: boolean ) {
    this.store$.dispatch(new ToggleNotifications(state));
  }

  addNode() {
    const node = new Node({assignRandomKey: true});
    this.store$.dispatch( new AddNode({ node, offset: 0, column: 2 }) );
  }

}
