import { async, TestBed } from '@angular/core/testing';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { By } from '@angular/platform-browser';
import { RouterTestingModule } from '@angular/router/testing';
import { NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';
import { provideMockActions } from '@ngrx/effects/testing';
import { Store } from '@ngrx/store';
import { provideMockStore } from '@ngrx/store/testing';
import { authState as initialAuthState } from 'core/store/auth/auth.reducer';
import { AddNode } from 'core/store/hierarchy/hierarchy.actions';
import { hierarchyState as initialHierarchyState } from 'core/store/hierarchy/hierarchy.reducer';
import { ToggleNotifications } from 'core/store/notifications/notifications.actions';
import { initialState as initialNotificationsState } from 'core/store/notifications/notifications.reducer';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { Observable } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { NavIconsComponent } from './nav-icons.component';

describe('NavIconsComponent', () => {
  let context: TestCtx<NavIconsComponent>;
  let actions: Observable<any>;
  let matDialogStub: jasmine.SpyObj<MatDialog>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        MatDialogModule,
        NgbTooltipModule,
        RouterTestingModule
      ],
      declarations: [
        NavIconsComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: { hierarchy: initialHierarchyState, notifications: initialNotificationsState, auth: initialAuthState } }),
        provideMockActions(() => actions),
        { provide: MatDialog, useFactory: () => jasmine.createSpyObj('MatDialog', ['open'] as Array<keyof MatDialog>) },
      ],
    })
  });

  beforeEach(async( async () => {
    matDialogStub = TestBed.get(MatDialog);
    context = await createStableTestContext(NavIconsComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });

  describe('openFAQ', () => {

    it('should open a modal of the FAQ when clicking on the FAQ icon', () => {
      context.fixture.debugElement.query( By.css('.faq-btn') ).triggerEventHandler('click', null);

      expect(matDialogStub.open).toHaveBeenCalled();
    });

  });

  describe('toggleDropdown', () => {

    it('should toggle the dropdown visibility when clicking the call button', () => {
      const isDropDownVisible = () => context.element.querySelector<HTMLDivElement>('.dropdown').classList.contains('open');
      const clickDropDown = () => {
        context.fixture.debugElement.query( By.css('.call-btn') ).triggerEventHandler('click', null);
        context.detectChanges();
      }

      expect( isDropDownVisible() ).toBe(false, 'not visible at first');

      clickDropDown();

      expect( isDropDownVisible() ).toBe(true, 'visible after 1 click');

      clickDropDown();

      expect( isDropDownVisible() ).toBe(false, 'not visible after 2 click');
    });

  });

  describe('toggleNotifications', () => {

    it('should dispatch a ToggleNotifications Action', () => {
      const spy = spyOn(TestBed.get(Store), 'dispatch');
      const action = new ToggleNotifications();

      context.fixture.debugElement.query( By.css('.notifications-btn') ).triggerEventHandler('click', null);

      expect(spy).toHaveBeenCalledWith(action);
    });

  });

  describe('addNode', () => {

    it('should dispatch an AddNode Action', () => {
      const spy = spyOn(TestBed.get(Store), 'dispatch');

      context.fixture.debugElement.query( By.css('.addnode-btn') ).triggerEventHandler('click', null);

      expect(spy).toHaveBeenCalledWith(jasmine.any(AddNode));
    });

  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
