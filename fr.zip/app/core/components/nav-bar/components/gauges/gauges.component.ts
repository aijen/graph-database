import { Component, OnInit } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { getAvailabilityPercent, getFeelingPercent, getPerformancePercent, getRiskPercent } from 'core/store/hierarchy/hierarchy.selectors';
import { AppState } from 'shared/models/state.model';

@Component({
  selector: 'cockpit-gauges',
  templateUrl: './gauges.component.html',
  styleUrls: ['./gauges.component.scss']
})
export class GaugesComponent implements OnInit {

  availabilityPercent = this.store$.pipe(select(getAvailabilityPercent));
  performancePercent = this.store$.pipe(select(getPerformancePercent));
  riskPercent = this.store$.pipe(select(getRiskPercent));
  feelingPercent = this.store$.pipe(select(getFeelingPercent));

  constructor(
    private store$: Store<AppState>,
  ) { }

  ngOnInit() {
  }

}
