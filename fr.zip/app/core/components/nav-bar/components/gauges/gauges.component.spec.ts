import { Component, Input } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { hierarchyState } from 'core/store/hierarchy/hierarchy.reducer';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { Observable } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { GaugesComponent } from './gauges.component';

@Component({
  selector: 'cockpit-alert-indicator',
  template: '',
})
class CockpitAlertIndicatorStubComponent {
  @Input() percent: any;
  @Input() type: any;
  @Input() tooltip: any;
}

describe('GaugesComponent', () => {
  let context: TestCtx<GaugesComponent>;
  let actions: Observable<any>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      declarations: [
        GaugesComponent,
        CockpitAlertIndicatorStubComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: { hierarchy: hierarchyState } }),
        provideMockActions(() => actions),
      ],
    })
  });

  beforeEach(async( async () => {
    context = await createStableTestContext(GaugesComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
