import { Component } from '@angular/core';
import { Store } from '@ngrx/store';
import { getTemplateName } from 'core/store/hierarchy/hierarchy.selectors';
import moment from 'moment';
import { interval } from 'rxjs';
import { map } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';
import { SearchService } from '../search/search.service';

@Component({
  selector: 'cockpit-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.scss']
})
export class NavBarComponent {

  currentDate = interval(300).pipe( map( () => moment() ) );

  showSearch$ = this.searchService.hasFilters();
  templateName$ = this.store$.select(getTemplateName);

  constructor(
    private searchService: SearchService<any>,
    private store$: Store<AppState>,
  ) {}
}
