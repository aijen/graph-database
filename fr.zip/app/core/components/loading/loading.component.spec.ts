import { async, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { NgbProgressbarModule } from '@ng-bootstrap/ng-bootstrap';
import { provideMockActions } from '@ngrx/effects/testing';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { HierarchyState } from 'core/store/hierarchy/hierarchy.model';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { Observable } from 'rxjs';
import { marbles } from 'rxjs-marbles/jasmine';
import { AppState } from 'shared/models/state.model';
import { LocationToken } from 'shared/tokens/location/location.token';
import { LoadingComponent } from './loading.component';

describe('LoadingComponent', () => {
  let context: TestCtx<LoadingComponent>;
  let actions: Observable<any>;
  let store: MockStore<Partial<AppState>>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [ NoopAnimationsModule, NgbProgressbarModule ],
      declarations: [
        LoadingComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: { hierarchy: new HierarchyState() } }),
        provideMockActions(() => actions),
        { provide: LocationToken, useFactory: () => ({ set href(v: string) {} }) }
      ],
    })
  });

  beforeEach(async( async () => {
    store = TestBed.get(Store);
    context = await createStableTestContext(LoadingComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });

  it('should redirect to the maintenance page if the hierarchy store has an error', marbles(m => {
    const loc: Location = TestBed.get(LocationToken);
    const spy = spyOnProperty(loc, 'href', 'set');

    store.setState({ hierarchy: { ...new HierarchyState(), hierarchyError: new Error('hierarchyError') } });

    expect(spy).toHaveBeenCalled();
  }))


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
