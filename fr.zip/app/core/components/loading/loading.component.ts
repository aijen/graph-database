import { animate, style, transition, trigger } from '@angular/animations';
import { Component, Inject, OnInit } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { getHierarchyError, getProgress, getReady } from 'core/store/hierarchy/hierarchy.selectors';
import { filter, skip, takeUntil, tap } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';
import { LocationToken } from 'shared/tokens/location/location.token';

@Component({
  selector: 'cockpit-loading',
  templateUrl: './loading.component.html',
  styleUrls: ['./loading.component.scss'],
  animations: [
    trigger('fadeAway', [
      transition( ':leave', [
        style({ 'pointer-events': 'none' }),
        animate('.7s',
          style({ opacity: 0 })
        )
      ] )
    ])
  ],
})
export class LoadingComponent implements OnInit {

  ready$ = this.store$.pipe( select(getReady), skip(1) );

  progress$ = this.store$.pipe( select(getProgress), takeUntil(this.ready$) );

  error$ = this.store$.pipe( select(getHierarchyError), filter( error => Boolean(error) ), tap( () => this.location.href = '/assets/503sorry.html' ) );

  constructor(
    private store$: Store<AppState>,
    @Inject(LocationToken) private location: Location,
  ) { }

  ngOnInit() {
  }

}
