import { async, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatTooltipModule } from '@angular/material/tooltip';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { Subject } from 'rxjs';
import { SearchComponent } from './search.component';
import { SearchResult, SearchResultSet, SearchService, SearchToken } from './search.service';

describe('SearchComponent', () => {
  let context: TestCtx<SearchComponent>;
  let results$: Subject<SearchResultSet<any>>;
  let searchService: jasmine.SpyObj<SearchService<any>>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [ MatAutocompleteModule, MatTooltipModule, ReactiveFormsModule ],
      declarations: [
        SearchComponent,
      ],
      providers: [
        { provide: SearchService, useFactory: () => jasmine.createSpyObj('SearchService', ['getFilters', 'hasFilters', 'getResults', 'register', 'unregister', 'search', 'select', 'getSelectedFor'] as Array<keyof SearchService<any>>) },
      ],
    })
  });

  beforeEach(async( async () => {
    results$ = new Subject<SearchResultSet<any>>();
    searchService = TestBed.get(SearchService);
    searchService.getResults.and.returnValue(results$);
    context = await createStableTestContext(SearchComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });

  describe('when typing in the form input', () => {

    it('should call the searchService search method', () => {
      expect(searchService.search).not.toHaveBeenCalled();
      context.component.searchControl.setValue('test');
      expect(searchService.search).toHaveBeenCalled();
    });

  });

  describe('#search', () => {

    it('should trigger a search for the form input value if the form input value is in the suggestions', async( async () => {
      const value: SearchResult<any> = {
        token: new SearchToken('test'),
        label: 'test',
        data: 'test',
      };
      results$.next( new SearchResultSet([ value ], 'test') );
      context.component.searchControl.setValue(value, { emitEvent: false });

      expect(searchService.select).not.toHaveBeenCalled();

      await context.component.search();

      expect(searchService.select).toHaveBeenCalled();
    }));

    it('should open the autocomplete panel if the form input value is not in the suggestion', async( async () => {
      spyOn(context.component.trigger, 'openPanel').and.callThrough();

      expect(context.component.trigger.openPanel).not.toHaveBeenCalled();

      await context.component.search();

      expect(context.component.trigger.openPanel).toHaveBeenCalled();
    }));

  });

  describe('#selected', () => {

    it('should proxy the selected value to the searchService', () => {
      const value: SearchResult<any> = {
        token: new SearchToken('test'),
        label: 'test',
        data: 'test',
      };
      context.component.selected(value);

      expect(searchService.select).toHaveBeenCalledWith(value);
    });

  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
