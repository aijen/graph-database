import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatAutocompleteTrigger } from '@angular/material/autocomplete';
import { SubscriptionAwareComponent } from 'core/utils/subscription-aware.component';
import { delay, filter, shareReplay, startWith, take } from 'rxjs/operators';
import { SearchResult, SearchResultSet, SearchService } from './search.service';

@Component({
  selector: 'pit-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent extends SubscriptionAwareComponent implements OnInit {

  @ViewChild(MatAutocompleteTrigger)
  trigger: MatAutocompleteTrigger;

  searchControl = new FormControl('');

  suggestions$ = this.searchService.getResults().pipe(
    startWith( new SearchResultSet<any>([], '') ),
    shareReplay({ bufferSize: 1, refCount: true }),
  );

  constructor(
    private searchService: SearchService<any>,
  ) { super(); }

  ngOnInit() {
    this.subscription.add(
      // performs a search each time the searchControl value changes
      this.searchControl.valueChanges.pipe(
        filter( (search): search is string => typeof search === 'string' )
      ).subscribe( search => this.searchService.search( search ) )
    );
  }

  /**
   * performs a search if the current search value is present in the suggestions, else open the suggestions panel
   */
  async search() {
    // using delay(0) because openPanel() effect is countered by the click outside the autocomplete input provoking a closePanel()
    const suggestions = await this.suggestions$.pipe( take(1), delay(0) ).toPromise();

    if( suggestions.results.includes(this.searchControl.value) ) {
      this.searchService.select( this.searchControl.value );
    } else {
      this.trigger.openPanel();
    }
  }

  displayWith( value: SearchResult<any> ) {
    return value.label;
  }

  selected( selected: SearchResult<any> ) {
    this.searchService.select( selected );
  }

}
