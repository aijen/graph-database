import { async, TestBed } from '@angular/core/testing';
import { configureTestSuite } from 'ng-bullet';
import { BehaviorSubject, pipe, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';
import { SearchResult, SearchResultSet, SearchService, SearchToken } from './search.service';

describe('SearchService', () => {
  let service: SearchService<any>;
  let token: SearchToken;
  let filters$: BehaviorSubject<any>;
  let hasFilters$: BehaviorSubject<any>;
  let results$: BehaviorSubject<any>;
  let selected$: BehaviorSubject<any>;
  let subs: Subscription;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [
        SearchService,
      ],
    })
  });

  beforeEach(async( async () => {
    token = new SearchToken('test');
    filters$ = new BehaviorSubject(null);
    hasFilters$ = new BehaviorSubject(null);
    results$ = new BehaviorSubject(null);
    selected$ = new BehaviorSubject(null);
    subs = new Subscription();
    service = TestBed.get(SearchService);
  } ));

  afterEach(() => {
    subs.unsubscribe();
  });

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  describe('#getFilters', () => {

    it('should return the registered filters', () => {
      subs.add( service.getFilters().subscribe(filters$) );
      const filter  = pipe( map( () => ([{ token: token , label: 'test', data: 'test' } as SearchResult<any>]) ) );

      expect(filters$.value).toEqual([]);

      service.register(token, filter);
      expect(filters$.value).toEqual([filter]);
    });

  });

  describe('#hasFilters', () => {

    it('should return true if filters are registered', () => {
      subs.add( service.hasFilters().subscribe(hasFilters$) );
      const filter  = pipe( map( () => ([{ token: token , label: 'test', data: 'test' } as SearchResult<any>]) ) );

      expect(hasFilters$.value).toEqual(false);

      service.register(token, filter);
      expect(hasFilters$.value).toEqual(true);
    });

  });

  describe('#getResults', () => {

    it('should return the result of the search', () => {
      subs.add( service.getResults().subscribe(results$) );
      const value: SearchResult<any> = { token: token , label: 'test', data: 'test' };
      const filter  = pipe( map( () => ([value]) ) );

      service.register(token, filter);
      service.search('test');
      expect(results$.value).toEqual(new SearchResultSet( [value], 'test'));
    });

  });

  describe('#register', () => {

    it('should register the provided filter if not already registered with the provided token', () => {
      subs.add( service.getFilters().subscribe(filters$) );
      const token2 = new SearchToken('test2');
      const filter  = pipe( map( () => ([{ token: token , label: 'test', data: 'test' } as SearchResult<any>]) ) );
      const filter2 = pipe( map( () => ([{ token: token2, label: 'test', data: 'test' } as SearchResult<any>]) ) );

      expect(filters$.value).toEqual([]);

      service.register(token, filter);
      expect(filters$.value).toEqual([filter]);

      service.register(token, filter);
      expect(filters$.value).toEqual([filter]);

      service.register(token2, filter2);
      expect(filters$.value).toEqual([filter, filter2]);
    });

    it('should unregister the provided filter when calling the returned SearchRegistration', () => {
      subs.add( service.getFilters().subscribe(filters$) );
      const token2 = new SearchToken('test2');
      const filter  = pipe( map( () => ([{ token: token , label: 'test', data: 'test' } as SearchResult<any>]) ) );
      const filter2 = pipe( map( () => ([{ token: token2, label: 'test', data: 'test' } as SearchResult<any>]) ) );

      const searchRegistration = service.register(token, filter);
      service.register(token2, filter2);
      expect(filters$.value).toEqual([filter, filter2]);

      searchRegistration.unregister();
      expect(filters$.value).toEqual([filter2]);
    });

  });

  describe('#unregister', () => {

    it('should remove the filter registered under the provided token', () => {
      subs.add( service.getFilters().subscribe(filters$) );
      const token2 = new SearchToken('test2');
      const filter  = pipe( map( () => ([{ token: token , label: 'test', data: 'test' } as SearchResult<any>]) ) );
      const filter2 = pipe( map( () => ([{ token: token2, label: 'test', data: 'test' } as SearchResult<any>]) ) );

      service.register(token, filter);
      service.register(token2, filter2);
      expect(filters$.value).toEqual([filter, filter2]);

      service.unregister(token);
      expect(filters$.value).toEqual([filter2]);

      service.unregister(token);
      expect(filters$.value).toEqual([filter2]);
    });

  });

  describe('#search should update the results observable', () => {

    it('with an empty searchResult if the search is empty', () => {
      subs.add( service.getResults().subscribe(results$) );
      const filter  = pipe( map( () => ([{ token: token , label: 'test', data: 'test' } as SearchResult<any>]) ) );

      service.register(token, filter);
      service.search('');
      expect(results$.value).toEqual(new SearchResultSet( [], ''));
    });

    it('with an empty searchResult if no filters were registered', () => {
      subs.add( service.getResults().subscribe(results$) );

      service.search('');
      expect(results$.value).toEqual(new SearchResultSet( [], ''));
    });

    it('with a searchResult of the search value filtered by the registered filters', () => {
      subs.add( service.getResults().subscribe(results$) );
      const value: SearchResult<any> = { token: token , label: 'test', data: 'test' };
      const filter  = pipe( map( () => ([value]) ) );

      service.register(token, filter);
      service.search('test');
      expect(results$.value).toEqual(new SearchResultSet( [value], 'test'));
    });

  });

  describe('#select', () => {

    it('should update the selected observable with the provided result', () => {
      subs.add( service.getSelectedFor(token).subscribe(selected$) );
      const searchResult: SearchResult<any> = { token: token , label: 'test', data: 'test' };

      expect(selected$.value).toBe(null);

      service.select(searchResult);
      expect(selected$.value).toBe(searchResult);
    });

  });

  describe('#getSelectedFor', () => {

    it('should return the selected observable filtered by the provided token', () => {
      const spy = jasmine.createSpy('selected$');
      const token2 = new SearchToken('test2');
      const searchResult:  SearchResult<any> = { token: token , label: 'test', data: 'test' };
      const searchResult2: SearchResult<any> = { token: token2, label: 'test', data: 'test' };
      subs.add( service.getSelectedFor(token).subscribe(spy) );

      expect(spy).not.toHaveBeenCalled();

      service.select(searchResult2);
      expect(spy).not.toHaveBeenCalled();

      service.select(searchResult);
      expect(spy).toHaveBeenCalledWith(searchResult);
    });

  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
