import { Injectable } from '@angular/core';
import flatten from 'lodash/flatten';
import { BehaviorSubject, combineLatest, Observable, of, OperatorFunction, Subject } from 'rxjs';
import { filter, map, switchMap } from 'rxjs/operators';

export class SearchToken {
  constructor( public token: string ) {}
}

export interface SearchResult<T> {
  label: string;
  token: SearchToken;
  data: T;
  hint?: string;
}

export type SearchFilter<T> = OperatorFunction<string, SearchResult<T>[]>;

export class SearchResultSet<T> {
  constructor(
    public results: SearchResult<T>[],
    public search: string,
  ) {}
}

export interface SearchRegistration {
  unregister: () => void
}

@Injectable({
  providedIn: 'root'
})
export class SearchService<T> {

  private _filters$ = new BehaviorSubject<Map<SearchToken, SearchFilter<T>>>(new Map());

  private _selected$ = new Subject<SearchResult<T>>();

  private _search$ = new Subject<string>();

  private filtersValues$: Observable<OperatorFunction<string, SearchResult<T>[]>[]> = this._filters$.pipe( map( filters => Array.from(filters.values()) ) );
  private hasFilters$: Observable<boolean> = this.filtersValues$.pipe( map( filters => Boolean(filters.length) ) );
  private results$: Observable<SearchResultSet<T>> = combineLatest(this.filtersValues$, this._search$).pipe(
    switchMap( ([ filters, search ]) =>
      (search && filters.length ? combineLatest(
        // using the registered filters array, create a new array of observable where each item is a filter fed with the search value
        filters.map( _filter => of(search).pipe( _filter ) )
      ) : of([] as SearchResult<T>[][])).pipe( map( flatten ), map( results => new SearchResultSet( results, search ) ) )
    ),
  );

  constructor() { }

  getFilters() {
    return this.filtersValues$;
  }

  hasFilters() {
    return this.hasFilters$;
  }

  getResults() {
    return this.results$;
  }

  /**
   * Register a filter associated to a SearchToken
   *
   * If a filter is already associated with the provided token, the newest filter is discarded
   *
   * Return a SearchRegistration object with an unregister method
   */
  register( token: SearchToken, searchFilter: SearchFilter<T> ): SearchRegistration {
    const filters = this._filters$.value;
    if( !filters.has(token) ) this._filters$.next( new Map(filters).set( token, searchFilter ) );
    return {
      unregister: () => this.unregister(token),
    };
  }

  /**
   * Unregister a filter associated to the SearchToken provided
   */
  unregister( token: SearchToken ) {
    if( !this._filters$.value.has( token ) ) return;
    const filters = new Map( this._filters$.value );
    filters.delete( token );
    this._filters$.next( filters );
  }

  /**
   * Performs a search using the provided string
   *
   * The string will be submitted to all registered filters and will update the results$ observable
   */
  search( search: string ) {
    this._search$.next( search );
  }

  /**
   * Emit the provided value on the selected$ observable
   */
  select( result: SearchResult<T> ) {
    this._selected$.next( result );
  }

  /**
   * Return an observable of the selected value filtered by the provided token
   */
  getSelectedFor( token: SearchToken ) {
    return this._selected$.pipe( filter( selected => selected.token === token ) );
  }

}
