import { Component, Directive, EventEmitter, Input, Output } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { MatTabsModule } from '@angular/material/tabs';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { provideMockActions } from '@ngrx/effects/testing';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { hierarchyState } from 'core/store/hierarchy/hierarchy.reducer';
import { ExportMonitoringNotifications, GetNotifications, StartNotificationPuller, StopNotificationPuller } from 'core/store/notifications/notifications.actions';
import { initialState as initialNotificationsState } from 'core/store/notifications/notifications.reducer';
import moment from 'moment';
import { configureTestSuite, createTestContext, TestCtx } from 'ng-bullet';
import { merge, Observable } from 'rxjs';
import { marbles } from 'rxjs-marbles/jasmine';
import { filter, tap } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';
import { NotificationContainerComponent } from './notifications-container.component';

@Component({
  selector: 'pit-date-picker',
  template: '',
})
class PitDatePickerStubComponent {
  @Input() selectedDate: any;
  @Input() displayType: any;
  @Input() pitIcon: any;
  @Input() toggleClasses: any;
  @Output() dateChange = new EventEmitter<any>();
}

@Component({
  selector: 'cockpit-notification',
  template: '',
})
class CockpitNotificationStubComponent {
  @Input() notification: any;
}

@Component({
  selector: 'cockpit-monitoring-notification',
  template: '',
})
class CockpitMonitoringNotificationStubComponent {
  @Input() notification: any;
}

@Component({
  selector: 'cockpit-notification-form',
  template: '',
})
class CockpitNotificationFormStubComponent {
  @Output() notifSaved = new EventEmitter<any>();
}

@Component({
  selector: 'pit-virtual-scrolling',
  template: '',
})
class VirtualScrollingStubComponent {
  @Input() items: any;
  @Input() itemSize: any;
}

@Directive({
  selector: '[cockpitAutoScroll]',
})
class CockpitAutoScrollStubDirective {
  @Input() cockpitAutoScroll: any;
  @Input() autoScrollTo: any;
}

describe('NotificationContainerComponent', () => {
  let context: TestCtx<NotificationContainerComponent>;
  let actions: Observable<any>;
  let store: MockStore<Partial<AppState>>;
  const initialState = { notifications: initialNotificationsState, hierarchy: hierarchyState };

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      declarations: [
        NotificationContainerComponent,
        PitDatePickerStubComponent,
        CockpitNotificationStubComponent,
        CockpitMonitoringNotificationStubComponent,
        CockpitNotificationFormStubComponent,
        VirtualScrollingStubComponent,
        CockpitAutoScrollStubDirective,
      ],
      imports: [
        MatTabsModule,
        NoopAnimationsModule,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState }),
        provideMockActions(() => actions),
      ],
    })
  });

  beforeEach(() => {
    jasmine.clock().install();
    jasmine.clock().mockDate(new Date(2000, 1, 1));
    store = TestBed.get(Store);
    spyOn(store, 'dispatch').and.callThrough();
    context = createTestContext(NotificationContainerComponent);
  });

  afterEach(() => {
    jasmine.clock().uninstall();
  })

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });

  it('should start the notificationPuller', () => {
    expect(store.dispatch).toHaveBeenCalledWith(new StartNotificationPuller());
  });

  describe('notifOpen$', () => {
    const supervisingState =    { ...hierarchyState, isSupervising: true };
    const notSupervisingState = { ...hierarchyState, isSupervising: false };
    const notificationOpen =    { ...initialNotificationsState, open: true };
    const notificationClose =   { ...initialNotificationsState, open: false };


    it('should always emit true if supervising', marbles(m => {
      const supervisingAndClose:  Partial<AppState> = {
        ...initialState,
        hierarchy: supervisingState,
        notifications: notificationClose,
      };
      const supervisingAndOpen:  Partial<AppState> = {
        ...initialState,
        hierarchy: supervisingState,
        notifications: notificationOpen,
      };
      const states =   m.hot( '--a--b--', {          a: supervisingAndClose, b: supervisingAndOpen });
      const expected = m.cold('i-a-----', { i: true, a: true, });

      const notifOpen$ = merge(
        states.pipe( tap( state => store.setState(state) ), filter( () => false ) ),
        context.component.notifOpen$
      );

      m.expect(notifOpen$).toBeObservable(expected);
    }));

    it('should emit the notificationOpen state when not supervising', marbles(m => {
      const notSupervisingAndClose:  Partial<AppState> = {
        ...initialState,
        hierarchy: notSupervisingState,
        notifications: notificationClose,
      };
      const notSupervisingAndOpen:  Partial<AppState> = {
        ...initialState,
        hierarchy: notSupervisingState,
        notifications: notificationOpen,
      };
      const states =   m.hot( '--a--b--', {          a: notSupervisingAndClose, b: notSupervisingAndOpen });
      const expected = m.cold('i-a--b--', { i: true, a: false,                  b: true });

      const notifOpen$ = merge(
        states.pipe( tap( state => store.setState(state) ), filter( () => false ) ),
        context.component.notifOpen$
      );

      m.expect(notifOpen$).toBeObservable(expected);
    }));

  });

  describe('#onDateSelect', () => {

    it('should start the notificationPuller if the selected date is today', () => {
      context.component.onDateSelect( { value: moment() } as any );

      expect(store.dispatch).toHaveBeenCalledWith(jasmine.any(StartNotificationPuller));
    });

    it('should stop the notificationPuller if the selected date is not today', () => {
      context.component.onDateSelect( { value: moment().subtract(1, 'day') } as any );

      expect(store.dispatch).toHaveBeenCalledWith(jasmine.any(StopNotificationPuller));

    });

    it('should dispatch a GetNotifications Action for the selected date if the selected date is not today', () => {
      const selected = context.component.selectedDate.subtract(1, 'day');
      const from = moment(new Date(2000, 1, 0)).unix();
      const to = moment(new Date(2000, 1, 1, 0, 0, 0, -1)).unix();
      context.component.onDateSelect( { value: selected } as any );

      expect(store.dispatch).toHaveBeenCalledWith(new GetNotifications(from, to));
    });

  });

  describe('#onNotifSaved', () => {

    it('should start the notificationPuller', () => {
      context.component.onNotifSaved();

      expect(store.dispatch).toHaveBeenCalledWith(jasmine.any(StartNotificationPuller));
    });

  });

  describe('#onExportMonitoringNotifs', () => {

    it('should dispatch a ExportMonitoringNotifications Action', () => {
      const from = moment(new Date(2000, 1, 1)).unix();
      const to = moment(new Date(2000, 1, 2, 0, 0, 0, -1)).unix();
      context.component.onExportMonitoringNotifs();

      expect(store.dispatch).toHaveBeenCalledWith(new ExportMonitoringNotifications(from, to));
    });

  });



  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
