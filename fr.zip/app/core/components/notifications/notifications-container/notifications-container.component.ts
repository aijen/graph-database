import { Component } from '@angular/core';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { select, Store } from '@ngrx/store';
import { getIsSupervising } from 'core/store/hierarchy/hierarchy.selectors';
import { ExportMonitoringNotifications, GetNotifications, StartNotificationPuller, StopNotificationPuller } from 'core/store/notifications/notifications.actions';
import { getMonitoringNotifications, getNotificationOpen, getNotifications } from 'core/store/notifications/notifications.selectors';
import moment from 'moment';
import { of } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { DatepickerDisplayType } from 'shared/models/datepicker.models';
import { AppState } from 'shared/models/state.model';

@Component({
  selector: 'cockpit-notifications-container',
  templateUrl: './notifications-container.component.html',
  styleUrls: ['./notifications-container.component.scss']
})
export class NotificationContainerComponent {
  selectedDate = moment();
  datepickerDisplayType = DatepickerDisplayType;
  notifications$ = this.store$.pipe(select(getNotifications));
  monitoringNotifications$ = this.store$.pipe(select(getMonitoringNotifications));
  isSupervising$ = this.store$.pipe(select(getIsSupervising));
  selectedIndex = 0;

  notifOpen$ = this.isSupervising$.pipe(
    switchMap(supervising => supervising ? of(true) : this.store$.pipe(select(getNotificationOpen)))
  );

  constructor(private store$: Store<AppState>) {
    this.store$.dispatch(new StartNotificationPuller());
  }

  onDateSelect(event: MatDatepickerInputEvent<moment.Moment>) {
    this.selectDate(event.value.clone());
  }

  onNotifSaved() {
    this.selectDate(moment());
  }

  onExportMonitoringNotifs() {
    const { from, to } = this.getDate(moment());

    this.store$.dispatch(new ExportMonitoringNotifications(from, to));
  }

  private selectDate(date: moment.Moment) {
    this.selectedDate = date;

    if (moment().isSame(date, 'date')) {
      this.store$.dispatch(new StartNotificationPuller());
    }
    else {
      const { from, to } = this.getDate(date);
      this.store$.dispatch(new StopNotificationPuller());
      this.store$.dispatch(new GetNotifications(from, to));
    }
  }

  private getDate(date: moment.Moment) {
    const from = date.clone().hour(0).minute(0).second(0).millisecond(0).locale('fr').unix();
    const to = date.clone().hour(23).minute(59).second(59).millisecond(999).locale('fr').unix();

    return { from, to };
  }
}
