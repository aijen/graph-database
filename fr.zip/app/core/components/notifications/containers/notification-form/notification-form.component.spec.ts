import { async, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { provideMockActions } from '@ngrx/effects/testing';
import { Store } from '@ngrx/store';
import { provideMockStore } from '@ngrx/store/testing';
import { SaveNotification } from 'core/store/notifications/notifications.actions';
import { initialState } from 'core/store/notifications/notifications.reducer';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { Observable } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { NotificationFormComponent } from './notification-form.component';

describe('NotificationFormComponent', () => {
  let context: TestCtx<NotificationFormComponent>;
  let actions: Observable<any>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule,
      ],
      declarations: [
        NotificationFormComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: { notifications: initialState } }),
        provideMockActions(() => actions),
      ],
    })
  });

  beforeEach(async( async () => {
    context = await createStableTestContext(NotificationFormComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });

  describe('onSubmit', () => {

    it('should set the formSubmitAttempt if the form is invalid', () => {
      expect(context.component.notificationForm.invalid).toBeTruthy();
      expect(context.component.formSubmitAttempt).toBeFalsy();

      context.component.onSubmit();

      expect(context.component.formSubmitAttempt).toBeTruthy();
    });

    it('should dispatch a SaveNotification Action if the form is valid', () => {
      const spy = spyOn(TestBed.get(Store), 'dispatch');
      context.component.notificationForm.patchValue({
        severity: 'INFO',
        title: 'info',
        message: 'information',
      });
      expect(context.component.notificationForm.valid).toBeTruthy();

      context.component.onSubmit();

      expect(spy).toHaveBeenCalledWith(jasmine.any(SaveNotification));
    });

    it('should reset the form if the form is valid', () => {
      context.component.notificationForm.patchValue({
        severity: 'INFO',
        title: 'info',
        message: 'information',
      });
      context.component.notificationForm.markAsDirty();
      context.component.notificationForm.markAsTouched();
      expect(context.component.notificationForm.valid).toBeTruthy();

      context.component.onSubmit();

      expect(context.component.notificationForm.value).toEqual({
        severity: null,
        title: null,
        message: null,
      });
      expect(context.component.notificationForm.pristine).toBeTruthy();
      expect(context.component.notificationForm.untouched).toBeTruthy();
    });

    it('should emit a notifSaved event if the form is valid', () => {
      const spy = jasmine.createSpy('notifSaved');
      const sub = context.component.notifSaved.subscribe(spy);
      context.component.notificationForm.patchValue({
        severity: 'INFO',
        title: 'info',
        message: 'information',
      });

      context.component.onSubmit();

      expect(spy).toHaveBeenCalled();

      sub.unsubscribe();
    });

  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
