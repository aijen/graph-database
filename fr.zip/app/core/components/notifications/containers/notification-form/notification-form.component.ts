import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';
import { SaveNotification } from 'core/store/notifications/notifications.actions';
import { CockpitNotification } from 'core/store/notifications/notifications.model';
import { AppState } from 'shared/models/state.model';

@Component({
  selector: 'cockpit-notification-form',
  templateUrl: './notification-form.component.html',
  styleUrls: ['./notification-form.component.scss']
})
export class NotificationFormComponent implements OnInit {
  notificationForm: FormGroup;
  severity: FormControl;
  title: FormControl;
  message: FormControl;
  formSubmitAttempt: boolean;

  @Output() notifSaved = new EventEmitter<void>();

  constructor(private store$: Store<AppState>) {}

  ngOnInit() {
    this.createFormControls();
    this.createForm();
  }

  private createForm() {
    this.notificationForm = new FormGroup({
      severity: this.severity,
      title: this.title,
      message: this.message
    });
  }

  private createFormControls() {
    this.severity = new FormControl('', Validators.required);
    this.title = new FormControl('', [
      Validators.required,
      Validators.maxLength(64)
    ]);
    this.message = new FormControl('', [
      Validators.required,
      Validators.maxLength(560)
    ]);
  }

  onSubmit() {
    this.formSubmitAttempt = true;
    if (this.notificationForm.valid) {
      const notification = new CockpitNotification(
        this.severity.value,
        this.title.value,
        false,
        this.message.value
      );
      this.store$.dispatch(new SaveNotification(notification));
      this.formSubmitAttempt = false;
      this.notificationForm.markAsPristine();
      this.notificationForm.markAsUntouched();
      this.notificationForm.reset();

      this.notifSaved.emit();
    }
  }
}
