import { async, TestBed } from '@angular/core/testing';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatMenuModule } from '@angular/material/menu';
import { provideMockActions } from '@ngrx/effects/testing';
import { Store } from '@ngrx/store';
import { provideMockStore } from '@ngrx/store/testing';
import { DeleteNotification } from 'core/store/notifications/notifications.actions';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { Observable, of } from 'rxjs';
import { DialogConfirmActions } from 'shared/components/dialog-confirm/dialog-confirm.component';
import { AppState } from 'shared/models/state.model';
import { NotificationMenuComponent } from './notification-menu.component';

describe('NotificationMenuComponent', () => {
  let context: TestCtx<NotificationMenuComponent>;
  let actions: Observable<any>;
  let dialog: MatDialog;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        MatMenuModule,
        MatDialogModule,
      ],
      declarations: [
        NotificationMenuComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: {} }),
        provideMockActions(() => actions),
      ],
    })
  });

  beforeEach(async(async () => {
    actions = null;
    context = await createStableTestContext(NotificationMenuComponent);
    dialog = (context.component as any).dialog;
  }));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });

  describe('update', () => {

    it('should open a dialog', () => {
      const openSpy = spyOn(dialog, 'open');

      context.component.update();

      expect(openSpy).toHaveBeenCalled();
    });

  });

  describe('delete', () => {

    it('should do nothing', async(async () => {
      const dispatchSpy = spyOn(TestBed.get(Store), 'dispatch');
      spyOn(dialog, 'open').and.returnValue({ afterClosed: () => of(DialogConfirmActions.CANCEL) });

      await context.component.delete();

      expect(dispatchSpy).not.toHaveBeenCalled();
    }));

    it('should dispatch the DeleteNotification action', async(async () => {
      const dispatchSpy = spyOn(TestBed.get(Store), 'dispatch');
      spyOn(dialog, 'open').and.returnValue({ afterClosed: () => of(DialogConfirmActions.CONFIRM) });

      await context.component.delete();

      expect(dispatchSpy).toHaveBeenCalledWith(new DeleteNotification(undefined));
    }));

  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for (const style of styles) head.removeChild(style);
  }
  afterAll(cleanStylesFromDom);
});
