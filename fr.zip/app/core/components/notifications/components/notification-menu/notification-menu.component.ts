import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { MatMenu } from '@angular/material/menu';
import { Store } from '@ngrx/store';
import { DeleteNotification } from 'core/store/notifications/notifications.actions';
import { CockpitNotification } from 'core/store/notifications/notifications.model';
import { DialogConfirmActions, DialogConfirmComponent } from 'shared/components/dialog-confirm/dialog-confirm.component';
import { AppState } from 'shared/models/state.model';
import { NotificationEditComponent } from '../notification-edit/notification-edit.component';

@Component({
  selector: 'pit-notification-menu',
  templateUrl: './notification-menu.component.html',
  styleUrls: ['./notification-menu.component.scss']
})
export class NotificationMenuComponent implements OnInit {

  @Input()
  notification: CockpitNotification;

  @ViewChild(MatMenu)
  menu: MatMenu;

  constructor(
    private store$: Store<AppState>,
    private dialog: MatDialog,
  ) { }

  ngOnInit() {
  }

  update() {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.minWidth = '60rem';
    dialogConfig.disableClose = true;
    dialogConfig.data = { ...this.notification };

    this.dialog.open(NotificationEditComponent, dialogConfig);
  }

  async delete() {
    const text = 'Voulez-vous vraiment supprimer cette notification ?';

    const action = await DialogConfirmComponent.openDialog(
      this.dialog,
      { data: { text } }
    ).afterClosed().toPromise();

    if (action !== DialogConfirmActions.CONFIRM) return;

    this.store$.dispatch(new DeleteNotification(this.notification));
  }
}
