import { async, TestBed } from '@angular/core/testing';
import { MatTooltipModule } from '@angular/material/tooltip';
import { configureTestSuite, createTestContext, TestCtx } from 'ng-bullet';
import { MonitoringNotificationComponent } from './monitoring-notification.component';

describe('MonitoringNotificationComponent', () => {
  let context: TestCtx<MonitoringNotificationComponent>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [ MatTooltipModule ],
      declarations: [
        MonitoringNotificationComponent,
      ],
    })
  });

  beforeEach(async( async () => {
    context = await createTestContext(MonitoringNotificationComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
