import { Component, Input } from '@angular/core';
import { CockpitNotification } from 'core/store/notifications/notifications.model';

@Component({
  selector: 'cockpit-monitoring-notification',
  templateUrl: './monitoring-notification.component.html',
  styleUrls: ['./monitoring-notification.component.scss']
})
export class MonitoringNotificationComponent {
  @Input()
  notification: CockpitNotification;

  SEVERITY = CockpitNotification.SEVERITY;
  META_TYPE = CockpitNotification.META_TYPE;
}
