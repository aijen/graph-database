import { TextFieldModule } from '@angular/cdk/text-field';
import { async, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { MatDialog, MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Store } from '@ngrx/store';
import { provideMockStore } from '@ngrx/store/testing';
import { UpdateNotification } from 'core/store/notifications/notifications.actions';
import { CockpitNotification, SEVERITY } from 'core/store/notifications/notifications.model';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { of } from 'rxjs';
import { DialogConfirmActions } from 'shared/components/dialog-confirm/dialog-confirm.component';
import { AppState } from 'shared/models/state.model';
import { NotificationEditComponent } from './notification-edit.component';

const generateNotification = (notification: Partial<CockpitNotification>) => {
  return {
    ...new CockpitNotification(SEVERITY.ERROR, 'title', false),
    ...notification,
  }
};

describe('NotificationEditComponent', () => {
  let context: TestCtx<NotificationEditComponent>;
  let dialog: MatDialog;
  let dialogRef: jasmine.SpyObj<MatDialogRef<NotificationEditComponent>>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        TextFieldModule,
        MatDialogModule,
      ],
      declarations: [
        NotificationEditComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: {} }),
        { provide: MatDialogRef, useFactory: () => jasmine.createSpyObj('MatDialogRef', ['close'] as Array<keyof MatDialogRef<NotificationEditComponent>>) },
        { provide: MAT_DIALOG_DATA, useValue: generateNotification({ message: 'message' }) },
        { provide: CockpitNotification, useFactory: () => ({}) },
      ],
    })
  });

  beforeEach(async( async () => {
    context = await createStableTestContext(NotificationEditComponent);
    dialog = (context.component as any).dialog;
    dialogRef = TestBed.get(MatDialogRef);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });

  describe('isModified', () => {

    it('should not be modified', () => {
      expect(context.component.isModified()).toBe(false);
    });

    it('should be modified', () => {
      context.component.updatedText = 'message updated';
      expect(context.component.isModified()).toBe(true);

      context.component.updatedTitle = 'title updated';
      context.component.updatedText = 'message';
      expect(context.component.isModified()).toBe(true);

      context.component.updatedTitle = 'title updated';
      context.component.updatedText = 'message updated';
      expect(context.component.isModified()).toBe(true);
    });

  });

  describe('update', () => {

    it('should have updated', () => {
      const dispatchSpy = spyOn(TestBed.get(Store), 'dispatch');
      const openSpy = spyOn(dialog, 'open');

      context.component.update();

      expect(dispatchSpy).toHaveBeenCalled();
      expect(dispatchSpy.calls.mostRecent().args[0]).toEqual(new UpdateNotification(generateNotification({ message: 'message' })));
      expect(openSpy).not.toHaveBeenCalled();
      expect(dialogRef.close).toHaveBeenCalled();
    });

  });

  describe('quit', () => {

    it('should not quit', async(async () => {
      context.component.updatedText = 'message updated';
      spyOn(dialog, 'open').and.returnValue({ afterClosed: () => of(DialogConfirmActions.CANCEL) });

      await context.component.quit();
      expect(dialogRef.close).not.toHaveBeenCalled();
    }));

    it('should quit', async(async () => {
      await context.component.quit();
      expect(dialogRef.close).toHaveBeenCalled();


      context.component.updatedText = 'message updated';
      spyOn(dialog, 'open').and.returnValue({ afterClosed: () => of(DialogConfirmActions.CONFIRM) });

      await context.component.quit();
      expect(dialogRef.close).toHaveBeenCalled();
    }));

  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
