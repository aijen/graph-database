import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Store } from '@ngrx/store';
import { UpdateNotification } from 'core/store/notifications/notifications.actions';
import { CockpitNotification } from 'core/store/notifications/notifications.model';
import { DialogConfirmActions, DialogConfirmComponent } from 'shared/components/dialog-confirm/dialog-confirm.component';
import { AppState } from 'shared/models/state.model';

@Component({
  selector: 'pit-notification-edit',
  templateUrl: './notification-edit.component.html',
  styleUrls: ['./notification-edit.component.scss']
})
export class NotificationEditComponent implements OnInit {
  updatedTitle: string;
  updatedText: string;

  constructor(
    private store$: Store<AppState>,
    private dialog: MatDialog,
    private dialogRef: MatDialogRef<NotificationEditComponent>,
    @Inject(MAT_DIALOG_DATA) private notification: CockpitNotification) {
      this.updatedTitle = notification.title;
      this.updatedText = notification.message;
  }

  ngOnInit() {
  }

  isModified() {
    return this.updatedTitle !== this.notification.title || this.updatedText !== this.notification.message;
  }

  update() {
    this.notification.title = this.updatedTitle;
    this.notification.message = this.updatedText;

    this.store$.dispatch(new UpdateNotification(this.notification));

    this.quit();
  }

  async quit() {
    if(this.isModified()) {
      const text = 'Si vous quittez, vos modifications seront perdues. Voulez-vous continuer ?';

      const action = await DialogConfirmComponent.openDialog(
        this.dialog,
        { data: { text } }
      ).afterClosed().toPromise();

      if (action !== DialogConfirmActions.CONFIRM) return;
    }

    this.dialogRef.close();
  }

}
