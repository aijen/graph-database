import { Component, Input } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { getUser } from 'core/store/auth/auth.selectors';
import { CockpitNotification } from 'core/store/notifications/notifications.model';
import { map } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';

@Component({
  selector: 'cockpit-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.scss']
})
export class NotificationComponent {
  @Input()
  notification: CockpitNotification;

  constructor(
    private store$: Store<AppState>,
  ) {}

  canEdit() {
    return this.store$.select(getUser).pipe(
      select(user => user.userId),
      map(id => id === (this.notification.user ? this.notification.user.userId : undefined)),
    );
  }
}
