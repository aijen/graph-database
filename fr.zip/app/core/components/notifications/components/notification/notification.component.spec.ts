import { Component, Input, ViewChild } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatMenuModule } from '@angular/material/menu';
import { Store } from '@ngrx/store';
import { provideMockStore } from '@ngrx/store/testing';
import { User } from 'core/models/user.model';
import { authState } from 'core/store/auth/auth.reducer';
import { CockpitNotification, SEVERITY } from 'core/store/notifications/notifications.model';
import { configureTestSuite } from 'ng-bullet';
import { AppState } from 'shared/models/state.model';
import { NotificationComponent } from './notification.component';

const generateNotification = (notification: Partial<CockpitNotification>) => {
  return {
    ...new CockpitNotification(SEVERITY.ERROR, 'title', false),
    ...notification,
  }
};

const generateUser = (user: Partial<User>) => {
  return {
    ...new User(),
    ...user,
  }
};

@Component({
  selector: `host-component`,
  template: `<cockpit-notification></cockpit-notification>`
})
class TestHostComponent {
  @ViewChild(NotificationComponent)
  public notificationComponent: NotificationComponent;
}

@Component({
  selector: 'pit-notification-menu',
  template: '',
})
class PitNotificationMenuStubComponent {
  @Input() notification: any;
}

describe('NotificationComponent', () => {
  let testHostFixture: ComponentFixture<TestHostComponent>;
  let testHostComponent: TestHostComponent;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        MatMenuModule,
      ],
      declarations: [
        TestHostComponent,
        NotificationComponent,
        PitNotificationMenuStubComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: { auth: authState } }),
      ],
    })
  });

  beforeEach(() => {
    testHostFixture = TestBed.createComponent(TestHostComponent);
    testHostComponent = testHostFixture.componentInstance;
    testHostComponent.notificationComponent.notification = generateNotification({ user: { userId: 'X123456' } });
    testHostFixture.detectChanges();
  });

  it('should create', () => {
    expect(testHostComponent).toBeTruthy();
    expect(testHostComponent.notificationComponent).toBeTruthy();
  });

  describe('canEdit', () => {

    it('could not edit', async(async () => {
      const canEdit = await testHostComponent.notificationComponent.canEdit().toPromise();

      expect(canEdit).toBe(false);
    }));

    it('could edit', async(async () => {
      TestBed.get(Store).setState({ auth: { user: generateUser({ userId: 'X123456' }) } });

      const canEdit = await testHostComponent.notificationComponent.canEdit().toPromise();

      expect(canEdit).toBe(true);
    }));

  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for (const style of styles) head.removeChild(style);
  }
  afterAll(cleanStylesFromDom);
});
