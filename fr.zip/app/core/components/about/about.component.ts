import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { getAbout, isAboutLoading } from 'core/store/about/about.selectors';
import { getExistingMetrics, isExistingMetricsLoading } from 'core/store/existing-metrics/existing-metrics.selectors';
import { combineLatest } from 'rxjs';
import { map } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';

@Component({
  selector: 'pit-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.scss']
})
export class AboutComponent implements OnInit {

  about$ = this.store$.select( getAbout );
  existingMetrics$ = this.store$.select(getExistingMetrics);
  loading$ = combineLatest(
    this.store$.select( isAboutLoading ),
    this.store$.select(isExistingMetricsLoading),
  ).pipe(map(([aboutLoading, existingMetricsLoading]) => aboutLoading || existingMetricsLoading));

  constructor(
    private store$: Store<AppState>,
  ) {
  }

  ngOnInit() {
  }

}
