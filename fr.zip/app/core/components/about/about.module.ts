import { NgModule } from '@angular/core';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { AboutStoreModule } from 'core/store/about/about.module';
import { SharedModule } from 'shared/shared.module';
import { AboutComponent } from './about.component';

@NgModule({
  declarations: [AboutComponent],
  exports: [AboutComponent],
  imports: [
    SharedModule,
    AboutStoreModule,
    MatProgressSpinnerModule,
  ]
})
export class AboutModule { }
