import { Component, Input } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { MatDialog } from '@angular/material/dialog';
import { MatTooltipModule } from '@angular/material/tooltip';
import { NgbAccordionModule } from '@ng-bootstrap/ng-bootstrap';
import { provideMockActions } from '@ngrx/effects/testing';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { ExcelService } from 'core/services/excel/excel.service';
import { authState } from 'core/store/auth/auth.reducer';
import { faqState } from 'core/store/faq/faq.reducer';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { Observable } from 'rxjs';
import { marbles } from 'rxjs-marbles/marbles';
import { AppState } from 'shared/models/state.model';
import { FaqComponent } from './faq.component';

@Component({
  selector: 'pit-close-modal',
  template: '',
})
class PitCloseModalStubComponent {}

@Component({
  selector: 'pit-about',
  template: '',
})
class PitAboutStubComponent {}

@Component({
  selector: 'pit-faq-description',
  template: '',
})
class PitFaqDescriptionStubComponent {
  @Input()
  description: string;
}

describe('FaqComponent', () => {
  let context: TestCtx<FaqComponent>;
  let store: MockStore<Partial<AppState>>;
  let actions: Observable<any>;
  let matDialogStub: jasmine.SpyObj<MatDialog>;
  let excelServiceStub: jasmine.SpyObj<ExcelService>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        MatTooltipModule,
        NgbAccordionModule,
      ],
      declarations: [
        FaqComponent,
        PitCloseModalStubComponent,
        PitAboutStubComponent,
        PitFaqDescriptionStubComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: {
          faq: {
            ...faqState,
            faq: [
              {
                title: 'title',
                description: 'description',
                faq: [
                  { title: 'title', description: 'description', faq: [] },
                  { title: 'title', faq: [] }
                ]
              }
            ] },
          auth: authState,
        } }),
        provideMockActions(() => actions),
        { provide: MatDialog, useFactory: () => jasmine.createSpyObj('MatDialog', ['open'] as Array<keyof MatDialog>) },
        { provide: ExcelService, useFactory: () => jasmine.createSpyObj('ExcelService', ['saveAsExcel', 'fileToWorkbook', 'sheetToJson'] as Array<keyof ExcelService>) },
      ],
    })
  });

  beforeEach(async( async () => {
    store = TestBed.get(Store);
    actions = null;
    matDialogStub = TestBed.get(MatDialog);
    excelServiceStub = TestBed.get(ExcelService);
    context = await createStableTestContext(FaqComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });

  describe('isDisabled', () => {
    it('should be disabled', marbles(m => {
      context.component.exporting$.next(true);
      let expected =  m.hot('a', {
        a: true,
      });

      m.expect(context.component.isDisabled()).toBeObservable(expected);
      context.component.exporting$.next(false);

      store.setState({ faq: { ...faqState, isLoading: true  }, auth: authState });
      expected =  m.hot('a', {
        a: true,
      });

      m.expect(context.component.isDisabled()).toBeObservable(expected);

      store.setState({ faq: { ...faqState, isSaving: true  }, auth: authState });
      expected =  m.hot('a', {
        a: true,
      });

      m.expect(context.component.isDisabled()).toBeObservable(expected);
    }));

    it('shouldn\'t be disabled', marbles(m => {
      const expected =  m.hot('a', {
        a: false,
      });

      m.expect(context.component.isDisabled()).toBeObservable(expected);
    }));
  });

  describe('import', () => {
    it('should call open() of dialog', () => {
      context.component.import();

      expect(matDialogStub.open).toHaveBeenCalled();
    });
  });

  describe('export', () => {
    it('should call saveAsExcel() of excelService', () => {
      context.component.export().then(() => {
        expect(excelServiceStub.saveAsExcel).toHaveBeenCalled();
      });
    });
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
