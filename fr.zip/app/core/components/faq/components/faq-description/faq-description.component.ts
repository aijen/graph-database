import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'pit-faq-description',
  templateUrl: './faq-description.component.html',
  styleUrls: ['./faq-description.component.scss']
})
export class FaqDescriptionComponent implements OnInit {

  @Input()
  description: string;

  constructor() { }

  ngOnInit() {
  }

  manageLinks(description: string) {
    return description.replace('<a', '<a target="_blank"');
  }

}
