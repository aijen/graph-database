import { Component, ViewChild } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { configureTestSuite } from 'ng-bullet';
import { FaqDescriptionComponent } from './faq-description.component';

@Component({
  selector: `host-component`,
  template: `<pit-faq-description></pit-faq-description>`
})
class TestHostComponent {
  @ViewChild(FaqDescriptionComponent)
  public component: FaqDescriptionComponent;
}

describe('FaqDescriptionComponent', () => {
  let testHostFixture: ComponentFixture<TestHostComponent>;
  let testHostComponent: TestHostComponent;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
      ],
      declarations: [
        TestHostComponent,
        FaqDescriptionComponent,
      ],
    })
  });

  beforeEach(async( async () => {
    testHostFixture = TestBed.createComponent(TestHostComponent);
    testHostComponent = testHostFixture.componentInstance;
    testHostComponent.component.description = '';
    testHostFixture.detectChanges();
  } ));

  it('should create', () => {
    expect(testHostComponent).toBeTruthy();
    expect(testHostComponent.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
