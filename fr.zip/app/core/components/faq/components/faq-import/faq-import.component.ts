import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { Actions, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { ExcelService } from 'core/services/excel/excel.service';
import { FaqActionTypes, FaqActionUnion, SaveFaq } from 'core/store/faq/faq.actions';
import { FAQ } from 'core/store/faq/faq.model';
import { isFaqLoadingOrSaving } from 'core/store/faq/faq.selectors';
import { of } from 'rxjs';
import { filter, switchMapTo, take, tap } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';

@Component({
  selector: 'pit-faq-import',
  templateUrl: './faq-import.component.html',
  styleUrls: ['./faq-import.component.scss']
})
export class FaqImportComponent implements OnInit {

  isLoadingOrSaving$ = this.store$.select(isFaqLoadingOrSaving);

  faq: FAQ[];
  file: File;
  fileName = '';
  fileSize = '';
  formatError = false;

  @ViewChild('f')
  private fileInput: ElementRef<HTMLInputElement>;

  constructor(
    private store$: Store<AppState>,
    private excelService: ExcelService,
    private actions$: Actions,
    private dialogRef: MatDialogRef<FaqImportComponent>,
  ) { }

  ngOnInit() {
  }

  fileChange(file: File) {
    const { name = '', size = 0 } = file || {};

    this.fileName = name;
    this.fileSize = this.getfilesize(size);
    this.file = file;

    this.parseFile();
  }

  private parseFile() {
    this.formatError = false;
    let fileReader = new FileReader();

    fileReader.readAsArrayBuffer(this.file);

    fileReader.onload = (e) => {
      const arrayBuffer: any = fileReader.result;
      const data = new Uint8Array(arrayBuffer);
      const arr = [];

      for (let i = 0; i != data.length; ++i) {
        arr[i] = String.fromCharCode(data[i]);
      }

      this.faq = [];
      const workbook = this.excelService.fileToWorkbook(arr.join(""), { type:"binary" });
      const content = this.excelService.sheetToJson(workbook.Sheets[workbook.SheetNames[0]], 1, false);

      // find the first item in faq with {search} title, or create it and insert it
      const getCat = (search) => {
        return this.faq.find(({ title }) => title === search)
          || (this.faq[this.faq.length] = { title: search, faq: [] });
      }

      // clean text, replace '\r\n' with '\n'
      const clean = (text) => {
        return text.replace(/\r\n|\r/g, '\n');
      }

      for (let line of content) {
        const [category, title, description] = line;

        if(!category || !title) {
          this.formatError = true;
        }

        getCat(category).faq.push({ title: clean(title), description: clean(description ? description : '') });
      }
    }
  }

  canImport() {
    return this.file && !this.isFileInvalid();
  }

  isFileInvalid() {
    return this.formatError || (this.file && !this.isExcelFile());
  }

  getErrorMessage() {
    if(this.file && !this.isExcelFile()) return 'Vous devez importer un fichier Excel';
    if(this.formatError) return 'Il y a une erreur dans le format du fichier';
  }

  private isExcelFile() {
    const nameParts = this.fileName.split('.');
    return nameParts[nameParts.length - 1] === 'xls' || nameParts[nameParts.length - 1] === 'xlsx';
  }

  async import() {
    const faq = this.faq;

    await of(new SaveFaq({ faq })).pipe(
      tap((save) => this.store$.dispatch(save)),
      switchMapTo(this.actions$),
      ofType<FaqActionUnion>(FaqActionTypes.LoadFaqSuccess),
      take(1),
      filter((action) => action.type === FaqActionTypes.LoadFaqSuccess),
      tap(() => this.dialogRef.close()),
    ).toPromise();
  }

  getfilesize(size: number) {
    const units = ['o', 'Ko', 'Mo', 'Go', 'To'];
    let unit = units.shift();

    while (units.length && size > 2 ** 10) {
      size = size / 2 ** 10;
      unit = units.shift();
    }

    return `${+size.toFixed(2)} ${unit}`;
  }

}
