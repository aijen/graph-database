import { Component, Input } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { MatDialogRef } from '@angular/material/dialog';
import { MatTooltipModule } from '@angular/material/tooltip';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { ExcelService } from 'core/services/excel/excel.service';
import { faqState } from 'core/store/faq/faq.reducer';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { Observable } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { FaqImportComponent } from './faq-import.component';

@Component({
  selector: 'pit-close-modal',
  template: '',
})
class PitCloseModalStubComponent {
  @Input() class: any;
}

describe('FaqImportComponent', () => {
  let context: TestCtx<FaqImportComponent>;
  let actions: Observable<any>;
  let excelServiceStub: jasmine.SpyObj<ExcelService>;
  let matDialogRefStub: jasmine.SpyObj<MatDialogRef<FaqImportComponent>>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        MatTooltipModule,
      ],
      declarations: [
        FaqImportComponent,
        PitCloseModalStubComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: {
          faq: faqState,
        } }),
        provideMockActions(() => actions),
        { provide: ExcelService, useFactory: () => jasmine.createSpyObj('ExcelService', ['saveAsExcel', 'fileToWorkbook', 'sheetToJson'] as Array<keyof ExcelService>) },
        { provide: MatDialogRef, useFactory: () => jasmine.createSpyObj('MatDialogRef', ['close'] as Array<keyof MatDialogRef<FaqImportComponent>>) },
      ],
    })
  });

  beforeEach(async( async () => {
    actions = null;
    excelServiceStub = TestBed.get(ExcelService);
    matDialogRefStub = TestBed.get(MatDialogRef);
    context = await createStableTestContext(FaqImportComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
