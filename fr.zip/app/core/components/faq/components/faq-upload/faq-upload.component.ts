import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {MatDialog, MatDialogConfig, MatDialogRef} from "@angular/material/dialog";
import {map, take, tap} from "rxjs/operators";
import {BehaviorSubject, noop} from "rxjs";
import {Store} from "@ngrx/store";
import { fadeAnimation } from 'core/animations/animations';
import {AppState} from "shared/models/state.model";
import {GET_FAQ_FILE} from "core/services/http/http-client.service";
import {
  faqUploadStateSelector,
  getFaqFile,
  isFaqLoadingOrSaving,
  isFaqPristine
} from "core/store/faq/faqUpload/faq-upload.selectors";
import {
  DeleteFile, LoadFaqFiles,
  MarkUserFilesAsDirty, ResetUserFiles, SaveFaqFiles,
} from "core/store/faq/faqUpload/faq-upload.actions";



@Component({
  selector: 'pit-faq-upload',
  templateUrl: './faq-upload.component.html',
  styleUrls: ['./faq-upload.component.scss'],
  animations: [fadeAnimation()]
})
export class FaqUploadComponent implements OnInit {

  static openDialog(dialog: MatDialog, config: MatDialogConfig) {
    return dialog.open<FaqUploadComponent>(FaqUploadComponent, config);
  }

  @ViewChild('f')
  private fileInput: ElementRef;

  userFiles$ = this.store$.select(faqUploadStateSelector)
    .pipe(
      tap(state => this.checkErrors(state.userFiles)),
      tap(state => state.isPristine ? this.clearFiles() : noop()),
      map(state => state.userFiles),
    );
  isFaqSaving$ = this.store$.select(isFaqLoadingOrSaving);

  fileNames: string;
  files: File[] = [];
  hasError$ = new BehaviorSubject<boolean>(false);
  errorMessage: string;
  isFaqPristine$ = this.store$.select(isFaqPristine);

  constructor(
    private store$: Store<AppState>,
    private dialogRef: MatDialogRef<FaqUploadComponent>,
  ) {
  }

  ngOnInit() {
    this.store$.dispatch(new LoadFaqFiles());
  }

  getFileUrl(fileName: string) {
    return `${GET_FAQ_FILE}?fileName=${fileName}`;
  }

  delete(fileName: string) {
    this.store$.dispatch(new DeleteFile({fileName}));
  }

  async fileChange(files: File[]) {
    this.fileNames = '';
    this.files = files;

    for (let file of files) {
      const {name = '', size = 0} = file || {};
      const fileSize = this.getfilesize(size);

      this.fileNames = this.fileNames.length > 0 ?
        `${this.fileNames}\r\n${name} (${fileSize})` :
        `${name} (${fileSize})`;
    }

    const userFiles = await this.store$.select(getFaqFile).pipe(take(1)).toPromise();
    this.checkErrors(userFiles);

    this.store$.dispatch(new MarkUserFilesAsDirty());
  }

  private checkErrors(userFiles: string[]) {
    for (let file of this.files) {
      const {name = '', size = 0} = file || {};

      if (size > 10000000) {
        this.errorMessage = 'Les fichiers ne doivent pas dépasser 10Mo';
        this.hasError$.next(true);
        return;
      } else if (userFiles.includes(name)) {
        this.errorMessage = `Un fichier ayant le nom ${name} existe déja`;
        this.hasError$.next(true);
        return;
      }
    }

    this.hasError$.next(false);
  }

  private getfilesize(size: number) {
    const units = ['o', 'Ko', 'Mo', 'Go', 'To'];
    let unit = units.shift();

    while (units.length && size > 2 ** 10) {
      size = size / 2 ** 10;
      unit = units.shift();
    }

    return `${+size.toFixed(2)} ${unit}`;
  }

  save() {
    this.store$.dispatch(new SaveFaqFiles({files: this.files}));
  }

  private clearFiles() {
    this.fileNames = undefined;
    this.files = [];
    this.hasError$.next(false);
    this.fileInput.nativeElement.value = '';
  }

  reset() {
    this.store$.dispatch(new ResetUserFiles());
  }

  quit() {
    this.dialogRef.close();
  }
}
