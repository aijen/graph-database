import { Component, OnInit } from '@angular/core';
import {MatDialog, MatDialogConfig} from '@angular/material/dialog';
import { Store } from '@ngrx/store';
import { ExcelService } from 'core/services/excel/excel.service';
import { LoadAbout } from 'core/store/about/about.actions';
import { hasFaqManagement } from 'core/store/auth/auth.selectors';
import { LoadExistingMetrics } from 'core/store/existing-metrics/existing-metrics.actions';
import { LoadFaq } from 'core/store/faq/faq.actions';
import { FAQ } from 'core/store/faq/faq.model';
import { getFaq, isFaqLoadingOrSaving } from 'core/store/faq/faq.selectors';
import { BehaviorSubject, combineLatest, Observable } from 'rxjs';
import { map, take } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';
import { FaqImportComponent } from './components/faq-import/faq-import.component';
import {FaqUploadComponent} from "core/components/faq/components/faq-upload/faq-upload.component";

@Component({
  selector: 'cockpit-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.scss']
})
export class FaqComponent implements OnInit {

  FAQ$ = this.store$.select(getFaq);
  canEditFaq$ = this.store$.select(hasFaqManagement);
  isLoadingOrSaving$ = this.store$.select(isFaqLoadingOrSaving);
  exporting$ = new BehaviorSubject<boolean>(false);

  constructor(
    private store$: Store<AppState>,
    private dialog: MatDialog,
    private excelService: ExcelService,
  ) { }

  ngOnInit() {
    this.store$.dispatch(new LoadFaq());
    this.store$.dispatch( new LoadAbout() );
    this.store$.dispatch( new LoadExistingMetrics() );
  }

  isDisabled(): Observable<boolean> {
    return combineLatest(this.exporting$, this.isLoadingOrSaving$).pipe(map(([exporting, loadingOrSaving]) => exporting || loadingOrSaving));
  }

  import() {
    this.dialog.open(FaqImportComponent);
  }

  async export() {
    this.exporting$.next(true);

    const faq = await this.FAQ$.pipe(take(1)).toPromise();

    this.excelService.saveAsExcel(`faq_export`, [
      {
        name: 'FAQ',
        data: [
          ['Chapitre', 'Questions', 'Réponses'],
          ...this.generateFaqLines(faq)
        ],
      },
    ]);

    this.exporting$.next(false);
  }

  openUserFiles() {
    const config = new MatDialogConfig();
    config.disableClose = true;
    config.minWidth = '60rem';
    config.width = '60rem';

    FaqUploadComponent.openDialog(this.dialog, config);
  }

  private generateFaqLines(faqs: FAQ[]): string[][] {
    // clean text, replace '\n' with '\r\n'
    const clean = (text) => {
      return text.replace('\n', '\r\n');
    }

    const lines: string[][] = [];

    faqs.forEach(faq => faq.faq.forEach(f => {
      const line: string[] = [];

      line.push(faq.title);
      line.push(clean(f.title));
      line.push(f.description ? clean(f.description) : '');

      lines.push(line);
    }));

    return lines;
  }

}
