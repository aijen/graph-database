import { TextFieldModule } from '@angular/cdk/text-field';
import { HttpClientModule } from '@angular/common/http';
import { NgModule, Optional, SkipSelf } from '@angular/core';
import { MatDialogModule } from '@angular/material/dialog';
import { MatMenuModule } from '@angular/material/menu';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { RouterModule } from '@angular/router';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { AuthEffects } from 'core/store/auth/auth.effects';
import { authReducer } from 'core/store/auth/auth.reducer';
import { DialogConfirmModule } from 'shared/components/dialog-confirm/dialog-confirm.module';
import { SharedModule } from 'shared/shared.module';
import { AboutModule } from './components/about/about.module';
import { FaqDescriptionComponent } from './components/faq/components/faq-description/faq-description.component';
import { FaqImportComponent } from './components/faq/components/faq-import/faq-import.component';
import { FaqComponent } from './components/faq/faq.component';
import { LoadingComponent } from './components/loading/loading.component';
import { AlertIndicatorComponent } from './components/nav-bar/components/alert-indicator/alert-indicator.component';
import { GaugesComponent } from './components/nav-bar/components/gauges/gauges.component';
import { NavIconsComponent } from './components/nav-bar/components/nav-icons/nav-icons.component';
import { NavBarComponent } from './components/nav-bar/nav-bar.component';
import { MonitoringNotificationComponent } from './components/notifications/components/monitoring-notification/monitoring-notification.component';
import { NotificationEditComponent } from './components/notifications/components/notification-edit/notification-edit.component';
import { NotificationMenuComponent } from './components/notifications/components/notification-menu/notification-menu.component';
import { NotificationComponent } from './components/notifications/components/notification/notification.component';
import { NotificationFormComponent } from './components/notifications/containers/notification-form/notification-form.component';
import { NotificationContainerComponent } from './components/notifications/notifications-container/notifications-container.component';
import { SearchModule } from './components/search/search.module';
import { ExistingMetricsStoreModule } from './store/existing-metrics/existing-metrics.module';
import { FaqStoreModule } from './store/faq/faq.module';
import { GroupsStoreModule } from './store/groups/groups.module';
import { HierarchyStoreModule } from './store/hierarchy/hierarchy.module';
import { HolidaysEffects } from './store/holidays/holidays.effects';
import { HolidaysReducer } from './store/holidays/holidays.reducer';
import { NotificationsEffects } from './store/notifications/notifications.effects';
import { notificationsReducer } from './store/notifications/notifications.reducer';
import { PopulatedMetasStoreModule } from './store/populated-metas/populated-metas.module';
import { SnoozeEffects } from './store/snooze/snooze.effects';
import { snoozeReducer } from './store/snooze/snooze.reducer';
import { TemplatesFormStoreModule } from './store/templates/templates.form.module';
import {FaqUploadComponent} from "core/components/faq/components/faq-upload/faq-upload.component";
import {MatProgressSpinnerModule} from "@angular/material/progress-spinner";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {FaqUploadStoreModule} from "core/store/faq/faqUpload/faq-upload.module";


@NgModule({
  declarations: [
    NavBarComponent,
    AlertIndicatorComponent,
    FaqComponent,
    GaugesComponent,
    NavIconsComponent,
    LoadingComponent,
    NotificationFormComponent,
    NotificationComponent,
    NotificationContainerComponent,
    MonitoringNotificationComponent,
    NotificationMenuComponent,
    NotificationEditComponent,
    FaqImportComponent,
    FaqDescriptionComponent,
    FaqUploadComponent,

  ],
  entryComponents: [
    FaqComponent,
    NotificationEditComponent,
    FaqImportComponent,
    FaqUploadComponent
  ],
  imports: [
    SharedModule,
    RouterModule,
    HttpClientModule,
    MatSnackBarModule,
    SearchModule,
    AboutModule,
    StoreModule.forFeature('auth', authReducer),
    EffectsModule.forFeature([AuthEffects]),
    StoreModule.forFeature('notifications', notificationsReducer),
    EffectsModule.forFeature([NotificationsEffects]),
    HierarchyStoreModule,
    StoreModule.forFeature('snooze', snoozeReducer),
    EffectsModule.forFeature([SnoozeEffects]),
    StoreModule.forFeature('holidays', HolidaysReducer),
    EffectsModule.forFeature([HolidaysEffects]),
    MatMenuModule,
    MatDialogModule,
    DialogConfirmModule,
    TextFieldModule,
    PopulatedMetasStoreModule,
    TemplatesFormStoreModule,
    GroupsStoreModule,
    FaqStoreModule,
    ExistingMetricsStoreModule,
    MatProgressSpinnerModule,
    BrowserAnimationsModule,
    FaqUploadStoreModule
  ],
  exports: [NavBarComponent, LoadingComponent, NotificationContainerComponent,],
})
export class CoreModule {
  constructor(@Optional() @SkipSelf() coreModule: CoreModule) {
    if (coreModule) {
      throw new Error('Core Module is already imported');
    }
  }
}
