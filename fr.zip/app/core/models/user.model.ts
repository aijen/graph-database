import { GroupsValueDTO } from 'core/store/groups/groups.model';
import { UserRole } from './userRoles.model';

export class User {

  public static from( from?: Partial<User> | null ) {
    const user = new User();
    if( !from ) return user;
    if( from.userId )    user.userId    = from.userId;
    if( from.firstName ) user.firstName = from.firstName;
    if( from.lastName )  user.lastName  = from.lastName;
    return user;
  }

  userId: string;
  gershwinId: string;
  rtfeId: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  serviceName: string;
  serviceCode: string;
  legalStatus: string;
  igg: string;
  job: string;
  roles: string[][];
}

export interface PitUser {
  readonly id: string;
  userId: string;
  profil: Profil;
  email: string;
}

export interface PitUserDTO {
  readonly id: string;
  userId: string;
  profiles: UserRole[];
  email?: string;
}

export interface PitUserWithGroups {
  user: PitUserDTO;
  groups: GroupsValueDTO[];
}

export interface UserName {
  userId?: string;
  firstName?: string;
  name?: string;
}

export interface Profil {
  profiles: UserRole[];
  permissions: Permissions[];
}

export const enum Permissions {
  ALL = 'ALL',
  ADMIN_SCREEN = 'ADMIN_SCREEN',
  ADMIN_ALERT_TAB = 'ADMIN_ALERT_TAB',
  ADMIN_MUTE_TAB = 'ADMIN_MUTE_TAB',
  ADMIN_BASELINES_TAB = 'ADMIN_BASELINES_TAB',
  ADMIN_METEO_TAB = 'ADMIN_METEO_TAB',
  ADMIN_PERIMETER_TAB = 'ADMIN_PERIMETER_TAB',
  ADMIN_ARBORESCENCE_TAB = 'ADMIN_ARBORESCENCE_TAB',
  ADMIN_METRICS_TAB = 'ADMIN_METRICS_TAB',
  ADMIN_PROFILS_TAB = 'ADMIN_PROFILS_TAB',
  ADMIN_EVENTS_TAB = 'ADMIN_EVENTS_TAB',
  ADMIN_PROFIL_GIVER = 'ADMIN_PROFIL_GIVER',
  SUPER_ADMIN_PROFIL_GIVER = 'SUPER_ADMIN_PROFIL_GIVER',
  PUBLIC_TEMPLATE_CREATION = 'PUBLIC_TEMPLATE_CREATION',
  ADMIN_PROFILS_FULL_MANAGEMENT = 'ADMIN_PROFILS_FULL_MANAGEMENT',
  FAQ_MANAGEMENT = 'FAQ_MANAGEMENT',
}
