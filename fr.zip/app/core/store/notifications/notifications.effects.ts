import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { ExcelService } from 'core/services/excel/excel.service';
import { INTERVAL } from 'core/services/http/http-client.service';
import { combineSortStrategies, sortByPropStrategy, sortDateStrategy, SORT_DIRECTION } from 'core/utils/sortStrategies';
import moment from 'moment';
import { concat } from 'rxjs';
import { of } from 'rxjs/observable/of';
import { TimerObservable } from 'rxjs/observable/TimerObservable';
import { catchError, map, mapTo, switchMap, take, takeUntil, tap } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { ColInfo, Range } from 'xlsx/types';
import { getUserConnected$ } from '../auth/auth.selectors';
import { getLeavesKeys } from '../hierarchy/hierarchy.selectors';
import { DeleteNotification, DeleteNotificationError, DeleteNotificationSuccess, ExportMonitoringNotificationsError, ExportMonitoringNotificationsSuccess, GetNotifications, GetNotificationsError, GetNotificationsSuccess, NotificationsActions, NotificationsActionTypes, SaveNotificationError, SaveNotificationSuccess, StartNotificationPuller, StopNotificationPuller, UpdateNotification, UpdateNotificationError, UpdateNotificationSuccess } from './notifications.actions';
import { NotificationsService } from './notifications.service';

@Injectable({providedIn: 'root'})
export class NotificationsEffects {
  public static messages = {
    DeleteError: `
      Une erreur est survenue pendant la suppression de la notification : veuillez rééssayer ou contacter le support Cockpit
    `,
    UpdateError: `
      Une erreur est survenue pendant la mise à jour de la notification : veuillez rééssayer ou contacter le support Cockpit
    `
  }

  constructor(
    private actions$: Actions<NotificationsActions>,
    private notificationsService: NotificationsService,
    private store$: Store<AppState>,
    private excelService: ExcelService,
    private snackbar: MessageHandler,
  ) {}

  @Effect()
  StartNotificationPuller = this.actions$.pipe(
    ofType(NotificationsActionTypes.StartNotificationPuller),
    switchMap(() => {
      return TimerObservable.create(0, INTERVAL).pipe(
        map(() => {
          const to = moment().unix() + 60;
          const from = to - 24 * 60 * 60;
          return new GetNotifications(from, to);
        }),
        takeUntil(this.actions$.pipe(ofType(NotificationsActionTypes.StopNotificationPuller)))
      );
    }),
  );

  @Effect()
  GetNotifications = this.actions$.pipe(
    ofType(NotificationsActionTypes.GetNotifications),
    switchMap((action) => this.notificationsService.load(action)),
    map(
      (notifications) =>
        new GetNotificationsSuccess(
          notifications.filter(notif => !notif.auto).sort( combineSortStrategies([ [ sortByPropStrategy('date', sortDateStrategy), SORT_DIRECTION.DESCENDING] ] ) ),
          notifications.filter(notif =>  notif.auto).sort( combineSortStrategies([ [ sortByPropStrategy('date', sortDateStrategy), SORT_DIRECTION.DESCENDING] ] ) )
        )
    ),
    catchError((error: Error, caught) => {
      console.log(NotificationsActionTypes.GetNotificationsError, ' :', error);
      return concat(of(new GetNotificationsError(error)), caught);
    })
  );

  @Effect()
  SaveNotification = this.actions$.pipe(
    ofType(NotificationsActionTypes.SaveNotification),
    switchMap( action => this.store$.pipe(
      getUserConnected$,
      map( user => ({action, user}) )
    )),
    switchMap( ({action, user}) => {
      const notification = action.payload;
      const { userId, firstName, lastName: name } = user;
      notification.user = { userId, firstName, name };
      notification.date = new Date();
      return this.notificationsService.save( notification )
    }),
    switchMap(() => [
      new SaveNotificationSuccess(),
      new StopNotificationPuller(),
      new StartNotificationPuller()
    ]),
    catchError((error: Error, caught) => {
      console.log(NotificationsActionTypes.SaveNotificationError, ' :', error);
      return concat(of(new SaveNotificationError(error)), caught);
    })
  );

  @Effect()
  ExportMonitoringNotifications = this.actions$.pipe(
    ofType(NotificationsActionTypes.ExportMonitoringNotifications),
    switchMap((action) => this.notificationsService.load(action)),
    switchMap( notifications => this.store$.select(getLeavesKeys).pipe( take(1), map( keys => ({ notifications, keys }) ) ) ),
    map( ({ notifications, keys }) => {
      const fileName = moment().format('[Pit_Export_]YYYY-MM-DD_HH[h]mm');
      const name = 'Monitoring Notifications Export';

      const headers: string[][] = [
        ['Leaf','TimeSlot','State','Meta']
      ];

      const linesData = notifications.filter( notif => notif.auto && keys.includes(notif.leafKey) )
      .sort(combineSortStrategies([ [ sortByPropStrategy('date', sortDateStrategy), SORT_DIRECTION.DESCENDING] ] ))
      .map(data => {
        return [ data.title, moment(data.date).toDate(), data.severity, data.metaType ];
      });

      const cols: ColInfo[] = [
        { wch: 30 },
        { wch: 16 },
        { wch: 10 },
        { wch: 13 }
      ];

      const merges: Range[] = [];

      this.excelService.saveAsExcel(fileName, [{ name, data: [...headers, ...linesData], cols, merges }]);

      return new ExportMonitoringNotificationsSuccess();
    }),
    catchError((error: Error, caught) => {
      console.log(NotificationsActionTypes.ExportMonitoringNotificationsError, ':', error);
      return concat(of(new ExportMonitoringNotificationsError(error)), caught);
    })
  );

  @Effect()
  UpdateNotification = this.actions$.pipe(
    ofType(NotificationsActionTypes.UpdateNotification),
    switchMap((action: UpdateNotification) => this.notificationsService.update( action.payload ).pipe(mapTo(action))),
    map(({ payload }) => new UpdateNotificationSuccess(payload)),
    catchError((error: Error, caught) => {
      return concat(of(new UpdateNotificationError({error})), caught);
    })
  );

  @Effect({ dispatch: false })
  UpdateError = this.actions$.pipe(
    ofType<UpdateNotificationError>(NotificationsActionTypes.UpdateNotificationError),
    tap(action => { console.error(action.payload.error); this.snackbar.show({ message: NotificationsEffects.messages.UpdateError, action: 'OK', isError: true, id: action.type }) })
  )

  @Effect()
  DeleteNotification = this.actions$.pipe(
    ofType(NotificationsActionTypes.DeleteNotification),
    switchMap((action: DeleteNotification) => this.notificationsService.delete( action.payload ).pipe(mapTo(action))),
    map(({ payload }) => new DeleteNotificationSuccess(payload)),
    catchError((error: Error, caught) => {
      return concat(of(new DeleteNotificationError({error})), caught);
    })
  );

  @Effect({ dispatch: false })
  DeleteError = this.actions$.pipe(
    ofType<DeleteNotificationError>(NotificationsActionTypes.DeleteNotificationError),
    tap(action => { console.error(action.payload.error); this.snackbar.show({ message: NotificationsEffects.messages.DeleteError, action: 'OK', isError: true, id: action.type }) })
  )
}
