import { Action } from '@ngrx/store';
import { CockpitNotification } from './notifications.model';

export enum NotificationsActionTypes {
  GetNotifications = '[COCKPIT] Get Notifications',
  GetNotificationsSuccess = '[COCKPIT] Get Notifications Success',
  GetNotificationsError = '[COCKPIT] Get Notifications Error',
  SaveNotification = '[COCKPIT] Save Notification',
  SaveNotificationSuccess = '[COCKPIT] Save Notification Success',
  SaveNotificationError = '[COCKPIT] Save Notification Error',
  StartNotificationPuller = '[COCKPIT] Start Puller',
  StartNotificationPullerError = '[COCKPIT] Start Puller Notification Error',
  StopNotificationPuller = '[COCKPIT] Stop Puller',
  ToggleNotifications = '[CockPit] Toggle Notifications',
  ExportMonitoringNotifications = '[COCKPIT] Export Monitoring Notifications',
  ExportMonitoringNotificationsSuccess = '[COCKPIT] Export Monitoring Notifications Success',
  ExportMonitoringNotificationsError = '[COCKPIT] Export Monitoring Notifications Error',
  UpdateNotification = '[COCKPIT] Update Notification',
  UpdateNotificationSuccess = '[COCKPIT] Update Notification Success',
  UpdateNotificationError = '[COCKPIT] Update Notification Error',
  DeleteNotification = '[COCKPIT] Delete Notification',
  DeleteNotificationSuccess = '[COCKPIT] Delete Notification Success',
  DeleteNotificationError = '[COCKPIT] Delete Notification Error',
}

export class GetNotifications implements Action {
  readonly type = NotificationsActionTypes.GetNotifications;
  constructor(public from: number, public to: number) {}
}
export class GetNotificationsSuccess implements Action {
  readonly type = NotificationsActionTypes.GetNotificationsSuccess;
  constructor(public manual: CockpitNotification[], public auto: CockpitNotification[]) {}
}

export class GetNotificationsError implements Action {
  readonly type = NotificationsActionTypes.GetNotificationsError;
  constructor(public error: Error) {}
}

export class SaveNotification implements Action {
  readonly type = NotificationsActionTypes.SaveNotification;
  constructor(public payload: CockpitNotification) {}
}
export class SaveNotificationSuccess implements Action {
  readonly type = NotificationsActionTypes.SaveNotificationSuccess;
}

export class SaveNotificationError implements Action {
  readonly type = NotificationsActionTypes.SaveNotificationError;
  constructor(public error: Error) {}
}

export class StartNotificationPuller implements Action {
  readonly type = NotificationsActionTypes.StartNotificationPuller;
}

export class StartNotificationPullerError implements Action {
  readonly type = NotificationsActionTypes.StartNotificationPullerError;
  constructor(public error: Error) {}
}

export class StopNotificationPuller implements Action {
  readonly type = NotificationsActionTypes.StopNotificationPuller;
}

export class ToggleNotifications implements Action {
  readonly type = NotificationsActionTypes.ToggleNotifications;
  constructor(public payload?: boolean) {}
}

export class ExportMonitoringNotifications implements Action {
  readonly type = NotificationsActionTypes.ExportMonitoringNotifications;
  constructor(public from: number, public to: number) {}
}
export class ExportMonitoringNotificationsSuccess implements Action {
  readonly type = NotificationsActionTypes.ExportMonitoringNotificationsSuccess;
}

export class ExportMonitoringNotificationsError implements Action {
  readonly type = NotificationsActionTypes.ExportMonitoringNotificationsError;
  constructor(public error: Error) {}
}

export class UpdateNotification implements Action {
  readonly type = NotificationsActionTypes.UpdateNotification;
  constructor(public payload: CockpitNotification) {}
}

export class UpdateNotificationSuccess implements Action {
  readonly type = NotificationsActionTypes.UpdateNotificationSuccess;
  constructor(public payload: CockpitNotification) {}
}

export class UpdateNotificationError implements Action {
  readonly type = NotificationsActionTypes.UpdateNotificationError;
  constructor(public payload: { error: Error }) {}
}

export class DeleteNotification implements Action {
  readonly type = NotificationsActionTypes.DeleteNotification;
  constructor(public payload: CockpitNotification) {}
}

export class DeleteNotificationSuccess implements Action {
  readonly type = NotificationsActionTypes.DeleteNotificationSuccess;
  constructor(public payload: CockpitNotification) {}
}

export class DeleteNotificationError implements Action {
  readonly type = NotificationsActionTypes.DeleteNotificationError;
  constructor(public payload: { error: Error }) {}
}

export type NotificationsActions =
  | GetNotifications
  | GetNotificationsSuccess
  | GetNotificationsError
  | SaveNotification
  | SaveNotificationSuccess
  | SaveNotificationError
  | StartNotificationPuller
  | StartNotificationPullerError
  | StopNotificationPuller
  | ToggleNotifications
  | ExportMonitoringNotifications
  | ExportMonitoringNotificationsSuccess
  | ExportMonitoringNotificationsError
  | UpdateNotification
  | UpdateNotificationSuccess
  | UpdateNotificationError
  | DeleteNotification
  | DeleteNotificationSuccess
  | DeleteNotificationError
;
