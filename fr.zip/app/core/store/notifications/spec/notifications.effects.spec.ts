import { HttpErrorResponse } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { User } from 'core/models/user.model';
import { ExcelService } from 'core/services/excel/excel.service';
import { DELETE_NOTIFICATIONS_URL, SAVE_NOTIFICATIONS_URL } from 'core/services/http/http-client.service';
import { authState } from 'core/store/auth/auth.reducer';
import merge from 'lodash/merge';
import moment from 'moment';
import { configureTestSuite } from 'ng-bullet';
import { Observable, of, Subject, throwError } from 'rxjs';
import { marbles } from 'rxjs-marbles/jasmine';
import { take } from 'rxjs/operators';
import { Leaf } from 'shared/models/leaf.model';
import { Node } from 'shared/models/node.model';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { DeleteNotification, DeleteNotificationError, DeleteNotificationSuccess, ExportMonitoringNotifications, ExportMonitoringNotificationsError, ExportMonitoringNotificationsSuccess, GetNotifications, GetNotificationsError, GetNotificationsSuccess, SaveNotification, SaveNotificationError, SaveNotificationSuccess, StartNotificationPuller, StopNotificationPuller, UpdateNotification, UpdateNotificationError, UpdateNotificationSuccess } from '../notifications.actions';
import { NotificationsEffects } from '../notifications.effects';
import { CockpitNotification, SEVERITY } from '../notifications.model';
import { NotificationsService } from '../notifications.service';


describe('NotificationsEffects', () => {
  let service: NotificationsEffects;
  let notificationsService: jasmine.SpyObj<NotificationsService>;
  let actions: Observable<any>;
  let store: MockStore<DeepPartial<AppState>>

  const createNode = ( node?: Partial<Node> ): Node => merge(new Node, node);
  const createLeaf = ( leaf?: Partial<Leaf> ): Leaf => merge(new Leaf, leaf);
  const generateNotification = ( notification?: Partial<CockpitNotification> ) => merge( new CockpitNotification(SEVERITY.ERROR, 'title', false), notification )

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [
        NotificationsEffects,
        provideMockStore<Partial<AppState>>({ initialState: {} }),
        provideMockActions(() => actions),
        { provide: ExcelService, useFactory: () => jasmine.createSpyObj('ExcelService', ['saveAsExcel']) },
        { provide: MessageHandler, useFactory: () => jasmine.createSpyObj('MessageHandler', ['ngOnDestroy', 'show']) },
        { provide: NotificationsService, useFactory: () => jasmine.createSpyObj('NotificationsService', ['load', 'save', 'update', 'delete'] as Array<keyof NotificationsService>) },
      ],
    })
  });

  beforeEach(() => {
    jasmine.clock().install()
    jasmine.clock().mockDate( new Date(2000, 6, 15) )
    store = TestBed.get(Store)
    service = TestBed.get(NotificationsEffects);
    notificationsService = TestBed.get(NotificationsService);
  } );

  afterEach(() => {
    jasmine.clock().uninstall()
  });

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  describe('StartNotificationPuller', () => {

    it('should emit GetNotifications Action every minute', marbles(m => {
      actions = m.hot('a', { a: new StartNotificationPuller })
      const expected = m.hot('a 999ms 59s b 999ms 59s (c|)', {
        a: new GetNotifications(
          moment('2000/07/14 00:01:00', 'YYYY/MM/DD HH:mm:ss').unix(),
          moment('2000/07/15 00:01:00', 'YYYY/MM/DD HH:mm:ss').unix()
        ),
        b: new GetNotifications(
          moment('2000/07/14 00:01:00', 'YYYY/MM/DD HH:mm:ss').unix(),
          moment('2000/07/15 00:01:00', 'YYYY/MM/DD HH:mm:ss').unix()
        ),
        c: new GetNotifications(
          moment('2000/07/14 00:01:00', 'YYYY/MM/DD HH:mm:ss').unix(),
          moment('2000/07/15 00:01:00', 'YYYY/MM/DD HH:mm:ss').unix()
        ),
      })

      m.expect(service.StartNotificationPuller.pipe(take(3))).toBeObservable(expected)
    }))

    it('should stop emitting after a StopNotificationPuller Action is dispatched', marbles(m => {
      actions = m.hot('a b', { a: new StartNotificationPuller, b: new StopNotificationPuller() })
      const expected = m.hot('(a) 5m -', {
        a: new GetNotifications(
          moment('2000/07/14 00:01:00', 'YYYY/MM/DD HH:mm:ss').unix(),
          moment('2000/07/15 00:01:00', 'YYYY/MM/DD HH:mm:ss').unix()
        ),
      })

      m.expect(service.StartNotificationPuller).toBeObservable(expected)
    }))

  })

  describe('GetNotifications', () => {

    it('should fetch the notifications', marbles(m => {
      const baseNotification = generateNotification({
        severity: CockpitNotification.SEVERITY.INFO,
        title: 'title',
        auto: false,
        message: 'message',
        user: { firstName: 'firstName', name: 'name' },
        metaType: null,
      })
      const response: CockpitNotification[] = [
        generateNotification({
          ...baseNotification,
          date: new Date(2000, 6, 15),
          id: 'id1',
        }),
        generateNotification({
          ...baseNotification,
          date: new Date(2000, 6, 15, 1),
          id: 'id2',
        }),
        generateNotification({
          ...baseNotification,
          auto: true,
          message: null,
          metaType: CockpitNotification.META_TYPE.AVAILABILITY,
          date: new Date(2000, 6, 15),
          id: 'id3',
        }),
        generateNotification({
          ...baseNotification,
          auto: true,
          message: null,
          metaType: CockpitNotification.META_TYPE.AVAILABILITY,
          date: new Date(2000, 6, 15, 1),
          id: 'id4',
        }),
      ]
      const result = new GetNotificationsSuccess( [
        generateNotification({
          ...baseNotification,
          date: new Date(2000, 6, 15, 1),
          id: 'id2',
        }),
        generateNotification({
          ...baseNotification,
          date: new Date(2000, 6, 15),
          id: 'id1',
        }),
      ], [
        generateNotification({
          ...baseNotification,
          auto: true,
          message: null,
          metaType: CockpitNotification.META_TYPE.AVAILABILITY,
          date: new Date(2000, 6, 15, 1),
          id: 'id4',
        }),
        generateNotification({
          ...baseNotification,
          auto: true,
          message: null,
          metaType: CockpitNotification.META_TYPE.AVAILABILITY,
          date: new Date(2000, 6, 15),
          id: 'id3',
        }),
      ] )
      const from = moment('2000/07/14 00:01:00', 'YYYY/MM/DD HH:mm:ss').unix()
      const to = moment('2000/07/15 00:01:00', 'YYYY/MM/DD HH:mm:ss').unix()

      actions = m.hot('a', { a: new GetNotifications(from, to) })
      const expected = m.hot('a', { a: result })

      notificationsService.load.and.returnValues( of(response) )
      m.expect(service.GetNotifications).toBeObservable(expected)

    }))

    it('should dispatch a GetNotificationsError Action when failing', marbles(m => {
      spyOn(console, 'log')
      actions = m.hot('a', { a: new GetNotifications(0, 0) })
      const expected = m.hot('a', { a: new GetNotificationsError( new HttpErrorResponse({ status: 500 }) ) })

      notificationsService.load.and.returnValue( throwError( new HttpErrorResponse({ status: 500 }) ) )
      m.expect(service.GetNotifications).toBeObservable(expected)
    }))

  })

  describe('SaveNotification', () => {

    it('should save the notification', marbles(m => {
      const user = User.from({ userId: 'userId', firstName: 'firstName', lastName: 'lastName' })
      store.setState({
        auth: { ...authState, isUserAuthenticated: true, user }
      })
      actions = m.hot('a', { a: new SaveNotification( new CockpitNotification(CockpitNotification.SEVERITY.INFO, 'title', false) ) })
      const expected = m.hot('(abc)', {
        a: new SaveNotificationSuccess(),
        b: new StopNotificationPuller(),
        c: new StartNotificationPuller(),
      })

      notificationsService.save.and.returnValue( of('') )
      m.expect(service.SaveNotification).toBeObservable(expected)
    }))

    it('should dispatch a SaveNotificationError Action when failing', marbles(m => {
      spyOn(console, 'log')
      const user = User.from({ userId: 'userId', firstName: 'firstName', lastName: 'lastName' })
      store.setState({
        auth: { ...authState, isUserAuthenticated: true, user }
      })
      actions = m.hot('a', { a: new SaveNotification( new CockpitNotification(CockpitNotification.SEVERITY.INFO, 'title', false) ) })
      const expected = m.hot('a', {
        a: new SaveNotificationError( new HttpErrorResponse({ status: 500 }) )
      })

      notificationsService.save.and.returnValue( throwError( new HttpErrorResponse({ status: 500 }) ) )
      m.expect(service.SaveNotification).toBeObservable(expected)
    }))

  })

  describe('ExportMonitoringNotifications', () => {

    it('should fetch the auto notifications and save them as excel (sorted by date descending)', () => {
      jasmine.clock().mockDate( new Date(2000, 6, 15, 1, 2) )
      store.setState({ hierarchy: { nodes: [
        createNode({
          leaves: [ createLeaf({ key: 'leaf1' }) ]
        }),
      ] } })
      const subject = actions = new Subject()
      const next = jasmine.createSpy('next')
      const from = moment('2000/07/14 00:01:00', 'YYYY/MM/DD HH:mm:ss').unix()
      const to = moment('2000/07/15 00:01:00', 'YYYY/MM/DD HH:mm:ss').unix()
      const response: CockpitNotification[] = [
        generateNotification({
          severity: CockpitNotification.SEVERITY.INFO,
          title: 'title',
          auto: false,
          message: 'message',
          user: { firstName: 'firstName', name: 'name' },
          date: new Date(2000, 6, 15),
          id: 'id1',
        }),
        generateNotification({
          severity: CockpitNotification.SEVERITY.INFO,
          title: 'title',
          auto: true,
          metaType: CockpitNotification.META_TYPE.AVAILABILITY,
          date: new Date(2000, 6, 15),
          id: 'id2',
          leafKey: 'leaf1',
        }),
        generateNotification({
          severity: CockpitNotification.SEVERITY.INFO,
          title: 'title',
          auto: true,
          metaType: CockpitNotification.META_TYPE.AVAILABILITY,
          date: new Date(2000, 6, 15, 1),
          id: 'id3',
          leafKey: 'leaf1',
        }),
        generateNotification({
          severity: CockpitNotification.SEVERITY.INFO,
          title: 'title',
          auto: true,
          metaType: CockpitNotification.META_TYPE.AVAILABILITY,
          date: new Date(2000, 6, 15, 2),
          id: 'id4',
          leafKey: 'leaf2',
        }),
      ]
      const sub = service.ExportMonitoringNotifications.subscribe(next)

      notificationsService.load.and.returnValue( of(response) )
      subject.next( new ExportMonitoringNotifications( from, to ) )

      const excelService:jasmine.SpyObj<ExcelService> = TestBed.get(ExcelService)
      expect(excelService.saveAsExcel).toHaveBeenCalled()
      expect(excelService.saveAsExcel.calls.mostRecent().args[0]).toEqual(`Pit_Export_2000-07-15_01h02`)
      expect(excelService.saveAsExcel.calls.mostRecent().args[1][0].data).toEqual([
        [ 'Leaf' , 'TimeSlot',              'State',                            'Meta'],
        [ 'title', new Date(2000, 6, 15, 1), CockpitNotification.SEVERITY.INFO, CockpitNotification.META_TYPE.AVAILABILITY ],
        [ 'title', new Date(2000, 6, 15),    CockpitNotification.SEVERITY.INFO, CockpitNotification.META_TYPE.AVAILABILITY ],
      ])
      expect(next).toHaveBeenCalledWith( new ExportMonitoringNotificationsSuccess() )

      sub.unsubscribe()
    })

    it('should dispatch a ExportMonitoringNotificationsError Action when failing', marbles(m => {
      actions = m.hot('a', { a: new ExportMonitoringNotifications( 0, 0 ) })
      const expected = m.hot('a', { a: new ExportMonitoringNotificationsError( new HttpErrorResponse({ status: 500 }) ) })

      notificationsService.load.and.returnValue( throwError( new HttpErrorResponse({ status: 500 }) ) )
      m.expect(service.ExportMonitoringNotifications).toBeObservable(expected)
    }))

  })

  describe('UpdateNotification', () => {

    it('should update the notification', marbles(m => {
      const user = User.from({ userId: 'userId', firstName: 'firstName', lastName: 'lastName' })
      actions = m.hot('a', { a: new UpdateNotification( generateNotification({ user }) ) })
      const expected = m.hot('(a)', { a: new UpdateNotificationSuccess(generateNotification({ user })) })

      notificationsService.update.and.returnValue( of('') )
      m.expect(service.UpdateNotification).toBeObservable(expected)
    }))

    it('should dispatch a UpdateNotificationError Action when failing', marbles(m => {
      const user = User.from({ userId: 'userId', firstName: 'firstName', lastName: 'lastName' })
      actions = m.hot('a', { a: new UpdateNotification( generateNotification({ user }) ) })
      const expected = m.hot('a', { a: new UpdateNotificationError( { error: new HttpErrorResponse({ status: 500 })} ) })

      notificationsService.update.and.returnValue( throwError( new HttpErrorResponse({ status: 500 }) ) )
      m.expect(service.UpdateNotification).toBeObservable(expected)
    }))

  })

  describe('UpdateError', () => {

    it('should show an error message', () => {
      spyOn(console, 'error')
      const error = new HttpErrorResponse({ error: 'Service unavailable', status: 503, statusText: 'KO', url: SAVE_NOTIFICATIONS_URL })
      const snackbar: jasmine.SpyObj<MessageHandler> = TestBed.get(MessageHandler)
      const subject = actions = new Subject()
      const next = jasmine.createSpy('next')
      const sub = service.UpdateError.subscribe(next)
      subject.next( new UpdateNotificationError( { error } ) )

      expect(console.error).toHaveBeenCalled()
      expect(snackbar.show).toHaveBeenCalled()

      sub.unsubscribe()
    })

  })

  describe('DeleteNotification', () => {

    it('should delete the notification', marbles(m => {
      const user = User.from({ userId: 'userId', firstName: 'firstName', lastName: 'lastName' })
      actions = m.hot('a', { a: new DeleteNotification( generateNotification({ user }) ) })
      const expected = m.hot('(a)', { a: new DeleteNotificationSuccess(generateNotification({ user })) })

      notificationsService.delete.and.returnValue( of('') )
      m.expect(service.DeleteNotification).toBeObservable(expected)
    }))

    it('should dispatch a DeleteNotificationError Action when failing', marbles(m => {
      const user = User.from({ userId: 'userId', firstName: 'firstName', lastName: 'lastName' })
      actions = m.hot('a', { a: new DeleteNotification( generateNotification({ user }) ) })
      const expected = m.hot('a', { a: new DeleteNotificationError( { error: new HttpErrorResponse({ status: 500 }) } ) })

      notificationsService.delete.and.returnValue( throwError( new HttpErrorResponse({ status: 500 }) ) )
      m.expect(service.DeleteNotification).toBeObservable(expected)
    }))

  })

  describe('DeleteError', () => {

    it('should show an error message', () => {
      spyOn(console, 'error')
      const error = new HttpErrorResponse({ error: 'Service unavailable', status: 503, statusText: 'KO', url: DELETE_NOTIFICATIONS_URL })
      const snackbar = TestBed.get(MessageHandler)
      const subject = actions = new Subject()
      const next = jasmine.createSpy('next')
      const sub = service.DeleteError.subscribe(next)
      subject.next( new DeleteNotificationError( { error } ) )

      expect(console.error).toHaveBeenCalled()
      expect(snackbar.show).toHaveBeenCalled()

      sub.unsubscribe()
    })

  })


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
