import merge from 'lodash/merge';
import { AppState } from 'shared/models/state.model';
import { DeleteNotificationSuccess, GetNotificationsSuccess, ToggleNotifications, UpdateNotificationSuccess } from '../notifications.actions';
import { CockpitNotification, NotificationsState, SEVERITY } from '../notifications.model';
import { initialState, notificationsReducer } from '../notifications.reducer';

// necessary to avoid the error :
// Invalid module name in augmentation, module 'shared/models/state.model' cannot be found.
let happy_compiler: AppState; // tslint:disable-line


const generateNotification = ( notification?: Partial<CockpitNotification> ) => merge( new CockpitNotification(SEVERITY.ERROR, 'title', false), notification )

describe('Notifications Reducer', () => {

  function getState( partialState: DeepPartial<NotificationsState> = {} ) {
    return merge({}, initialState, partialState);
  }

  describe('undefined action', () => {

    it('should return the default state', () => {
      const action = { type: null, payload: null };
      const state = notificationsReducer( undefined, action );

      expect(state).toBe(initialState);
    })

  });

  describe('GetNotificationsSuccess', () => {

    it('should save the notifications in the state', () => {
      const action = new GetNotificationsSuccess([
        generateNotification()
      ], [
        generateNotification({ auto: true })
      ]);
      const state = notificationsReducer( initialState, action );

      expect(state).toEqual(jasmine.objectContaining<NotificationsState>({
        notifications: [
          generateNotification()
        ],
        monitoringNotifications: [
          generateNotification({ auto: true })
        ]
      }));
    })

  })

  describe('ToggleNotifications', () => {

    it('should toggle the open state', () => {
      {
        const action = new ToggleNotifications();
        const state = notificationsReducer( getState({ open: false }), action );

        expect(state).toEqual(jasmine.objectContaining<NotificationsState>({
          open: true
        }))
      }
      {
        const action = new ToggleNotifications();
        const state = notificationsReducer( getState({ open: true }), action );

        expect(state).toEqual(jasmine.objectContaining<NotificationsState>({
          open: false
        }))
      }
    })

    it('should save the open state if the overload is set', () => {
      {
        const action = new ToggleNotifications(true);
        const state = notificationsReducer( getState({ open: true }), action );

        expect(state).toEqual(jasmine.objectContaining<NotificationsState>({
          open: true
        }))
      }
      {
        const action = new ToggleNotifications(false);
        const state = notificationsReducer( getState({ open: false }), action );

        expect(state).toEqual(jasmine.objectContaining<NotificationsState>({
          open: false
        }))
      }
    })

  })

  describe('UpdateNotificationSuccess', () => {

    it('should replace a notification by the updated one', () => {
      const updatedNotification = generateNotification({ id: 'objectId', title: 'updated' });
      const notifications = [generateNotification(), generateNotification({ id: 'objectId' })];
      const startState = {
        ...initialState,
        notifications,
      };
      const action = new UpdateNotificationSuccess(updatedNotification);
      const state = notificationsReducer( startState, action );

      expect(state.notifications).toEqual([generateNotification(), updatedNotification]);
    })

  })

  describe('DeleteNotificationSuccess', () => {

    it('should remove the notification', () => {
      const deletedNotification = generateNotification({ id: 'objectId' });
      const notifications = [generateNotification(), deletedNotification];
      const startState = {
        ...initialState,
        notifications,
      };
      const action = new DeleteNotificationSuccess(deletedNotification);
      const state = notificationsReducer( startState, action );

      expect(state.notifications).toEqual([generateNotification()]);
    })

  })

} );
