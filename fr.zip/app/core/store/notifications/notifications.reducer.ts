import { combineSortStrategies, sortByPropStrategy, sortDateStrategy, SORT_DIRECTION } from 'core/utils/sortStrategies';
import { NotificationsActions, NotificationsActionTypes } from './notifications.actions';
import { NotificationsState } from './notifications.model';

export const initialState: NotificationsState = {
  notifications: [],
  monitoringNotifications: [],
  open: true,
};

export function notificationsReducer(
  state: NotificationsState = initialState,
  action: NotificationsActions
): NotificationsState {
  switch (action.type) {
    case NotificationsActionTypes.GetNotificationsSuccess: {
      return {
        ...state,
        notifications: action.manual,
        monitoringNotifications: action.auto
      };
    }
    case NotificationsActionTypes.ToggleNotifications: {
      return {
        ...state,
        open: action.payload === undefined ? !state.open : action.payload,
      };
    }
    case NotificationsActionTypes.UpdateNotificationSuccess: {
      const { payload } = action;
      const notifications = state.notifications.filter(notif => notif.id != payload.id);
      notifications.push(payload);
      notifications.sort( combineSortStrategies([ [ sortByPropStrategy('date', sortDateStrategy), SORT_DIRECTION.DESCENDING] ] ) );

      return {
        ...state,
        notifications,
      }
    }
    case NotificationsActionTypes.DeleteNotificationSuccess: {
      const notifications = state.notifications.filter(notif => notif.id != action.payload.id);

      return {
        ...state,
        notifications,
      }
    }
    default:
      return state;
  }
}
