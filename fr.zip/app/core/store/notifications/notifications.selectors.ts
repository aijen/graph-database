import { createFeatureSelector, createSelector } from '@ngrx/store';
import { getLeavesKeys } from '../hierarchy/hierarchy.selectors';
import { NotificationsState } from './notifications.model';

export const getNotificationsState = createFeatureSelector<NotificationsState>(
  'notifications'
);

export const getNotifications = createSelector(
  getNotificationsState,
  (state: NotificationsState) => state.notifications
);

export const getMonitoringNotifications = createSelector(
  getNotificationsState,
  getLeavesKeys,
  (state: NotificationsState, keys: string[] ) => state.monitoringNotifications.filter( notif => keys.includes(notif.leafKey) )
);

export const getNotificationOpen = createSelector(
  getNotificationsState,
  (state: NotificationsState) => state.open
);
