import { HttpParams, HttpRequest } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { DELETE_NOTIFICATIONS_URL, LOAD_NOTIFICATIONS_URL, SAVE_NOTIFICATIONS_URL } from 'core/services/http/http-client.service';
import isEqual from 'lodash/isEqual';
import merge from 'lodash/merge';
import { configureTestSuite } from 'ng-bullet';
import { CockpitNotification, NotificationModel, SEVERITY } from './notifications.model';
import { NotificationsService } from './notifications.service';

describe('NotificationsService', () => {
  let service: NotificationsService;
  let httpTestingController: HttpTestingController;

  const generateNotification = ( notification?: Partial<CockpitNotification> ) => merge( new CockpitNotification(SEVERITY.INFO, 'title', false), notification )
  const generateNotificationDTO = ( notification?: Partial<NotificationModel> ): NotificationModel => ({
    severity: SEVERITY.INFO,
    title: 'title',
    auto: false,
    ...notification
  })

  function fromHttpParams( params: HttpParams ) {
    return params.keys()
      .map( k => ({ [k]: params.get(k) }) )
      .reduce( (acc, value) => ({ ...acc, ...value }), {});
  }

  function isParamsEqual( params: HttpParams, comp: any ) {
    return isEqual( fromHttpParams(params), comp );
  }

  function isRequest(matcher: { url?: string, method?: string, params?: any, body?: any }) {
    return (req: HttpRequest<any>) =>
         (!matcher.url    || req.url === matcher.url)
      && (!matcher.method || req.method === matcher.method)
      && (!matcher.params || isParamsEqual(req.params, matcher.params))
      && (!matcher.body   || isEqual(req.body, matcher.body));
  }

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
      ],
      providers: [
        NotificationsService,
      ],
    })
  });

  beforeEach( () => {
    service = TestBed.get(NotificationsService);
    httpTestingController = TestBed.get(HttpTestingController);
  } );

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  describe('load', () => {

    it('should load the notifications', () => {
      const result = jasmine.createSpy('result')
      const sub = service.load( { from: 0, to: 0 } ).subscribe(result)

      httpTestingController.expectOne(isRequest({
        url: LOAD_NOTIFICATIONS_URL,
        method: 'GET',
        params: { from: '0', to: '0' },
      })).flush( [
        generateNotificationDTO(),
        generateNotificationDTO({ date: new Date(2000, 6, 15).toISOString() }),
      ] )

      expect(result).toHaveBeenCalledWith([
        generateNotification(),
        generateNotification({ date: new Date(2000, 6, 15) }),
      ])

      sub.unsubscribe()
    })

    it('should return an empty array when there is no data', () => {
      const result = jasmine.createSpy('result')
      const sub = service.load( { from: 0, to: 0 } ).subscribe(result)

      httpTestingController.expectOne(isRequest({
        url: LOAD_NOTIFICATIONS_URL,
        method: 'GET',
        params: { from: '0', to: '0' },
      })).flush( null )

      expect(result).toHaveBeenCalledWith([])

      sub.unsubscribe()
    })

  })

  describe('save', () => {

    it('should save the notifications', () => {
      const result = jasmine.createSpy('result')
      const sub = service.save( generateNotification() ).subscribe(result)

      httpTestingController.expectOne(isRequest({
        url: SAVE_NOTIFICATIONS_URL,
        method: 'POST',
        body: generateNotification(),
      })).flush( 'notification saved' )

      expect(result).toHaveBeenCalledWith('notification saved')

      sub.unsubscribe()
    })

  })

  describe('update', () => {

    it('should save the notifications', () => {
      const result = jasmine.createSpy('result')
      const sub = service.update( generateNotification() ).subscribe(result)

      httpTestingController.expectOne(isRequest({
        url: SAVE_NOTIFICATIONS_URL,
        method: 'PUT',
        body: generateNotification(),
      })).flush( 'notification updated' )

      expect(result).toHaveBeenCalledWith('notification updated')

      sub.unsubscribe()
    })

  })

  describe('delete', () => {

    it('should save the notifications', () => {
      const result = jasmine.createSpy('result')
      const sub = service.delete( generateNotification() ).subscribe(result)

      httpTestingController.expectOne(isRequest({
        url: DELETE_NOTIFICATIONS_URL,
        method: 'DELETE',
        body: generateNotification(),
      })).flush( 'notification deleted' )

      expect(result).toHaveBeenCalledWith('notification deleted')

      sub.unsubscribe()
    })

  })


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
