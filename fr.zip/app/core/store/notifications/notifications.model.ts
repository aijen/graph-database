import { UserName } from 'core/models/user.model';

declare module 'shared/models/state.model' {
  export interface AppState {
    readonly notifications: NotificationsState;
  }
}

export enum SEVERITY {
  ERROR = 'ERROR',
  INFO = 'INFO',
  WARNING = 'WARNING'
}

export enum META_TYPE {
  PERFORMANCE = 'PERFORMANCE',
  AVAILABILITY = 'AVAILABILITY',
  USER_XP = 'USER_XP',
  RISK = 'RISK',
}

export interface NotificationModel {
  severity: SEVERITY;
  title: string;
  auto: boolean;
  message?: string;
  user?: UserName;
  metaType?: META_TYPE;
  date?: string;
  id?: Readonly<String>;
  leafKey?: string;
}

export class CockpitNotification {
  public static SEVERITY = SEVERITY;
  public static META_TYPE = META_TYPE;

  constructor(
    public severity: SEVERITY,
    public title: string,
    public auto: boolean,
    public message?: string,
    public user?: UserName,
    public metaType?: META_TYPE,
    public date?: Date,
    public id?: Readonly<String>,
    public leafKey?: string,
  ) {}
}

export interface NotificationsState {
  notifications: CockpitNotification[];
  monitoringNotifications: CockpitNotification[];
  open: boolean;
}
