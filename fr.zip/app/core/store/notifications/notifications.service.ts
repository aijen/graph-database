import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { DELETE_NOTIFICATIONS_URL, LOAD_NOTIFICATIONS_URL, SAVE_NOTIFICATIONS_URL } from 'core/services/http/http-client.service';
import { map } from 'rxjs/operators';
import { CockpitNotification, NotificationModel } from './notifications.model';

function fromJSON( dto: NotificationModel ): CockpitNotification {
  return new CockpitNotification(
    dto.severity,
    dto.title,
    dto.auto,
    dto.message,
    dto.user,
    dto.metaType,
    dto.date ? new Date(dto.date) : undefined,
    dto.id,
    dto.leafKey,
  )
}

function fromJSONCollection( dto: NotificationModel[] ): CockpitNotification[] {
  return Array.isArray(dto) ? dto.map( fromJSON ) : []
}

@Injectable({
  providedIn: 'root'
})
export class NotificationsService {

  constructor(
    private http: HttpClient,
  ) {}

  load( {from, to}: {from: number, to: number} ) {
    const params = { from: from.toString(), to: to.toString() }
    return this.http.get<NotificationModel[]>( LOAD_NOTIFICATIONS_URL, { params } ).pipe( map( fromJSONCollection ) )
  }

  save( notification: CockpitNotification ) {
    return this.http.post(SAVE_NOTIFICATIONS_URL, notification, { responseType: 'text' })
  }

  update( notification: CockpitNotification ) {
    return this.http.put(SAVE_NOTIFICATIONS_URL, notification, { responseType: 'text' })
  }

  delete( notification: CockpitNotification ) {
    return this.http.request('delete', DELETE_NOTIFICATIONS_URL, { body: notification, responseType: 'text' })
  }

}
