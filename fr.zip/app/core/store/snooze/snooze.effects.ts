import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { select, Store } from '@ngrx/store';
import { of } from 'rxjs';
import { catchError, concatMap, map, mapTo, switchMap, tap, withLatestFrom } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { GetNodes } from '../hierarchy/hierarchy.actions';
import { getLeaves } from '../hierarchy/hierarchy.selectors';
import { PopulatedMetasService } from '../populated-metas/populated-metas.service';
import { LoadSnoozeError, SaveSnooze, SaveSnoozeError, SaveSnoozeSuccess, SnoozeActionTypes, ToggleSnoozeGlobalMeta, ToggleSnoozeLeafMeta } from './snooze.actions';
import { selectSnoozeConfig } from './snooze.selectors';
import { SnoozeService } from './snooze.service';

@Injectable({providedIn: 'root'})
export class SnoozeEffects {

  public static messages = {
    loadError: `
      Une erreur est survenue pendant le chargement de la configuration 'snooze': les alertes ne seront pas désactivées
    `,
    saveError: `
      Une erreur est survenue pendant la sauvegarde, veuillez réessayer ou contacter le support si le problème persiste
    `,
  }

  config$ = this.store$.pipe(
    select(selectSnoozeConfig),
  );

  constructor(
    private actions$: Actions,
    private snackbar: MessageHandler,
    private store$: Store<AppState>,
    private snoozeService: SnoozeService,
    private populatedMetasService: PopulatedMetasService,
  ) {}

  @Effect({ dispatch: false })
  loadSnoozeError = this.actions$.pipe(
    ofType<LoadSnoozeError>(SnoozeActionTypes.LoadSnoozeError),
    tap( action => { console.error(action.payload.error); this.snackbar.show( { message: SnoozeEffects.messages.loadError, action: 'OK', isError: true, id: action.type } ) } ),
  )

  @Effect()
  toggleSnoozeLeafMeta = this.actions$.pipe(
    ofType<ToggleSnoozeLeafMeta>(SnoozeActionTypes.ToggleSnoozeLeafMeta),
    map(() => new SaveSnooze()),
  )

  @Effect()
  toggleSnoozeGlobalMeta = this.actions$.pipe(
    ofType<ToggleSnoozeGlobalMeta>(SnoozeActionTypes.ToggleSnoozeGlobalMeta),
    map(() => new SaveSnooze()),
  )

  @Effect()
  saveSnooze = this.actions$.pipe(
    ofType<SaveSnooze>(SnoozeActionTypes.SaveSnooze),
    withLatestFrom(this.config$),
    switchMap(([, config]) => this.snoozeService.updateSnooze(config).pipe(mapTo(config))),
    withLatestFrom(this.store$.select(getLeaves)),
    withLatestFrom(this.populatedMetasService.populatedMetas$),
    concatMap(([[config, leaves], populatedMetas]) => ([
      new SaveSnoozeSuccess({ config }),
      new GetNodes({leaves, config, populatedMetas}),
    ])),
    catchError(error => of(new SaveSnoozeError({ error }))),
  )

  @Effect({ dispatch: false })
  saveSnoozeError = this.actions$.pipe(
    ofType<SaveSnoozeError>(SnoozeActionTypes.SaveSnoozeError),
    tap( action => { console.error(action.payload.error); this.snackbar.show( { message: SnoozeEffects.messages.saveError, action: 'OK', isError: true, id: action.type } ) } ),
  )

}
