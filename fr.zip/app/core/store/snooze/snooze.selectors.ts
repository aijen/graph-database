import { createFeatureSelector, createSelector } from '@ngrx/store';
import { SnoozeState } from './snooze.model';

export const getSnoozeState = createFeatureSelector<SnoozeState>(
  'snooze'
);

export const isSnoozeLoading = createSelector(
  getSnoozeState,
  state => state.isLoading,
);

export const isSnoozeLoaded = createSelector(
  getSnoozeState,
  state => state.isLoaded,
);

export const selectSnoozeConfig = createSelector(
  getSnoozeState,
  state => state.config,
);
