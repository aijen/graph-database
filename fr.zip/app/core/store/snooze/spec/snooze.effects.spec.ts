import { HttpErrorResponse } from '@angular/common/http';
import { async, TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { LOAD_SNOOZE_URL, SAVE_SNOOZE_URL } from 'core/services/http/http-client.service';
import { GetNodes } from 'core/store/hierarchy/hierarchy.actions';
import { hierarchyState } from 'core/store/hierarchy/hierarchy.reducer';
import { PopulatedMetasValue } from 'core/store/populated-metas/populated-metas.model';
import { PopulatedMetasService } from 'core/store/populated-metas/populated-metas.service';
import { configureTestSuite } from 'ng-bullet';
import { Observable, of, Subject, throwError } from 'rxjs';
import { marbles } from 'rxjs-marbles/jasmine';
import { switchMap } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { LoadSnoozeError, SaveSnooze, SaveSnoozeError, SaveSnoozeSuccess, ToggleSnoozeGlobalMeta, ToggleSnoozeLeafMeta } from '../snooze.actions';
import { SnoozeEffects } from '../snooze.effects';
import { snoozeState } from '../snooze.reducer';
import { SnoozeService } from '../snooze.service';

describe('SnoozeEffects', () => {
  let service: SnoozeEffects;
  let actions: Observable<any>;
  let snoozeService: jasmine.SpyObj<SnoozeService>;
  let populatedMetas$: Observable<PopulatedMetasValue[]>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [
        SnoozeEffects,
        provideMockStore<Partial<AppState>>({ initialState: { snooze: snoozeState, hierarchy: hierarchyState } }),
        provideMockActions(() => actions),
        { provide: MessageHandler, useFactory: () => jasmine.createSpyObj('MessageHandler', ['ngOnDestroy', 'show']) },
        { provide: SnoozeService, useFactory: () => jasmine.createSpyObj('SnoozeService', ['updateSnooze']) },
        { provide: PopulatedMetasService, useFactory: () => ({ populatedMetas$: of(null).pipe( switchMap( () => populatedMetas$) ) }) },
      ],
    })
  });

  beforeEach(async(async () => {
    service = TestBed.get(SnoozeEffects);
    snoozeService = TestBed.get(SnoozeService);
    populatedMetas$ = of([])
  }));

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  describe('LoadSnoozeError action', () => {

    it('should display an error message', () => {
      spyOn(console, 'error');
      const error = new HttpErrorResponse({ error: 'Service unavailable', status: 503, statusText: 'KO', url: LOAD_SNOOZE_URL });
      const snackbar = TestBed.get(MessageHandler);
      const subject = actions = new Subject();
      const next = jasmine.createSpy('next');
      const sub = service.loadSnoozeError.subscribe(next);
      subject.next(new LoadSnoozeError({ error }));

      expect(console.error).toHaveBeenCalled();
      expect(snackbar.show).toHaveBeenCalled();

      sub.unsubscribe();
    });

  });

  describe('toggleSnoozeLeafMeta action', () => {

    it('should dispatch a SaveSnooze action', marbles(m => {
      actions = m.hot('a', { a: new ToggleSnoozeLeafMeta({ leafKey: 'IPPI', metaType: 'availability' }) });
      const expected = m.hot('a', { a: new SaveSnooze() });

      m.expect(service.toggleSnoozeLeafMeta).toBeObservable(expected);
    }));

  });

  describe('toggleSnoozeGlobalMeta action', () => {

    it('should dispatch a SaveSnooze action', marbles(m => {
      actions = m.hot('a', { a: new ToggleSnoozeGlobalMeta({ metaType: 'availability' }) });
      const expected = m.hot('a', { a: new SaveSnooze() });

      m.expect(service.toggleSnoozeGlobalMeta).toBeObservable(expected);
    }));

  });

  describe('saveSnooze action', () => {

    it('should save the snooze config and dispatch a SaveSnoozeSuccess action', () => {
      snoozeService.updateSnooze.and.returnValue(of('Snooze was updated'));
      const subject = actions = new Subject();
      const next = jasmine.createSpy('next');
      const sub = service.saveSnooze.subscribe(next);
      subject.next(new SaveSnooze());

      expect(snoozeService.updateSnooze).toHaveBeenCalled();
      expect(next.calls.argsFor(0)).toEqual([jasmine.any(SaveSnoozeSuccess)])
      expect(next.calls.argsFor(1)).toEqual([jasmine.any(GetNodes)])

      sub.unsubscribe();
    });

    it('should dispatch a saveSnoozeError action when failing', () => {
      const error = new HttpErrorResponse({ error: 'Service unavailable', status: 503, statusText: 'KO', url: SAVE_SNOOZE_URL });
      snoozeService.updateSnooze.and.returnValue(throwError(error));
      const subject = actions = new Subject();
      const next = jasmine.createSpy('next');
      const sub = service.saveSnooze.subscribe(next);
      subject.next(new SaveSnooze());

      expect(snoozeService.updateSnooze).toHaveBeenCalled();
      expect(next).toHaveBeenCalledWith(jasmine.any(SaveSnoozeError));

      sub.unsubscribe();
    });

  });

  describe('saveSnoozeError action', () => {

    it('should display an error message', () => {
      spyOn(console, 'error');
      const error = new HttpErrorResponse({ error: 'Service unavailable', status: 503, statusText: 'KO', url: SAVE_SNOOZE_URL });
      const snackbar = TestBed.get(MessageHandler);
      const subject = actions = new Subject();
      const next = jasmine.createSpy('next');
      const sub = service.saveSnoozeError.subscribe(next);
      subject.next(new SaveSnoozeError({ error }));

      expect(console.error).toHaveBeenCalled();
      expect(snackbar.show).toHaveBeenCalled();

      sub.unsubscribe();
    });

  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for (const style of styles) head.removeChild(style);
  }
  afterAll(cleanStylesFromDom);
});
