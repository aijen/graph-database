import { HttpErrorResponse } from '@angular/common/http';
import { metasCheckState } from 'core/store/leaves/leaves.model';
import { AppState } from 'shared/models/state.model';
import { LoadSnooze, LoadSnoozeError, LoadSnoozeSuccess, SaveSnoozeSuccess, ToggleSnoozeGlobalMeta, ToggleSnoozeLeafMeta, UnloadSnooze, UnmuteAll } from '../snooze.actions';
import { SnoozeLeaf, snoozeLeavesState, SnoozeState } from '../snooze.model';
import { snoozeReducer, snoozeState } from '../snooze.reducer';

const generateSnoozeState = (state?: Partial<SnoozeState>) => {
  return {
    config: { global: { ...metasCheckState }, leaves: { ...snoozeLeavesState } },
    isLoading: false,
    isLoaded: false,
    ...state,
  }
}

const generateSnoozeLeaf = (leaf?: Partial<SnoozeLeaf>) => {
  return {
    leafId: 'leafId',
    name: 'name',
    availability: { enabled: false, admin: false },
    performance: { enabled: false, admin: false },
    risk: { enabled: false, admin: false },
    userXp: { enabled: false, admin: false },
    selected: false,
    ...leaf,
  };
};

// necessary to avoid the error :
// Invalid module name in augmentation, module 'shared/models/state.model' cannot be found.
let happy_compiler: AppState; // tslint:disable-line

describe('Snooze Reducer', () => {

  describe('undefined action', () => {

    it('should return the default state', () => {
      const action = { type: null, payload: null };
      const state = snoozeReducer( undefined, action );

      expect(state).toBe(snoozeState);
    });

  });

  describe('LoadSnooze action', () => {

    it('should be loading but not loaded', () => {
      const action = new LoadSnooze();
      const state = snoozeReducer(snoozeState, action);

      expect(state.isLoading).toBe(true);
      expect(state.isLoaded).toBe(false);
    });

  });

  describe('LoadSnoozeSuccess action', () => {

    it('should set config and be loaded but not loading', () => {
      const config = { leaves: snoozeLeavesState };
      const action = new LoadSnoozeSuccess({ config });
      const state = snoozeReducer(snoozeState, action);

      expect(state.config).toEqual(config);
      expect(state.isLoaded).toBe(true);
      expect(state.isLoading).toBe(false);
    });

  });

  describe('LoadSnoozeError action', () => {

    it('should not be loading', () => {
      const error = new HttpErrorResponse({});
      const action = new LoadSnoozeError({ error });
      const state = snoozeReducer(snoozeState, action);

      expect(state.isLoading).toBe(false);
    });

  });

  describe('UnloadSnooze action', () => {

    it('should retun the default snooze state', () => {
      const modifiedState = generateSnoozeState({ isLoading: true, isLoaded: true });
      const action = new UnloadSnooze();
      const state = snoozeReducer(modifiedState, action);

      expect(state).toEqual(snoozeState);
    });

  });

  describe('ToggleSnoozeLeafMeta action', () => {

    it('should return the same state', () => {
      const action = new ToggleSnoozeLeafMeta({ leafKey: 'IPPI', metaType: 'availability' });
      const state = snoozeReducer(snoozeState, action);

      expect(state).toEqual(snoozeState);
    });

    it('should return the updated state', () => {
      const modifiedState = generateSnoozeState({ config: { global: metasCheckState, leaves: { BDDF: [generateSnoozeLeaf({ leafId: 'IPPI', availability: { enabled: false, admin: false } })] } } });
      const expecteConfig = { global: metasCheckState, leaves: { BDDF: [generateSnoozeLeaf({ leafId: 'IPPI', availability: { enabled: true, admin: false } })] } };
      const action = new ToggleSnoozeLeafMeta({ leafKey: 'IPPI', metaType: 'availability' });
      const state = snoozeReducer(modifiedState, action);

      expect(state.config).toEqual(expecteConfig);
    });

  });

  describe('ToggleSnoozeGlobalMeta action', () => {

    it('should return the updated state', () => {
      const modifiedState = generateSnoozeState();
      const expecteConfig = { global: { availability: true, performance: false, risk: false, userXp: false }, leaves: snoozeLeavesState };
      const action = new ToggleSnoozeGlobalMeta({ metaType: 'availability' });
      const state = snoozeReducer(modifiedState, action);

      expect(state.config).toEqual(expecteConfig);
    });

    it('should return the updated state after created config.global', () => {
      const modifiedState = generateSnoozeState({ config: { leaves: snoozeLeavesState } });
      const expecteConfig = { global: { availability: true, performance: false, risk: false, userXp: false }, leaves: snoozeLeavesState };
      const action = new ToggleSnoozeGlobalMeta({ metaType: 'availability' });
      const state = snoozeReducer(modifiedState, action);

      expect(state.config).toEqual(expecteConfig);
    });

  });

  describe('SaveSnoozeSuccess action', () => {

    it('should set config', () => {
      const config = { global: metasCheckState, leaves: { BDDF: [ generateSnoozeLeaf() ] } };
      const action = new SaveSnoozeSuccess({ config });
      const state = snoozeReducer(snoozeState, action);

      expect(state.config).toEqual(config);
    });

  });

  describe('UnmuteAll action', () => {

    it('should unmute all metas for all leaves', () => {
      const modifiedState = generateSnoozeState({ config: { global: { availability: true, performance: true, risk: false, userXp: false }, leaves: { BDDF: [generateSnoozeLeaf({ leafId: 'IPPI', availability: { enabled: true, admin: false }, performance: { enabled: true, admin: true } })] } } });
      const expecteConfig = { global: metasCheckState, leaves: { BDDF: [generateSnoozeLeaf({ leafId: 'IPPI', performance: { enabled: true, admin: true } })] } };
      const action = new UnmuteAll();
      const state = snoozeReducer(modifiedState, action);

      expect(modifiedState.config).toEqual(expecteConfig);
    });

  });

} );
