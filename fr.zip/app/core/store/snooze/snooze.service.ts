import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { LOAD_SNOOZE_URL, SAVE_SNOOZE_URL } from 'core/services/http/http-client.service';
import { of } from 'rxjs';
import { catchError, map, share, switchMap, switchMapTo, tap } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';
import { getUserConnected$ } from '../auth/auth.selectors';
import { sortByNameCaseInsensitive } from '../leaves/leaves.model';
import { LoadSnooze, LoadSnoozeError, LoadSnoozeSuccess } from './snooze.actions';
import { SnoozeConfig, SnoozeLeaf, SnoozeLeavesState } from './snooze.model';
import { isSnoozeLoaded, selectSnoozeConfig } from './snooze.selectors';

const fromJson = ( conf: SnoozeConfig ): SnoozeConfig => {
  Object.keys(conf.leaves).forEach(bank => {
    conf.leaves[bank].sort( sortByNameCaseInsensitive );
  });
  return conf;
}

@Injectable({
  providedIn: 'root'
})
export class SnoozeService {

  constructor(
    private store$: Store<AppState>,
    private http: HttpClient,
  ) {}

  private getConfig$ = (userId: string) => this.http.get<SnoozeConfig>(LOAD_SNOOZE_URL, { params: { userId } }).pipe( map( fromJson ), share() );

  private require$ = of<void>(null).pipe(
    tap( () => this.store$.dispatch( new LoadSnooze() ) ),
    switchMap( () => this.store$.pipe(getUserConnected$)),
    switchMap(({ userId }) => this.getConfig$(userId) ),
    tap( config => this.store$.dispatch( new LoadSnoozeSuccess( { config } ) ) ),
    catchError( error => (this.store$.dispatch( new LoadSnoozeError( { error } ) ), of<void>(null)) ),
    share(),
  );

  private selectConfig$ = this.store$.pipe( select( selectSnoozeConfig ) );

  private getAndSelectConfig$ = this.require$.pipe( switchMapTo( this.selectConfig$ ) );

  config$ = this.store$.pipe(
    select( isSnoozeLoaded ),
    switchMap( loaded => loaded ? this.selectConfig$ : this.getAndSelectConfig$ ),
  );

  updateSnooze(snoozeConfig: SnoozeConfig) {
    return this.http.put(SAVE_SNOOZE_URL, snoozeConfig, { responseType: 'text' });
  }

  static findLeafByKey(leaves: SnoozeLeavesState, leafKey: string): SnoozeLeaf {
    const banks = Object.keys(leaves);

    for(let bank of banks) {
      const leaf = leaves[bank].find(l => l.leafId === leafKey);

      if(leaf !== undefined) {
        return leaf;
      }
    }

    return undefined;
  }
}
