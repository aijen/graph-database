import { HttpErrorResponse } from '@angular/common/http';
import { Action } from '@ngrx/store';
import { AdminLeafMetaType } from 'shared/store/leaves/leaves.form.model';
import { SnoozeConfig } from './snooze.model';

export enum SnoozeActionTypes {
  LoadSnooze = '[CockPit] Snooze Load',
  LoadSnoozeSuccess = '[CockPit] Snooze LoadSuccess',
  LoadSnoozeError = '[CockPit] Snooze LoadError',
  UnloadSnooze = '[CockPit] Snooze UnloadSnooze',
  ToggleSnoozeLeafMeta = '[Cockpit] Snooze ToggleSnoozeLeafMeta',
  ToggleSnoozeGlobalMeta = '[Cockpit] Snooze ToggleSnoozeGlobalMeta',
  SaveSnooze = '[Cockpit] Snooze SaveSnooze',
  SaveSnoozeSuccess = '[Cockpit] Snooze SaveSnoozeSuccess',
  SaveSnoozeError = '[Cockpit] Snooze SaveSnoozeError',
  UnmuteAll = '[Cockpit] Snooze UnmuteAll',
}

export class LoadSnooze implements Action {
  readonly type = SnoozeActionTypes.LoadSnooze;
  constructor() {}
}

export class LoadSnoozeSuccess implements Action {
  readonly type = SnoozeActionTypes.LoadSnoozeSuccess;
  constructor( public payload: { config: SnoozeConfig } ) {}
}

export class LoadSnoozeError implements Action {
  readonly type = SnoozeActionTypes.LoadSnoozeError;
  constructor( public payload: { error: HttpErrorResponse } ) {}
}

export class UnloadSnooze implements Action {
  readonly type = SnoozeActionTypes.UnloadSnooze;
  constructor() {}
}

export class ToggleSnoozeLeafMeta implements Action {
  readonly type = SnoozeActionTypes.ToggleSnoozeLeafMeta;
  constructor( public payload: { leafKey: string, metaType: AdminLeafMetaType } ) {}
}

export class ToggleSnoozeGlobalMeta implements Action {
  readonly type = SnoozeActionTypes.ToggleSnoozeGlobalMeta;
  constructor( public payload: { metaType: AdminLeafMetaType } ) {}
}

export class SaveSnooze implements Action {
  readonly type = SnoozeActionTypes.SaveSnooze;
  constructor() {}
}

export class SaveSnoozeSuccess implements Action {
  readonly type = SnoozeActionTypes.SaveSnoozeSuccess;
  constructor( public payload: { config: SnoozeConfig }) {}
}

export class SaveSnoozeError implements Action {
  readonly type = SnoozeActionTypes.SaveSnoozeError;
  constructor( public payload: { error: HttpErrorResponse } ) {}
}

export class UnmuteAll implements Action {
  readonly type = SnoozeActionTypes.UnmuteAll;
  constructor() {}
}

export type SnoozeActionsUnion =
  | LoadSnooze
  | LoadSnoozeSuccess
  | LoadSnoozeError
  | UnloadSnooze
  | ToggleSnoozeLeafMeta
  | ToggleSnoozeGlobalMeta
  | SaveSnooze
  | SaveSnoozeSuccess
  | SaveSnoozeError
  | UnmuteAll
;
