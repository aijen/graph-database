import { AdminLeafMetaType } from 'shared/store/leaves/leaves.form.model';
import { MetasCheck, metasCheckState } from '../leaves/leaves.model';
import { SnoozeActionsUnion, SnoozeActionTypes } from './snooze.actions';
import { SnoozeConfig, SnoozeLeaf, snoozeLeavesState, SnoozeState } from './snooze.model';
import { SnoozeService } from './snooze.service';

const disableGlobalMute = (metasCheck: MetasCheck, metaTypes: AdminLeafMetaType[]) => {
  metaTypes.forEach(metaType => {
    if(metasCheck !== undefined && metasCheck[metaType] !== undefined) {
      metasCheck[metaType] = false;
    }
  });
}

const disableLeafMute = (leaf: SnoozeLeaf, metaTypes: AdminLeafMetaType[]) => {
  metaTypes.forEach(metaType => {
    if(leaf[metaType] !== undefined && leaf[metaType].enabled !== undefined && leaf[metaType].admin !== undefined) {
      leaf[metaType].enabled = leaf[metaType].admin ? leaf[metaType].enabled : false;
    }
  });
}

const disableAllMutes = (config: SnoozeConfig) => {
  const metaTypes = ['availability', 'performance', 'risk', 'userXp'] as AdminLeafMetaType[];

  disableGlobalMute(config.global, metaTypes);

  const keys = Object.keys(config.leaves);
  keys.forEach(key => config.leaves[key].forEach(leaf => disableLeafMute(leaf, metaTypes)));

  return config;
}

export const snoozeState: SnoozeState = {
  config: { global: metasCheckState, leaves: snoozeLeavesState },
  isLoading: false,
  isLoaded: false,
};

export function snoozeReducer(
  state: SnoozeState = snoozeState,
  action: SnoozeActionsUnion
): SnoozeState {

  switch (action.type) {
    case SnoozeActionTypes.LoadSnooze: {
      return {
        ...state,
        isLoading: true,
        isLoaded: false,
      };
    }
    case SnoozeActionTypes.LoadSnoozeSuccess: {
      return {
        ...state,
        config: action.payload.config,
        isLoading: false,
        isLoaded: true,
      };
    }
    case SnoozeActionTypes.LoadSnoozeError: {
      return {
        ...state,
        isLoading: false,
      };
    }
    case SnoozeActionTypes.UnloadSnooze: {
      return snoozeState;
    }
    case SnoozeActionTypes.ToggleSnoozeLeafMeta: {
      const { config } = state;
      const snoozeLeaf = SnoozeService.findLeafByKey(config.leaves, action.payload.leafKey);

      if(snoozeLeaf !== undefined) {
        snoozeLeaf[action.payload.metaType].enabled = !snoozeLeaf[action.payload.metaType].enabled;
      }

      return {
        ...state,
        config,
      };
    }
    case SnoozeActionTypes.ToggleSnoozeGlobalMeta: {
      const { config } = state;
      const { global } = config.global ? config : { global: { ...metasCheckState } };
      const metaType = action.payload.metaType;

      global[metaType] = !global[metaType];
      config.global = global;

      return {
        ...state,
        config,
      };
    }

    case SnoozeActionTypes.SaveSnoozeSuccess: {
      const config = action.payload.config;

      return {
        ...state,
        config,
      };
    }

    case SnoozeActionTypes.UnmuteAll: {
      return {
        ...state,
        config: disableAllMutes(state.config),
      };
    }

    default:
      return state;
  }

}
