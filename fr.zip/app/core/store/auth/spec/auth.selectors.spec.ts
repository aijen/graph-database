import { Permissions, User } from 'core/models/user.model';
import { UserRole } from 'core/models/userRoles.model';
import { marbles } from 'rxjs-marbles/jasmine';
import { AppState } from 'shared/models/state.model';
import { authState } from '../auth.reducer';
import { canAssignAdmin, canAssignSuperAdmin, canCreatePublicTemplates, getIsUserAuthenticated, getPermissions, getUser, getUserConnected$, getUserId$, hasAdminScreenAccess, hasAlertTabAccess, hasArborescenceTabAccess, hasBaselinesTabAccess, hasMeteoTabAccess, hasMetricsTabAccess, hasMuteTabAccess, hasPerimeterTabAccess, hasProfilsTabAccess, isAdmin$ } from '../auth.selectors';

describe('Auth Selectors', () => {

  it('getUser should get the user', () => {
    const user = User.from();
    expect(getUser.projector({ user })).toBe(user);
  } );

  it('getIsUserAuthenticated should get the authenticated status', () => {
    expect(getIsUserAuthenticated.projector({isUserAuthenticated: true})).toBe(true);
  } );

  it('getPermissions should get the user\'s permissions', () => {
    expect(getPermissions.projector({ name: UserRole.PUBLIC, permissions: [] })).toEqual([]);
  });

  it('hasAdminScreenAccess should be true', () => {
    expect(hasAdminScreenAccess.projector([Permissions.ALL])).toBe(true);
    expect(hasAdminScreenAccess.projector([Permissions.ADMIN_SCREEN])).toBe(true);
  });

  it('hasAlertTabAccess should be true', () => {
    expect(hasAlertTabAccess.projector([Permissions.ALL])).toBe(true);
    expect(hasAlertTabAccess.projector([Permissions.ADMIN_ALERT_TAB])).toBe(true);
  });

  it('hasMuteTabAccess should be true', () => {
    expect(hasMuteTabAccess.projector([Permissions.ALL])).toBe(true);
    expect(hasMuteTabAccess.projector([Permissions.ADMIN_MUTE_TAB])).toBe(true);
  });

  it('hasBaselinesTabAccess should be true', () => {
    expect(hasBaselinesTabAccess.projector([Permissions.ALL])).toBe(true);
    expect(hasBaselinesTabAccess.projector([Permissions.ADMIN_BASELINES_TAB])).toBe(true);
  });

  it('hasMeteoTabAccess should be true', () => {
    expect(hasMeteoTabAccess.projector([Permissions.ALL])).toBe(true);
    expect(hasMeteoTabAccess.projector([Permissions.ADMIN_METEO_TAB])).toBe(true);
  });

  it('hasPerimeterTabAccess should be true', () => {
    expect(hasPerimeterTabAccess.projector([Permissions.ALL])).toBe(true);
    expect(hasPerimeterTabAccess.projector([Permissions.ADMIN_PERIMETER_TAB])).toBe(true);
  });

  it('hasArborescenceTabAccess should be true', () => {
    expect(hasArborescenceTabAccess.projector([Permissions.ALL])).toBe(true);
    expect(hasArborescenceTabAccess.projector([Permissions.ADMIN_ARBORESCENCE_TAB])).toBe(true);
  });

  it('hasMetricsTabAccess should be true', () => {
    expect(hasMetricsTabAccess.projector([Permissions.ALL])).toBe(true);
    expect(hasMetricsTabAccess.projector([Permissions.ADMIN_METRICS_TAB])).toBe(true);
  });

  it('hasProfilsTabAccess should be true', () => {
    expect(hasProfilsTabAccess.projector([Permissions.ALL])).toBe(true);
    expect(hasProfilsTabAccess.projector([Permissions.ADMIN_PROFILS_TAB])).toBe(true);
  });

  it('canAssignAdmin should be true', () => {
    expect(canAssignAdmin.projector([Permissions.ALL])).toBe(true);
    expect(canAssignAdmin.projector([Permissions.ADMIN_PROFIL_GIVER])).toBe(true);
  });

  it('canAssignSuperAdmin should be true', () => {
    expect(canAssignSuperAdmin.projector([Permissions.ALL])).toBe(true);
    expect(canAssignSuperAdmin.projector([Permissions.SUPER_ADMIN_PROFIL_GIVER])).toBe(true);
  });

  it('canCreatePublicTemplates should be true', () => {
    expect(canCreatePublicTemplates.projector([Permissions.ALL])).toBe(true);
    expect(canCreatePublicTemplates.projector([Permissions.PUBLIC_TEMPLATE_CREATION])).toBe(true);
  });

  it('isAdmin$ should emit the isAdmin status when the user is authenticated', marbles(m => {
    const user = User.from();
    const initialTestState: Partial<AppState> = { auth: { ...authState } };
    const userAuthenticated: Partial<AppState> = { auth: { ...authState, user, isUserAuthenticated: true, profil: { profiles: [UserRole.SUPER_ADMIN], permissions: [Permissions.ALL] } } };
    const states   = m.hot('a--b-', { a: initialTestState, b: userAuthenticated });
    const expected = m.hot('---b-', {                      b: true              });

    m.expect(states.pipe(isAdmin$)).toBeObservable(expected);
  }) );

  it('getUserConnected$ should emit the user connected when the user is authenticated', marbles(m => {
    const user = User.from();
    const initialTestState: Partial<AppState> = { auth: { ...authState } };
    const userAuthenticated: Partial<AppState> = { auth: { ...authState, user, isUserAuthenticated: true, profil: { profiles: [UserRole.SUPER_ADMIN], permissions: [Permissions.ALL] } } };
    const states   = m.hot('a--b-', { a: initialTestState, b: userAuthenticated });
    const expected = m.hot('---b-', {                      b: user              });

    m.expect(states.pipe(getUserConnected$)).toBeObservable(expected);
  }) );

  it('getUserId$ should emit the user id when the user is authenticated', marbles(m => {
    const user = User.from({ userId: '1' });
    const initialTestState: Partial<AppState> = { auth: { ...authState } };
    const userAuthenticated: Partial<AppState> = { auth: { ...authState, user, isUserAuthenticated: true, profil: { profiles: [UserRole.SUPER_ADMIN], permissions: [Permissions.ALL] } } };
    const states   = m.hot('a--b-', { a: initialTestState, b: userAuthenticated });
    const expected = m.hot('---b-', {                      b: user.userId       });

    m.expect(states.pipe(getUserId$)).toBeObservable(expected);
  }) );

} );
