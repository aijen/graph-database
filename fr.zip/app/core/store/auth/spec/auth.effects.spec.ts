import { HttpErrorResponse } from '@angular/common/http';
import { fakeAsync, TestBed, tick } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Store } from '@ngrx/store';
import { provideMockStore } from '@ngrx/store/testing';
import { Permissions, PitUserWithGroups, User } from 'core/models/user.model';
import { UserRole } from 'core/models/userRoles.model';
import { LoadGroupsSuccess } from 'core/store/groups/groups.actions';
import { environment } from 'env/environment';
import { configureTestSuite } from 'ng-bullet';
import { Observable, of, Subject } from 'rxjs';
import { marbles } from 'rxjs-marbles/jasmine';
import { AppState } from 'shared/models/state.model';
import { SgSigninMock, SgSigninMockProvider } from 'testing/SgSigninMockFactory';
import { GetUser, GetUserError, GetUserSuccess } from '../auth.actions';
import { AuthEffects } from '../auth.effects';
import { authState as initialAuthState } from '../auth.reducer';
import { AuthService } from '../auth.service';

describe('Auth Effects', () => {
  let effects: AuthEffects;
  let authService: jasmine.SpyObj<AuthService>;
  let actions: Observable<any>;
  let sgSignInMock: SgSigninMock;
  const initialState: Partial<AppState> = { auth: initialAuthState };
  const initialEnvironment = { ...environment };

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [
        AuthEffects,
        provideMockActions(() => actions),
        provideMockStore<Partial<AppState>>({ initialState }),
        SgSigninMockProvider,
        { provide: AuthService, useFactory: () => jasmine.createSpyObj('AuthService', ['getPitUser']) },
      ]
    });
  });

  beforeEach(() => {
    authService = TestBed.get(AuthService);
    sgSignInMock = TestBed.get(SgSigninMockProvider.provide);
  });

  describe('with environment.sgSignIn = true', () => {

    beforeEach(() => {
      environment.sgSignIn = true;
    });
    afterEach(() => {
      environment.sgSignIn = initialEnvironment.sgSignIn;
    });

    it('should start the SgSignin lifecycle', () => {
      effects = TestBed.get(AuthEffects);
      expect(sgSignInMock).toHaveBeenCalled();
    });

    it('should dispatch an error if SgSignin fails', () => {
      const SgSigninFailError = new Error('SgSigninFailError');
      const dispatchSpy = spyOn(TestBed.get(Store), 'dispatch');
      const sgSignInConstructorFunctionFailing = (url, errorCallback) => errorCallback(SgSigninFailError);
      sgSignInMock.and.callFake(sgSignInConstructorFunctionFailing);

      effects = TestBed.get(AuthEffects);
      expect(dispatchSpy).toHaveBeenCalled();
      expect(dispatchSpy.calls.mostRecent().args[0]).toEqual(new GetUserError({ error: SgSigninFailError }));
    });

    describe('getUser$', () => {
      beforeEach(() => {
        effects = TestBed.get(AuthEffects);
      });

      it('should return the user once SgSignin resolve', marbles(m => {

        const user = new User() as SgSignInUser;
        sgSignInMock.getCurrentUser.and.returnValues(null, null, user);
        const expected = m.cold(' 2s (a|)', { a: user });

        m.expect(effects.getUser$).toBeObservable(expected);

      }));

    });

    describe('refreshToken$', () => {
      beforeEach(() => {
        effects = TestBed.get(AuthEffects);
      });

      it('should refresh token', fakeAsync(() => {
        const getToken = () => ({
          iat: Date.now(),
          durationAccessToken: 3600,
        });
        const user = {
          token: getToken(),
        } as SgSignInUser;

        const actionsSubject = new Subject<any>();
        actions = actionsSubject.asObservable();

        sgSignInMock.getAccessToken.and.returnValue(Promise.resolve());
        sgSignInMock.getCurrentUser.and.callFake(() => ({ token: getToken() }));

        const sub = effects.refreshToken$.subscribe();

        actionsSubject.next(new GetUserSuccess({ user, profil: { profiles: [UserRole.PUBLIC], permissions: [] } }));

        tick(3600 * 1000);

        expect(sgSignInMock.getAccessToken).toHaveBeenCalled();
        expect(sgSignInMock.getCurrentUser).toHaveBeenCalled();

        sub.unsubscribe();

      }));

    });

  });

  describe('with environment.sgSignIn = false', () => {

    beforeEach(() => {
      environment.sgSignIn = false;
      effects = TestBed.get(AuthEffects);
    });
    afterEach(() => {
      environment.sgSignIn = initialEnvironment.sgSignIn;
    });

    it('should not start the SgSignin lifecycle', () => {
      effects = TestBed.get(AuthEffects);
      expect(sgSignInMock).not.toHaveBeenCalled();
    });

    describe('getUser$', () => {
      it('should return a user from the environment', marbles(m => {
        const user = User.from(environment.user) as SgSignInUser;
        const expected = m.cold('(a|)', { a: user });

        m.expect(effects.getUser$).toBeObservable(expected);
      }));
    });

    describe('refreshToken$', () => {

      it('should not refresh token', fakeAsync(() => {
        const user = {
          token: {
            iat: Date.now(),
            durationAccessToken: 3600,
          }
        } as SgSignInUser;

        const actionsSubject = new Subject<any>();
        actions = actionsSubject.asObservable();

        effects.refreshToken$.subscribe();

        actionsSubject.next(new GetUserSuccess({ user, profil: { profiles: [UserRole.PUBLIC], permissions: [] } }));

        tick(3600 * 1000);

        expect(sgSignInMock.getAccessToken).not.toHaveBeenCalled();

      }));

    });

  });


  describe('GetUser', () => {

    it('should emit a GetUserSuccess with the user and its permissions and a LoadGroupsSuccess', marbles(m => {
      effects = TestBed.get(AuthEffects);

      const user = User.from(environment.user) as SgSignInUser;
      const profil = { profiles: [UserRole.PUBLIC, UserRole.ADMIN, UserRole.SUPER_ADMIN], permissions: [Permissions.ADMIN_SCREEN, Permissions.ADMIN_ALERT_TAB, Permissions.ADMIN_MUTE_TAB, Permissions.ADMIN_METEO_TAB, Permissions.ADMIN_PROFILS_TAB, Permissions.ADMIN_EVENTS_TAB, Permissions.ADMIN_PROFIL_GIVER, Permissions.PUBLIC_TEMPLATE_CREATION, Permissions.ADMIN_PROFILS_FULL_MANAGEMENT, Permissions.FAQ_MANAGEMENT, Permissions.ALL] };
      const userWithGroups: PitUserWithGroups = { groups: [{ id: '', name: 'name', description: 'description' }], user: { id: '', userId: user.userId, profiles: [UserRole.PUBLIC, UserRole.ADMIN, UserRole.SUPER_ADMIN] } };

      authService.getPitUser.and.returnValue(of([userWithGroups]));

      actions = m.hot('a', { a: new GetUser() });
      const expected = m.hot('(ab)', {
        a: new GetUserSuccess({ user: { ...user, email: undefined }, profil }),
        b: new LoadGroupsSuccess({ userId: user.userId, groups: [{ id: '', name: 'name', description: 'description', admins: [], users: [], defaultTemplate: '' }] }),
      });

      m.expect(effects.GetUser).toBeObservable(expected);
    }));

    it('should emit a GetUserSuccess with the user and empty permissions when the user does not exists', marbles(m => {
      effects = TestBed.get(AuthEffects);

      const user = User.from(environment.user) as SgSignInUser;
      const profil = { profiles: [UserRole.PUBLIC], permissions: environment.permissions };

      authService.getPitUser.and.returnValue(of([{}]));

      actions = m.hot('a', { a: new GetUser() });
      const expected = m.hot('(ab)', {
        a: new GetUserSuccess({ user: { ...user, email: undefined }, profil }),
        b: new LoadGroupsSuccess({ userId: user.userId, groups: [] }),
      });

      m.expect(effects.GetUser).toBeObservable(expected);
    }));

    it('should emit a GetUserError after 3 tries', fakeAsync(() => {
      const actionsSubject = new Subject<any>();
      const user = User.from(environment.user) as SgSignInUser;
      const spy = jasmine.createSpy('subscribe');

      effects = TestBed.get(AuthEffects);
      actions = actionsSubject.asObservable();

      const sub = effects.GetUser.subscribe(spy);
      actionsSubject.next(new GetUser());

      authService.getPitUser.and.returnValue(of(null, new HttpErrorResponse({ status: 500 })));
      tick(2000);
      authService.getPitUser.and.returnValue(of(null, new HttpErrorResponse({ status: 500 })));
      tick(2000);
      authService.getPitUser.and.returnValue(of(null, new HttpErrorResponse({ status: 500 })));

      expect(spy).toHaveBeenCalledWith(jasmine.any(GetUserError));

      sub.unsubscribe();
    }));

  });

});
