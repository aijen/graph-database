import { Permissions, User } from 'core/models/user.model';
import { UserRole } from 'core/models/userRoles.model';
import { AppState } from 'shared/models/state.model';
import { GetUserSuccess } from '../auth.actions';
import { authReducer, authState } from '../auth.reducer';

// necessary to avoid the error :
// Invalid module name in augmentation, module 'shared/models/state.model' cannot be found.
let happy_compiler: AppState; // tslint:disable-line

describe('Auth Reducer', () => {

  describe('undefined action', () => {

    it('should return the default state', () => {
      const action = { type: null, payload: null };
      const state = authReducer( undefined, action );

      expect(state).toBe(authState);
    })

  });

  describe('GET_USER_SUCCESS action', () => {

    it('should register the user and roles in the state and set the authenticated flag', () => {
      const user = User.from( {} ) as SgSignInUser;
      const profil = { profiles: [UserRole.SUPER_ADMIN], permissions: [Permissions.ALL] };
      const action = new GetUserSuccess( { user, profil } );
      const state = authReducer(authState, action);

      expect(state.user).toEqual(user);
      expect(state.profil).toEqual(profil);
      expect(state.isUserAuthenticated).toBe(true);
    })

  })

} );
