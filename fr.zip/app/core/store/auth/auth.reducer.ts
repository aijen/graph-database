import { User } from 'core/models/user.model';
import { UserRole } from 'core/models/userRoles.model';
import { AuthActions, GET_USER_SUCCESS } from 'core/store/auth/auth.actions';
import { environment } from 'env/environment';
import { AuthState } from './auth.model';

export const authState: AuthState = {
  user: User.from( environment.user ),
  isUserAuthenticated: false,
  profil: { profiles: [UserRole.PUBLIC], permissions: [] },
};

export function authReducer(
  state: AuthState = authState,
  action: AuthActions
): AuthState {
  switch (action.type) {
    case GET_USER_SUCCESS:
      return {
        ...state,
        user: action.payload.user,
        isUserAuthenticated: true,
        profil: action.payload.profil,
      };
    default:
      return state;
  }
}
