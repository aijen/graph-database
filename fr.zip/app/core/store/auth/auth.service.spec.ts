import { HttpParams, HttpRequest } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { PitUserWithGroups, User } from 'core/models/user.model';
import { UserRole } from 'core/models/userRoles.model';
import { LOAD_PIT_USERS_URL } from 'core/services/http/http-client.service';
import { environment } from 'env/environment';
import isEqual from 'lodash/isEqual';
import { configureTestSuite } from 'ng-bullet';
import { AuthService } from './auth.service';

describe('AuthService', () => {
  let service: AuthService;
  let httpTestingController: HttpTestingController;

  function fromHttpParams(params: HttpParams) {
    return params.keys()
      .map(k => ({ [k]: params.get(k) }))
      .reduce((acc, value) => ({ ...acc, ...value }), {});
  }

  function isParamsEqual(params: HttpParams, comp: any) {
    return isEqual(fromHttpParams(params), comp);
  }

  function isRequest(matcher: { url?: string, method?: string, params?: any, body?: any }) {
    return (req: HttpRequest<any>) =>
      (!matcher.url || req.url === matcher.url)
      && (!matcher.method || req.method === matcher.method)
      && (!matcher.params || isParamsEqual(req.params, matcher.params))
      && (!matcher.body || isEqual(req.body, matcher.body));
  }

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
      ],
      providers: [
        AuthService,
      ],
    })
  });

  beforeEach( () => {
    service = TestBed.get(AuthService);
    httpTestingController = TestBed.get(HttpTestingController);
  } );

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  describe('getPitUser', () => {

    it('should get the user and its groups', () => {
      const spy = jasmine.createSpy('response');
      const user = User.from(environment.user) as SgSignInUser;
      const userWithGroups: PitUserWithGroups = { groups: [], user: { id: '', userId: 'A123456', profiles: [UserRole.PUBLIC] } };

      let sub = service.getPitUser(user).subscribe(spy);

      httpTestingController.expectOne(isRequest({
        url: LOAD_PIT_USERS_URL,
        method: 'GET',
        params: { userId: user.userId },
      })).flush([userWithGroups]);

      expect(spy).toHaveBeenCalledWith([userWithGroups])

      sub.unsubscribe();
    });

  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
