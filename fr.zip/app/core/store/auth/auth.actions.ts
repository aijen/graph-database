import { Action } from '@ngrx/store';
import { Profil } from 'core/models/user.model';

export const GET_USER = '[COCKPIT] Get User';
export const GET_USER_SUCCESS = '[COCKPIT] Get User SUCCESS';
export const GET_USER_ERROR = '[COCKPIT] Get User Error';

export class GetUser implements Action {
  readonly type = GET_USER;
}

export class GetUserSuccess implements Action {
  readonly type = GET_USER_SUCCESS;
  constructor(public payload: { user: SgSignInUser, profil: Profil }) {}
}

export class GetUserError implements Action {
  readonly type = GET_USER_ERROR;
  constructor(public payload: { error: Error }) {}
}

export type AuthActions =
  | GetUser
  | GetUserSuccess
  | GetUserError
  ;
