import { Inject, Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action, Store } from '@ngrx/store';
import { SgSignInToken } from 'app/shared/tokens/auth/auth.token';
import { Permissions, Profil, User } from 'core/models/user.model';
import { UserRole } from 'core/models/userRoles.model';
import { GetUser, GetUserError, GetUserSuccess, GET_USER, GET_USER_ERROR, GET_USER_SUCCESS } from 'core/store/auth/auth.actions';
import { retryStrategy } from 'core/utils/retryStrategy';
import { environment } from 'env/environment';
import { combineLatest, concat, from, Observable, timer } from 'rxjs';
import { of } from 'rxjs/observable/of';
import { catchError, concatMap, delay, filter, map, retryWhen, switchMap, switchMapTo } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';
import { LoadGroupsSuccess } from '../groups/groups.actions';
import { GroupsValue, GroupsValueDTO } from '../groups/groups.model';
import { AuthService } from './auth.service';

const profilFromJson = (profilsDto: UserRole[]): Profil => {
  const profil: Profil = { profiles: [], permissions: [] };

  profilsDto.forEach(profilDto => {
    profil.profiles.push(profilDto);
    profil.permissions.push(...getPermissionsByProfil(profilDto));
  });

  profil.profiles = [...new Set(profil.profiles)];
  profil.permissions = [...new Set(profil.permissions)];

  return profil;
}

const getPermissionsByProfil = (profilDto: UserRole): Permissions[] => {
  switch (profilDto) {
    case UserRole.PUBLIC:
      return [];
    case UserRole.ADMIN:
      return [
        Permissions.ADMIN_SCREEN,
        Permissions.ADMIN_ALERT_TAB,
        Permissions.ADMIN_MUTE_TAB,
        Permissions.ADMIN_METEO_TAB,
        Permissions.ADMIN_PROFILS_TAB,
        Permissions.ADMIN_EVENTS_TAB,
        Permissions.ADMIN_PROFIL_GIVER,
        Permissions.PUBLIC_TEMPLATE_CREATION,
        Permissions.ADMIN_PROFILS_FULL_MANAGEMENT,
        Permissions.FAQ_MANAGEMENT,
      ];
    case UserRole.SUPER_ADMIN:
      return [Permissions.ALL];
    case UserRole.GROUP_MANAGER:
      return [
        Permissions.ADMIN_SCREEN,
        Permissions.ADMIN_PROFILS_TAB,
      ];
  }
}

const groupsFromJson = (groupsDto: GroupsValueDTO[]): GroupsValue[] => {
  return groupsDto.map(groupDto => ({
    ...groupDto,
    users: groupDto.users || [],
    admins: groupDto.admins || [],
    defaultTemplate: groupDto.defaultTemplate || '',
  }));
};

@Injectable({ providedIn: 'root' })
export class AuthEffects {
  constructor(
    private actions$: Actions,
    private store$: Store<AppState>,
    private authService: AuthService,
    @Inject(SgSignInToken)
    private sgSignIn: SgSignIn,
  ) {
    if (environment.sgSignIn) {
      // tslint:disable-next-line: no-unused-expression
      new this.sgSignIn(environment.sgSignInUrl, (error) => this.store$.dispatch(new GetUserError({ error })));
    }
  }

  getUser$ = environment.sgSignIn
    ? of<void>(null).pipe(
      map(() => {
        const user = this.sgSignIn.getCurrentUser();
        if (!user) throw new Error();
        return user;
      }),
      retryWhen(errors => errors.pipe(delay(1000))),
    )
    : of(User.from(environment.user) as SgSignInUser);


  @Effect()
  GetUser: Observable<Action> = this.actions$.pipe(
    ofType<GetUser>(GET_USER),
    switchMapTo(this.getUser$),
    switchMap(user => combineLatest(
      of(user),
      this.authService.getPitUser(user).pipe(
        retryWhen(retryStrategy({ delay: 2000 })),
        map(pitUsers => Boolean(pitUsers && pitUsers[0] && pitUsers[0].user) ? pitUsers[0] : undefined),
      )
    )),
    concatMap(([user, pitUser]) => [
      new GetUserSuccess({ user: { ...user, email: pitUser ? pitUser.user.email: undefined }, profil: Boolean(pitUser && pitUser.user && pitUser.user.profiles) ? profilFromJson(pitUser.user.profiles) : { profiles: [UserRole.PUBLIC], permissions: environment.permissions } }),
      new LoadGroupsSuccess({ userId: user.userId, groups: Boolean(pitUser && pitUser.groups) ? groupsFromJson(pitUser.groups) : [] }),
    ]),
    catchError((error: Error, caught) => {
      console.log(GET_USER_ERROR + ': ', error);
      return concat(of(new GetUserError({ error })), caught);
    })
  );

  @Effect({
    dispatch: false
  })
  refreshToken$ = this.actions$.pipe(
    ofType<GetUserSuccess>(GET_USER_SUCCESS),
    filter(() => environment.sgSignIn),
    map((action) => action.payload.user),
    map(({ token }) => token),
    switchMap((_token) => {
      const refresh = ({ iat, durationAccessToken: duration }: SgSignInToken) => {
        const now = Date.now();
        const iatTimestamp = (new Date(iat)).getTime();
        const durationMs = duration * 1000;
        const dueTime = iatTimestamp + durationMs - now;

        // console.log( `[refreshToken$] iat: ${iat}, duration: ${duration}, dueTime: ${dueTime}ms` );

        return timer(dueTime).pipe(
          // tap( () => console.log( '[refreshToken$] refreshingToken before', this.sgSignIn.getCurrentUser().token ) ),
          map(() => this.sgSignIn.getAccessToken()),
          // tap( ( accessTokenPromise ) => console.log( '[refreshToken$] accessTokenPromise', accessTokenPromise ) ),
          switchMap((accessTokenPromise) => from(accessTokenPromise)),
          map(() => this.sgSignIn.getCurrentUser().token),
          // tap( token => console.log( '[refreshToken$] refreshingToken after', token ) ),
          // finalize( () => console.log( '[refreshToken$] complete' ) ),
          switchMap(refresh),
        );
      }

      return refresh(_token);
    }),
  )
}
