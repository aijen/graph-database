import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { PitUserWithGroups } from 'core/models/user.model';
import { LOAD_PIT_USERS_URL } from 'core/services/http/http-client.service';

@Injectable({ providedIn: 'root' })
export class AuthService {
  constructor(
    private http: HttpClient,
  ) { }

  getPitUser(user: SgSignInUser) {
    return this.http.get<PitUserWithGroups[] | null>(LOAD_PIT_USERS_URL, { params: { userId: user.userId } });
  }
}
