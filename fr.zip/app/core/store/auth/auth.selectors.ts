import { createFeatureSelector, createSelector, select } from '@ngrx/store';
import { Permissions, User } from 'core/models/user.model';
import { pipe } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { AuthState } from './auth.model';

export const getAuthState = createFeatureSelector<AuthState>('auth');

export const getUser = createSelector(
  getAuthState,
  (state: AuthState) => state.user
);

export const getIsUserAuthenticated = createSelector(
  getAuthState,
  (state: AuthState) => state.isUserAuthenticated
);

const getProfil = createSelector(
  getAuthState,
  state => state.profil,
);

export const getPermissions = createSelector(
  getProfil,
  profil => profil.permissions,
);

export const hasAdminScreenAccess = createSelector(
  getPermissions,
  permissions => permissions.includes(Permissions.ALL) || permissions.includes(Permissions.ADMIN_SCREEN)
);

export const hasAlertTabAccess = createSelector(
  getPermissions,
  permissions => permissions.includes(Permissions.ALL) || permissions.includes(Permissions.ADMIN_ALERT_TAB)
);

export const hasMuteTabAccess = createSelector(
  getPermissions,
  permissions => permissions.includes(Permissions.ALL) || permissions.includes(Permissions.ADMIN_MUTE_TAB)
);

export const hasBaselinesTabAccess = createSelector(
  getPermissions,
  permissions => permissions.includes(Permissions.ALL) || permissions.includes(Permissions.ADMIN_BASELINES_TAB)
);

export const hasMeteoTabAccess = createSelector(
  getPermissions,
  permissions => permissions.includes(Permissions.ALL) || permissions.includes(Permissions.ADMIN_METEO_TAB)
);

export const hasPerimeterTabAccess = createSelector(
  getPermissions,
  permissions => permissions.includes(Permissions.ALL) || permissions.includes(Permissions.ADMIN_PERIMETER_TAB)
);

export const hasArborescenceTabAccess = createSelector(
  getPermissions,
  permissions => permissions.includes(Permissions.ALL) || permissions.includes(Permissions.ADMIN_ARBORESCENCE_TAB)
);

export const hasMetricsTabAccess = createSelector(
  getPermissions,
  permissions => permissions.includes(Permissions.ALL) || permissions.includes(Permissions.ADMIN_METRICS_TAB)
);

export const hasProfilsTabAccess = createSelector(
  getPermissions,
  permissions => permissions.includes(Permissions.ALL) || permissions.includes(Permissions.ADMIN_PROFILS_TAB)
);

export const hasEventsTabAccess = createSelector(
  getPermissions,
  permissions => permissions.includes(Permissions.ALL) || permissions.includes(Permissions.ADMIN_EVENTS_TAB)
);

export const canAssignAdmin = createSelector(
  getPermissions,
  permissions => permissions.includes(Permissions.ALL) || permissions.includes(Permissions.ADMIN_PROFIL_GIVER)
);

export const canAssignSuperAdmin = createSelector(
  getPermissions,
  permissions => permissions.includes(Permissions.ALL) || permissions.includes(Permissions.SUPER_ADMIN_PROFIL_GIVER)
);

export const canCreatePublicTemplates = createSelector(
  getPermissions,
  permissions => permissions.includes(Permissions.ALL) || permissions.includes(Permissions.PUBLIC_TEMPLATE_CREATION)
);

export const hasProfilsFullManagement = createSelector(
  getPermissions,
  permissions => permissions.includes(Permissions.ALL) || permissions.includes(Permissions.ADMIN_PROFILS_FULL_MANAGEMENT)
);

export const hasFaqManagement = createSelector(
  getPermissions,
  permissions => permissions.includes(Permissions.ALL) || permissions.includes(Permissions.FAQ_MANAGEMENT)
);

export const isAdmin$ = pipe(
  select( createSelector(
    getIsUserAuthenticated,
    hasAdminScreenAccess,
    (isAuthenticated, hasAccess) => [isAuthenticated, hasAccess] as [boolean, boolean]
  ) ),
  filter( ([isAuthenticated]) => isAuthenticated ),
  map( ([auth, hasAccess]) => hasAccess )
)

export const getUserConnected$ = pipe(
  select( createSelector(
    getIsUserAuthenticated,
    getUser,
    (isAuthenticated, user) => [isAuthenticated, user] as [boolean, User]
  ) ),
  filter( ([isAuthenticated]) => isAuthenticated ),
  map( ([, user]) => user ),
);

export const getUserId$ = pipe(
  getUserConnected$,
  map( user => user.userId ),
)
