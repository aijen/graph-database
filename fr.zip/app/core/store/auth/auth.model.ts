import { Profil, User } from 'core/models/user.model';

declare module 'shared/models/state.model' {
  export interface AppState {
    readonly auth: AuthState;
  }
}

export interface AuthState {
  user: User;
  isUserAuthenticated: boolean;
  profil: Profil,
}
