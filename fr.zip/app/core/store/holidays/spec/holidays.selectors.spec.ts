import merge from 'lodash/merge';
import { HolidaysState } from '../holidays.model';
import { initialState } from '../holidays.reducer';
import { isHolidaysLoaded, isHolidaysLoading, selectPublicHolidays } from '../holidays.selectors';

describe('Holidays Selectors', () => {

  function getState( partialState: DeepPartial<HolidaysState> = {} ) {
    return merge({}, initialState, partialState);
  }

  describe('isHolidaysLoading', () => {

    it('should return the loading state',() => {
      const state = getState({ isLoading: true })
      const expected = true
      expect(isHolidaysLoading.projector(state)).toEqual(expected)
    })

  })

  describe('isHolidaysLoaded', () => {

    it('should return the loading state',() => {
      const state = getState({ loaded: true })
      const expected = true
      expect(isHolidaysLoaded.projector(state)).toEqual(expected)
    })

  })

  describe('selectPublicHolidays', () => {

    it('should return the loading state',() => {
      const state = getState({ publicHolidays: [] })
      const expected = []
      expect(selectPublicHolidays.projector(state)).toEqual(expected)
    })

  })

} );
