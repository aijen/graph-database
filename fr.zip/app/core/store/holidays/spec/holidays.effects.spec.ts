import { async, TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { configureTestSuite } from 'ng-bullet';
import { Subject } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { LoadHolidaysError } from '../holidays.actions';
import { HolidaysEffects } from '../holidays.effects';

describe('HolidaysEffects', () => {
  let service: HolidaysEffects;
  let actions: Subject<any>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [
        HolidaysEffects,
        provideMockStore<Partial<AppState>>({ initialState: {} }),
        provideMockActions(() => actions),
        { provide: MessageHandler, useFactory: () => jasmine.createSpyObj('MessageHandler', ['ngOnDestroy', 'show']) },
      ],
    })
  });

  beforeEach(async( async () => {
    service = TestBed.get(HolidaysEffects);
  } ));

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  describe('loadError', () => {

    it('should show a message in case of error', () => {
      actions = new Subject<LoadHolidaysError>()
      const snackbar = TestBed.get(MessageHandler)
      spyOn(console, 'error')

      const sub = service.loadError.subscribe()
      actions.next( new LoadHolidaysError( { error: new Error() } ) )

      expect(console.error).toHaveBeenCalled()
      expect(snackbar.show).toHaveBeenCalled()

      sub.unsubscribe()
    })

  })


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
