import { AppState } from 'shared/models/state.model';
import { LoadHolidays, LoadHolidaysError, LoadHolidaysSuccess, UnloadHolidays } from '../holidays.actions';
import { HolidaysState } from '../holidays.model';
import { HolidaysReducer, initialState } from '../holidays.reducer';

// necessary to avoid the error :
// Invalid module name in augmentation, module 'shared/models/state.model' cannot be found.
let happy_compiler: AppState; // tslint:disable-line

describe('Holidays Reducer', () => {

  describe('undefined action', () => {

    it('should return the default state', () => {
      const action = { type: null, payload: null };
      const state = HolidaysReducer( undefined, action );

      expect(state).toBe(initialState);
    })

  });

  describe('LoadHolidays action', () => {

    it('should be loading but not loaded', () => {
      const action = new LoadHolidays();
      const state = HolidaysReducer(initialState, action);

      expect(state.isLoading).toBe(true);
      expect(state.loaded).toBe(false);
    });

  });

  describe('LoadHolidaysSuccess action', () => {

    it('should set config and be loaded but not loading', () => {
      const publicHolidays = [];
      const action = new LoadHolidaysSuccess({ publicHolidays });
      const state = HolidaysReducer(initialState, action);

      expect(state.publicHolidays).toEqual(publicHolidays);
      expect(state.loaded).toBe(true);
      expect(state.isLoading).toBe(false);
    });

  });

  describe('LoadHolidaysError action', () => {

    it('should not be loading', () => {
      const error = new Error();
      const action = new LoadHolidaysError({error});
      const state = HolidaysReducer(initialState, action);

      expect(state.isLoading).toBe(false);
    });

  });

  describe('UnloadHolidays action', () => {

    it('should retun the default snooze state', () => {
      const modifiedState: HolidaysState = {
        publicHolidays: [],
        isLoading: true,
        loaded: true,
      };
      const action = new UnloadHolidays();
      const state = HolidaysReducer(modifiedState, action);

      expect(state).toEqual(initialState);
    });

  });

} );
