import { createFeatureSelector, createSelector } from '@ngrx/store';
import { HolidaysState } from './holidays.model';

export const getHolidaysState = createFeatureSelector<HolidaysState>(
  'holidays'
);

export const isHolidaysLoading = createSelector(
  getHolidaysState,
  state => state.isLoading,
);

export const isHolidaysLoaded = createSelector(
  getHolidaysState,
  state => state.loaded,
);

export const selectPublicHolidays = createSelector(
  getHolidaysState,
  state => state.publicHolidays,
);
