import { HolidaysActionsUnion, HolidaysActionTypes } from './holidays.actions';
import { HolidaysState } from "./holidays.model";

export const initialState: HolidaysState = {
  publicHolidays: [],
  isLoading: false,
  loaded: false,
};

export function HolidaysReducer(
  state: HolidaysState = initialState,
  action: HolidaysActionsUnion
): HolidaysState {

  switch (action.type) {
    case HolidaysActionTypes.LoadHolidays: {
      return {
        ...state,
        isLoading: true,
        loaded: false,
      };
    }
    case HolidaysActionTypes.LoadHolidaysSuccess: {
      return {
        ...state,
        publicHolidays: action.payload.publicHolidays,
        isLoading: false,
        loaded: true,
      };
    }
    case HolidaysActionTypes.LoadHolidaysError: {
      return {
        ...state,
        isLoading: false,
      }
    }
    case HolidaysActionTypes.UnloadHolidays: {
      return initialState;
    }
    default:
      return state;
  }

}
