import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { tap } from 'rxjs/operators';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { HolidaysActionTypes, LoadHolidaysError } from './holidays.actions';

@Injectable({providedIn: 'root'})
export class HolidaysEffects {

  public static messages = {
    loadError: `
      Une erreur est survenue pendant le chargement de la configuration 'Holidays'
    `
  }

  constructor(
    private actions$: Actions,
    private snackbar: MessageHandler,
  ) {}

  @Effect({ dispatch: false })
  loadError = this.actions$.pipe(
    ofType<LoadHolidaysError>(HolidaysActionTypes.LoadHolidaysError),
    tap( action => { console.error(action.payload.error); this.snackbar.show( { message: HolidaysEffects.messages.loadError, action: 'OK', isError: true, id: action.type } ) } ),
  )

}
