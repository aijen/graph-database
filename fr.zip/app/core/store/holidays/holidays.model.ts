declare module 'shared/models/state.model' {
  export interface AppState {
    readonly holidays: HolidaysState;
  }
}

export interface HolidaysState {
  publicHolidays: string[];
  isLoading: boolean;
  loaded: boolean;
}
