import { HttpErrorResponse } from '@angular/common/http';
import { Action } from '@ngrx/store';

export enum HolidaysActionTypes {
  LoadHolidays = '[CockPit] Holidays Load',
  LoadHolidaysSuccess = '[CockPit] Holidays LoadSuccess',
  LoadHolidaysError = '[CockPit] Holidays LoadError',
  UnloadHolidays = '[CockPit] Holidays UnloadHolidays',
}

export class LoadHolidays implements Action {
  readonly type = HolidaysActionTypes.LoadHolidays;
  constructor() {}
}

export class LoadHolidaysSuccess implements Action {
  readonly type = HolidaysActionTypes.LoadHolidaysSuccess;
  constructor( public payload: { publicHolidays: string[] } ) {}
}

export class LoadHolidaysError implements Action {
  readonly type = HolidaysActionTypes.LoadHolidaysError;
  constructor( public payload: { error: Error } ) {}
}

export class UnloadHolidays implements Action {
  readonly type = HolidaysActionTypes.UnloadHolidays;
  constructor() {}
}

export type HolidaysActionsUnion =
  | LoadHolidays
  | LoadHolidaysSuccess
  | LoadHolidaysError
  | UnloadHolidays
;
