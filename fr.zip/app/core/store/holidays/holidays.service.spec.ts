import { HttpErrorResponse } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { async, TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { LOAD_HOLIDAYS_URL } from 'core/services/http/http-client.service';
import merge from 'lodash/merge';
import { configureTestSuite } from 'ng-bullet';
import { Observable, Subscription } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { LoadHolidays, LoadHolidaysError, LoadHolidaysSuccess } from './holidays.actions';
import { HolidaysState } from './holidays.model';
import { initialState } from './holidays.reducer';
import { HolidaysService } from './holidays.service';

describe('HolidaysService', () => {
  let service: HolidaysService;
  let httpTestingController: HttpTestingController;
  let actions: Observable<any>;
  let store: MockStore<Partial<AppState>>;

  function setState( state: DeepPartial<HolidaysState> = {} ) {
    store.setState( { holidays: merge({}, initialState, state) } )
  }

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
      ],
      providers: [
        HolidaysService,
        provideMockStore<Partial<AppState>>({ initialState: { holidays: initialState } }),
        provideMockActions(() => actions),
      ],
    })
  });

  beforeEach(async( async () => {
    store = TestBed.get(Store);
    service = TestBed.get(HolidaysService);
    httpTestingController = TestBed.get(HttpTestingController);
  } ));

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  describe('config$.subscribe()', () => {

    describe('when cached', () => {

      it('should return the config', () => {
        setState({ loaded: true, publicHolidays: ['foo'] })
        const next = jasmine.createSpy('next')
        const sub = service.config$.subscribe(next)

        expect(next).toHaveBeenCalledWith(['foo'])

        sub.unsubscribe()
      })

    })

    describe('when not cached', () => {

      it('should dispatch a LoadHolidays Action, fetch the config, dispatch a LoadHolidaysSuccess Action, and return the config', () => {
        setState({ loaded: false, publicHolidays: [] })
        const dispatchSpy = spyOn(store, 'dispatch')
        const next = jasmine.createSpy('next')
        const sub = service.config$.subscribe(next)
        const publicHolidays = ['foo', 'bar']

        expect(dispatchSpy).toHaveBeenCalledWith(new LoadHolidays())
        const req = httpTestingController.expectOne( LOAD_HOLIDAYS_URL )

        dispatchSpy.and.callFake( () => setState({ loaded: true, publicHolidays }) )
        req.flush({ publicHolidays })

        expect(dispatchSpy).toHaveBeenCalledWith( new LoadHolidaysSuccess( { publicHolidays } ) )
        expect(next).toHaveBeenCalledWith(publicHolidays)

        sub.unsubscribe()
      })

      it('should dispatch a LoadHolidaysError Action when failing', () => {
        setState({ loaded: false })
        const dispatchSpy = spyOn(store, 'dispatch')
        const error = new HttpErrorResponse({ status: 500 })
        const sub = service.config$.subscribe()

        httpTestingController.expectOne( LOAD_HOLIDAYS_URL ).flush(null, error)

        expect(dispatchSpy).toHaveBeenCalledWith(jasmine.any(LoadHolidaysError))

        sub.unsubscribe()
      })

      it('should execute only one request even when subscribed multiple times', () => {
        setState({ loaded: false })
        const sub = new Subscription()

        for(let i = 0; i < 5; i++)
          sub.add( service.config$.subscribe() )

        httpTestingController.expectOne( LOAD_HOLIDAYS_URL )

        sub.unsubscribe()
      })

    })

  })


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
