import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { HolidaysDTO } from 'app/pages/tab-baselines/store/holidays/holidays.form.model';
import { LOAD_HOLIDAYS_URL } from 'core/services/http/http-client.service';
import { of } from 'rxjs';
import { catchError, map, share, switchMap, switchMapTo, tap } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';
import { LoadHolidays, LoadHolidaysError, LoadHolidaysSuccess } from './holidays.actions';
import { isHolidaysLoaded, selectPublicHolidays } from './holidays.selectors';

const fromJson = ( dto: HolidaysDTO ): string[] => {
  return dto.publicHolidays;
}

@Injectable({
  providedIn: 'root'
})
export class HolidaysService {

  constructor(
    private store$: Store<AppState>,
    private http: HttpClient,
  ) {}

  private getConfig$ = this.http.get<HolidaysDTO>( LOAD_HOLIDAYS_URL ).pipe( map( fromJson ), share() );

  private require$ = of<void>(null).pipe(
    tap( () => this.store$.dispatch( new LoadHolidays() ) ),
    switchMapTo( this.getConfig$ ),
    tap( publicHolidays => this.store$.dispatch( new LoadHolidaysSuccess( { publicHolidays } ) ) ),
    catchError( error => (this.store$.dispatch( new LoadHolidaysError( { error } ) ), of<void>(null)) ),
    share(),
  );

  private selectConfig$ = this.store$.pipe( select( selectPublicHolidays ) );

  private getAndSelectConfig$ = this.require$.pipe( switchMapTo( this.selectConfig$ ) );

  config$ = this.store$.pipe(
    select( isHolidaysLoaded ),
    switchMap( loaded => loaded ? this.selectConfig$ : this.getAndSelectConfig$ ),
  );

}
