import { sortStringCaseInsensitiveStrategy } from 'core/utils/sortStrategies';
import { SnoozeLeaf } from '../snooze/snooze.model';

export interface MetasCheck {
  availability: boolean;
  performance: boolean;
  risk: boolean;
  userXp: boolean;
}

export interface MetasCheckDTO {
  AVAILABILITY: boolean;
  PERFORMANCE: boolean;
  RISK: boolean;
  USER_XP: boolean;
}

export interface AdminLeaf extends MetasCheck {
  leafId: string;
  name: string;
  selected: boolean;
}

export interface LeavesState {
  [index:string]: AdminLeaf[],
  BDDF?: AdminLeaf[],
  CDN?: AdminLeaf[],
};

export const metasCheckState: MetasCheck = {
  availability: false,
  performance: false,
  risk: false,
  userXp: false,
}

export const leavesState: LeavesState = {
  BDDF: [],
  CDN: [],
}

export const sortByNameCaseInsensitive = ( leafA: AdminLeaf | SnoozeLeaf, leafB: AdminLeaf | SnoozeLeaf ) => sortStringCaseInsensitiveStrategy( leafA.name, leafB.name )
