import { Injectable } from '@angular/core';
import uniq from 'lodash/uniq';
import { Leaf } from 'shared/models/leaf.model';
import { Node } from 'shared/models/node.model';
import { HierarchyState, NODE_KEYS_POSITION } from './hierarchy.model';

@Injectable({
  providedIn: 'root'
})
export class TreeService {

  public static findRoot( state: HierarchyState, node: Node ): {fromColumn: number, fromOffset: number} {
    let fromColumn, fromOffset;
    fromColumn = state.nodesPosition.findIndex( column => -1 !== (fromOffset = column.findIndex( key => key === node.technicalKey )) );
    return {fromColumn, fromOffset};
  }

  private static moveRoot( state: HierarchyState, node: Node, columnIndex: number, offset: number ): HierarchyState {
    let nodesPosition = state.nodesPosition;
    let column = nodesPosition[columnIndex];
    column = [ ...column.slice(0, offset), node.technicalKey, ...column.slice(offset) ];
    nodesPosition = [ ...nodesPosition.slice(0, columnIndex), column, ...nodesPosition.slice(columnIndex + 1) ] as NODE_KEYS_POSITION;
    return {
      ...state,
      nodesPosition,
    };
  }

  public static addRoot( state: HierarchyState, node: Node | Leaf, columnIndex: number, offset: number ): HierarchyState {
    let { openLeaves } = state;
    if( Leaf.isLeaf( node ) ) {
      const leaf = node;
      node = new Node( { assignRandomKey: true, isLeafWrapper: true } );
      node.leaves = [leaf];
      node.isNew = false;
      leaf.parent = node;

      openLeaves = [ ...openLeaves, leaf.technicalKey, node.technicalKey ];
    } else {
      openLeaves = [ ...openLeaves, node.technicalKey ];
    }

    state = {
      ...state,
      nodes: [ ...state.nodes, node ],
      openLeaves: uniq(openLeaves),
    }

    return TreeService.moveRoot( state, node, columnIndex, offset );
  }

  public static removeRoot( state: HierarchyState, node: Node, fromColumn: number, fromOffset: number ): HierarchyState {
    if( fromColumn === -1 || fromOffset === -1 ) return state;

    let { nodes, openLeaves } = state;
    const index = nodes.indexOf( node );
    if(index === -1) return state;
    nodes = [ ...state.nodes.slice( 0, index ), ...state.nodes.slice( index + 1 ) ];
    openLeaves = openLeaves.filter( key => key !== node.technicalKey );

    let nodesPosition = state.nodesPosition;
    let column = nodesPosition[fromColumn];
    column = [ ...column.slice(0, fromOffset), ...column.slice(fromOffset + 1) ];
    nodesPosition = [ ...nodesPosition.slice(0, fromColumn), column, ...nodesPosition.slice( fromColumn + 1 ) ] as NODE_KEYS_POSITION;

    return {
      ...state,
      nodes,
      nodesPosition,
      openLeaves,
    };
  }

  public static addTree( node: Node | Leaf, _offset: number, parent: Node ) {
    if( Node.isNode( node ) ) {
      const parentNodes = parent.nodes;
      parent.nodes = [ ...parentNodes.slice(0, _offset), node, ...parentNodes.slice(_offset) ];
    } else {
      const parentLeaves = parent.leaves;
      parent.leaves = [ ...parentLeaves.slice(0, _offset), node, ...parentLeaves.slice(_offset) ];
    }
    node.parent = parent;
  }

  public static removeTree( node: Node | Leaf, parent: Node ) {
    if( Node.isNode( node ) ) {
      const index = parent.nodes.indexOf( node );
      if(index === -1) return;
      parent.nodes = [ ...parent.nodes.slice(0, index), ...parent.nodes.slice(index + 1) ];
    } else {
      const index = parent.leaves.indexOf( node );
      if(index === -1) return;
      parent.leaves = [ ...parent.leaves.slice(0, index), ...parent.leaves.slice(index + 1) ];
    }
    node.parent = null;
  }

  public static clone( nodeOrLeaf: Node | Leaf, _parent: Node ) {
    if( Node.isNode( nodeOrLeaf ) ) return Node.clone( nodeOrLeaf, _parent );
    else                            return Leaf.clone( nodeOrLeaf, _parent );
  }

}
