import merge from 'lodash/merge';
import { Leaf } from 'shared/models/leaf.model';
import { Node } from 'shared/models/node.model';
import { HierarchyState, NODE_KEYS_POSITION } from './hierarchy.model';
import { hierarchyState } from './hierarchy.reducer';
import { TreeService } from './tree.service';

describe('TreeService', () => {

  const createNode = ( node?: Partial<Node>, options: { asObject?: boolean, skipUpdateChildrenParent?: boolean } = {} ): Node => {
    const newNode = merge(new Node, { isNew: false, ...node });
    if(!options.skipUpdateChildrenParent) {
      newNode.nodes.forEach( child => child.parent = newNode);
      newNode.leaves.forEach( child => child.parent = newNode);
    }
    return options.asObject ? { ...newNode } : newNode;
  }
  const createLeaf = ( leaf?: Partial<Leaf> ): Leaf => merge(new Leaf, leaf);
  function getState( partialState: DeepPartial<HierarchyState> = {} ) {
    return merge({}, hierarchyState, partialState);
  }

  it('should create', () => {
    expect(new TreeService).toBeTruthy();
  });

  describe('findRoot', () => {

    it('should find the position of a node in the nodesPosition', () => {
      const node = createNode({ technicalKey: 'node' })
      const notFound = createNode({ technicalKey: 'notFound' })
      const nodesPosition: NODE_KEYS_POSITION = [['node'],[],[],[]]

      expect(TreeService.findRoot(getState({ nodesPosition }), node)).toEqual({ fromColumn: 0, fromOffset: 0 })
      expect(TreeService.findRoot(getState({ nodesPosition }), notFound)).toEqual({ fromColumn: -1, fromOffset: -1 })
    })

  })

  describe('addRoot', () => {

    it('should insert the provided node in the state at the provided column and offset', () => {
      const node = createNode({ technicalKey: 'node' })
      const columnIndex = 0
      const offset = 0

      expect(TreeService.addRoot( getState(), node, columnIndex, offset )).toEqual(jasmine.objectContaining<HierarchyState>({
        nodes: [ node ],
        openLeaves: ['node'],
        nodesPosition: [['node'],[],[],[]],
      }))
    })

    it('should wrap the the provided leaf in a leafwrapper and insert it in the state at the provided column and offset', () => {
      const leaf = createLeaf({ technicalKey: 'leaf' })
      const columnIndex = 0
      const offset = 0

      spyOn(Node, 'randomKey').and.returnValue('random')
      const result = TreeService.addRoot( getState(), leaf, columnIndex, offset );
      expect(result).toEqual(jasmine.objectContaining<HierarchyState>({
        nodes: [ createNode({ technicalKey: 'random', key: 'random', isLeafWrapper: true, leaves: [leaf] }, { skipUpdateChildrenParent: true }) ],
        openLeaves: ['leaf', 'random'],
        nodesPosition: [['random'],[],[],[]],
      }))
      expect(result.nodes[0].leaves[0]).toBe(leaf)
    })

    it('should open the provided node or leaf', () => {
      const node = createNode({ technicalKey: 'node' })
      const leaf = createLeaf({ technicalKey: 'leaf' })

      expect(TreeService.addRoot( getState(), node, 0, 0 )).toEqual(jasmine.objectContaining<HierarchyState>({
        openLeaves: ['node'],
      }))
      spyOn(Node, 'randomKey').and.returnValue('random')
      expect(TreeService.addRoot( getState(), leaf, 0, 0 )).toEqual(jasmine.objectContaining<HierarchyState>({
        openLeaves: ['leaf', 'random'],
      }))
    })

  })

  describe('removeRoot', () => {

    it('should return the state if the provided column and offset are invalid', () => {
      const node = createNode({ technicalKey: 'node' })

      expect(TreeService.removeRoot(hierarchyState, node, -1, -1)).toEqual(hierarchyState)
    })

    it('should return the state if the provided node is not found', () => {
      const node = createNode({ technicalKey: 'node' })

      expect(TreeService.removeRoot(hierarchyState, node, 0, 0)).toEqual(hierarchyState)
    })

    it('should remove the provided node at the provided column and offset from the state', () => {
      const node = createNode({ technicalKey: 'node' })
      const nodes = [ node ]
      const nodesPosition: NODE_KEYS_POSITION = [ ['node'],[],[],[] ]
      const openLeaves = ['node']
      const state = getState({ nodes, nodesPosition, openLeaves })

      expect(TreeService.removeRoot(state, node, 0, 0)).toEqual(jasmine.objectContaining<HierarchyState>({
        nodes: [],
        nodesPosition: [ [],[],[],[] ],
        openLeaves: []
      }))
    })

  })

  describe('addTree', () => {

    it('should insert the node in the parent provided at the specified offset', () => {
      const node = createNode({ technicalKey: 'node' })
      const parent = createNode({ technicalKey: 'parent' })

      TreeService.addTree(node, 0, parent)
      expect( parent.nodes ).toEqual( [ node ] )
      expect( parent.nodes[0].parent ).toEqual( parent )
    })

    it('should insert the leaf in the parent provided at the specified offset', () => {
      const leaf = createLeaf({ technicalKey: 'leaf' })
      const parent = createNode({ technicalKey: 'parent' })

      TreeService.addTree(leaf, 0, parent)
      expect( parent.leaves ).toEqual( [ leaf ] )
      expect( parent.leaves[0].parent ).toEqual( parent )
    })

  })

  describe('removeTree', () => {

    it('should remove the node from the parent provided', () => {
      const node = createNode({ technicalKey: 'node' })
      const parent = createNode({ technicalKey: 'parent', nodes: [ node ] })

      TreeService.removeTree(node, parent)

      expect( parent.nodes ).toEqual([])
      expect( node.parent ).toBeNull()
    })

    it('should remove the leaf from the parent provided', () => {
      const leaf = createLeaf({ technicalKey: 'leaf' })
      const parent = createNode({ technicalKey: 'parent', leaves: [ leaf ] })

      TreeService.removeTree(leaf, parent)

      expect( parent.leaves ).toEqual([])
      expect( leaf.parent ).toBeNull()
    })

    it('should do nothing if the node or leaf is not found', () => {
      const node1 = createNode({ technicalKey: 'node1' })
      const node2 = createNode({ technicalKey: 'node2' })
      const leaf1 = createLeaf({ technicalKey: 'leaf1' })
      const leaf2 = createLeaf({ technicalKey: 'leaf2' })
      const parent = createNode({ technicalKey: 'parent', nodes: [ node1, node2 ], leaves: [ leaf1, leaf2 ] })

      TreeService.removeTree(createNode(), parent)
      TreeService.removeTree(createLeaf(), parent)

      expect( parent.nodes ).toEqual( [ node1, node2 ] )
      expect( parent.leaves ).toEqual( [ leaf1, leaf2 ] )
      expect( node1.parent ).toBe( parent )
      expect( leaf1.parent ).toBe( parent )
    })

  })

  describe('clone', () => {

    it('should clone the provided node', () => {
      const node = createNode()
      spyOn(Node, 'randomKey').and.returnValue('random')

      expect(TreeService.clone(node, undefined)).toEqual( createNode({ key: 'random', technicalKey: 'random' }) )
      expect(TreeService.clone(node, undefined)).not.toBe( node )
    })

    it('should clone the provided leaf', () => {
      const leaf = createLeaf()
      spyOn(Node, 'randomKey').and.returnValue('random')

      expect(TreeService.clone(leaf, undefined)).toEqual( createLeaf({ technicalKey: 'random' }) )
      expect(TreeService.clone(leaf, undefined)).not.toBe( leaf )
    })

  })



  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
