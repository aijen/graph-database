import { createFeatureSelector, createSelector } from '@ngrx/store';
import { Leaf } from 'shared/models/leaf.model';
import { Node } from 'shared/models/node.model';
import { HierarchyState } from './hierarchy.model';

export const getHierarchyState = createFeatureSelector<HierarchyState>(
  'hierarchy'
);

export const getNodes = createSelector(
  getHierarchyState,
  (state: HierarchyState) => state.nodes
);

export const getNodesPosition = createSelector(
  getHierarchyState,
  state => state.nodesPosition,
);

export const getLeaves = createSelector(
  getHierarchyState,
  (state: HierarchyState) => state.leaves
);

const getLeavesWithAlert = (rootNodes: Node[]) => {

  const findLeavesWithAlert = (node: Node): Set<Leaf> => {
    const { leaves, nodes } = node;
    let { nbAlert } = node;
    let leavesWithAlert = new Set<Leaf>();

    if( !nbAlert ) return leavesWithAlert;

    for( const leaf of leaves ) {
      if( leaf.hasAlert ) {
        leavesWithAlert.add(leaf);
        nbAlert -= 1;
      }
      if( !nbAlert ) break;
    }

    for( const childNode of nodes ) {
      if( !nbAlert ) break;
      leavesWithAlert = new Set([ ...leavesWithAlert, ...findLeavesWithAlert(childNode) ]);
      nbAlert -= childNode.nbAlert;
    }

    return leavesWithAlert;
  }

  return rootNodes.map( node => {
    const leaves = [...findLeavesWithAlert( node )];
    return { ...node, leaves, nodes: [] } as Node;
  });

}

const sortLeavesByAlertStartTime = (node : Node) => {

  const leaves = [...node.leaves];

  leaves.sort( (leafA, leafB) => {
    const firstTimeA = Math.max(
      leafA.firstAvailabilityTimeKO || 0,
      leafA.firstFeelingTimeKO      || 0,
      leafA.firstPerformanceTimeKO  || 0,
      leafA.firstRiskTimeKO         || 0,
    );
    const firstTimeB = Math.max(
      leafB.firstAvailabilityTimeKO || 0,
      leafB.firstFeelingTimeKO      || 0,
      leafB.firstPerformanceTimeKO  || 0,
      leafB.firstRiskTimeKO         || 0,
    );
    return firstTimeB - firstTimeA;
  })

  return { ...node, leaves };

}

export const getOpenLeaves = createSelector(
  getHierarchyState,
  (state: HierarchyState) => state.openLeaves
);

export const isPullerLaunched = createSelector(
  getHierarchyState,
  (state: HierarchyState) => state.isPullerLaunched
);

export const getAvailabilityPercent = createSelector(
  getHierarchyState,
  (state: HierarchyState) => state.availibiltyPercent
);

export const getPerformancePercent = createSelector(
  getHierarchyState,
  (state: HierarchyState) => state.performancePercent
);
export const getRiskPercent = createSelector(
  getHierarchyState,
  (state: HierarchyState) => state.riskPercent
);
export const getFeelingPercent = createSelector(
  getHierarchyState,
  (state: HierarchyState) => state.feelingPercent
);
export const getIsSupervising = createSelector(
  getHierarchyState,
  (state: HierarchyState) => state.isSupervising
);

export const getProgressLoaded = createSelector(
  getHierarchyState,
  ({progressLoaded}) => progressLoaded
);
export const getProgressTotal = createSelector(
  getHierarchyState,
  ({progressTotal}) => progressTotal
);
export const getProgress = createSelector(
  getProgressLoaded,
  getProgressTotal,
  (loaded, total) => ({ loaded, total, progress: loaded / total })
);
export const getReady = createSelector(
  getHierarchyState,
  (state: HierarchyState) => state.ready
);
export const getHierarchyError = createSelector(
  getHierarchyState,
  (state: HierarchyState) => state.hierarchyError
);

export const getNodeByKey = createSelector(
  getNodes,
  (nodes: Node[], key: string) => {
    const is = ( node: Node | Leaf ) => node.key === key
    const finder = ( node: Node | Leaf ) => is( node ) ? node : undefined
    const walker = (acc: Node | Leaf, node: Node): Node | Leaf => {
      return acc
        || finder( node )
        || node.leaves.find( is )
        || node.nodes.reduce( walker, undefined )
    }
    return nodes.reduce( walker, undefined );
  }
)

export const getPositionedNodes = createSelector(
  getNodes,
  getNodesPosition,
  getIsSupervising,
  (nodes, positions: string[][], supervising): Node[][] => {
    if( !nodes.length ) return [];
    if( supervising ) {

      nodes = nodes.filter( node => !node.isHiddenOnTree );
      let usernodes = nodes.filter( node => !node.readOnly );
      nodes = nodes.filter( node => node.readOnly );
      nodes = getLeavesWithAlert( nodes ).map( sortLeavesByAlertStartTime );
      positions = nodes.reduce(( acc, node, index ) => {
        acc[index % 2] = acc[index % 2] || [];
        acc[index % 2].push(node.technicalKey);
        return acc;
      }, []);

      usernodes = getLeavesWithAlert( usernodes );
      const userleaves = usernodes.reduce( ( acc, node ) => [...acc, ...node.leaves], [] as Leaf[] );
      if( userleaves.length ) {
        let usernode = new Node({ isNew: false, assignRandomKey: false });
        usernode.leaves = userleaves;
        usernode.name = usernode.key = usernode.technicalKey = 'Liste Personnalisée';
        usernode = sortLeavesByAlertStartTime( usernode );

        nodes.push( usernode );
        positions.push( [usernode.technicalKey] );
      }
    }

    const isNode = (itemTechnicalKey: string) => (node: Node) => node.technicalKey === itemTechnicalKey;
    const getNodeWithKey = (itemTechnicalKey: string) => nodes.find( isNode( itemTechnicalKey ) );
    const mapKeysToNodesInColumn = (column: string[]) => column.map( getNodeWithKey ).filter( node => Boolean(node) );
    return positions.map(
      mapKeysToNodesInColumn
    );
  }
);

export const getLastRestore = createSelector(
  getHierarchyState,
  state => state.lastRestore,
);

export const getRenamedNodeKey = createSelector(
  getHierarchyState,
  ( state ) => state.renamedNode,
)

export const getFlattenHierarchy = createSelector(
  getNodes,
  ( nodes ) => {
    const reducer = ( acc: Array<Leaf | Node>, node: Node ): Array<Leaf | Node> => [ ...acc, node, ...node.leaves, ...node.nodes.reduce( reducer, [] ) ];
    const flatten = nodes.reduce( reducer, [] as Array<Leaf | Node> );
    return flatten.filter( value => value.fullname || value.name );
  }
);

export const getLeafDetail = createSelector(
  getHierarchyState,
  state => state.leafDetail,
)

export const getLeavesKeys = createSelector(
  getNodes,
  ( allNodes ) => {
    const extractLeavesKeysFromNodes = (nodes: Node[], leavesIds: Set<string>) => {
      for(const node of nodes) if( !node.isHiddenOnTree ) {
        for(const leaf of node.leaves) if( !leaf.isHiddenOnTree )
          leavesIds.add(leaf.key)
        extractLeavesKeysFromNodes(node.nodes, leavesIds);
      }
    }
    const leavesKeys = new Set<string>();
    extractLeavesKeysFromNodes(allNodes, leavesKeys)
    return [...leavesKeys]
  }
)

export const getCockpitLeaves = createSelector(
  getHierarchyState,
  state => state.cockpitLeaves,
)

export const getTemplateName = createSelector(
  getHierarchyState,
  state => state.templateName,
)
