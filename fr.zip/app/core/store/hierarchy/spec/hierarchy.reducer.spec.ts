import { GetUserError } from 'core/store/auth/auth.actions';
import merge from 'lodash/merge';
import { Leaf } from 'shared/models/leaf.model';
import { Node } from 'shared/models/node.model';
import { AppState } from 'shared/models/state.model';
import { AddNode, DeleteNode, GetHierarchyError, GetHierarchySuccess, GetLeafDetailError, GetLeafDetailSuccess, GetLeavesSuccess, GetNodesSuccess, HideNodeFromTree, InitPullerSuccess, Loading, PullHierarchyrError, Ready, RenameLeaf, RenameNode, SetIndicatorsPercents, SetOpenLeaves, StartRenameNode, ToggleIsSupervising, UpdateLastRestore } from '../hierarchy.actions';
import { HierarchyState } from '../hierarchy.model';
import { hierarchyReducer, hierarchyState } from '../hierarchy.reducer';

// necessary to avoid the error :
// Invalid module name in augmentation, module 'shared/models/state.model' cannot be found.
let happy_compiler: AppState; // tslint:disable-line

describe('Hierarchy Reducer', () => {

  const createNode = ( node?: Partial<Node> ): Node => {
    const newNode = merge(new Node, { isNew: false, ...node });
    newNode.nodes.forEach( child => child.parent = newNode);
    newNode.leaves.forEach( child => child.parent = newNode);
    return newNode;
  }
  const createLeaf = ( leaf?: Partial<Leaf> ): Leaf => merge(new Leaf, leaf);
  function getState( partialState: DeepPartial<HierarchyState> ) {
    return merge({}, hierarchyState, partialState);
  }

  describe('undefined action', () => {

    it('should return the default state', () => {
      const action = { type: null, payload: null };
      const state = hierarchyReducer( undefined, action );

      expect(state).toBe(hierarchyState);
    })

  });

  describe('GET_HIERARCHY_SUCCESS', () => {

    it('should save the nodes, nodesPosition, hiddenNodes and templateName', () => {
      const action = new GetHierarchySuccess( {
        nodes: [ createNode({ technicalKey: 'BDDF' }) ],
        nodesPosition: [['BDDF'],[],[],[]],
        hiddenNodes: { CDN: ['CDN']},
        templateName: 'name',
      } );
      const state = hierarchyReducer( undefined, action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        nodes: [ createNode({ technicalKey: 'BDDF' }) ],
        nodesPosition: [['BDDF'],[],[],[]],
        hiddenNodes: { CDN: ['CDN']},
        templateName: 'name',
      }));
    });

    it('should default nodesPosition to the state value', () => {
      const action = new GetHierarchySuccess( {
        nodes: [ createNode({ technicalKey: 'BDDF' }) ],
        nodesPosition: undefined,
        hiddenNodes: {},
        templateName: '',
      } );
      const state = hierarchyReducer( getState({ nodesPosition: [['BDDF'],[],[],[]] }), action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        nodesPosition: [['BDDF'],[],[],[]],
      }));
    });

    it('should clean nodesPosition from non-existing node technicalKey', () => {
      const action = new GetHierarchySuccess( {
        nodes: [ createNode({ technicalKey: 'BDDF' }) ],
        nodesPosition: [['BDDF'],['CDN'],[],[]],
        hiddenNodes: {},
        templateName: '',
      } );
      const state = hierarchyReducer( undefined, action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        nodes: [ createNode({ technicalKey: 'BDDF' }) ],
        nodesPosition: [['BDDF'],[],[],[]],
      }));
    });

    it('should remove user nodes without a position from the nodes', () => {
      const action = new GetHierarchySuccess( {
        nodes: [ createNode({ technicalKey: 'BDDF' }), createNode({ technicalKey: 'user' }) ],
        nodesPosition: [['BDDF'],[],[],[]],
        hiddenNodes: {},
        templateName: '',
      } );
      const state = hierarchyReducer( undefined, action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        nodes: [ createNode({ technicalKey: 'BDDF' }) ],
        nodesPosition: [['BDDF'],[],[],[]],
      }));
    });

    it('should add readonly nodes without a position to nodesPosition at the first available space not occupied by a readonly node', () => {
      {
        const action = new GetHierarchySuccess( {
          nodes: [ createNode({ technicalKey: 'BDDF', readOnly: true }) ],
          nodesPosition: [[],[],[],[]],
          hiddenNodes: {},
          templateName: '',
        } );
        const state = hierarchyReducer( undefined, action );

        expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
          nodes: [ createNode({ technicalKey: 'BDDF', readOnly: true }) ],
          nodesPosition: [['BDDF'],[],[],[]],
        }));
      }
      {
        const action = new GetHierarchySuccess( {
          nodes: [ createNode({ technicalKey: 'BDDF', readOnly: true }), createNode({ technicalKey: 'user' }) ],
          nodesPosition: [['user'],[],[],[]],
          hiddenNodes: {},
          templateName: '',
        } );
        const state = hierarchyReducer( undefined, action );

        expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
          nodesPosition: [['BDDF', 'user'],[],[],[]],
        }));
      }
      {
        const action = new GetHierarchySuccess( {
          nodes: [ createNode({ technicalKey: 'BDDF', readOnly: true }), createNode({ technicalKey: 'CDN', readOnly: true }) ],
          nodesPosition: [['CDN'],[],[],[]],
          hiddenNodes: {},
          templateName: '',
        } );
        const state = hierarchyReducer( undefined, action );

        expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
          nodesPosition: [['CDN'],['BDDF'],[],[]],
        }));
      }
      {
        const action = new GetHierarchySuccess( {
          nodes: [ createNode({ technicalKey: 'BDDF', readOnly: true }), createNode({ technicalKey: 'CDN', readOnly: true }) ],
          nodesPosition: [[],[],[],[]],
          hiddenNodes: {},
          templateName: '',
        } );
        const state = hierarchyReducer( undefined, action );

        expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
          nodesPosition: [['BDDF'],['CDN'],[],[]],
        }));
      }
    });

    it('should set openLeaves to root node keys and wrapped leaf keys', () => {
      const action = new GetHierarchySuccess( {
        nodes: [
          createNode({ technicalKey: 'BDDF', readOnly: true, nodes: [
              createNode({ technicalKey: 'user' }),
            ],leaves: [
              createLeaf({ technicalKey: 'leaf' }),
            ],
          }),
          createNode({ technicalKey: 'wrapper', isLeafWrapper: true, leaves: [
              createLeaf({ technicalKey: 'leafWrapped' }),
            ],
          }),
        ],
        nodesPosition: [['BDDF'],[],['wrapper'],[]],
        hiddenNodes: {},
        templateName: '',
      } );
      const state = hierarchyReducer( undefined, action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        openLeaves: ['BDDF', 'wrapper', 'leafWrapped'],
      }));
    });

  });

  describe('GET_NODES_SUCCESS', () => {

    it('should save the nodes in the state', () => {
      const action = new GetNodesSuccess( [ createNode({}), ] );
      const state = hierarchyReducer( undefined, action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        nodes: [ createNode({}), ],
      }));
    });

  });

  describe('PULL_HIERARCHY_ERROR', () => {

    it('should save the error message in the state', () => {
      const action = new PullHierarchyrError( { error: new Error('error message') } );
      const state = hierarchyReducer( undefined, action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        hierarchyError: 'error message',
      }));
    });

  });

  describe('GET_HIERARCHY_ERROR', () => {

    it('should save the error message in the state', () => {
      const action = new GetHierarchyError( { error: new Error('error message') } );
      const state = hierarchyReducer( undefined, action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        hierarchyError: 'error message',
      }));
    });

  });

  describe('GET_USER_ERROR', () => {

    it('should save the error message in the state', () => {
      const action = new GetUserError( { error: new Error('error message') } );
      const state = hierarchyReducer( undefined, action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        hierarchyError: 'error message',
      }));
    });

  });

  describe('GET_LEAF_DETAIL_ERROR', () => {

    it('should save the error message in the state', () => {
      const action = new GetLeafDetailError( { error: new Error('error message') } );
      const state = hierarchyReducer( undefined, action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        hierarchyError: 'error message',
      }));
    });

  });

  describe('GET_LEAVES_SUCCESS', () => {

    it('should save the leaves in the state', () => {
      const action = new GetLeavesSuccess( [ createLeaf() ] );
      const state = hierarchyReducer( undefined, action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        leaves: [ createLeaf() ],
      }));
    });

  });

  describe('INIT_PULLER_SUCCESS', () => {

    it('should save the init puller success in the state', () => {
      const action = new InitPullerSuccess( true );
      const state = hierarchyReducer( undefined, action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        isPullerLaunched: true,
      }));
    });

  });

  describe('SET_OPEN_LEAVES', () => {

    it('should add the open leaves in the state if they are not already present', () => {
      const action = new SetOpenLeaves( ['leaf'] );
      const state = hierarchyReducer( getState({ openLeaves: [] }), action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        openLeaves: ['leaf'],
      }));
    });

    it('should remove the open leaves in the state if they are already present', () => {
      const action = new SetOpenLeaves( ['leaf'] );
      const state = hierarchyReducer( getState({ openLeaves: ['leaf'] }), action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        openLeaves: [],
      }));
    })

    it('should not remove the open leaves in the state if they are already present and the fromAutoComplete flag is true', () => {
      const action = new SetOpenLeaves( ['leaf'], true );
      const state = hierarchyReducer( getState({ openLeaves: ['leaf'] }), action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        openLeaves: ['leaf'],
      }));
    })

  });

  describe('SET_INDICATORS_PERCENT', () => {

    it('should save the percent in the state', () => {
      const action = new SetIndicatorsPercents( {
        availibiltyPercent: 1,
        performancePercent: 2,
        riskPercent: 3,
        feelingPercent: 4,
      } );
      const state = hierarchyReducer( undefined, action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        availibiltyPercent: 1,
        performancePercent: 2,
        riskPercent: 3,
        feelingPercent: 4,
      }));
    });

    it('should check for NaN values', () => {
      const action = new SetIndicatorsPercents( {
        availibiltyPercent: NaN,
        performancePercent: NaN,
        riskPercent: NaN,
        feelingPercent: NaN,
      } );
      const state = hierarchyReducer( undefined, action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        availibiltyPercent: undefined,
        performancePercent: undefined,
        riskPercent: undefined,
        feelingPercent: undefined,
      }));
    })

  });

  describe('TOGGLE_IS_SUPERVISING', () => {

    it('should toggle the supervising state', () => {
      {
        const action = new ToggleIsSupervising();
        const state = hierarchyReducer( getState({ isSupervising: false }), action );

        expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
          isSupervising: true,
        }));
      }
      {
        const action = new ToggleIsSupervising();
        const state = hierarchyReducer( getState({ isSupervising: true }), action );

        expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
          isSupervising: false,
        }));
      }
    });

    it('should save the supervising state if the overload is set', () => {
      {
        const action = new ToggleIsSupervising( true );
        const state = hierarchyReducer( getState({ isSupervising: false }), action );

        expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
          isSupervising: true,
        }));
      }
      {
        const action = new ToggleIsSupervising( false );
        const state = hierarchyReducer( getState({ isSupervising: false }), action );

        expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
          isSupervising: false,
        }));
      }
    })

  });

  describe('LOADING', () => {

    it('should save the loading state', () => {
      {
        const action = new Loading( 1, 2 );
        const state = hierarchyReducer( undefined, action );

        expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
          progressLoaded: 1,
          progressTotal: 2,
        }));
      }
      {
        const action = new Loading( 1 );
        const state = hierarchyReducer( undefined, action );

        expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
          progressLoaded: 1,
          progressTotal: Infinity,
        }));
      }
    });

  });

  describe('READY', () => {

    it('should save the ready state', () => {
      const action = new Ready( true );
      const state = hierarchyReducer( getState({ ready: false }), action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        ready: true
      }));
    });

  });

  describe('HIDE_NODE_FROM_TREE', () => {

    it('should hide a node in the tree and add it to the hidden nodes array', () => {
      const action = new HideNodeFromTree( 'node' );
      const state = hierarchyReducer( getState({
        nodes: [ createNode({ technicalKey: 'node' }) ],
        hiddenNodes: {},
      }), action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        nodes: [ createNode({ technicalKey: 'node', isHiddenOnTree: true }) ],
        hiddenNodes: { node: ['node'] },
      }));
    });

  });

  describe('ADD_NODE', () => {

    describe('from root', () => {

      it('should do nothing if moving a leaf', () => {
        const action = new AddNode( {
          node: createLeaf(),
          offset: 0,
        } );
        const state = hierarchyReducer( undefined, action );

        expect(state).toEqual(hierarchyState);
      })

      describe('to root', () => {

        it('should move', () => {
          { // different column
            const node = createNode({ technicalKey: 'node' });
            const action = new AddNode( {
              node: node,
              offset: 0,
              column: 1,
            } );
            const state = hierarchyReducer( getState({
              nodes: [ node ],
              nodesPosition: [ ['node'],[],[],[] ],
              openLeaves: [],
            }), action );

            expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
              nodes: [ createNode({ technicalKey: 'node' }) ],
              nodesPosition: [ [],['node'],[],[] ],
              openLeaves: [],
            }));
          }
          { // same column, lower offset
            const node = createNode({ technicalKey: 'node' });
            const action = new AddNode( {
              node: node,
              offset: 0,
              column: 0,
            } );
            const state = hierarchyReducer( getState({
              nodes: [ node ],
              nodesPosition: [ ['foo', 'node'],[],[],[] ],
              openLeaves: [],
            }), action );

            expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
              nodes: [ createNode({ technicalKey: 'node' }) ],
              nodesPosition: [ ['node', 'foo'],[],[],[] ],
              openLeaves: [],
            }));
          }
          { // same column, higher offset
            const node = createNode({ technicalKey: 'node' });
            const action = new AddNode( {
              node: node,
              offset: 2,
              column: 0,
            } );
            const state = hierarchyReducer( getState({
              nodes: [ node ],
              nodesPosition: [ ['node', 'foo'],[],[],[] ],
              openLeaves: [],
            }), action );

            expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
              nodes: [ createNode({ technicalKey: 'node' }) ],
              nodesPosition: [ ['foo', 'node'],[],[],[] ],
              openLeaves: [],
            }));
          }
        })

        it('should preserve the open state', () => {
          {
            const node = createNode({ technicalKey: 'node' });
            const action = new AddNode( {
              node: node,
              offset: 0,
              column: 1,
            } );
            const state = hierarchyReducer( getState({
              nodes: [ node ],
              nodesPosition: [ ['node'],[],[],[] ],
              openLeaves: [],
            }), action );

            expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
              nodes: [ createNode({ technicalKey: 'node' }) ],
              nodesPosition: [ [],['node'],[],[] ],
              openLeaves: [],
            }));
          }
          {
            const node = createNode({ technicalKey: 'node' });
            const action = new AddNode( {
              node: node,
              offset: 0,
              column: 1,
            } );
            const state = hierarchyReducer( getState({
              nodes: [ node ],
              nodesPosition: [ ['node'],[],[],[] ],
              openLeaves: ['node'],
            }), action );

            expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
              nodes: [ createNode({ technicalKey: 'node' }) ],
              nodesPosition: [ [],['node'],[],[] ],
              openLeaves: ['node'],
            }));
          }
        })

        it('should add the node if not present', () => {
          const action = new AddNode( {
            node: createNode({ technicalKey: 'node' }),
            offset: 0,
            column: 1,
          } );
          const state = hierarchyReducer( getState({
            nodes: [],
            nodesPosition: [ [],[],[],[] ],
            openLeaves: [],
          }), action );

          expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
            nodes: [ createNode({ technicalKey: 'node' }) ],
            nodesPosition: [ [],['node'],[],[] ],
            openLeaves: [],
          }));
        })

      })

      describe('to tree', () => {

        describe('from readonly', () => {

          it('should copy', () => {
            const parent = createNode({ technicalKey: 'foo' });
            const node = createNode({ technicalKey: 'node', readOnly: true });
            const clone = createNode({ technicalKey: 'clone' });

            spyOn(Node, 'clone').and.returnValue( clone );
            const action = new AddNode( {
              node,
              offset: 0,
              parent,
            } );
            const state = hierarchyReducer( getState({
              nodes: [
                node,
                parent,
              ],
              nodesPosition: [ ['node', 'foo'],[],[],[] ],
              openLeaves: [],
            }), action );

            expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
              nodes: [
                createNode({ technicalKey: 'node', readOnly: true }),
                createNode({ technicalKey: 'foo', nodes: [ createNode({ technicalKey: 'clone' }) ] })
              ],
              nodesPosition: [ ['node', 'foo'],[],[],[] ],
              openLeaves: [],
            }));
          })

        })

        describe('from user', () => {

          it('should move', () => {
            const parent = createNode({ technicalKey: 'foo' });
            const node = createNode({ technicalKey: 'node' });

            const action = new AddNode( {
              node,
              offset: 0,
              parent,
            } );
            const state = hierarchyReducer( getState({
              nodes: [
                node,
                parent,
              ],
              nodesPosition: [ ['node', 'foo'],[],[],[] ],
              openLeaves: [],
            }), action );

            expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
              nodes: [
                createNode({ technicalKey: 'foo', nodes: [ createNode({ technicalKey: 'node' }) ] })
              ],
              nodesPosition: [ ['foo'],[],[],[] ],
              openLeaves: [],
            }));
          })

        })

      })

    })

    describe('from tree', () => {

      describe('from readonly', () => {

        describe('to root', () => {

          it('should copy node', () => {
            const node = createNode({ technicalKey: 'node', readOnly: true });
            const root = createNode({ technicalKey: 'root', readOnly: true, nodes: [ node ] });
            const clone = createNode({ technicalKey: 'clone' });

            spyOn(Node, 'clone').and.returnValue( clone );
            const action = new AddNode( {
              node,
              offset: 0,
              column: 0,
            } );
            const state = hierarchyReducer( getState({
              nodes: [
                root
              ],
              nodesPosition: [ ['root'],[],[],[] ],
              openLeaves: [],
            }), action );

            expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
              nodes: [
                createNode({ technicalKey: 'root', readOnly: true, nodes: [ createNode({ technicalKey: 'node', readOnly: true }) ] }),
                createNode({ technicalKey: 'clone' }),
              ],
              nodesPosition: [ ['clone', 'root'],[],[],[] ],
              openLeaves: ['clone'],
            }));
          })

          it('should copy leaf and wrap it in a node', () => {
            const leaf = createLeaf({ technicalKey: 'leaf', readOnly: true });
            const root = createNode({ technicalKey: 'root', readOnly: true, leaves: [ leaf ] });
            const clone = createLeaf({ technicalKey: 'clone' });

            spyOn(Leaf, 'clone').and.returnValue( clone );
            spyOn(Node, 'randomKey').and.returnValue( 'wrapper' );
            const action = new AddNode( {
              node: leaf,
              offset: 0,
              column: 0,
            } );
            const state = hierarchyReducer( getState({
              nodes: [
                root
              ],
              nodesPosition: [ ['root'],[],[],[] ],
              openLeaves: [],
            }), action );

            expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
              nodes: [
                createNode({ technicalKey: 'root', readOnly: true, leaves: [ createLeaf({ technicalKey: 'leaf', readOnly: true }) ] }),
                createNode({ technicalKey: 'wrapper', key: 'wrapper', isLeafWrapper: true, leaves: [ createLeaf({ technicalKey: 'clone' }) ] }),
              ],
              nodesPosition: [ ['wrapper', 'root'],[],[],[] ],
              openLeaves: ['clone', 'wrapper'],
            }));
          })
        })

        describe('to tree', () => {

          it('should copy node', () => {
            const node = createNode({ technicalKey: 'node', readOnly: true });
            const root = createNode({ technicalKey: 'root', readOnly: true, nodes: [ node ] });
            const clone = createNode({ technicalKey: 'clone' });
            const parent = createNode({ technicalKey: 'user' });

            spyOn(Node, 'clone').and.returnValue( clone );
            const action = new AddNode( {
              node,
              offset: 0,
              parent,
            } );
            const state = hierarchyReducer( getState({
              nodes: [
                root,
                parent
              ],
              nodesPosition: [ ['root'],['user'],[],[] ],
              openLeaves: [],
            }), action );

            expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
              nodes: [
                createNode({ technicalKey: 'root', readOnly: true, nodes: [ createNode({ technicalKey: 'node', readOnly: true }) ] }),
                createNode({ technicalKey: 'user', nodes: [ createNode({ technicalKey: 'clone' }) ] }),
              ],
              nodesPosition: [ ['root'],['user'],[],[] ],
              openLeaves: [],
            }));
          })

          it('should copy leaf', () => {
            const leaf = createLeaf({ technicalKey: 'leaf', readOnly: true });
            const root = createNode({ technicalKey: 'root', readOnly: true, leaves: [ leaf ] });
            const clone = createLeaf({ technicalKey: 'clone' });
            const parent = createNode({ technicalKey: 'user' });

            spyOn(Leaf, 'clone').and.returnValue( clone );
            const action = new AddNode( {
              node: leaf,
              offset: 0,
              parent,
            } );
            const state = hierarchyReducer( getState({
              nodes: [
                root,
                parent
              ],
              nodesPosition: [ ['root'],['user'],[],[] ],
              openLeaves: [],
            }), action );

            expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
              nodes: [
                createNode({ technicalKey: 'root', readOnly: true, leaves: [ createLeaf({ technicalKey: 'leaf', readOnly: true }) ] }),
                createNode({ technicalKey: 'user', leaves: [ createLeaf({ technicalKey: 'clone' }) ] }),
              ],
              nodesPosition: [ ['root'],['user'],[],[] ],
              openLeaves: [],
            }));
          })

        })

      })

      describe('from user', () => {

        describe('to root', () => {

          it('should move node', () => {
            const node = createNode({ technicalKey: 'node', });
            const root = createNode({ technicalKey: 'root', nodes: [ node ] });

            const action = new AddNode( {
              node,
              offset: 0,
              column: 0,
            } );
            const state = hierarchyReducer( getState({
              nodes: [
                root
              ],
              nodesPosition: [ ['root'],[],[],[] ],
              openLeaves: [],
            }), action );

            expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
              nodes: [
                createNode({ technicalKey: 'root' }),
                createNode({ technicalKey: 'node' }),
              ],
              nodesPosition: [ ['node', 'root'],[],[],[] ],
              openLeaves: ['node'],
            }));
          })

          it('should move leaf and wrap it in a node', () => {
            const leaf = createLeaf({ technicalKey: 'leaf', });
            const root = createNode({ technicalKey: 'root', leaves: [ leaf ] });

            spyOn(Node, 'randomKey').and.returnValue( 'wrapper' );
            const action = new AddNode( {
              node: leaf,
              offset: 0,
              column: 0,
            } );
            const state = hierarchyReducer( getState({
              nodes: [
                root
              ],
              nodesPosition: [ ['root'],[],[],[] ],
              openLeaves: [],
            }), action );

            expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
              nodes: [
                createNode({ technicalKey: 'root' }),
                createNode({ technicalKey: 'wrapper', key: 'wrapper', isLeafWrapper: true, leaves: [ createLeaf({ technicalKey: 'leaf', }) ] }),
              ],
              nodesPosition: [ ['wrapper', 'root'],[],[],[] ],
              openLeaves: ['leaf', 'wrapper'],
            }));
          })

        })

        describe('to tree', () => {

          it('should move node', () => {
            { // different parent
              const node = createNode({ technicalKey: 'node' });
              const root = createNode({ technicalKey: 'root', nodes: [ node ] });
              const parent = createNode({ technicalKey: 'user' });

              const action = new AddNode( {
                node,
                offset: 0,
                parent,
              } );
              const state = hierarchyReducer( getState({
                nodes: [
                  root,
                  parent
                ],
                nodesPosition: [ ['root'],['user'],[],[] ],
                openLeaves: [],
              }), action );

              expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
                nodes: [
                  createNode({ technicalKey: 'root', }),
                  createNode({ technicalKey: 'user', nodes: [ createNode({ technicalKey: 'node' }) ] }),
                ],
                nodesPosition: [ ['root'],['user'],[],[] ],
                openLeaves: [],
              }));
            }
            { // same parent, lower offset
              const node = createNode({ technicalKey: 'node' });
              const root = createNode({ technicalKey: 'root', nodes: [ createNode({ technicalKey: 'sibling' }), node ] });

              const action = new AddNode( {
                node,
                offset: 0,
                parent: root,
              } );
              const state = hierarchyReducer( getState({
                nodes: [
                  root,
                ],
                nodesPosition: [ ['root'],[],[],[] ],
                openLeaves: [],
              }), action );

              expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
                nodes: [
                  createNode({ technicalKey: 'root', nodes: [ createNode({ technicalKey: 'node' }), createNode({ technicalKey: 'sibling' }) ], }),
                ],
                nodesPosition: [ ['root'],[],[],[] ],
                openLeaves: [],
              }));
            }
            { // same parent, higher offset
              const node = createNode({ technicalKey: 'node' });
              const root = createNode({ technicalKey: 'root', nodes: [ node, createNode({ technicalKey: 'sibling' }) ] });

              const action = new AddNode( {
                node,
                offset: 2,
                parent: root,
              } );
              const state = hierarchyReducer( getState({
                nodes: [
                  root,
                ],
                nodesPosition: [ ['root'],[],[],[] ],
                openLeaves: [],
              }), action );

              expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
                nodes: [
                  createNode({ technicalKey: 'root', nodes: [ createNode({ technicalKey: 'sibling' }), createNode({ technicalKey: 'node' }) ], }),
                ],
                nodesPosition: [ ['root'],[],[],[] ],
                openLeaves: [],
              }));
            }
          })

          it('should move leaf', () => {
            { // different parent
              const leaf = createLeaf({ technicalKey: 'leaf' });
              const root = createNode({ technicalKey: 'root', leaves: [ leaf ] });
              const parent = createNode({ technicalKey: 'user' });

              const action = new AddNode( {
                node: leaf,
                offset: 0,
                parent,
              } );
              const state = hierarchyReducer( getState({
                nodes: [
                  root,
                  parent
                ],
                nodesPosition: [ ['root'],['user'],[],[] ],
                openLeaves: [],
              }), action );

              expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
                nodes: [
                  createNode({ technicalKey: 'root', }),
                  createNode({ technicalKey: 'user', leaves: [ createLeaf({ technicalKey: 'leaf' }) ] }),
                ],
                nodesPosition: [ ['root'],['user'],[],[] ],
                openLeaves: [],
              }));
            }
            { // same parent, lower offset
              const leaf = createLeaf({ technicalKey: 'node' });
              const root = createNode({ technicalKey: 'root', leaves: [ leaf ] });

              const action = new AddNode( {
                node: leaf,
                offset: 0,
                parent: root,
              } );
              const state = hierarchyReducer( getState({
                nodes: [
                  root,
                ],
                nodesPosition: [ ['root'],[],[],[] ],
                openLeaves: [],
              }), action );

              expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
                nodes: [
                  createNode({ technicalKey: 'root', leaves: [ createLeaf({ technicalKey: 'node' }) ], }),
                ],
                nodesPosition: [ ['root'],[],[],[] ],
                openLeaves: [],
              }));
            }
            { // same parent, higher offset
              const leaf = createLeaf({ technicalKey: 'node' });
              const root = createNode({ technicalKey: 'root', leaves: [ leaf ] });

              const action = new AddNode( {
                node: leaf,
                offset: 1,
                parent: root,
              } );
              const state = hierarchyReducer( getState({
                nodes: [
                  root,
                ],
                nodesPosition: [ ['root'],[],[],[] ],
                openLeaves: [],
              }), action );

              expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
                nodes: [
                  createNode({ technicalKey: 'root', leaves: [ createLeaf({ technicalKey: 'node' }) ], }),
                ],
                nodesPosition: [ ['root'],[],[],[] ],
                openLeaves: [],
              }));
            }
          })

        })

        it('should remove the emptyleafwrapper left after moving its leaf', () => {
          const leaf = createLeaf({ technicalKey: 'leaf' });
          const wrapper = createNode({ technicalKey: 'wrapper', isLeafWrapper: true, leaves: [ leaf ] });
          const parent = createNode({ technicalKey: 'user' });

          const action = new AddNode( {
            node: leaf,
            offset: 0,
            parent,
          } );
          const state = hierarchyReducer( getState({
            nodes: [
              wrapper,
              parent
            ],
            nodesPosition: [ ['wrapper'],['user'],[],[] ],
            openLeaves: [],
          }), action );

          expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
            nodes: [
              createNode({ technicalKey: 'user', leaves: [ createLeaf({ technicalKey: 'leaf' }) ] }),
            ],
            nodesPosition: [ [],['user'],[],[] ],
            openLeaves: [],
          }));
        })

      })

    })

  });

  describe('START_RENAME_NODE', () => {

    it('should save the renamed node in the state', () => {
      const action = new StartRenameNode( { node: createNode({ technicalKey: 'node' }) } );
      const state = hierarchyReducer( undefined, action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        renamedNode: 'node',
      }));
    });

  });

  describe('RENAME_NODE', () => {

    it('should do nothing if not finding the node', () => {
      const node = createNode({ technicalKey: 'foo', isNew: true });
      const action = new RenameNode( { node, name: 'node' } );
      const state = hierarchyReducer( undefined , action );

      expect(state).toBe(hierarchyState);
    });

    it('should replace the node with a renamed one', () => {
      {
        const node = createNode({ technicalKey: 'foo', isNew: true });
        const action = new RenameNode( { node, name: 'node' } );
        const state = hierarchyReducer( getState({
          nodes: [ node ],
          openLeaves: [],
          renamedNode: 'foo',
        }), action );

        expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
          nodes: [ createNode({ technicalKey: 'foo', name: 'node', isNew: false, fullname: '' }) ],
          openLeaves: ['foo'],
          renamedNode: '',
        }));
        expect(state.nodes[0]).not.toBe(node);
      }
      {
        const node = createNode({ technicalKey: 'foo', isNew: true });
        const root = createNode({ technicalKey: 'root', nodes: [ node ] });
        const action = new RenameNode( { node, name: 'node' } );
        const state = hierarchyReducer( getState({
          nodes: [ root ],
          openLeaves: [],
          renamedNode: 'foo',
        }), action );

        expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
          nodes: [ createNode({ technicalKey: 'root', nodes: [ createNode({ technicalKey: 'foo', name: 'node', isNew: false, fullname: '' }) ] }) ],
          openLeaves: ['foo'],
          renamedNode: '',
        }));
        expect(state.nodes[0].nodes[0]).not.toBe(node);
      }
    });

    it('should update the parent of the renamed node childs', () => {
      const node = createNode({ technicalKey: 'foo', isNew: true, nodes: [ createNode() ], leaves: [ createLeaf() ] });
      const action = new RenameNode( { node, name: 'node' } );
      const state = hierarchyReducer( getState({
        nodes: [ node ],
      }), action );

      expect(state.nodes[0].nodes[0].parent).toBe(state.nodes[0]);
      expect(state.nodes[0].leaves[0].parent).toBe(state.nodes[0]);
    })

  });

  describe('RENAME_LEAF', () => {

    it('should replace the leaf with a renamed one', () => {
      const leaf = createLeaf({ technicalKey: 'foo' });
      const root = createNode({ technicalKey: 'root', leaves: [ leaf ] });
      const action = new RenameLeaf( { node: leaf, name: 'leaf' } );
      const state = hierarchyReducer( getState({
        nodes: [ root ],
        openLeaves: [],
        renamedNode: 'foo',
      }), action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        nodes: [ createNode({ technicalKey: 'root', leaves: [ createLeaf({ technicalKey: 'foo', name: 'leaf', fullname: '' }) ] }) ],
        openLeaves: ['foo'],
        renamedNode: '',
      }));
      expect(state.nodes[0].leaves[0]).not.toBe(leaf);
    });

  });

  describe('DELETE_NODE', () => {

    it('should remove root node', () => {
      const node = createNode({ technicalKey: 'root' });
      const action = new DeleteNode( { node } );
      const state = hierarchyReducer( getState({
        nodes: [ node ],
        openLeaves: ['root'],
        nodesPosition: [['root'],[],[],[]],
      }), action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        nodes: [],
        openLeaves: [],
        nodesPosition: [[],[],[],[]],
      }));
    });

    it('should not remove root leaf', () => {
      const leaf = createLeaf({ technicalKey: 'leaf' });
      const action = new DeleteNode( { node: leaf } );
      const state = hierarchyReducer( undefined, action );

      expect(state).toBe(hierarchyState);
    })

    it('should remove flying leaf', () => {
      const leaf = createLeaf({ technicalKey: 'leaf' });
      const node = createNode({ technicalKey: 'wrapper', isLeafWrapper: true, leaves: [ leaf ] });
      const action = new DeleteNode( { node: leaf } );
      const state = hierarchyReducer( getState({
        nodes: [ node ],
        openLeaves: ['wrapper'],
        nodesPosition: [['wrapper'],[],[],[]],
      }), action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        nodes: [],
        openLeaves: [],
        nodesPosition: [[],[],[],[]],
      }));
    })

    it('should remove tree node', () => {
      const node = createNode({ technicalKey: 'node' });
      const root = createNode({ technicalKey: 'root', nodes: [ node ] });
      const action = new DeleteNode( { node } );
      const state = hierarchyReducer( getState({
        nodes: [ root ],
        openLeaves: ['root'],
        nodesPosition: [['root'],[],[],[]],
      }), action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        nodes: [ createNode({ technicalKey: 'root', nodes: [] }) ],
        openLeaves: ['root'],
        nodesPosition: [['root'],[],[],[]],
      }));
    })

    it('should remove tree leaf', () => {
      const leaf = createLeaf({ technicalKey: 'node' });
      const root = createNode({ technicalKey: 'root', leaves: [ leaf ] });
      const action = new DeleteNode( { node: leaf } );
      const state = hierarchyReducer( getState({
        nodes: [ root ],
        openLeaves: ['root'],
        nodesPosition: [['root'],[],[],[]],
      }), action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        nodes: [ createNode({ technicalKey: 'root', leaves: [] }) ],
        openLeaves: ['root'],
        nodesPosition: [['root'],[],[],[]],
      }));
    })

    it('should not remove readonly nodes', () => {
      const node = createNode({ technicalKey: 'root', readOnly: true });
      const action = new DeleteNode( { node } );
      const state = hierarchyReducer( getState({
        nodes: [ node ],
        openLeaves: ['root'],
        nodesPosition: [['root'],[],[],[]],
      }), action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        nodes: [ createNode({ technicalKey: 'root', readOnly: true }) ],
        openLeaves: ['root'],
        nodesPosition: [['root'],[],[],[]],
      }));
    })

  });

  describe('UPDATE_LAST_RESTORE', () => {

    it('should update the state lastRestore', () => {
      jasmine.clock().install();
      jasmine.clock().mockDate( new Date(2000, 6, 15) );

      const spy = spyOn(localStorage, 'setItem')
      const action = new UpdateLastRestore();
      const state = hierarchyReducer( getState({
        lastRestore: new Date(2000, 6, 10).getTime(),
      }), action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        lastRestore: new Date(2000, 6, 15).getTime(),
      }));
      expect(spy).toHaveBeenCalled();

      jasmine.clock().uninstall();
    });

  });

  describe('GET_LEAF_DETAIL_SUCCESS', () => {

    it('should save the leaf details in the state', () => {
      const action = new GetLeafDetailSuccess( { leaf: createLeaf() } );
      const state = hierarchyReducer( getState({
        leafDetail: null,
      }), action );

      expect(state).toEqual(jasmine.objectContaining<HierarchyState>({
        leafDetail: createLeaf(),
      }));
    });

  });

} );
