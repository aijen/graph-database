import merge from 'lodash/merge';
import { Leaf } from 'shared/models/leaf.model';
import { Node } from 'shared/models/node.model';
import { HierarchyState } from '../hierarchy.model';
import { hierarchyState } from '../hierarchy.reducer';
import { getAvailabilityPercent, getFeelingPercent, getFlattenHierarchy, getHierarchyError, getIsSupervising, getLastRestore, getLeafDetail, getLeaves, getLeavesKeys, getNodeByKey, getNodes, getNodesPosition, getOpenLeaves, getPerformancePercent, getPositionedNodes, getProgress, getProgressLoaded, getProgressTotal, getReady, getRenamedNodeKey, getRiskPercent, isPullerLaunched } from '../hierarchy.selectors';

describe('Hierarchy Selectors', () => {

  const createNode = ( node?: Partial<Node>, options: { asObject?: boolean, skipUpdateChildrenParent?: boolean } = {} ): Node => {
    const newNode = merge(new Node, { isNew: false, ...node });
    if(!options.skipUpdateChildrenParent) {
      newNode.nodes.forEach( child => child.parent = newNode);
      newNode.leaves.forEach( child => child.parent = newNode);
    }
    return options.asObject ? { ...newNode } : newNode;
  }
  const createLeaf = ( leaf?: Partial<Leaf> ): Leaf => merge(new Leaf, leaf);
  function getState( partialState: DeepPartial<HierarchyState> = {} ) {
    return merge({}, hierarchyState, partialState);
  }

  describe('getNodes', () => {

    it('should return the nodes', () => {
      expect(getNodes.projector(getState())).toEqual([])
    })

  })

  describe('getNodesPosition', () => {

    it('should return the nodes position', () => {
      expect(getNodesPosition.projector(getState())).toEqual([[],[],[],[]])
    })

  })

  describe('getLeaves', () => {

    it('should return the leaves', () => {
      expect(getLeaves.projector(getState())).toEqual([])
    })

  })

  describe('getOpenLeaves', () => {

    it('should return the open leaves', () => {
      expect(getOpenLeaves.projector(getState())).toEqual([])
    })

  })

  describe('isPullerLaunched', () => {

    it('should return the isPullerLaunched state', () => {
      expect(isPullerLaunched.projector(getState())).toEqual(false)
    })

  })

  describe('getAvailabilityPercent', () => {

    it('should return the availibility percent', () => {
      expect(getAvailabilityPercent.projector(getState())).toEqual(-1)
    })

  })

  describe('getPerformancePercent', () => {

    it('should return the performance percent', () => {
      expect(getPerformancePercent.projector(getState())).toEqual(-1)
    })

  })

  describe('getRiskPercent', () => {

    it('should return the risk percent', () => {
      expect(getRiskPercent.projector(getState())).toEqual(-1)
    })

  })

  describe('getFeelingPercent', () => {

    it('should return the feeling percent', () => {
      expect(getFeelingPercent.projector(getState())).toEqual(-1)
    })

  })

  describe('getIsSupervising', () => {

    it('should return the supervising state', () => {
      expect(getIsSupervising.projector(getState())).toEqual(false)
    })

  })

  describe('getProgressLoaded', () => {

    it('should return the progress loaded', () => {
      expect(getProgressLoaded.projector(getState())).toEqual(0)
    })

  })

  describe('getProgressTotal', () => {

    it('should return the progress total', () => {
      expect(getProgressTotal.projector(getState())).toEqual(Infinity)
    })

  })

  describe('getProgress', () => {

    it('should return the progress', () => {
      expect(getProgress.projector(0, Infinity)).toEqual({ loaded: 0, total: Infinity, progress: 0 })
      expect(getProgress.projector(5, 10)).toEqual({ loaded: 5, total: 10, progress: 0.5 })
    })

  })

  describe('getReady', () => {

    it('should return the ready state', () => {
      expect(getReady.projector(getState())).toEqual(false)
    })

  })

  describe('getHierarchyError', () => {

    it('should return the hierarchy error', () => {
      expect(getHierarchyError.projector(getState())).toEqual(null)
    })

  })

  describe('getNodeByKey', () => {

    it('should return a node by its key', () => {
      {
        expect(getNodeByKey.projector([], '')).toEqual(undefined)
      }
      {
        expect(getNodeByKey.projector([
          createNode({ key: 'node' })
        ], 'node')).toEqual(createNode({ key: 'node' }))
      }
      {
        const node = createNode({ key: 'node' })
        expect(getNodeByKey.projector([
          createNode({ key: 'parent', nodes: [ node ] })
        ], 'node')).toBe(node)
      }
    })

    it('should return a leaf by its key', () => {
      {
        const leaf = createLeaf({ key: 'leaf' })
        expect(getNodeByKey.projector([
          createNode({ key: 'parent', leaves: [ leaf ] })
        ], 'leaf')).toBe(leaf)
      }
      {
        const leaf = createLeaf({ key: 'leaf' })
        expect(getNodeByKey.projector([
          createNode({ key: 'grandparent', nodes: [ createNode({ key: 'parent', leaves: [ leaf ] }) ] })
        ], 'leaf')).toBe(leaf)
      }
    })

  })

  describe('getPositionedNodes', () => {

    it('should return an empty array if nodes is empty', () => {
      const nodes = []
      const nodesPosition = [[],[],[],[]]
      const supervising = false
      const expected = []
      expect(getPositionedNodes.projector( nodes, nodesPosition, supervising )).toEqual(expected)
    })

    it('should return the positioned nodes if not supervising', () => {
      const nodes = [
        createNode({ technicalKey: 'node1' }),
        createNode({ technicalKey: 'node2' }),
      ]
      const nodesPosition = [['node1'],['node2'],[],[]]
      const supervising = false
      const expected = [[createNode({ technicalKey: 'node1' })],[createNode({ technicalKey: 'node2' })],[],[]]
      expect(getPositionedNodes.projector( nodes, nodesPosition, supervising )).toEqual(expected)
    })

    it('should ignore unknown nodes', () => {
      const nodes = [
        createNode({ technicalKey: 'node1' }),
        createNode({ technicalKey: 'node2' }),
      ]
      const nodesPosition = [['node1'],['node2'],['unknown'],[]]
      const supervising = false
      const expected = [[createNode({ technicalKey: 'node1' })],[createNode({ technicalKey: 'node2' })],[],[]]
      expect(getPositionedNodes.projector( nodes, nodesPosition, supervising )).toEqual(expected)
    })

    it('should return the readonly root nodes with only the leaf in alerts when supervising', () => {
      const leaf1 = createLeaf({ key: 'leaf1', hasAlert: true })
      const leaf2 = createLeaf({ key: 'leaf2', hasAlert: false })
      const nodes = [
        createNode({ technicalKey: 'node1', readOnly: true, nbAlert: 1,
          nodes: [
            createNode({ technicalKey: 'node5', readOnly: true, nbAlert: 1, leaves: [ leaf1, leaf2 ], }),
            createNode({ technicalKey: 'node4', readOnly: true, nbAlert: 0 }),
          ]
        }),
        createNode({ technicalKey: 'node2', readOnly: true }),
        createNode({ technicalKey: 'node3', readOnly: false }),
      ]
      const nodesPosition = [['node1'],['node2'],[],[]]
      const supervising = true
      const expected = [
        [createNode({ technicalKey: 'node1', readOnly: true, nbAlert: 1, leaves: [ leaf1 ] }, { asObject: true, skipUpdateChildrenParent: true })],
        [createNode({ technicalKey: 'node2', readOnly: true }, { asObject: true })],
      ]
      expect(getPositionedNodes.projector( nodes, nodesPosition, supervising )).toEqual(expected)
    })

    it('should ignore nodespositions and stack the readonly nodes in the first two columns when supervising', () => {
      const nodes = [
        createNode({ technicalKey: 'node1', readOnly: true }),
        createNode({ technicalKey: 'node2', readOnly: true }),
        createNode({ technicalKey: 'node3', readOnly: true }),
      ]
      const nodesPosition = [['node1'],['node2'],[],[]]
      const supervising = true
      const expected = [
        [
          createNode({ technicalKey: 'node1', readOnly: true }, { asObject: true }),
          createNode({ technicalKey: 'node3', readOnly: true }, { asObject: true })
        ],
        [createNode({ technicalKey: 'node2', readOnly: true }, { asObject: true })],
      ]
      expect(getPositionedNodes.projector( nodes, nodesPosition, supervising )).toEqual(expected)
    })

    it('should regroup the leaves in alert of the user tree in the first empty column available when supervising', () => {
      const leaf1 = createLeaf({ key: 'leaf1', hasAlert: true });
      const leaf2 = createLeaf({ key: 'leaf2', hasAlert: false });
      const leaf3 = createLeaf({ key: 'leaf3', hasAlert: true });
      const nodes = [
        createNode({ technicalKey: 'node1', readOnly: false, nbAlert: 1, leaves: [ leaf2, leaf1 ] }),
        createNode({ technicalKey: 'node2', readOnly: false, nbAlert: 1, leaves: [ leaf3 ] }),
        createNode({ technicalKey: 'node3', readOnly: false, nbAlert: 0 }),
      ]
      const nodesPosition = [['node1'],['node2'],[],[]]
      const supervising = true
      const expected = [
        [
          createNode({ technicalKey: 'Liste Personnalisée', key: 'Liste Personnalisée', name: 'Liste Personnalisée', leaves: [leaf1, leaf3] }, { asObject: true, skipUpdateChildrenParent: true }),
        ],
      ]
      expect(getPositionedNodes.projector( nodes, nodesPosition, supervising )).toEqual(expected)
    })

  })

  describe('getLastRestore', () => {

    it('should return the progress', () => {
      expect(getLastRestore.projector(getState({ lastRestore: 12345 }))).toEqual( 12345 )
    })

  })

  describe('getRenamedNodeKey', () => {

    it('should return the renamed node key', () => {
      expect(getRenamedNodeKey.projector(getState({ renamedNode: 'key' }))).toEqual( 'key' )
    })

  })

  describe('getFlattenHierarchy', () => {

    it('should return a one dimension array of all the nodes and leaves with a fullname or a name', () => {
      const leaf1 = createLeaf({ name: 'leaf1' })
      const innerNode = createNode({ name: 'innerNode', leaves: [ leaf1 ] })
      const rootNode = createNode({ name: 'rootNode', nodes: [ innerNode ] })
      const nonameNode = createNode()
      const nodes = [
        rootNode,
        nonameNode,
      ]
      const expected = jasmine.arrayWithExactContents([
        leaf1,
        innerNode,
        rootNode,
      ])

      const result = getFlattenHierarchy.projector(nodes)
      expect(result).toEqual( expected )
    })

  })

  describe('getLeafDetail', () => {

    it('should return the leaf detail', () => {
      expect(getLeafDetail.projector(getState({ leafDetail: createLeaf({ key: 'leaf' }) }))).toEqual( createLeaf({ key: 'leaf' }) )
    })

  })

  describe('getLeavesKeys', () => {

    it('should return all visible leaf keys', () => {
      const nodes =  [
        createNode({
          leaves: [
            createLeaf({ key: 'visibleLeaf' }),
            createLeaf({ key: 'hiddenLeaf', isHiddenOnTree: true })
          ],
        }),
        createNode({
          isHiddenOnTree: true,
          leaves: [
            createLeaf({ key: 'hiddenByParentLeaf' }),
          ]
        }),
      ]
      const expected = ['visibleLeaf']

      expect( getLeavesKeys.projector(nodes) ).toEqual(expected)
    })

  })

} );
