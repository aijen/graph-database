import { HttpErrorResponse } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { fakeAsync, TestBed, tick } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { ApiNodesService } from 'core/services/api/api.nodes';
import { HierarchyService } from 'core/services/hierarchy/hierarchy.service';
import { LEAVES_METAS_URL } from 'core/services/http/http-client.service';
import { PopulatedMetasValue } from 'core/store/populated-metas/populated-metas.model';
import { PopulatedMetasService } from 'core/store/populated-metas/populated-metas.service';
import { SnoozeConfig } from 'core/store/snooze/snooze.model';
import { SnoozeService } from 'core/store/snooze/snooze.service';
import merge from 'lodash/merge';
import { configureTestSuite } from 'ng-bullet';
import { Observable, of, throwError } from 'rxjs';
import { marbles } from 'rxjs-marbles/jasmine';
import { switchMap, take, tap } from 'rxjs/operators';
import { Leaf } from 'shared/models/leaf.model';
import { Node } from 'shared/models/node.model';
import { AppState } from 'shared/models/state.model';
import { AddNode, DeleteNode, GetCockpitLeaves, GetHierarchy, GetHierarchyError, GetHierarchySuccess, GetLeafDetail, GetLeafDetailError, GetLeafDetailSuccess, GetLeavesSuccess, GetNodes, GetNodesSuccess, HideNodeFromTree, InitPuller, InitPullerSuccess, PullHierarchy, PullHierarchyrError, Ready, RenameNode, RestoreDefaultsNodes, SaveNodes, SetIndicatorsPercents, SetTemplateName, UpdateLastRestore } from '../hierarchy.actions';
import { HierarchyEffects } from '../hierarchy.effects';
import { HierarchyState, IndicatorsPercent, NODE_KEYS_POSITION } from '../hierarchy.model';

describe('HierarchyEffects', () => {
  let service: HierarchyEffects;
  let httpTestingController: HttpTestingController;
  let actions: Observable<any>;
  let config$: Observable<SnoozeConfig>;
  let populatedMetas$: Observable<PopulatedMetasValue[]>;
  let apiNodesService: jasmine.SpyObj<ApiNodesService>;
  let hierarchyService: jasmine.SpyObj<HierarchyService>;
  let populatedMetasService: jasmine.SpyObj<PopulatedMetasService>;
  let store: MockStore<Partial<AppState>>;
  const initialState = { hierarchy: new HierarchyState() };

  function setPartialState( partialState: DeepPartial<AppState> ) {
    const state = merge({}, initialState, partialState);
    store.setState(state);
    return state;
  }

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
      ],
      providers: [
        HierarchyEffects,
        provideMockStore<Partial<AppState>>({ initialState }),
        provideMockActions(() => actions),
        { provide: HierarchyService, useFactory: () => jasmine.createSpyObj('HierarchyService', ['resetComputedMetadataLeaf', 'resetComputedMetadata', 'hideNodeOnTree', 'getLeavesKeys', 'extractLeavesKeysFromNode', 'populateLeaves', 'populateLeavesFromNode', 'populateMetas', 'populateMetasFromNode', 'computeBarsInfosForAllMetaTypesAndAll', 'getLeavesUrl', 'checkIsAlert', 'setLeafFirstTimeKOByMetaType', 'checkAvailiblity', 'checkPerformance', 'checkRisk', 'checkFeeling', 'calculatePercents', 'calculateNodesAlerts', 'calculateNodeAlerts', 'sortMetaByDateDesc'] as Array<keyof HierarchyService>) },
        { provide: ApiNodesService, useFactory: () => jasmine.createSpyObj('ApiNodesService', ['getNodes', 'getUserNodes', 'saveNodes', 'getLeavesByGivenCriteria', 'hideNodeFromTree', 'restoreDefaultsNodes'] as Array<keyof ApiNodesService>) },
        { provide: PopulatedMetasService, useFactory: () => ({ populatedMetas$: of(null).pipe( switchMap( () => populatedMetas$) ) }) },
        { provide: SnoozeService, useFactory: () => ({ config$: of(null).pipe( switchMap( () => config$) ) }) },
      ],
    })
  });

  beforeEach( () => {
    store = TestBed.get(Store);
    apiNodesService = TestBed.get(ApiNodesService);
    hierarchyService = TestBed.get(HierarchyService);
    populatedMetasService = TestBed.get(PopulatedMetasService);
    service = TestBed.get(HierarchyEffects);
    httpTestingController = TestBed.get(HttpTestingController);
  } );

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  describe('GetHierarchy$', () => {

    it('should dispatch a GetHierarchySuccess Action with the user nodes', marbles(m => {
      const nodes = [];
      const nodesPosition = [[],[],[],[]] as NODE_KEYS_POSITION;
      const hiddenNodes = {};
      const templateName = '';
      apiNodesService.getUserNodes.and.returnValue( of({ nodes, nodesPosition, hiddenNodes, templateName }) );

      actions =        m.hot('a', { a: new GetHierarchy });
      const expected = m.hot('a', { a: new GetHierarchySuccess( { nodes, nodesPosition, hiddenNodes, templateName } ) });

      m.expect(service.GetHierarchy$).toBeObservable(expected);
    }));

    it('should try 3 times before failing and dispatching an error Action', marbles(m => {
      const error = new Error();
      const spy = jasmine.createSpy('subscribeSpy', () => throwError(error));
      const subscribeSpy = of(null).pipe( switchMap( spy ) );
      apiNodesService.getUserNodes.and.returnValue( subscribeSpy );

      actions =        m.hot('a', { a: new GetHierarchy });
      const expected = m.hot('20s (a|)', { a: new GetHierarchyError( {error} ) });
      const completeExpectation = tap( () => expect(spy).toHaveBeenCalledTimes(3) );

      m.expect(service.GetHierarchy$.pipe( completeExpectation )).toBeObservable(expected);
    }));

  });

  describe('GetHierarchySuccess', () => {

    it('should dispatch a PullHierachy Action every minutes', marbles(m => {
      const nodes = [];
      const nodesPosition = [[],[],[],[]] as NODE_KEYS_POSITION;
      const hiddenNodes = {};
      const templateName = '';
      hierarchyService.getLeavesKeys.and.returnValue([]);

      actions =        m.hot('a',    { a: new GetHierarchySuccess( { nodes, nodesPosition, hiddenNodes, templateName } ) });
      const expected = m.hot('(hil)', { h: new PullHierarchy( { periodTime: 300, leaves: '' } ), i: new InitPuller, l: new GetCockpitLeaves() });

      m.expect( service.GetHierarchySuccess ).toBeObservable(expected);
    }));

    it('should dispatch a PullHierachy Action every minutes (cont.)', marbles(m => {
      hierarchyService.getLeavesKeys.and.returnValue([]);

      actions =        m.hot('i',         { i: new InitPuller });
      const expected = m.hot('60s (hs|)', { h: new PullHierarchy( { periodTime: 300, leaves: '' } ), s: new InitPullerSuccess(true) });

      m.expect( service.InitPuller.pipe( take( 2 ) ) ).toBeObservable(expected);
    }));

    it('should dispatch a PullHierachy Action every minutes (cont.)', marbles(m => {
      hierarchyService.getLeavesKeys.and.returnValue([]);
      setPartialState({ hierarchy: { isPullerLaunched: true } });

      actions =        m.hot('i',                    { i: new InitPuller });
      const expected = m.hot('60s h 999ms 59s (h|)', { h: new PullHierarchy( { periodTime: 300, leaves: '' } ) });

      m.expect( service.InitPuller.pipe( take( 2 ) ) ).toBeObservable(expected);
    }));

  });

  describe('PullHierachy', () => {

    it('should dispatch a GetNodes Action with the leaves and snoozeconfig', () => {
      hierarchyService.getLeavesUrl.and.returnValue(LEAVES_METAS_URL);
      actions = of(new PullHierarchy( { periodTime: 300, leaves: '' } ));
      config$ = of({ leaves: {} });
      populatedMetas$ = of([]);
      const spy = jasmine.createSpy('subscribe');
      const dispatch = spyOn(store, 'dispatch');

      const sub = service.PullHierachy.subscribe(spy);
      httpTestingController.expectOne(LEAVES_METAS_URL).flush([]);

      expect(dispatch).toHaveBeenCalled();
      expect(dispatch.calls.allArgs()).toEqual( [ [ new Ready(true) ] ] );
      expect(spy).toHaveBeenCalled();
      expect(spy.calls.allArgs()).toEqual( [ [ new GetNodes({leaves: [], config: { leaves: {} }, populatedMetas: []}) ] ] );

      sub.unsubscribe();
    });

    it('should try 3 times before failing and dispatching an error Action', fakeAsync(() => {
      hierarchyService.getLeavesUrl.and.returnValue(LEAVES_METAS_URL);
      actions = of(new PullHierarchy( { periodTime: 300, leaves: '' } ));
      config$ = of({ leaves: {} });
      populatedMetas$ = of([]);
      const spy = jasmine.createSpy('subscribe');

      const sub = service.PullHierachy.subscribe(spy);
      httpTestingController.expectOne(LEAVES_METAS_URL).flush(null, new HttpErrorResponse({ status: 500 }));
      tick(10000);
      httpTestingController.expectOne(LEAVES_METAS_URL).flush(null, new HttpErrorResponse({ status: 500 }));
      tick(10000);
      httpTestingController.expectOne(LEAVES_METAS_URL).flush(null, new HttpErrorResponse({ status: 500 }));

      expect(spy).toHaveBeenCalled();
      expect(spy.calls.mostRecent().args[0]).toEqual( jasmine.any(PullHierarchyrError) );

      sub.unsubscribe();
    }));

  });

  describe('GetNodes', () => {

    it('should populate and update the hierarchy with the leaves data', marbles(m => {
      hierarchyService.populateMetas.and.returnValue([]);
      hierarchyService.calculatePercents.and.returnValue({});

      actions =        m.hot('a', { a: new GetNodes( { leaves: [], config: { leaves: {} }, populatedMetas: [] } ) });
      const expected = m.hot('(abc)', {
        a: new GetNodesSuccess( [] ),
        b: new GetLeavesSuccess( [] ),
        c: new SetIndicatorsPercents( {} as IndicatorsPercent ),
      });
      const completeExpectation = tap( () => {
        expect(hierarchyService.populateMetas).toHaveBeenCalled();
        expect(hierarchyService.calculateNodesAlerts).toHaveBeenCalled();
        expect(hierarchyService.calculatePercents).toHaveBeenCalled();
      });

      m.expect(service.GetNodes.pipe( completeExpectation )).toBeObservable(expected);
    }));

  });

  describe('HideNodeBackend', () => {

    it('should call the webservice for hiding a node', () => {
      actions = of(new HideNodeFromTree(''));
      apiNodesService.hideNodeFromTree.and.returnValue(of());
      const sub = service.HideNodeBackend.subscribe();

      expect(apiNodesService.hideNodeFromTree).toHaveBeenCalled();

      sub.unsubscribe();
    });

  });

  describe('HideNode', () => {

    it('should populate and update the hierarchy with the leaves data', marbles(m => {
      config$ = of({ leaves: {} });
      hierarchyService.populateMetas.and.returnValue([]);
      hierarchyService.calculatePercents.and.returnValue({});

      actions = m.hot('a', { a: new HideNodeFromTree('') });
      const expected = m.hot('(abcd)', {
        a: new UpdateLastRestore(),
        b: new GetNodesSuccess([]),
        c: new GetLeavesSuccess([]),
        d: new SetIndicatorsPercents({} as IndicatorsPercent),
      });

      m.expect(service.HideNode).toBeObservable(expected)
    }));

  });

  describe('RestoreDefaultsNodes', () => {

    it('should call the webservice for restoring a node', marbles(m => {
      apiNodesService.restoreDefaultsNodes.and.returnValue(of(null));

      actions =        m.hot('a', { a: new RestoreDefaultsNodes('') });
      const expected = m.hot('(abc)', {
        a: new UpdateLastRestore(),
        b: new Ready(false),
        c: new GetHierarchy(),
      });
      const completeExpectation = tap( () => {
        expect(apiNodesService.restoreDefaultsNodes).toHaveBeenCalled();
      });

      m.expect(service.RestoreDefaultsNodes.pipe( completeExpectation )).toBeObservable(expected);
    }));

  });

  describe('saveNodesOnHierarchyChange$', () => {

    it('should dispatch a SetTemplateName ans a SaveNodes Action on hierarchy change', marbles(m => {
      const expected = m.hot('(ab)(ab)(ab)(ab)', { a: new SetTemplateName({ templateName: '' }), b: new SaveNodes });
      actions =        m.hot('a-b-c-d-e---f', {
        a: new RenameNode( { node: new Node(), name: '' } ),
        b: new AddNode( { node: new Node(), offset: 0 } ),
        c: new AddNode( { node: new Node( { isNew: false} ), offset: 0 } ),
        d: new DeleteNode( { node: new Node() } ),
        e: new DeleteNode( { node: new Node( { isNew: false} ) } ),
        f: new DeleteNode( { node: new Leaf } ),
      });

      m.expect(service.saveNodesOnHierarchyChange$).toBeObservable(expected);
    }));

  });

  describe('saveNodes$', () => {

    it('should update the hierarchy', () => {
      config$ = of({ leaves: {} });
      apiNodesService.saveNodes.and.returnValue(of());
      actions = of(new SaveNodes);
      const sub = service.saveNodes$.subscribe();

      expect(hierarchyService.calculateNodesAlerts).toHaveBeenCalled();
      expect(hierarchyService.calculatePercents).toHaveBeenCalled();

      sub.unsubscribe()
    });

    it('should call the webservice for saving the hierarchy', marbles(m => {
      config$ = of({ leaves: {} });
      apiNodesService.saveNodes.and.returnValue(of(null));
      actions = m.hot('a', { a: new SaveNodes });
      const expected = m.hot('(ab)', {
        a: new SetIndicatorsPercents(undefined),
        b: new UpdateLastRestore(),
      });

      m.expect(service.saveNodes$).toBeObservable(expected);
    }));

    it('should not complete on error', marbles(m => {
      config$ = of({ leaves: {} });
      apiNodesService.saveNodes.and.returnValue(throwError(new Error()));
      actions = m.hot('a', { a: new SaveNodes });
      const expected = m.hot('a', {
        a: new SetIndicatorsPercents(undefined),
      });

      m.expect(service.saveNodes$).toBeObservable(expected);
    }));

  });

  describe('getLeafDetail', () => {

    it('should dispatch a GetLeafDetailSuccess Action with the provided leaf details', marbles(m => {
      apiNodesService.getLeavesByGivenCriteria.and.returnValue(of([new Leaf]));
      actions = m.hot('a', { a: new GetLeafDetail({ from: 0, to: 0, leaf: '' }) });
      const expected = m.hot('a', {
        a: new GetLeafDetailSuccess({ leaf: new Leaf })
      });

      m.expect(service.getLeafDetail).toBeObservable(expected);
    }));

    it('should dispatch a GetLeafDetailSuccess Action with the provided leaf details (cont.)', marbles(m => {
      apiNodesService.getLeavesByGivenCriteria.and.returnValue(of([]));
      actions = m.hot('a', { a: new GetLeafDetail({ from: 0, to: 0, leaf: '' }) });
      const expected = m.hot('a', {
        a: new GetLeafDetailSuccess({ leaf: null })
      });

      m.expect(service.getLeafDetail).toBeObservable(expected);
    }));

    it('should dispatch an error Action on failing', marbles(m => {
      apiNodesService.getLeavesByGivenCriteria.and.returnValue(throwError(new Error()));
      actions = m.hot('a', { a: new GetLeafDetail({ from: 0, to: 0, leaf: '' }) });
      const expected = m.hot('(a)', {
        a: new GetLeafDetailError({ error: new Error() })
      });

      m.expect(service.getLeafDetail).toBeObservable(expected);
    }));

  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
