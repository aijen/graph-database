import {HierarchyService} from 'core/services/hierarchy/hierarchy.service';
import flatten from 'lodash/flatten';
import uniqBy from 'lodash/uniqBy';
import {Leaf} from 'shared/models/leaf.model';
import {Node} from 'shared/models/node.model';
import {GET_USER_ERROR, GetUserError} from '../auth/auth.actions';
import {HierarchyActionsUnion, HierarchyActionTypes} from './hierarchy.actions';
import {HierarchyState, NODE_KEYS_POSITION, PIT_LAST_RESTORE_KEY} from './hierarchy.model';
import {TreeService} from './tree.service';

export const hierarchyState: HierarchyState = new HierarchyState();

export function hierarchyReducer(
  state: HierarchyState = hierarchyState,
  action: HierarchyActionsUnion | GetUserError
): HierarchyState {
  switch (action.type) {
    case HierarchyActionTypes.GET_HIERARCHY_SUCCESS: {
      let { nodes, nodesPosition = state.nodesPosition, hiddenNodes = {}, templateName = '' } = action.payload;
      /* remove duplicates from nodes (because sometimes, shit happens) */
      nodes = uniqBy( nodes, ({ technicalKey }) =>  technicalKey)

      /* clean nodesPosition from non-existing node technicalKey */
      nodesPosition = nodesPosition.map( column => column.filter( technicalKey => nodes.some( node => node.technicalKey === technicalKey ) ) ) as NODE_KEYS_POSITION;

      const flatPositions = flatten(nodesPosition);
      const readonlyNodes = nodes.filter( node => node.readOnly );
      /** readonly nodes without a position */
      const orphanReadonlyNodes = readonlyNodes.filter( readonlyNode => !flatPositions.includes( readonlyNode.technicalKey ) );
      const userNodes = nodes.filter( node => !node.readOnly );
      /** user nodes without a position */
      const orphanUserNodes = userNodes.filter( userNode => !flatPositions.includes( userNode.technicalKey ) );

      /* remove user nodes without a position from the nodes */
      if( orphanUserNodes.length ) nodes = nodes.filter( node => !orphanUserNodes.includes( node ) );

      /* add readonly nodes without a position to nodesPosition at the first available space not occupied by a readonly node */
      {
        let line = 0;
        const findNode = ( key: string ) => nodes.find( node => node.technicalKey === key );
        while( orphanReadonlyNodes.length ) {
          for( let column = 0; column < nodesPosition.length; column++) {
            const key = nodesPosition[column][line];
            if( key ) {
              const node = findNode( key );
              if( node && node.readOnly ) continue;
            }
            const inserted = orphanReadonlyNodes.shift();
            nodesPosition[column].splice( line, 0, inserted.technicalKey );
            if( !orphanReadonlyNodes.length ) break;
          }
          line++;
        }
      }

      const leafWrappersKeys = nodes.filter( node => node.isLeafWrapper ).reduce( (acc, node) => [...acc, node.leaves[0].technicalKey], [] );
      const rootNodesKeys = nodes.map( node => node.technicalKey );
      const openLeaves = [ ...rootNodesKeys, ...leafWrappersKeys ];

      return {
        ...state,
        nodes,
        hiddenNodes,
        nodesPosition,
        openLeaves,
        templateName,
      };
    }
    case HierarchyActionTypes.GET_NODES_SUCCESS: {
      const nodes = action.payload;
      return {
        ...state,
        nodes,
      };
    }
    case HierarchyActionTypes.PULL_HIERARCHY_ERROR:
    case HierarchyActionTypes.GET_HIERARCHY_ERROR:
    case GET_USER_ERROR:
    case HierarchyActionTypes.GET_LEAF_DETAIL_ERROR:
    case HierarchyActionTypes.GET_COCKPIT_LEAVES_ERROR:
      return {
        ...state,
        hierarchyError: action.payload.error.message,
      }
    case HierarchyActionTypes.GET_LEAVES_SUCCESS:
      return {
        ...state,
        leaves: action.payload
      };
    case HierarchyActionTypes.INIT_PULLER_SUCCESS:
      return {
        ...state,
        isPullerLaunched: action.payload
      };
    case HierarchyActionTypes.SET_OPEN_LEAVES: {

      const openLeaves = Object.assign([], state.openLeaves);

      action.payload.forEach(lf => {
        const leafIndex = openLeaves.indexOf(lf);

        if (leafIndex === -1) {
          openLeaves.push(lf);
        } else {
          if (!action.fromAutoComplete) {
            openLeaves.splice(leafIndex, 1);
          }
        }
      });
      return {
        ...state,
        openLeaves: openLeaves,
      };
    }
    case HierarchyActionTypes.CLOSE_LEAVES:{
      let openLeaves = Object.assign([], state.openLeaves);
      let technicalKeys = HierarchyService.recursiveFindTechnicalKeys(action.payload, Object.assign([]));
      openLeaves = openLeaves.filter(leaf => !technicalKeys.includes(leaf));

      return  {
        ...state,
        openLeaves: openLeaves
      }
    }
    case HierarchyActionTypes.SET_INDICATORS_PERCENT:
      return {
        ...state,
        availibiltyPercent: isNaN(action.payload.availibiltyPercent)
          ? undefined
          : action.payload.availibiltyPercent,
        performancePercent: isNaN(action.payload.performancePercent)
          ? undefined
          : action.payload.performancePercent,
        riskPercent: isNaN(action.payload.riskPercent)
          ? undefined
          : action.payload.riskPercent,
        feelingPercent: isNaN(action.payload.feelingPercent)
          ? undefined
          : action.payload.feelingPercent
      };
    case HierarchyActionTypes.TOGGLE_IS_SUPERVISING:
      return {
        ...state,
        isSupervising: action.payload === undefined ? !state.isSupervising : action.payload,
      };
    case HierarchyActionTypes.LOADING:
      return {
        ...state,
        progressLoaded: action.loaded,
        progressTotal: action.total,
      };
    case HierarchyActionTypes.READY:
      return {
        ...state,
        ready: action.payload,
      };
    case HierarchyActionTypes.HIDE_NODE_FROM_TREE:
      const technicalKey = action.payload;
      const rootNode = technicalKey.split('|')[0];
      const { hiddenNodes } = state;

      hiddenNodes[rootNode] = hiddenNodes[rootNode] ? hiddenNodes[rootNode].concat(technicalKey) : [technicalKey];

      return {
        ...state,
        hiddenNodes,
        nodes: HierarchyService.hideNodeOnTree(state.nodes.slice(0), action.payload),
      }
    case HierarchyActionTypes.ADD_NODE: {

      const { parent, offset, column: columnIndex } = action.payload;
      const { node: oldNode } = action.payload;
      const oldParent = oldNode.parent;
      const fromRoot = !oldParent;
      const toRoot = !parent;
      const fromReadonly = oldNode.readOnly;

      if( fromRoot ) {
        if( Leaf.isLeaf( oldNode ) ) return state;
        if( toRoot ) {
          /* move root to root */

          // find old location
          let {fromColumn, fromOffset} = TreeService.findRoot( state, oldNode ); // tslint:disable-line: prefer-const
          const { openLeaves } = state;

          // remove old location
          state = TreeService.removeRoot( state, oldNode, fromColumn, fromOffset );

          // adjust old location if inserting in same column
          let adjust = 0;
          if( fromColumn === columnIndex ) {
            if( offset > fromOffset ) adjust -= 1;
          }

          // insert new location
          state = TreeService.addRoot( state, oldNode, columnIndex, offset + adjust );
          state.openLeaves = openLeaves;

        } else {

          if( fromReadonly ) {
            /* copy root to tree */

            const newNode = TreeService.clone( oldNode, parent );
            TreeService.addTree( newNode, offset, parent );
          } else {
            /* move root to tree */

            // find old location
            const {fromColumn, fromOffset} = TreeService.findRoot( state, oldNode );

            // remove old location
            state = TreeService.removeRoot( state, oldNode, fromColumn, fromOffset );

            TreeService.addTree( oldNode, offset, parent );
          }

        }

      } else {

        if( fromReadonly ) {
          const newNode = TreeService.clone( oldNode, parent );
          if( toRoot ) {
            /* copy tree to root */
            state = TreeService.addRoot( state, newNode, columnIndex, offset );
          } else {
            /* copy tree to tree */
            TreeService.addTree( newNode, offset, parent);
          }
        } else {

          if( toRoot ) {
            /* move tree to root */

            TreeService.removeTree( oldNode, oldParent );
            state = TreeService.addRoot( state, oldNode, columnIndex, offset );

          } else {
            /* move tree to tree */
            let adjust = 0;
            if( oldNode.parent === parent ) {
              const fromIndex = Node.isNode( oldNode ) ? oldNode.parent.nodes.indexOf( oldNode ) : oldNode.parent.leaves.indexOf( oldNode );
              if( offset > fromIndex ) adjust -= 1;
            }

            TreeService.removeTree( oldNode, oldParent );
            TreeService.addTree( oldNode, offset + adjust, parent);
          }

          if( Leaf.isLeaf( oldNode ) && oldParent.isLeafWrapper ) {
            const {fromColumn, fromOffset} = TreeService.findRoot( state, oldParent );

            // remove old location
            state = TreeService.removeRoot(state, oldParent, fromColumn, fromOffset);
          }

        }

      }

      return {...state};
    }
    case HierarchyActionTypes.START_RENAME_NODE: {
      const { node } = action.payload;

      return {
        ...state,
        renamedNode: node.technicalKey,
      };
    }
    // TODO : Refactor with RENAME_LEAF
    case HierarchyActionTypes.RENAME_NODE: {
      const { node: oldNode, name } = action.payload;
      const newNode = Object.assign(new Node(), oldNode, {
        name,
        fullname: '',
        isNew: false,
      });

      const newState = {
        ...state
      };

      const parent = oldNode.parent ? oldNode.parent : newState;
      const nodes = parent.nodes;
      const nodeIndex = nodes.indexOf(oldNode);
      if(nodeIndex === -1) return state;

      parent.nodes = [ ...nodes.slice(0, nodeIndex), newNode, ...nodes.slice(nodeIndex + 1) ];

      for( const childNode of newNode.nodes )  { childNode.parent = newNode; }
      for( const childLeaf of newNode.leaves ) { childLeaf.parent = newNode; }

      newState.openLeaves = [ ...newState.openLeaves, newNode.technicalKey ];
      newState.renamedNode = '';

      return newState;
    }
    // TODO : Refactor with RENAME_NODE
    case HierarchyActionTypes.RENAME_LEAF: {
      const { node: oldLeaf, name } = action.payload;
      const newLeaf = Object.assign(new Leaf(), oldLeaf, {
        name,
        fullname: '',
      });

      state = {
        ...state
      };

      const parent = oldLeaf.parent;
      const leaves = parent.leaves;
      const leafIndex = leaves.indexOf(oldLeaf);

      parent.leaves = [ ...leaves.slice(0, leafIndex), newLeaf, ...leaves.slice(leafIndex + 1) ];

      state.openLeaves = [ ...state.openLeaves, newLeaf.technicalKey ];
      state.renamedNode = '';

      return state;
    }
    case HierarchyActionTypes.DELETE_NODE: {
      const { node } = action.payload;
      if( node.readOnly ) return state;

      const fromRoot = !node.parent;

      if( fromRoot ) {
        if( Leaf.isLeaf( node ) ) return state; // cannot remove leaves from root (as they are always wrapped in a node). this is merely here for typescript type hinting.
        const {fromColumn, fromOffset} = TreeService.findRoot(state, node);
        state = TreeService.removeRoot(state, node, fromColumn, fromOffset);
      } else {
        if( Leaf.isLeaf( node ) && node.parent.isLeafWrapper ) { // while removing a leaf, if it's wrapped in a LeafWrapper, we assume the leafWrapper is at the root level.
          const {fromColumn, fromOffset} = TreeService.findRoot( state, node.parent );

          // remove old location
          state = TreeService.removeRoot(state, node.parent, fromColumn, fromOffset);
        } else {
          TreeService.removeTree(node, node.parent);
        }
      }

      return {...state};
    }
    case HierarchyActionTypes.UPDATE_LAST_RESTORE:
      const lastRestore = Date.now();
      localStorage.setItem( PIT_LAST_RESTORE_KEY, lastRestore.toString() );
      return {
        ...state,
        lastRestore
      }
    case HierarchyActionTypes.GET_LEAF_DETAIL_SUCCESS: {
      return {
        ...state,
        leafDetail: action.payload.leaf
      }
    }

    case HierarchyActionTypes.GET_COCKPIT_LEAVES_SUCCESS: {
      const { cockpitLeaves } = action.payload;

      return {
        ...state,
        cockpitLeaves,
      };
    }

    case HierarchyActionTypes.SET_TEMPLATE_NAME: {
      const { templateName } = action.payload;

      return {
        ...state,
        templateName,
      };
    }

    default:
      return state;
  }
}
