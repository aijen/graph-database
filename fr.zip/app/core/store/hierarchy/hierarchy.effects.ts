import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { ApiNodesService } from 'core/services/api/api.nodes';
import { HierarchyService } from 'core/services/hierarchy/hierarchy.service';
import { INTERVAL, PULLER_INTERVAL } from 'core/services/http/http-client.service';
import { GetCockpitLeaves, GetCockpitLeavesError, GetCockpitLeavesSuccess, Ready, SetTemplateName } from 'core/store/hierarchy/hierarchy.actions';
import { SnoozeService } from 'core/store/snooze/snooze.service';
import { retryStrategy } from 'core/utils/retryStrategy';
import { combineLatest, concat, merge, of } from 'rxjs';
import { TimerObservable } from 'rxjs/observable/TimerObservable';
import { catchError, concatMap, filter, map, mapTo, retryWhen, switchMap, switchMapTo, tap, withLatestFrom } from 'rxjs/operators';
import { Leaf, LeafDTO } from 'shared/models/leaf.model';
import { Node } from 'shared/models/node.model';
import { AppState } from 'shared/models/state.model';
import { PopulatedMetasService } from '../populated-metas/populated-metas.service';
import { AddNode, DeleteNode, GetHierarchy, GetHierarchyError, GetHierarchySuccess, GetLeafDetail, GetLeafDetailError, GetLeafDetailSuccess, GetLeavesSuccess, GetNodes, GetNodesSuccess, HideNodeFromTree, HierarchyActionsUnion, HierarchyActionTypes, InitPuller, InitPullerSuccess, PullHierarchy, PullHierarchyrError, RenameLeaf, RenameNode, RestoreDefaultsNodes, SaveNodes, SetIndicatorsPercents, UpdateLastRestore } from './hierarchy.actions';
import { HierarchyState } from './hierarchy.model';
import { getHierarchyState } from './hierarchy.selectors';


@Injectable({ providedIn: 'root' })
export class HierarchyEffects {

  hierarchyState$ = this.store$.select(getHierarchyState);

  @Effect()
  GetHierarchy$ = this.actions$.pipe(
    ofType<GetHierarchy>(HierarchyActionTypes.GET_HIERARCHY),
    switchMap(() => this.apiNodesService.getUserNodes().pipe(retryWhen(retryStrategy()))),
    map(({ nodes, nodesPosition, hiddenNodes, templateName }) => new GetHierarchySuccess({ nodes: Node.fromJSONCollection(nodes), nodesPosition, hiddenNodes, templateName })),
    catchError((error: Error) =>
      of(new GetHierarchyError({ error }))
    )
  );

  // get leaves and metas, init puller
  @Effect()
  GetHierarchySuccess = this.actions$.pipe(
    ofType<GetHierarchySuccess>(HierarchyActionTypes.GET_HIERARCHY_SUCCESS),
    withLatestFrom(this.hierarchyState$),
    concatMap(([, state]) => ([
      new PullHierarchy({ periodTime: 300, leaves: this.hierarchyService.getLeavesKeys(state.nodes).join(',') }),
      new InitPuller(),
      new GetCockpitLeaves(),
    ])),
  );

  @Effect()
  InitPuller = this.actions$.pipe(
    ofType<InitPuller>(HierarchyActionTypes.INIT_PULLER),
    switchMap(() => {
      return TimerObservable.create(PULLER_INTERVAL, INTERVAL).pipe(
        withLatestFrom(this.hierarchyState$),
        concatMap(([, state]) => {
          const actions: HierarchyActionsUnion[] = [
            new PullHierarchy({ periodTime: 300, leaves: this.hierarchyService.getLeavesKeys(state.nodes).join(',') })
          ];

          if (!state.isPullerLaunched) {
            actions.push(new InitPullerSuccess(true));
          }

          return actions;
        })
      );
    }),
  );

  @Effect()
  PullHierachy = this.actions$.pipe(
    ofType<PullHierarchy>(HierarchyActionTypes.PULL_HIERARCHY),
    map(({ payload: { periodTime, leaves } }) => this.hierarchyService.getLeavesUrl(leaves, periodTime)),
    switchMap(leavesUrl =>
      combineLatest(
        this.httpClient.get<LeafDTO[]>(leavesUrl).pipe(
          retryWhen(retryStrategy()),
          map((leaves) => Leaf.fromJSONCollection(leaves)),
        ),
        this.snoozeService.config$,
        this.populatedMetasService.populatedMetas$,
      )
    ),
    tap(() => this.store$.dispatch(new Ready(true))),
    map(([leaves, config, populatedMetas]) => new GetNodes({ leaves, config, populatedMetas })),
    catchError((error: Error) => {
      console.log(HierarchyActionTypes.PULL_HIERARCHY_ERROR + ': ', error);
      return of(new PullHierarchyrError({ error }));
    })
  );

  // affect leaves and metas to nodes
  @Effect()
  GetNodes = this.actions$.pipe(
    ofType<GetNodes>(HierarchyActionTypes.GET_NODES),
    withLatestFrom(this.hierarchyState$),
    map(([{ payload: { leaves, config, populatedMetas } }, { nodes }]: [GetNodes, HierarchyState]) => ({
      nodes,
      leaves,
      config,
      populatedMetas,
    })),
    concatMap(({ nodes, leaves, config, populatedMetas }) => {
      const nds = this.hierarchyService.populateMetas(nodes, leaves, config, populatedMetas);
      this.hierarchyService.calculateNodesAlerts(nodes, config);
      const percent = this.hierarchyService.calculatePercents(nodes);
      return [
        new GetNodesSuccess(nds),
        new GetLeavesSuccess(leaves),
        new SetIndicatorsPercents(percent),
      ];
    }),
  );

  @Effect({ dispatch: false })
  HideNodeBackend = this.actions$.pipe(
    ofType<HideNodeFromTree>(HierarchyActionTypes.HIDE_NODE_FROM_TREE),
    switchMap(action => this.apiNodesService.hideNodeFromTree(action.payload)),
  );

  @Effect()
  HideNode = this.actions$.pipe(
    ofType<HideNodeFromTree>(HierarchyActionTypes.HIDE_NODE_FROM_TREE),
    switchMapTo(
      combineLatest(
        this.snoozeService.config$,
        this.populatedMetasService.populatedMetas$,
      )
    ),
    withLatestFrom(this.hierarchyState$),
    concatMap(([[config, populatedMeta], state]) => {
      const { nodes, leaves } = state;
      const nds = this.hierarchyService.populateMetas(nodes, leaves, config, populatedMeta);
      this.hierarchyService.calculateNodesAlerts(nodes, config);
      const percent = this.hierarchyService.calculatePercents(nodes);
      return [
        new UpdateLastRestore(),
        new GetNodesSuccess(nds),
        new GetLeavesSuccess(leaves),
        new SetIndicatorsPercents(percent),
      ]
    })
  );

  @Effect()
  RestoreDefaultsNodes = this.actions$.pipe(
    ofType<RestoreDefaultsNodes>(HierarchyActionTypes.RESTORE_DEFAULTS_NODES),
    switchMap(action => this.apiNodesService.restoreDefaultsNodes(action.payload)),
    concatMap(() => ([
      new UpdateLastRestore(),
      new Ready(false),
      new GetHierarchy(),
    ]))
  )

  @Effect()
  saveNodesOnHierarchyChange$ = this.actions$.pipe(
    ofType<AddNode | DeleteNode | RenameNode | RenameLeaf>(HierarchyActionTypes.ADD_NODE, HierarchyActionTypes.DELETE_NODE, HierarchyActionTypes.RENAME_NODE, HierarchyActionTypes.RENAME_LEAF),
    filter(({ type, payload: { node } }) => (type === HierarchyActionTypes.RENAME_NODE || type === HierarchyActionTypes.RENAME_LEAF) ? true : Node.isNode(node) ? !node.isNew : true),
    withLatestFrom(this.hierarchyState$),
    concatMap(([action, { templateName }]) => ([
      new SetTemplateName({ templateName: templateName.length === 0 || templateName.charAt(templateName.length - 1) === '*' ? templateName : `${templateName}*` }),
      new SaveNodes(),
    ])),
  );

  @Effect()
  saveNodes$ = this.actions$.pipe(
    ofType<SaveNodes>(HierarchyActionTypes.SAVE_NODES),
    switchMapTo(this.snoozeService.config$),
    withLatestFrom(this.hierarchyState$),
    concatMap(([config, { nodes, nodesPosition, templateName }]) => {
      this.hierarchyService.calculateNodesAlerts(nodes, config);
      const percent = this.hierarchyService.calculatePercents(nodes);
      return merge(
        of(new SetIndicatorsPercents(percent)),
        this.apiNodesService.saveNodes(nodes, nodesPosition, templateName).pipe(mapTo(new UpdateLastRestore())),
      );
    }),
    catchError((error, caught) => caught),
  );

  @Effect()
  getLeafDetail = this.actions$.pipe(
    ofType<GetLeafDetail>(HierarchyActionTypes.GET_LEAF_DETAIL),
    switchMap(({ payload: { from, to, leaf } }) => this.apiNodesService.getLeavesByGivenCriteria(leaf, from, to, 1)),
    map(leaves => leaves && leaves.length > 0 ? leaves[0] : null),
    map(leaf => new GetLeafDetailSuccess({ leaf })),
    catchError((error: Error, caught) => {
      console.log(HierarchyActionTypes.GET_LEAF_DETAIL_ERROR + ': ', error);
      return concat(of(new GetLeafDetailError({ error })), caught);
    })
  );

  @Effect()
  getCockpitLeaves = this.actions$.pipe(
    ofType<GetCockpitLeaves>(HierarchyActionTypes.GET_COCKPIT_LEAVES),
    switchMap(() => this.apiNodesService.getCockpitLeaves()),
    map(cockpitLeaves => new GetCockpitLeavesSuccess({ cockpitLeaves })),
    catchError((error: Error, caught) => {
      console.log(HierarchyActionTypes.GET_COCKPIT_LEAVES_ERROR + ': ', error);
      return concat(of(new GetCockpitLeavesError({ error })), caught);
    })
  );

  constructor(
    private actions$: Actions,
    private store$: Store<AppState>,
    private httpClient: HttpClient,
    private hierarchyService: HierarchyService,
    private apiNodesService: ApiNodesService,
    private snoozeService: SnoozeService,
    private populatedMetasService: PopulatedMetasService,
  ) { }
}
