import { CockpitLeaf } from 'shared/models/cockpit-leaf.model';
import { Leaf } from 'shared/models/leaf.model';
import { Node } from 'shared/models/node.model';

declare module 'shared/models/state.model' {
  export interface AppState {
    readonly hierarchy: HierarchyState;
  }
}

export const PIT_LAST_RESTORE_KEY = 'pit-last-restore';

export interface IndicatorsPercent {
  availibiltyPercent: number;
  performancePercent: number;
  riskPercent: number;
  feelingPercent: number;
}

export type NODE_KEYS_COLUMN = string[];
export type NODE_KEYS_POSITION = [NODE_KEYS_COLUMN, NODE_KEYS_COLUMN, NODE_KEYS_COLUMN, NODE_KEYS_COLUMN];
export type NODES_POSITION = [Node[], Node[], Node[], Node[]];
export type HiddenNodes = { [index:string]: string[] };

export class HierarchyState {
  constructor(
    public nodes: Node[] = [],
    public leaves: Leaf[] = [],
    public openLeaves: string[] = [],
    public isPullerLaunched: boolean = false,
    public availibiltyPercent = -1,
    public performancePercent = -1,
    public riskPercent = -1,
    public feelingPercent = -1,
    public isSupervising = false,
    public progressLoaded = 0,
    public progressTotal = Infinity,
    public ready = false,
    public hierarchyError = null,
    public hiddenNodes: HiddenNodes = {},
    public nodesPosition: NODE_KEYS_POSITION = [[], [], [], []],
    public lastRestore = +localStorage.getItem( PIT_LAST_RESTORE_KEY ),
    public renamedNode = '',
    public templateName = '',
    // TODO: Remove useless var and associated code
    public leafDetail: Leaf = null,
    public cockpitLeaves: CockpitLeaf[] = [],
  ) {
    if( !lastRestore ) {
      this.lastRestore = Date.now();
      localStorage.setItem( PIT_LAST_RESTORE_KEY, this.lastRestore.toString() );
    }
  }
}
