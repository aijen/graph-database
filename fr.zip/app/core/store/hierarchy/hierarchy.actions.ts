import { Action } from '@ngrx/store';
import { SnoozeConfig } from 'core/store/snooze/snooze.model';
import { CockpitLeaf } from 'shared/models/cockpit-leaf.model';
import { Leaf } from 'shared/models/leaf.model';
import { Node } from 'shared/models/node.model';
import { PopulatedMetasValue } from '../populated-metas/populated-metas.model';
import { HiddenNodes, IndicatorsPercent, NODE_KEYS_POSITION } from './hierarchy.model';

export enum HierarchyActionTypes {
  GET_HIERARCHY = '[COCKPIT] Get Hierarchy',
  GET_HIERARCHY_SUCCESS = '[COCKPIT] Get Hierarchy Success',
  GET_HIERARCHY_ERROR = '[COCKPIT] Get Hierarchy Error',
  GET_NODES = '[COCKPIT] Get Nodes',
  GET_NODES_SUCCESS = '[COCKPIT] Get Nodes Success',
  GET_LEAVES_SUCCESS = '[COCKPIT] Get Leaves Success',
  INIT_PULLER = '[COCKPIT] Init Puller',
  INIT_PULLER_SUCCESS = '[COCKPIT] Init Puller Success',
  PULL_HIERARCHY = '[COCKPIT] Pull Hierarchy',
  PULL_HIERARCHY_ERROR = '[COCKPIT] Pull Hierarchy Error',
  GET_LEAF_DETAIL = '[COCKPIT] Get Leaf Detail',
  GET_LEAF_DETAIL_SUCCESS = '[COCKPIT] Get Leaf Detail Success',
  GET_LEAF_DETAIL_ERROR = '[COCKPIT] Get Leaf Detail Error',
  SET_OPEN_LEAVES = '[COCKPIT] Set Opens Leaves',
  CLOSE_LEAVES = '[COCKPIT] Close Opened Leaves',
  SET_INDICATORS_PERCENT = '[COCKPIT] Set Indicators Percent',
  TOGGLE_IS_SUPERVISING = '[CockPit] Set Is Supervising',
  LOADING = '[CockPit] Loading',
  READY = '[CockPit] Ready',
  HIDE_NODE_FROM_TREE = '[CockPit] Hide node from tree',
  RESTORE_DEFAULTS_NODES = '[CockPit] Restore defaults nodes',
  ADD_NODE = '[CockPit] AddNode',
  DELETE_NODE = '[CockPit] DeleteNode',
  START_RENAME_NODE = '[CockPit] StartRenameNode',
  RENAME_NODE = '[CockPit] RenameNode',
  RENAME_LEAF = '[CockPit] RenameLeaf',
  SAVE_NODES = '[CockPit] SaveNodes',
  UPDATE_LAST_RESTORE = '[CockPit] Update Last Restore',
  GET_COCKPIT_LEAVES = '[Cockpit] Get Cockpit Leaves',
  GET_COCKPIT_LEAVES_SUCCESS = '[Cockpit] Get Cockpit Leaves Success',
  GET_COCKPIT_LEAVES_ERROR = '[Cockpit] Get Cockpit Leaves Error',
  SET_TEMPLATE_NAME = '[Cockpit] Set Template Name',
}

export class GetHierarchy implements Action {
  readonly type = HierarchyActionTypes.GET_HIERARCHY;
  constructor() {}
}
export class GetHierarchySuccess implements Action {
  readonly type = HierarchyActionTypes.GET_HIERARCHY_SUCCESS;
  constructor(public payload: { nodes: Node[], nodesPosition: NODE_KEYS_POSITION, hiddenNodes: HiddenNodes, templateName: string }) {}
}

export class GetHierarchyError implements Action {
  readonly type = HierarchyActionTypes.GET_HIERARCHY_ERROR;
  constructor(public payload: { error: Error }) {}
}
export class GetNodes implements Action {
  readonly type = HierarchyActionTypes.GET_NODES;
  constructor(public payload: { leaves: Leaf[], config: SnoozeConfig, populatedMetas: PopulatedMetasValue[] }) {}
}
export class GetNodesSuccess implements Action {
  readonly type = HierarchyActionTypes.GET_NODES_SUCCESS;
  constructor(public payload: Node[]) {}
}

export class GetLeavesSuccess implements Action {
  readonly type = HierarchyActionTypes.GET_LEAVES_SUCCESS;
  constructor(public payload: Leaf[]) {}
}

export class InitPuller implements Action {
  readonly type = HierarchyActionTypes.INIT_PULLER;
}
export class InitPullerSuccess implements Action {
  readonly type = HierarchyActionTypes.INIT_PULLER_SUCCESS;
  constructor(public payload: boolean) {}
}

export class SetOpenLeaves implements Action {
  readonly type = HierarchyActionTypes.SET_OPEN_LEAVES;
  constructor(public payload: string[], public fromAutoComplete = false) {}
}

export class CloseLeaves implements Action {
  readonly type = HierarchyActionTypes.CLOSE_LEAVES;
  constructor(public payload: Node) {}
}

export class SetIndicatorsPercents implements Action {
  readonly type = HierarchyActionTypes.SET_INDICATORS_PERCENT;
  constructor(public payload: IndicatorsPercent) {}
}

export class PullHierarchy implements Action {
  readonly type = HierarchyActionTypes.PULL_HIERARCHY;
  constructor(public payload: {periodTime: number, leaves: string}) {}
}

export class PullHierarchyrError implements Action {
  readonly type = HierarchyActionTypes.PULL_HIERARCHY_ERROR;
  constructor(public payload: { error: Error }) {}
}

export class GetLeafDetail implements Action {
  readonly type = HierarchyActionTypes.GET_LEAF_DETAIL;
  constructor(public payload: {from: number, to: number, leaf: string}) {}
}

export class GetLeafDetailSuccess implements Action {
  readonly type = HierarchyActionTypes.GET_LEAF_DETAIL_SUCCESS;
  constructor(public payload: {leaf: Leaf}) {}
}

export class GetLeafDetailError implements Action {
  readonly type = HierarchyActionTypes.GET_LEAF_DETAIL_ERROR;
  constructor(public payload: { error: Error }) {}
}

export class ToggleIsSupervising implements Action {
  readonly type = HierarchyActionTypes.TOGGLE_IS_SUPERVISING;
  constructor(public payload?: boolean) {}
}

export class Loading implements Action {
  readonly type = HierarchyActionTypes.LOADING;
  constructor(public loaded: number, public total: number = Infinity) {}
}

export class Ready implements Action {
  readonly type = HierarchyActionTypes.READY;
  constructor(public payload: boolean) {}
}

export class HideNodeFromTree implements Action {
  readonly type = HierarchyActionTypes.HIDE_NODE_FROM_TREE;
  constructor(public payload: string) {}
}

export class RestoreDefaultsNodes implements Action {
  readonly type = HierarchyActionTypes.RESTORE_DEFAULTS_NODES;
  constructor(public payload: string) {}
}

export class AddNode implements Action {
  readonly type = HierarchyActionTypes.ADD_NODE;
  constructor(public payload: { node: Node | Leaf, offset: number, parent?: Node, column?: number }) {}
}

export class DeleteNode implements Action {
  readonly type = HierarchyActionTypes.DELETE_NODE;
  constructor(public payload: { node: Node | Leaf }) {}
}

export class StartRenameNode implements Action {
  readonly type = HierarchyActionTypes.START_RENAME_NODE;
  constructor(public payload: { node: Node | Leaf }) {}
}

export class RenameNode implements Action {
  readonly type = HierarchyActionTypes.RENAME_NODE;
  constructor(public payload: { node: Node, name: string }) {}
}

export class RenameLeaf implements Action {
  readonly type = HierarchyActionTypes.RENAME_LEAF;
  constructor(public payload: { node: Leaf, name: string }) {}
}

export class SaveNodes implements Action {
  readonly type = HierarchyActionTypes.SAVE_NODES;
  constructor() {}
}

export class UpdateLastRestore implements Action {
  readonly type = HierarchyActionTypes.UPDATE_LAST_RESTORE;
  constructor() {}
}

export class GetCockpitLeaves implements Action {
  readonly type = HierarchyActionTypes.GET_COCKPIT_LEAVES;
  constructor() {}
}

export class GetCockpitLeavesSuccess implements Action {
  readonly type = HierarchyActionTypes.GET_COCKPIT_LEAVES_SUCCESS;
  constructor(public payload: { cockpitLeaves: CockpitLeaf[] }) {}
}

export class GetCockpitLeavesError implements Action {
  readonly type = HierarchyActionTypes.GET_COCKPIT_LEAVES_ERROR;
  constructor(public payload: { error: Error }) {}
}

export class SetTemplateName implements Action {
  readonly type = HierarchyActionTypes.SET_TEMPLATE_NAME;
  constructor(public payload: { templateName: string }) {}
}

export type HierarchyActionsUnion =
  | GetHierarchy
  | GetHierarchySuccess
  | GetHierarchyError
  | GetNodes
  | GetNodesSuccess
  | GetLeavesSuccess
  | InitPuller
  | InitPullerSuccess
  | PullHierarchy
  | PullHierarchyrError
  | GetLeafDetail
  | GetLeafDetailSuccess
  | GetLeafDetailError
  | SetOpenLeaves
  | CloseLeaves
  | SetIndicatorsPercents
  | ToggleIsSupervising
  | Loading
  | Ready
  | HideNodeFromTree
  | RestoreDefaultsNodes
  | AddNode
  | DeleteNode
  | StartRenameNode
  | RenameNode
  | RenameLeaf
  | SaveNodes
  | UpdateLastRestore
  | GetCockpitLeaves
  | GetCockpitLeavesSuccess
  | GetCockpitLeavesError
  | SetTemplateName
  ;
