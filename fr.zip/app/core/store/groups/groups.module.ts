import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';
import { groupsReducer } from './groups.reducer';

@NgModule({
  declarations: [],
  imports: [
    StoreModule.forFeature('groups', groupsReducer),
  ]
})
export class GroupsStoreModule { }
