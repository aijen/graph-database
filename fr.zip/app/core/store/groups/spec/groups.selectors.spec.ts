import { GroupsValue } from "../groups.model";
import { getGroups } from '../groups.selectors';

describe('Groups Selectors', () => {

  it('getGroups should get the groups', () => {
    const groups: GroupsValue[] = [{ id: 'id', name: 'name', description: 'description', admins: [], users: [], defaultTemplate: '' }];

    expect(getGroups.projector({ groups })).toBe(groups);
  });

});
