import { AppState } from 'shared/models/state.model';
import { LoadGroupsSuccess } from '../groups.actions';
import { GroupsValue } from '../groups.model';
import { groupsReducer, groupsState } from '../groups.reducer';

// necessary to avoid the error :
// Invalid module name in augmentation, module 'shared/models/state.model' cannot be found.
let happy_compiler: AppState; // tslint:disable-line

describe('Groups Reducer', () => {

  describe('undefined action', () => {

    it('should return the default state', () => {
      const action = { type: null, payload: null };
      const state = groupsReducer(undefined, action);

      expect(state).toBe(groupsState);
    })

  });

  describe('LoadGroupsSuccess action', () => {

    it('should add the private group to the group list', () => {
      const userId = 'userId';
      const groups: GroupsValue[] = [{ id: 'id', name: 'name', description: 'description', admins: [], users: [], defaultTemplate: '' }];
      const privateGroup: GroupsValue = {
        id: userId,
        name: userId,
        description: '',
        admins: [userId],
        users: [userId],
        defaultTemplate: '',
      };
      const action = new LoadGroupsSuccess({ userId, groups });
      const state = groupsReducer(groupsState, action);

      expect(state.groups).toEqual([privateGroup, ...groups]);
    });

  });

});
