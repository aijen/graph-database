import { Action } from '@ngrx/store';
import { GroupsValue } from './groups.model';

export enum GroupsActionTypes {
  LoadGroupsSuccess = '[Groups] LoadSuccess',
}

export class LoadGroupsSuccess implements Action {
  readonly type = GroupsActionTypes.LoadGroupsSuccess;
  constructor( public payload: { userId: string, groups: GroupsValue[] } ) {}
}

export type GroupsActionUnion =
  | LoadGroupsSuccess
  ;
