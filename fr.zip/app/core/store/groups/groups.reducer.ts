import { GroupsActionTypes, GroupsActionUnion } from './groups.actions';
import { GroupsState, GroupsValue } from './groups.model';

export const groupsState: GroupsState = {
  groups: [],
};

export function groupsReducer(
  state = groupsState,
  action: GroupsActionUnion
): GroupsState {

  switch( action.type ) {
    case GroupsActionTypes.LoadGroupsSuccess: {
      const { userId, groups } = action.payload;
      const privateGroup: GroupsValue = {
        id: userId,
        name: userId,
        description: '',
        admins: [userId],
        users: [userId],
        defaultTemplate: '',
      };

      return {
        ...state,
        groups: [privateGroup, ...groups],
      };
    }

    default: {
      return state;
    }
  }
}
