import { createFeatureSelector, createSelector } from '@ngrx/store';
import { ExistingMetricsState } from './existing-metrics.model';

export const existingMetricsStateSelector = createFeatureSelector<ExistingMetricsState>(
  'existingMetrics'
);

export const getExistingMetrics = createSelector(
  existingMetricsStateSelector,
  state => state.existingMetrics,
);

export const isExistingMetricsLoading = createSelector(
  existingMetricsStateSelector,
  state => state.isLoading,
);
