import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LOAD_EXISTING_METRICS_URL } from 'core/services/http/http-client.service';
import { map } from 'rxjs/operators';
import { ExistingMetricsDTO, ExistingMetricsValue } from './existing-metrics.model';

const fromJson = ( dto: ExistingMetricsDTO ): ExistingMetricsValue => {
  return {
    ...dto.metrics,
  };
}

@Injectable({
  providedIn: 'root'
})
export class ExistingMetricsService {

  constructor(
    private http: HttpClient,
  ) {}

  load() {
    return this.http.get<ExistingMetricsDTO>(LOAD_EXISTING_METRICS_URL).pipe( map( fromJson ) );
  }
}
