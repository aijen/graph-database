
declare module 'shared/models/state.model' {
  export interface AppState {
    readonly existingMetrics: ExistingMetricsState;
  }
}
export interface ExistingMetricsValue {
  AVAILABILITY: number;
  PERFORMANCE: number;
  RISK: number;
  USER_XP: number;
}

export interface ExistingMetricsDTO {
  metrics: {
    AVAILABILITY: number;
    PERFORMANCE: number;
    RISK: number;
    USER_XP: number;
  }
}

export interface ExistingMetricsState {
  existingMetrics: ExistingMetricsValue;
  isLoading: boolean;
}
