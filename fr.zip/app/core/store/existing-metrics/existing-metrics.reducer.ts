import { ExistingMetricsActionTypes, ExistingMetricsActionUnion } from './existing-metrics.actions';
import { ExistingMetricsState } from './existing-metrics.model';

export const existingMetricsState: ExistingMetricsState = {
  existingMetrics: {
    AVAILABILITY: 0,
    PERFORMANCE: 0,
    RISK: 0,
    USER_XP: 0,
  },
  isLoading: false,
};

export function existingMetricsReducer(
  state = existingMetricsState,
  action: ExistingMetricsActionUnion
): ExistingMetricsState {

  switch( action.type ) {

    case ExistingMetricsActionTypes.LoadExistingMetrics: {
      return {
        ...state,
        isLoading: true,
      };
    }
    case ExistingMetricsActionTypes.LoadExistingMetricsError: {
      return {
        ...state,
        isLoading: false,
      };
    }
    // Optimistic save, assumes no change were done on the server between saves
    case ExistingMetricsActionTypes.LoadExistingMetricsSuccess: {
      const { existingMetrics } = action.payload;

      return {
        ...state,
        existingMetrics,
        isLoading: false,
      };
    }

    default: {
      return state;
    }
  }
}
