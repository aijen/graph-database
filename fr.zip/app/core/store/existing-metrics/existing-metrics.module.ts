import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { ExistingMetricsEffects } from './existing-metrics.effects';
import { existingMetricsReducer } from './existing-metrics.reducer';

@NgModule({
  declarations: [],
  imports: [
    StoreModule.forFeature('existingMetrics', existingMetricsReducer),
    EffectsModule.forFeature([ExistingMetricsEffects]),
  ]
})
export class ExistingMetricsStoreModule { }
