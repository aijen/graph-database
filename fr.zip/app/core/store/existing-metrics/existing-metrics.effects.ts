import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { concat, of } from 'rxjs';
import { catchError, map, switchMap, tap } from 'rxjs/operators';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { ExistingMetricsActionTypes, LoadExistingMetrics, LoadExistingMetricsError, LoadExistingMetricsSuccess } from './existing-metrics.actions';
import { ExistingMetricsService } from './existing-metrics.service';

@Injectable()
export class ExistingMetricsEffects {

  public static messages = {
    loadError: `
      Une erreur est survenue pendant le chargement de la configuration 'ExistingMetrics': Veuillez réessayer
    `,
  }

  constructor(
    private actions$: Actions,
    private existingMetricsService: ExistingMetricsService,
    private snackbar: MessageHandler,
  ) {}

  @Effect()
  load$ = this.actions$.pipe(
    ofType<LoadExistingMetrics>( ExistingMetricsActionTypes.LoadExistingMetrics ),
    switchMap(() => this.existingMetricsService.load()),
    map(existingMetrics => new LoadExistingMetricsSuccess( { existingMetrics } )),
    catchError((error, caught) => concat(of(new LoadExistingMetricsError({ error })), caught)),
  );

  @Effect({ dispatch: false })
  loadError$ = this.actions$.pipe(
    ofType<LoadExistingMetricsError>( ExistingMetricsActionTypes.LoadExistingMetricsError ),
    tap( action => { console.error(action.payload.error); this.snackbar.show( { message: ExistingMetricsEffects.messages.loadError, action: 'OK', isError: true } )} ),
  );

}
