import { AppState } from 'shared/models/state.model';
import { existingMetricsReducer, existingMetricsState } from '../existing-metrics.reducer';

// necessary to avoid the error :
// Invalid module name in augmentation, module 'shared/models/state.model' cannot be found.
let happy_compiler: AppState; // tslint:disable-line

describe('ExistingMetrics Reducer', () => {

  describe('undefined action', () => {

    it('should return the default state', () => {
      const action = { type: null, payload: null };
      const state = existingMetricsReducer( undefined, action );

      expect(state).toBe(existingMetricsState);
    });

  });

} );
