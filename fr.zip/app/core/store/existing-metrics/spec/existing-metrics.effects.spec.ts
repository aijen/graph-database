import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { configureTestSuite } from 'ng-bullet';
import { Observable } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { ExistingMetricsEffects } from '../existing-metrics.effects';
import { existingMetricsState } from '../existing-metrics.reducer';
import { ExistingMetricsService } from '../existing-metrics.service';

describe('ExistingMetrics Effects', () => {
  let service: ExistingMetricsEffects;
  let actions: Observable<any>;
  let existingMetricsServiceStub: jasmine.SpyObj<ExistingMetricsService>;
  let messageHandlerStub: jasmine.SpyObj<MessageHandler>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule
      ],
      providers: [
        ExistingMetricsEffects,
        provideMockActions(() => actions),
        provideMockStore<Partial<AppState>>({ initialState: { existingMetrics: existingMetricsState } }),
        { provide: ExistingMetricsService, useFactory: () => jasmine.createSpyObj('ExistingMetricsService', ['load', 'save'] as Array<keyof ExistingMetricsService>) },
        { provide: MessageHandler, useFactory: () => jasmine.createSpyObj('MessageHandler', ['ngOnDestroy', 'show'] as Array<keyof MessageHandler>) },
      ]
    });
  } );

  beforeEach(() => {
    actions = null;
    existingMetricsServiceStub = TestBed.get(ExistingMetricsService);
    messageHandlerStub = TestBed.get(MessageHandler);
    service = TestBed.get(ExistingMetricsEffects);
  });

  it('should work', () => {
    expect(service).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
} );
