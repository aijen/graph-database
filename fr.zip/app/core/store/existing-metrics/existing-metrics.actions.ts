import { Action } from '@ngrx/store';
import { ExistingMetricsValue } from './existing-metrics.model';

export enum ExistingMetricsActionTypes {
  LoadExistingMetrics = '[ExistingMetrics] Load',
  LoadExistingMetricsSuccess = '[ExistingMetrics] LoadSuccess',
  LoadExistingMetricsError = '[ExistingMetrics] LoadError',
}

export class LoadExistingMetrics implements Action {
  readonly type = ExistingMetricsActionTypes.LoadExistingMetrics;
  constructor() {}
}

export class LoadExistingMetricsSuccess implements Action {
  readonly type = ExistingMetricsActionTypes.LoadExistingMetricsSuccess;
  constructor( public payload: { existingMetrics: ExistingMetricsValue } ) {}
}

export class LoadExistingMetricsError implements Action {
  readonly type = ExistingMetricsActionTypes.LoadExistingMetricsError;
  constructor( public payload: { error: Error } ) {}
}

export type ExistingMetricsActionUnion =
  | LoadExistingMetrics
  | LoadExistingMetricsSuccess
  | LoadExistingMetricsError
  ;
