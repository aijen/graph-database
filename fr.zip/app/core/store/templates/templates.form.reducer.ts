import { enableIfStable } from 'core/utils/forms.helpers';
import { AddArrayControlAction, createFormGroupState, createFormStateReducerWithUpdate, disable, FormGroupState, markAsDirty, RemoveArrayControlAction, reset, setValue, updateArray, updateGroup, validate } from 'ngrx-forms';
import { required } from 'ngrx-forms/validation';
import { TemplatesFormActionTypes, TemplatesFormActionUnion } from './templates.form.actions';
import { Template, TemplatesFormState, TemplatesFormValue, UserView } from './templates.form.model';

const FORM_ID = 'ADMIN_TEMPLATES_FORM';

const toggleUpdateTemplate = (updatedTemplate: Template, defaultTemplate: Template, checked: boolean, userView: UserView) =>
  updateArray<Template>(
    (template) => template.value.id !== updatedTemplate.id
    ? template
    : updateGroup<Template>(template, {
      nodes: n => markAsDirty(setValue(n, checked ? userView.nodes : defaultTemplate.nodes)),
      hiddenNodes: hn => markAsDirty(setValue(hn, checked ? userView.hiddenNodes : defaultTemplate.hiddenNodes)),
      nodesPosition: np => markAsDirty(setValue(np, checked ? userView.nodesPosition : defaultTemplate.nodesPosition)),
    })
  );

const updateTemplate = (state: TemplatesFormState, updatedTemplate: Template, checked: boolean, userView: UserView) => updateGroup<TemplatesFormValue>(state.templatesForm, {
  templates: toggleUpdateTemplate(updatedTemplate, state.defaultTemplatesForm.templates.find(t => t.id === updatedTemplate.id), checked, userView),
});

const templatesState = createFormGroupState<TemplatesFormValue>(FORM_ID, {
  templates: [],
  deletedTemplates: [],
  newTemplates: [],
  newTemplatesName: '',
});

const formUpdate = updateGroup<TemplatesFormValue>({
});

const validateTemplate = (form: FormGroupState<TemplatesFormValue>) => updateGroup<Template>( {
  name: ( name, template ) => validate(name, ( value ) => required( value ), ( value ) => form.controls.templates.controls.some( compare => (compare.id !== template.id) && (compare.value.type === template.value.type) && (compare.value.owner === template.value.owner) && (compare.value.name === name.value) && Boolean(name.value) ) ? { notUnique: true } : null ),
} );

const validateNewTemplatesName = (form: TemplatesFormValue, name: string) => {
  for(let template of form.newTemplates) {
    if(form.templates.some(compare => (compare.type === template.type) && (compare.owner === template.owner) && (compare.name === name) && Boolean(name) )) {
      return { notUnique: true };
    }
  }

  return null;
}

const formValidation = (form: FormGroupState<TemplatesFormValue>) => updateGroup<TemplatesFormValue>(form, {
  templates: updateArray<Template>(validateTemplate(form)),
  newTemplatesName: newTemplatesName => validate(newTemplatesName, () => validateNewTemplatesName(form.value, newTemplatesName.value)),
});

const updateAndValidate = ( templatesForm: FormGroupState<TemplatesFormValue> ) => formValidation(formUpdate(templatesForm));

const formReducer = createFormStateReducerWithUpdate(updateAndValidate);

export const templatesFormState: TemplatesFormState = {
  templatesForm: updateAndValidate(templatesState),
  defaultTemplatesForm: templatesState.value,
  isSaving: false,
  isLoading: false,
  isLoaded: false,
};

export function templatesFormReducer(
  state = templatesFormState,
  action: TemplatesFormActionUnion
): TemplatesFormState {

  let templatesForm = formReducer(state.templatesForm, action);

  if(templatesForm !== state.templatesForm) {
    state = { ...state, templatesForm };
  }

  switch( action.type ) {

    case TemplatesFormActionTypes.LoadTemplatesForm: {
      return {
        ...state,
        templatesForm: disable(state.templatesForm),
        isLoading: true,
      };
    }
    case TemplatesFormActionTypes.LoadTemplatesFormError: {
      return {
        ...state,
        isLoading: false,
      };
    }
    // Optimistic save, assumes no change were done on the server between saves
    case TemplatesFormActionTypes.LoadTemplatesFormSuccess: {
      const { templatesForm } = action.payload;
      const { isSaving } = state;
      const defaultTemplatesForm = { ...state.templatesForm.value, ...templatesForm };

      return {
        ...state,
        templatesForm: updateAndValidate(enableIfStable(reset(setValue(state.templatesForm, defaultTemplatesForm)), { isSaving, isLoading: false } )),
        defaultTemplatesForm,
        isLoading: false,
        isLoaded: true,
      };
    }

    case TemplatesFormActionTypes.ResetTemplatesForm: {
      const { defaultTemplatesForm } = state;
      return {
        ...state,
        templatesForm: updateAndValidate(reset(setValue(state.templatesForm, defaultTemplatesForm ))),
      };
    }

    case TemplatesFormActionTypes.CreateTemplates:
    case TemplatesFormActionTypes.UpdateTemplates: {
      return {
        ...state,
        templatesForm: disable(state.templatesForm),
        isSaving: true,
      };
    }
    case TemplatesFormActionTypes.SaveTemplatesFormSuccess: {
      return {
        ...state,
        isSaving: false,
      };
    }
    case TemplatesFormActionTypes.SaveTemplatesFormError: {
      const { isLoading } = state;

      return {
        ...state,
        templatesForm: updateAndValidate(enableIfStable(state.templatesForm, { isSaving: false, isLoading } )),
        isSaving: false,
      };
    }

    case TemplatesFormActionTypes.DeleteTemplate: {
      const { template } = action.payload;
      const index = templatesForm.value.templates.findIndex( t => t.id === template.id );

      templatesForm = formReducer( templatesForm, new AddArrayControlAction( templatesForm.controls.deletedTemplates.id, template ) );
      templatesForm = formReducer( templatesForm, new RemoveArrayControlAction( templatesForm.controls.templates.id, index ) );

      return {
        ...state,
        templatesForm: markAsDirty(updateAndValidate(templatesForm)),
      };
    }

    case TemplatesFormActionTypes.UnloadTemplates:
    case TemplatesFormActionTypes.LoadSelectedTemplateError: {
      return templatesFormState;
    }

    case TemplatesFormActionTypes.UpdateNewTemplate: {
      const { type, owner, userView: { nodes, hiddenNodes, nodesPosition }, checked } = action.payload;
      const template = {
        id: undefined,
        name: undefined,
        type,
        owner,
        nodes: nodes.filter( node => !node.readOnly ),
        hiddenNodes,
        nodesPosition,
      };

      if(checked) {
        templatesForm = formReducer( templatesForm, new AddArrayControlAction( templatesForm.controls.newTemplates.id, template ) );
      }
      else {
        const index = templatesForm.value.newTemplates.findIndex( t => t.type === template.type && t.owner === template.owner );
        templatesForm = formReducer( templatesForm, new RemoveArrayControlAction( templatesForm.controls.newTemplates.id, index ) );
      }

      return {
        ...state,
        templatesForm: markAsDirty(updateAndValidate(templatesForm)),
      };
    }

    case TemplatesFormActionTypes.ToggleUpdateTemplate: {
      const { updatedTemplate, checked, userView } = action.payload;

      userView.nodes = userView.nodes.filter( node => !node.readOnly );

      return {
        ...state,
        templatesForm: updateTemplate(state, updatedTemplate, checked, userView),
      };
    }

    default: {
      return state;
    }
  }
}
