import { FormGroupState } from 'ngrx-forms';
import { NodeDTO } from 'shared/models/node.model';
import { HiddenNodes, NODE_KEYS_POSITION } from '../hierarchy/hierarchy.model';

export const isSameTemplate = (t1: Template, t2: Template): boolean => {
  const sameId = t1.id === t2.id;
  const sameName = t1.name === t2.name;
  const sameType = t1.type === t2.type;
  const sameOwner = t1.owner === t2.owner;
  const sameNodes = JSON.stringify(t1.nodes) === JSON.stringify(t2.nodes);
  const sameHiddenNodes = JSON.stringify(t1.hiddenNodes) === JSON.stringify(t2.hiddenNodes);
  const sameNodesPosition = JSON.stringify(t1.nodesPosition) === JSON.stringify(t2.nodesPosition);

  return sameId && sameName && sameType && sameOwner && sameNodes && sameHiddenNodes && sameNodesPosition;
}

declare module 'shared/models/state.model' {
  export interface AppState {
    readonly templatesForm: TemplatesFormState;
  }
}

export enum TemplateType {
  PUBLIC = 'PUBLIC',
  USER = 'USER',
  GROUP = 'GROUP',
}

export const PUBLIC_GROUP = 'Public';
export const PRIVATE_GROUP = 'Privé';

export interface UserView {
  nodes: NodeDTO[];
  hiddenNodes: HiddenNodes;
  nodesPosition: NODE_KEYS_POSITION;
}

export interface Template extends UserView {
  readonly id: string;
  name: string;
  type: TemplateType;
  owner?: string;
}

export interface TemplateDTO {
  readonly id: string;
  name: string;
  type: TemplateType;
  owner?: string;
  nodes?: NodeDTO[];
  hiddenNodes?: HiddenNodes;
  nodesPosition?: NODE_KEYS_POSITION;
}

export interface TemplatesFormValue {
  templates: Template[];
  deletedTemplates?: Template[];
  newTemplates?: Template[];
  newTemplatesName?: string;
}

export type TemplatesFormDto = TemplateDTO[];

export interface TemplatesFormState {
  templatesForm: FormGroupState<TemplatesFormValue>;
  defaultTemplatesForm: TemplatesFormValue;
  isSaving: boolean;
  isLoading: boolean;
  isLoaded: boolean;
}
