import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { DELETE_TEMPLATES_URL, LOAD_TEMPLATES_URL, SAVE_TEMPLATES_URL, SET_USER_VIEW_FROM_TEMPLATE } from 'core/services/http/http-client.service';
import { combineLatest, of } from 'rxjs';
import { catchError, map, share, switchMap, switchMapTo, tap } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';
import { getUserConnected$ } from '../auth/auth.selectors';
import { LoadTemplatesForm, LoadTemplatesFormError, LoadTemplatesFormSuccess } from './templates.form.actions';
import { Template, TemplateDTO, TemplatesFormDto, TemplatesFormValue } from './templates.form.model';
import { getTemplatesForm, getTemplatesValues, isTemplatesFormLoaded } from './templates.form.selectors';

const fromJson = (dto: TemplatesFormDto): TemplatesFormValue => {
  return {
    templates: templatesFromJson(dto)
  };
}

const templatesFromJson = (dtos: TemplatesFormDto): Template[] => {
  return dtos.map(dto => templateFromJson(dto));
}

const templateFromJson = (dto: TemplateDTO): Template => {
  return {
    ...dto,
    nodes: Boolean(dto.nodes) ? dto.nodes : [],
    hiddenNodes: Boolean(dto.hiddenNodes) ? dto.hiddenNodes : {},
    nodesPosition: Boolean(dto.nodesPosition) ? dto.nodesPosition : [[], [], [], []],
  }
}

@Injectable({
  providedIn: 'root'
})
export class TemplatesFormService {

  constructor(
    private store$: Store<AppState>,
    private http: HttpClient,
  ) { }

  private getForm$ = (userId: string) => this.http.get<TemplatesFormDto>(LOAD_TEMPLATES_URL, { params: { userId } }).pipe( map(fromJson), share() );

  private require$ = of<void>(null).pipe(
    tap(() => this.store$.dispatch(new LoadTemplatesForm())),
    switchMap(() => this.store$.pipe(getUserConnected$)),
    switchMap(({ userId }) => this.getForm$(userId)),
    tap(templatesForm => this.store$.dispatch(new LoadTemplatesFormSuccess({ templatesForm }))),
    catchError(error => (this.store$.dispatch(new LoadTemplatesFormError({ error })), of<void>(null))),
    share(),
  );

  private selectForm$ = this.store$.pipe(select(getTemplatesForm));
  private getAndSelectForm$ = this.require$.pipe(switchMapTo(this.selectForm$));

  form$ = this.store$.pipe(
    select(isTemplatesFormLoaded),
    switchMap(loaded => loaded ? this.selectForm$ : this.getAndSelectForm$),
  );

  private selectValues$ = this.store$.pipe(select(getTemplatesValues));
  private getAndSelectValues$ = this.require$.pipe(switchMapTo(this.selectValues$));

  values$ = this.store$.pipe(
    select(isTemplatesFormLoaded),
    switchMap(loaded => loaded ? this.selectValues$ : this.getAndSelectValues$),
  )

  loadSelected(userId: string, template: Template) {
    return this.http.post(SET_USER_VIEW_FROM_TEMPLATE, template, { responseType: 'text', params: { userId } });
  }

  async save(name: string, newTemplates: Template[]) {
    let result = '';

    newTemplates.forEach(template => template.name = name);

    for(let template of newTemplates) {
      result = await this.http.post(SAVE_TEMPLATES_URL, template, { responseType: 'text' }).toPromise();
    }

    return of(result);
  }

  manage(deletedTemplates: Template[], updatedTemplates: Template[]) {
    return combineLatest(
      this.delete(deletedTemplates),
      this.update(updatedTemplates),
    )
  }

  private async delete(deletedTemplates: Template[]) {
    let result = '';

    for(let template of deletedTemplates) {
      result = await this.http.delete(DELETE_TEMPLATES_URL + '/' + template.id, { responseType: 'text' }).toPromise();
    }

    return result;
  }

  private async update(updatedTemplates: Template[]) {
    let result = '';

    for(let template of updatedTemplates) {
      result = await this.http.put(SAVE_TEMPLATES_URL, template, { responseType: 'text' }).toPromise();
    }

    return result;
  }

}
