import { createFeatureSelector, createSelector } from '@ngrx/store';
import { isSameTemplate, Template, TemplatesFormState } from './templates.form.model';

export const templatesFormStateSelector = createFeatureSelector<TemplatesFormState>(
  'templatesForm'
);

export const getTemplatesForm = createSelector(
  templatesFormStateSelector,
  state => state.templatesForm,
);

export const isTemplatesFormLoading = createSelector(
  templatesFormStateSelector,
  state => state.isLoading,
);

export const isTemplatesFormLoaded = createSelector(
  templatesFormStateSelector,
  state => state.isLoaded,
);

export const isTemplatesFormLoadingOrSaving = createSelector(
  templatesFormStateSelector,
  state => state.isLoading || state.isSaving,
);

export const isModified = createSelector(
  templatesFormStateSelector,
  ({ templatesForm, isLoading }) => !(templatesForm.isPristine || isLoading),
);

export const getTemplatesValues = createSelector(
  getTemplatesForm,
  form => form.value
);

export const getUpdatedTemplates = createSelector(
  templatesFormStateSelector,
  state => {
    const { defaultTemplatesForm, templatesForm } = state;
    const defaultTemplates = defaultTemplatesForm.templates;
    const templates = templatesForm.value.templates;
    const updatedTemplates: Template[] = [];

    templates.forEach(template => {
      const defaultTemplate = defaultTemplates.find(t => t.id === template.id);

      if(!isSameTemplate(template, defaultTemplate)) {
        updatedTemplates.push(template);
      }
    });

    return updatedTemplates;
  }
);

export const getDeletedTemplates = createSelector(
  getTemplatesForm,
  form => form.controls.deletedTemplates.controls,
)
