import { Action } from '@ngrx/store';
import { Template, TemplatesFormValue, TemplateType, UserView } from './templates.form.model';

export enum TemplatesFormActionTypes {
  LoadTemplatesForm = '[Templates] LoadForm',
  LoadTemplatesFormSuccess = '[Templates] LoadFormSuccess',
  LoadTemplatesFormError = '[Templates] LoadFormError',
  ResetTemplatesForm = '[Templates] ResetForm',
  CreateTemplates = '[Templates] Create',
  UpdateTemplates = '[Templates] Update',
  SaveTemplatesFormSuccess = '[Templates] SaveFormSuccess',
  SaveTemplatesFormError = '[Templates] SaveFormError',
  LoadSelectedTemplate = '[Templates] LoadSelectedTemplate',
  LoadSelectedTemplateError = '[Templates] LoadSelectedTemplateError',
  DeleteTemplate = '[Templates] DeleteTemplate',
  UnloadTemplates = '[Templates] UnloadTemplates',
  AddNewTemplate = '[Templates] AddNewTemplate',
  RemoveNewTemplate = '[Templates] RemoveNewTemplate',
  UpdateNewTemplate = '[Templates] UpdateNewTemplate',
  ToggleUpdateTemplate = '[Templates] ToggleUpdateTemplate',
}

export class LoadTemplatesForm implements Action {
  readonly type = TemplatesFormActionTypes.LoadTemplatesForm;
  constructor() {}
}

export class LoadTemplatesFormSuccess implements Action {
  readonly type = TemplatesFormActionTypes.LoadTemplatesFormSuccess;
  constructor( public payload: { templatesForm: Partial<TemplatesFormValue> } ) {}
}

export class LoadTemplatesFormError implements Action {
  readonly type = TemplatesFormActionTypes.LoadTemplatesFormError;
  constructor( public payload: { error: Error } ) {}
}

export class ResetTemplatesForm implements Action {
  readonly type = TemplatesFormActionTypes.ResetTemplatesForm;
  constructor() {}
}

export class CreateTemplates implements Action {
  readonly type = TemplatesFormActionTypes.CreateTemplates;
  constructor() {}
}

export class UpdateTemplates implements Action {
  readonly type = TemplatesFormActionTypes.UpdateTemplates;
  constructor() {}
}

export class SaveTemplatesFormSuccess implements Action {
  readonly type = TemplatesFormActionTypes.SaveTemplatesFormSuccess;
  constructor() {}
}

export class SaveTemplatesFormError implements Action {
  readonly type = TemplatesFormActionTypes.SaveTemplatesFormError;
  constructor( public payload: { error: Error } ) {}
}

export class LoadSelectedTemplate implements Action {
  readonly type = TemplatesFormActionTypes.LoadSelectedTemplate;
  constructor(public payload: { template: Template }) {}
}

export class LoadSelectedTemplateError implements Action {
  readonly type = TemplatesFormActionTypes.LoadSelectedTemplateError;
  constructor(public payload: { error: Error }) {}
}

export class DeleteTemplate implements Action {
  readonly type = TemplatesFormActionTypes.DeleteTemplate;
  constructor(public payload: { template: Template }) {}
}

export class UnloadTemplates implements Action {
  readonly type = TemplatesFormActionTypes.UnloadTemplates;
  constructor() {}
}

export class AddNewTemplate implements Action {
  readonly type = TemplatesFormActionTypes.AddNewTemplate;
  constructor(public payload: { type: TemplateType, owner: string }) {}
}

export class RemoveNewTemplate implements Action {
  readonly type = TemplatesFormActionTypes.RemoveNewTemplate;
  constructor(public payload: { type: TemplateType, owner: string }) {}
}

export class UpdateNewTemplate implements Action {
  readonly type = TemplatesFormActionTypes.UpdateNewTemplate;
  constructor(public payload: { type: TemplateType, owner: string, userView: UserView, checked: boolean }) {}
}

export class ToggleUpdateTemplate implements Action {
  readonly type = TemplatesFormActionTypes.ToggleUpdateTemplate;
  constructor(public payload: { checked: boolean, updatedTemplate: Template, userView: UserView }) {}
}

export type TemplatesFormActionUnion =
  | LoadTemplatesForm
  | LoadTemplatesFormSuccess
  | LoadTemplatesFormError
  | ResetTemplatesForm
  | CreateTemplates
  | UpdateTemplates
  | SaveTemplatesFormSuccess
  | SaveTemplatesFormError
  | LoadSelectedTemplate
  | LoadSelectedTemplateError
  | DeleteTemplate
  | UnloadTemplates
  | AddNewTemplate
  | RemoveNewTemplate
  | UpdateNewTemplate
  | ToggleUpdateTemplate
  ;
