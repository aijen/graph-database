import { HttpErrorResponse } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { User } from 'core/models/user.model';
import { UserRole } from 'core/models/userRoles.model';
import { LOAD_TEMPLATES_URL, SAVE_TEMPLATES_URL, SET_USER_VIEW_FROM_TEMPLATE } from 'core/services/http/http-client.service';
import { GetHierarchy, Ready, SaveNodes, UpdateLastRestore } from 'core/store/hierarchy/hierarchy.actions';
import { HierarchyState } from 'core/store/hierarchy/hierarchy.model';
import { configureTestSuite } from 'ng-bullet';
import { combineLatest, Observable, of, throwError } from 'rxjs';
import { marbles } from 'rxjs-marbles/marbles';
import { tap } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { AddNewTemplate, CreateTemplates, LoadSelectedTemplate, LoadSelectedTemplateError, LoadTemplatesFormError, RemoveNewTemplate, SaveTemplatesFormError, SaveTemplatesFormSuccess, UnloadTemplates, UpdateNewTemplate, UpdateTemplates } from '../templates.form.actions';
import { TemplatesFormEffects } from '../templates.form.effects';
import { Template, TemplateType, UserView } from '../templates.form.model';
import { templatesFormState } from '../templates.form.reducer';
import { TemplatesFormService } from '../templates.form.service';

const generateUser = (user?: Partial<User>): User => {
  return {
    ...User.from(),
    ...user,
  }
}

const generateTemplate = (template?: Partial<Template>): Template => {
  return {
    id: 'id',
    name: 'name',
    type: TemplateType.USER,
    owner: 'userId',
    nodes: [],
    hiddenNodes: {},
    nodesPosition: [[], [], [], []],
    ...template,
  }
}

describe('TemplatesFormEffects', () => {
  let service: TemplatesFormEffects;
  let actions: Observable<any>;
  let templatesFormService: jasmine.SpyObj<TemplatesFormService>;
  let snackbar: jasmine.SpyObj<MessageHandler>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
      ],
      providers: [
        TemplatesFormEffects,
        provideMockStore<Partial<AppState>>({ initialState: {
          auth: { user: generateUser({ userId: 'A123456' }), isUserAuthenticated: true, profil: { profiles: [UserRole.PUBLIC], permissions: [] } },
          templatesForm: {
            ...templatesFormState,
            templatesForm: {
              ...templatesFormState.templatesForm,
              value: {
                ...templatesFormState.templatesForm.value,
                templates: [
                  generateTemplate({ id: 'ID1', name: 'template 1 updated' }),
                  generateTemplate({ id: 'ID2', name: 'template 2' }),
                  generateTemplate({ id: 'ID3', name: 'template 3' }),
                ],
                deletedTemplates: [
                  generateTemplate({ name: 'deleted' }),
                ],
                newTemplates: [
                  generateTemplate({ name: 'new' }),
                ],
                newTemplatesName: 'newName',
              }
            },
            defaultTemplatesForm: {
              ...templatesFormState.defaultTemplatesForm,
              templates: [
                generateTemplate({ id: 'ID1', name: 'template 1' }),
                generateTemplate({ id: 'ID2', name: 'template 2' }),
                generateTemplate({ id: 'ID3', name: 'template 3' }),
              ],
            },
          },
          hierarchy: {
            ...new HierarchyState(),
          }
        } }),
        provideMockActions(() => actions),
        { provide: TemplatesFormService, useFactory: () => jasmine.createSpyObj('TemplatesFormService', ['loadSelected', 'save', 'manage', 'delete', 'update'] as Array<keyof TemplatesFormService>) },
        { provide: MessageHandler, useFactory: () => jasmine.createSpyObj('MessageHandler', ['ngOnDestroy', 'show'] as Array<keyof MessageHandler>) },
      ],
    })
  });

  beforeEach(() => {
    actions = null;
    templatesFormService = TestBed.get(TemplatesFormService);
    snackbar = TestBed.get(MessageHandler);
    service = TestBed.get(TemplatesFormEffects);
  });

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  describe('LoadTemplatesFormError action', () => {

    it('should display an error snackbar', marbles(m => {
      const errorSpy = spyOn(console, 'error');
      const error = new HttpErrorResponse({ error: 'Service unavailable', status: 503, statusText: 'KO', url: LOAD_TEMPLATES_URL });

      actions =         m.hot('a', {
        a: new LoadTemplatesFormError({ error })
      });
      const expected =  m.hot('a', {
        a: new LoadTemplatesFormError({ error }),
      });
      const completeExpectation = tap(() => {
        expect(errorSpy).toHaveBeenCalledWith(error);
        expect(snackbar.show).toHaveBeenCalledWith({ message: TemplatesFormEffects.messages.loadError, action: 'OK', isError: true });
      });

      m.expect(service.loadError$.pipe(completeExpectation)).toBeObservable(expected);
    }));

  });

  describe('LoadSelectedTemplate action', () => {

    it('should change the user view and then reload arborescence', marbles(m => {
      templatesFormService.loadSelected.and.returnValue(of(''));

      const template: Template = {
        id: 'id',
        name: 'name',
        type: TemplateType.USER,
        owner: 'A123456',
        nodes: [],
        hiddenNodes: {},
        nodesPosition: [[], [], [], []]
      };

      actions =         m.hot('a', {
        a: new LoadSelectedTemplate({ template })
      });
      const expected =  m.hot('(abcd)', {
        a: new UpdateLastRestore(),
        b: new Ready(false),
        c: new GetHierarchy(),
        d: new UnloadTemplates(),
      });
      const completeExpectation = tap(() => {
        expect(templatesFormService.loadSelected).toHaveBeenCalled();
      });

      m.expect(service.loadSelected$.pipe(completeExpectation)).toBeObservable(expected);
    }));

    it('should dispatch a LoadSelectedTemplateError action', marbles(m => {
      templatesFormService.loadSelected.and.returnValue(throwError(new Error()));

      const template: Template = {
        id: 'id',
        name: 'name',
        type: TemplateType.USER,
        owner: 'A123456',
        nodes: [],
        hiddenNodes: {},
        nodesPosition: [[], [], [], []]
      };

      actions =         m.hot('a', {
        a: new LoadSelectedTemplate({ template })
      });
      const expected =  m.hot('a', {
        a: new LoadSelectedTemplateError({ error: new Error() }),
      });
      const completeExpectation = tap(() => {
        expect(templatesFormService.loadSelected).toHaveBeenCalled();
      });

      m.expect(service.loadSelected$.pipe(completeExpectation)).toBeObservable(expected);
    }));

  });

  describe('LoadSelectedTemplateError action', () => {

    it('should display an error snackbar', marbles(m => {
      const errorSpy = spyOn(console, 'error');
      const error = new HttpErrorResponse({ error: 'Service unavailable', status: 503, statusText: 'KO', url: SET_USER_VIEW_FROM_TEMPLATE });

      actions =         m.hot('a', {
        a: new LoadSelectedTemplateError({ error })
      });
      const expected =  m.hot('a', {
        a: new LoadSelectedTemplateError({ error }),
      });
      const completeExpectation = tap(() => {
        expect(errorSpy).toHaveBeenCalledWith(error);
        expect(snackbar.show).toHaveBeenCalledWith({ message: TemplatesFormEffects.messages.loadSelectedError, action: 'OK', isError: true });
      });

      m.expect(service.loadSelectedError$.pipe(completeExpectation)).toBeObservable(expected);
    }));

  });

  describe('CreateTemplates action', () => {

    it('should dispatch a SaveTemplatesFormSuccess action', marbles(m => {
      templatesFormService.save.and.returnValue(of(''));

      actions =         m.hot('a', {
        a: new CreateTemplates()
      });
      const expected =  m.hot('a', {
        a: new SaveTemplatesFormSuccess(),
      });
      const completeExpectation = tap(() => {
        expect(templatesFormService.save).toHaveBeenCalledWith('newName', [generateTemplate({ name: 'new' })]);
      });

      m.expect(service.save$.pipe(completeExpectation)).toBeObservable(expected);
    }));

    it('should dispatch a SaveTemplatesFormError action', marbles(m => {
      templatesFormService.save.and.returnValue(throwError(new Error()));

      actions =         m.hot('a', {
        a: new CreateTemplates()
      });
      const expected =  m.hot('a', {
        a: new SaveTemplatesFormError({ error: new Error() }),
      });
      const completeExpectation = tap(() => {
        expect(templatesFormService.save).toHaveBeenCalledWith('newName', [generateTemplate({ name: 'new' })]);
      });

      m.expect(service.save$.pipe(completeExpectation)).toBeObservable(expected);
    }));

  });

  describe('UpdateTemplates action', () => {

    it('should dispatch a SaveTemplatesFormSuccess action', marbles(m => {
      templatesFormService.manage.and.returnValue(combineLatest(of(''), of('')));

      actions =         m.hot('a', {
        a: new UpdateTemplates()
      });
      const expected =  m.hot('a', {
        a: new SaveTemplatesFormSuccess(),
      });
      const completeExpectation = tap(() => {
        expect(templatesFormService.manage).toHaveBeenCalledWith([generateTemplate({ name: 'deleted' })], [generateTemplate({ id: 'ID1', name: 'template 1 updated' })]);
      });

      m.expect(service.update$.pipe(completeExpectation)).toBeObservable(expected);
    }));

    it('should dispatch a SaveTemplatesFormError action', marbles(m => {
      templatesFormService.manage.and.returnValue(throwError(new Error()));

      actions =         m.hot('a', {
        a: new UpdateTemplates()
      });
      const expected =  m.hot('a', {
        a: new SaveTemplatesFormError({ error: new Error() }),
      });
      const completeExpectation = tap(() => {
        expect(templatesFormService.manage).toHaveBeenCalledWith([generateTemplate({ name: 'deleted' })], [generateTemplate({ id: 'ID1', name: 'template 1 updated' })]);
      });

      m.expect(service.update$.pipe(completeExpectation)).toBeObservable(expected);
    }));

  });

  describe('SaveTemplatesFormSuccess action', () => {

    it('should display a success message and unload Templates', marbles(m => {
      actions =         m.hot('a', {
        a: new SaveTemplatesFormSuccess()
      });
      const expected =  m.hot('(ab)', {
        a: new SaveNodes(),
        b: new UnloadTemplates(),
      });
      const completeExpectation = tap(() => {
        expect(snackbar.show).toHaveBeenCalledWith({ message: TemplatesFormEffects.messages.saveSuccess });
      });

      m.expect(service.saveSuccess$.pipe(completeExpectation)).toBeObservable(expected);
    }));

  });

  describe('SaveTemplatesFormError action', () => {

    it('should display an error snackbar', marbles(m => {
      const errorSpy = spyOn(console, 'error');
      const error = new HttpErrorResponse({ error: 'Service unavailable', status: 503, statusText: 'KO', url: SAVE_TEMPLATES_URL });

      actions =         m.hot('a', {
        a: new SaveTemplatesFormError({ error })
      });
      const expected =  m.hot('a', {
        a: new SaveTemplatesFormError({ error }),
      });
      const completeExpectation = tap(() => {
        expect(errorSpy).toHaveBeenCalledWith(error);
        expect(snackbar.show).toHaveBeenCalledWith({ message: TemplatesFormEffects.messages.saveError, action: 'OK', isError: true });
      });

      m.expect(service.saveError$.pipe(completeExpectation)).toBeObservable(expected);
    }));

  });

  describe('AddNewTemplate action', () => {

    it('should dispatch a UpdateNewTemplate action', marbles(m => {
      const type = TemplateType.USER;
      const owner = 'A123456';
      const userView: UserView = { nodes: [], hiddenNodes: {}, nodesPosition: [[], [], [], []] };
      const checked = true;

      actions =         m.hot('a', {
        a: new AddNewTemplate({ type, owner })
      });
      const expected =  m.hot('a', {
        a: new UpdateNewTemplate({ type, owner, userView, checked }),
      });

      m.expect(service.addNew$).toBeObservable(expected);
    }));

  });

  describe('RemoveNewTemplate action', () => {

    it('should dispatch a UpdateNewTemplate action', marbles(m => {
      const type = TemplateType.USER;
      const owner = 'A123456';
      const userView: UserView = { nodes: [], hiddenNodes: {}, nodesPosition: [[], [], [], []] };
      const checked = false;

      actions =         m.hot('a', {
        a: new RemoveNewTemplate({ type, owner })
      });
      const expected =  m.hot('a', {
        a: new UpdateNewTemplate({ type, owner, userView, checked }),
      });

      m.expect(service.removeNew$).toBeObservable(expected);
    }));

  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for (const style of styles) head.removeChild(style);
  }
  afterAll(cleanStylesFromDom);
});
