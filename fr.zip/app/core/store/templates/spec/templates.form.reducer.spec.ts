import { createFormGroupState, disable } from 'ngrx-forms';
import { AppState } from 'shared/models/state.model';
import { CreateTemplates, DeleteTemplate, LoadSelectedTemplateError, LoadTemplatesForm, LoadTemplatesFormError, LoadTemplatesFormSuccess, ResetTemplatesForm, SaveTemplatesFormError, SaveTemplatesFormSuccess, ToggleUpdateTemplate, UnloadTemplates, UpdateNewTemplate, UpdateTemplates } from '../templates.form.actions';
import { isSameTemplate, Template, TemplatesFormState, TemplatesFormValue, TemplateType, UserView } from '../templates.form.model';
import { templatesFormReducer, templatesFormState } from '../templates.form.reducer';

const generateTemplatesFormState = (state?: Partial<TemplatesFormState>) => {
  return {
    ...templatesFormState,
    ...state,
  };
};

const generateTemplatesForm = (templatesForm?: Partial<TemplatesFormValue>) => createFormGroupState<TemplatesFormValue>('ADMIN_TEMPLATES_FORM', {
  ...templatesFormState.templatesForm.value,
  ...templatesForm,
});

const generateTemplate = (template?: Partial<Template>): Template => {
  return {
    id: 'id',
    name: 'name',
    type: TemplateType.USER,
    owner: 'userId',
    nodes: [],
    hiddenNodes: {},
    nodesPosition: [[], [], [], []],
    ...template,
  }
}

// necessary to avoid the error :
// Invalid module name in augmentation, module 'shared/models/state.model' cannot be found.
let happy_compiler: AppState; // tslint:disable-line

describe('Templates Reducer', () => {

  describe('undefined action', () => {

    it('should return the default state', () => {
      const action = { type: null, payload: null };
      const state = templatesFormReducer(undefined, action);

      expect(state).toBe(templatesFormState);
    });

  });

  describe('LoadTemplatesForm action', () => {

    it('should be loading and disabled', () => {
      const action = new LoadTemplatesForm();
      const state = templatesFormReducer(undefined, action);

      expect(state.isLoading).toBe(true);
      expect(state.templatesForm.isEnabled).toBe(false);
    });

  });

  describe('LoadTemplatesFormError action', () => {

    it('should not be loading', () => {
      const action = new LoadTemplatesFormError({ error: new Error() });
      const state = templatesFormReducer(generateTemplatesFormState({ isLoading: true }), action);

      expect(state.isLoading).toBe(false);
    });

  });

  describe('LoadTemplatesFormSuccess action', () => {

    it('should update the form and default form', () => {
      const templates = [
        generateTemplate({ id: 'ID1', name: 'template 1' }),
        generateTemplate({ id: 'ID2', name: 'template 2' }),
        generateTemplate({ id: 'ID3', name: 'template 3' }),
      ];
      const templatesForm = generateTemplatesForm({ templates });

      const action = new LoadTemplatesFormSuccess({ templatesForm: { templates } });
      const state = templatesFormReducer(generateTemplatesFormState({ isLoading: true }), action);

      expect(state.templatesForm).toEqual(templatesForm);
      expect(state.defaultTemplatesForm).toEqual(templatesForm.value);
      expect(state.isLoading).toBe(false);
      expect(state.isLoaded).toBe(true);
    });

  });

  describe('ResetTemplatesForm action', () => {

    it('should set the form value to the default form', () => {
      const templates = [
        generateTemplate({ id: 'ID1', name: 'template 1' }),
        generateTemplate({ id: 'ID2', name: 'template 2' }),
        generateTemplate({ id: 'ID3', name: 'template 3' }),
      ];
      const defaultTemplatesForm = {
        templates,
        deletedTemplates: [],
        newTemplates: [],
        newTemplatesName: '',
      };

      const action = new ResetTemplatesForm();
      const state = templatesFormReducer(generateTemplatesFormState({ defaultTemplatesForm }), action);

      expect(state.templatesForm.value).toEqual(defaultTemplatesForm);
    });

  });

  describe('CreateTemplates action', () => {

    it('should be saving and disabled', () => {
      const action = new CreateTemplates();
      const state = templatesFormReducer(undefined, action);

      expect(state.templatesForm.isEnabled).toBe(false);
      expect(state.isSaving).toBe(true);
    });

  });

  describe('UpdateTemplates action', () => {

    it('should be saving and disabled', () => {
      const action = new UpdateTemplates();
      const state = templatesFormReducer(undefined, action);

      expect(state.templatesForm.isEnabled).toBe(false);
      expect(state.isSaving).toBe(true);
    });

  });

  describe('SaveTemplatesFormSuccess action', () => {

    it('should not be saving', () => {
      const action = new SaveTemplatesFormSuccess();
      const state = templatesFormReducer(generateTemplatesFormState({ isSaving: true }), action);

      expect(state.isSaving).toBe(false);
    });

  });

  describe('SaveTemplatesFormError action', () => {

    it('should not be saving and enabled', () => {
      const templatesForm = disable(generateTemplatesForm());
      const action = new SaveTemplatesFormError({ error: new Error() });
      const state = templatesFormReducer(generateTemplatesFormState({ isSaving: true, templatesForm }), action);

      expect(state.templatesForm.isEnabled).toBe(true);
      expect(state.isSaving).toBe(false);
    });

  });

  describe('DeleteTemplate action', () => {

    it('should remove a template from the form', () => {
      const template = generateTemplate({ id: 'ID1', name: 'template 1' });
      const templatesForm = generateTemplatesForm({ templates: [template] });

      const action = new DeleteTemplate({ template });
      const state = templatesFormReducer(generateTemplatesFormState({ templatesForm }), action);

      expect(state.templatesForm.isPristine).toBe(false);
      expect(state.templatesForm.value.templates.length).toEqual(0);
    });

  });

  describe('UnloadTemplates action', () => {

    it('should return the initial state', () => {
      const templates = [
        generateTemplate({ id: 'ID1', name: 'template 1' }),
        generateTemplate({ id: 'ID2', name: 'template 2' }),
        generateTemplate({ id: 'ID3', name: 'template 3' }),
      ];
      const templatesForm = generateTemplatesForm({ templates });
      const defaultTemplatesForm = templatesForm.value;

      const action = new UnloadTemplates();
      const state = templatesFormReducer(generateTemplatesFormState({ isLoaded: true, templatesForm, defaultTemplatesForm }), action);

      expect(state).toEqual(templatesFormState);
    });

  });

  describe('LoadSelectedTemplateError action', () => {

    it('should return the initial state', () => {
      const templates = [
        generateTemplate({ id: 'ID1', name: 'template 1' }),
        generateTemplate({ id: 'ID2', name: 'template 2' }),
        generateTemplate({ id: 'ID3', name: 'template 3' }),
      ];
      const templatesForm = generateTemplatesForm({ templates });
      const defaultTemplatesForm = templatesForm.value;

      const action = new LoadSelectedTemplateError({ error: new Error() });
      const state = templatesFormReducer(generateTemplatesFormState({ isLoaded: true, templatesForm, defaultTemplatesForm }), action);

      expect(state).toEqual(templatesFormState);
    });

  });

  describe('UpdateNewTemplate action', () => {

    it('should add a new template in the newTemplates array', () => {
      const type = TemplateType.USER;
      const owner = 'A123456';
      const userView: UserView = { nodes: [], hiddenNodes: {}, nodesPosition: [[], [], [], []] };
      const checked = true;
      const template = generateTemplate({ id: undefined, name: undefined, type, owner, ...userView });

      const action = new UpdateNewTemplate({ type, owner, userView, checked });
      const state = templatesFormReducer(undefined, action);

      expect(isSameTemplate(state.templatesForm.value.newTemplates[0], template)).toBe(true);
      expect(state.templatesForm.isPristine).toBe(false);
    });

    it('should add a new template in the newTemplates array and generate errors', () => {
      const type = TemplateType.USER;
      const owner = 'A123456';
      const userView: UserView = { nodes: [], hiddenNodes: {}, nodesPosition: [[], [], [], []] };
      const checked = true;
      const template = generateTemplate({ id: 'templateId', name: 'newName', type, owner, ...userView });
      const newtemplate = generateTemplate({ id: undefined, name: undefined, type, owner, ...userView });

      const action = new UpdateNewTemplate({ type, owner, userView, checked });
      const state = templatesFormReducer(generateTemplatesFormState({ templatesForm: generateTemplatesForm({ templates: [template], newTemplatesName: 'newName' }) }), action);

      expect(isSameTemplate(state.templatesForm.value.newTemplates[0], newtemplate)).toBe(true);
      expect(state.templatesForm.isPristine).toBe(false);
      expect(state.templatesForm.isValid).toBe(false);
    });

    it('should remove a template of the newTemplates array', () => {
      const type = TemplateType.USER;
      const owner = 'A123456';
      const userView: UserView = { nodes: [], hiddenNodes: {}, nodesPosition: [[], [], [], []] };
      const checked = false;
      const template = generateTemplate({ id: undefined, name: undefined, type, owner, ...userView });

      const action = new UpdateNewTemplate({ type, owner, userView, checked });
      const state = templatesFormReducer(generateTemplatesFormState({ templatesForm: generateTemplatesForm({ newTemplates: [template] }) }), action);

      expect(state.templatesForm.value.newTemplates.length).toEqual(0);
      expect(state.templatesForm.isPristine).toBe(false);
    });

  });

  describe('ToggleUpdateTemplate action', () => {

    it('should update the selected template with the user view', () => {
      const userView: UserView = { nodes: [], hiddenNodes: { BDDF: ['BDDF'] }, nodesPosition: [[], ['CDN'], [], []] };
      const newTemplate = generateTemplate({ ...userView });

      const templateView: UserView = { nodes: [], hiddenNodes: {}, nodesPosition: [[], [], [], []] };
      const defaultTemplate = generateTemplate({ ...templateView });

      const checked = true;

      const action = new ToggleUpdateTemplate({ updatedTemplate: defaultTemplate, checked, userView });
      const state = templatesFormReducer(generateTemplatesFormState({ templatesForm: generateTemplatesForm({ templates: [defaultTemplate] }), defaultTemplatesForm: generateTemplatesForm({ templates: [defaultTemplate] }).value }), action);

      expect(isSameTemplate(state.templatesForm.value.templates[0], newTemplate)).toBe(true);
      expect(state.templatesForm.isPristine).toBe(false);
    });

    it('should revert the selected template to its default value', () => {
      const userView: UserView = { nodes: [], hiddenNodes: { BDDF: ['BDDF'] }, nodesPosition: [[], ['CDN'], [], []] };
      const newTemplate = generateTemplate({ ...userView });

      const templateView: UserView = { nodes: [], hiddenNodes: {}, nodesPosition: [[], [], [], []] };
      const defaultTemplate = generateTemplate({ ...templateView });

      const checked = false;

      const action = new ToggleUpdateTemplate({ updatedTemplate: newTemplate, checked, userView });
      const state = templatesFormReducer(generateTemplatesFormState({ templatesForm: generateTemplatesForm({ templates: [newTemplate, generateTemplate({ id: 'templateId' })] }), defaultTemplatesForm: generateTemplatesForm({ templates: [defaultTemplate, generateTemplate({ id: 'templateId' })] }).value }), action);

      expect(isSameTemplate(state.templatesForm.value.templates[0], defaultTemplate)).toBe(true);
    });

  });

});
