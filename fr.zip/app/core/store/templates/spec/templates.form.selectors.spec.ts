import { createFormGroupState, markAsDirty } from 'ngrx-forms';
import { Template, TemplatesFormState, TemplatesFormValue, TemplateType } from "../templates.form.model";
import { templatesFormState } from '../templates.form.reducer';
import { getTemplatesForm, getTemplatesValues, getUpdatedTemplates, isModified, isTemplatesFormLoaded, isTemplatesFormLoading, isTemplatesFormLoadingOrSaving } from '../templates.form.selectors';

const generateTemplatesFormState = (state?: Partial<TemplatesFormState>) => {
  return {
    ...templatesFormState,
    ...state,
  };
};

const generateTemplatesForm = (templatesForm?: Partial<TemplatesFormValue>) => createFormGroupState<TemplatesFormValue>('ADMIN_TEMPLATES_FORM', {
  ...templatesFormState.templatesForm.value,
  ...templatesForm,
});

const generateTemplate = (template?: Partial<Template>): Template => {
  return {
    id: 'id',
    name: 'name',
    type: TemplateType.USER,
    owner: 'userId',
    nodes: [],
    hiddenNodes: {},
    nodesPosition: [[], [], [], []],
    ...template,
  }
}

describe('Templates Selectors', () => {

  describe('getTemplatesForm', () => {

    it('should return the form', () => {
      expect(getTemplatesForm.projector(templatesFormState)).toEqual(templatesFormState.templatesForm);
    });

  });

  describe('isTemplatesFormLoading', () => {

    it('shouldn\'t be loading', () => {
      expect(isTemplatesFormLoading.projector(templatesFormState)).toBe(false);
    });

    it('should be loading', () => {
      expect(isTemplatesFormLoading.projector(generateTemplatesFormState({ isLoading: true }))).toBe(true);
    });

  });

  describe('isTemplatesFormLoaded', () => {

    it('shouldn\'t be loaded', () => {
      expect(isTemplatesFormLoaded.projector(templatesFormState)).toBe(false);
    });

    it('should be loaded', () => {
      expect(isTemplatesFormLoaded.projector(generateTemplatesFormState({ isLoaded: true }))).toBe(true);
    });

  });

  describe('isTemplatesFormLoadingOrSaving', () => {

    it('shouldn\'t be loading or saving', () => {
      expect(isTemplatesFormLoadingOrSaving.projector(templatesFormState)).toBe(false);
    });

    it('should be loading or saving', () => {
      expect(isTemplatesFormLoadingOrSaving.projector(generateTemplatesFormState({ isLoading: true }))).toBe(true);
      expect(isTemplatesFormLoadingOrSaving.projector(generateTemplatesFormState({ isSaving: true }))).toBe(true);
    });

  });

  describe('isModified', () => {

    it('shouldn\'t be modified', () => {
      expect(isModified.projector(generateTemplatesFormState({ templatesForm: generateTemplatesForm() }))).toBe(false);
      expect(isModified.projector(generateTemplatesFormState({ isLoading: true }))).toBe(false);
    });

    it('should be modified', () => {
      expect(isModified.projector(generateTemplatesFormState({ templatesForm: markAsDirty(generateTemplatesForm()) }))).toBe(true);
    });

  });

  describe('getTemplatesValues', () => {

    it('should return the form value', () => {
      expect(getTemplatesValues.projector(generateTemplatesForm())).toEqual(generateTemplatesForm().value);
    });

  });

  describe('getUpdatedTemplates', () => {

    it('should be empty', () => {
      expect(getUpdatedTemplates.projector(templatesFormState)).toEqual([]);
    });

    it('should return one template', () => {
      const templatesForm = generateTemplatesForm({ templates: [
        generateTemplate({ id: 'ID1', name: 'template 1 updated' }),
        generateTemplate({ id: 'ID2', name: 'template 2' }),
        generateTemplate({ id: 'ID3', name: 'template 3' }),
      ] });
      const defaultTemplatesForm = generateTemplatesForm({ templates: [
        generateTemplate({ id: 'ID1', name: 'template 1' }),
        generateTemplate({ id: 'ID2', name: 'template 2' }),
        generateTemplate({ id: 'ID3', name: 'template 3' }),
      ] }).value;

      expect(getUpdatedTemplates.projector(generateTemplatesFormState({ templatesForm, defaultTemplatesForm }))).toEqual([generateTemplate({ id: 'ID1', name: 'template 1 updated' })]);
    });

  });

} );
