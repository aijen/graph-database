import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { TemplatesFormEffects } from './templates.form.effects';
import { templatesFormReducer } from './templates.form.reducer';

@NgModule({
  declarations: [],
  imports: [
    StoreModule.forFeature('templatesForm', templatesFormReducer),
    EffectsModule.forFeature([TemplatesFormEffects]),
  ]
})
export class TemplatesFormStoreModule { }
