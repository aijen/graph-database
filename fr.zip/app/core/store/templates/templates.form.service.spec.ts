import { HttpErrorResponse, HttpParams, HttpRequest } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { fakeAsync, TestBed, tick } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { User } from 'core/models/user.model';
import { UserRole } from 'core/models/userRoles.model';
import { DELETE_TEMPLATES_URL, LOAD_TEMPLATES_URL, SAVE_TEMPLATES_URL, SET_USER_VIEW_FROM_TEMPLATE } from 'core/services/http/http-client.service';
import isEqual from 'lodash/isEqual';
import { configureTestSuite } from 'ng-bullet';
import { createFormGroupState, FormGroupState } from 'ngrx-forms';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { LoadTemplatesFormError, LoadTemplatesFormSuccess } from './templates.form.actions';
import { Template, TemplatesFormState, TemplatesFormValue, TemplateType } from './templates.form.model';
import { templatesFormState } from './templates.form.reducer';
import { TemplatesFormService } from './templates.form.service';

const generateUser = (user?: Partial<User>): User => {
  return {
    ...User.from(),
    ...user,
  }
}
const generateTemplatesFormState = (state?: Partial<TemplatesFormState>) => {
  return {
    ...templatesFormState,
    ...state,
  };
};

const generateTemplatesForm = (templatesForm?: Partial<TemplatesFormValue>) => createFormGroupState<TemplatesFormValue>('ADMIN_TEMPLATES_FORM', {
  ...templatesFormState.templatesForm.value,
  ...templatesForm,
});

const generateTemplate = (template?: Partial<Template>): Template => {
  return {
    id: 'id',
    name: 'name',
    type: TemplateType.USER,
    owner: 'userId',
    nodes: [],
    hiddenNodes: {},
    nodesPosition: [[], [], [], []],
    ...template,
  }
}

describe('TemplatesFormService', () => {
  let service: TemplatesFormService;
  let httpTestingController: HttpTestingController;
  let actions: Observable<any>;
  let store: MockStore<Partial<AppState>>;

  function fromHttpParams(params: HttpParams) {
    return params.keys()
      .map(k => ({ [k]: params.get(k) }))
      .reduce((acc, value) => ({ ...acc, ...value }), {});
  }

  function isParamsEqual(params: HttpParams, comp: any) {
    return isEqual(fromHttpParams(params), comp);
  }

  function isRequest(matcher: { url?: string, method?: string, params?: any, body?: any }) {
    return (req: HttpRequest<any>) =>
      (!matcher.url || req.url === matcher.url)
      && (!matcher.method || req.method === matcher.method)
      && (!matcher.params || isParamsEqual(req.params, matcher.params))
      && (!matcher.body || isEqual(req.body, matcher.body));
  }

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
      ],
      providers: [
        TemplatesFormService,
        provideMockStore<Partial<AppState>>({ initialState: {
          auth: { user: generateUser({ userId: 'A123456' }), isUserAuthenticated: true, profil: { profiles: [UserRole.PUBLIC], permissions: [] } },
          templatesForm: templatesFormState,
        } }),
        provideMockActions(() => actions),
      ],
    })
  });

  beforeEach( () => {
    actions = null;
    service = TestBed.get(TemplatesFormService);
    httpTestingController = TestBed.get(HttpTestingController);
    store = TestBed.get(Store);
  } );

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  describe('load templates', () => {

    it('should dispatch a LoadTemplatesFormSuccess action', () => {
      const dispatchSpy = spyOn(store, 'dispatch');
      const subject = new Subject();
      const next = jasmine.createSpy('next');
      const templates = [
        generateTemplate({ id: 'ID1', name: 'template 1' }),
        generateTemplate({ id: 'ID2', name: 'template 2' }),
        generateTemplate({ id: 'ID3', name: 'template 3' }),
      ];

      let sub = service.form$.subscribe(next);
      subject.next(null);

      httpTestingController.expectOne(isRequest({
        url: LOAD_TEMPLATES_URL,
        method: 'GET',
        params: { userId: 'A123456' },
      })).flush(templates);

      expect(dispatchSpy).toHaveBeenCalledWith(new LoadTemplatesFormSuccess({ templatesForm: { templates } }));

      sub.unsubscribe();

      sub = service.values$.subscribe(next);
      subject.next(null);

      httpTestingController.expectOne(isRequest({
        url: LOAD_TEMPLATES_URL,
        method: 'GET',
        params: { userId: 'A123456' },
      })).flush(templates);

      expect(dispatchSpy).toHaveBeenCalledWith(new LoadTemplatesFormSuccess({ templatesForm: { templates } }));

      sub.unsubscribe();
    });

    it('should dispatch LoadTemplatesFormError action', () => {
      const dispatchSpy = spyOn(TestBed.get(Store), 'dispatch');
      const subject = new Subject();
      const next = jasmine.createSpy('next');

      let sub = service.form$.subscribe(next);
      subject.next(null);

      httpTestingController.expectOne(isRequest({
        url: LOAD_TEMPLATES_URL,
        method: 'GET',
        params: { userId: 'A123456' },
      })).flush(null, new HttpErrorResponse({ status: 500 }));

      expect(dispatchSpy).toHaveBeenCalledWith( jasmine.any(LoadTemplatesFormError) );

      sub.unsubscribe();

      sub = service.values$.subscribe(next);
      subject.next(null);

      httpTestingController.expectOne(isRequest({
        url: LOAD_TEMPLATES_URL,
        method: 'GET',
        params: { userId: 'A123456' },
      })).flush(null, new HttpErrorResponse({ status: 500 }));

      expect(dispatchSpy).toHaveBeenCalledWith( jasmine.any(LoadTemplatesFormError) );

      sub.unsubscribe();
    });

    it('should select data in store', () => {
      const updatedState = generateTemplatesFormState({
        templatesForm: generateTemplatesForm({
          templates: [
            generateTemplate({ id: 'ID1', name: 'template 1' }),
            generateTemplate({ id: 'ID2', name: 'template 2' }),
            generateTemplate({ id: 'ID3', name: 'template 3' }),
          ],
        }),
        isLoaded: true,
      });
      const dispatchSpy = spyOn(TestBed.get(Store), 'dispatch');
      const formResult = new BehaviorSubject<FormGroupState<TemplatesFormValue>>(null);
      const subject = new Subject();

      store.setState({ templatesForm: updatedState });

      let sub = service.form$.subscribe(formResult);
      subject.next(null);

      httpTestingController.expectNone(LOAD_TEMPLATES_URL);

      expect(dispatchSpy).not.toHaveBeenCalled();
      expect(formResult.value).toEqual(updatedState.templatesForm);

      sub.unsubscribe();

      const valuesResult = new BehaviorSubject<TemplatesFormValue>(null);
      sub = service.values$.subscribe(valuesResult);
      subject.next(null);

      httpTestingController.expectNone(LOAD_TEMPLATES_URL);

      expect(dispatchSpy).not.toHaveBeenCalled();
      expect(valuesResult.value).toEqual(updatedState.templatesForm.value);

      sub.unsubscribe();
    });

  });

  describe('loadSelected', () => {

    it('should request the server', () => {
      const subject = new Subject();
      const next = jasmine.createSpy('next');
      const template = generateTemplate({ id: 'ID1', name: 'template 1' });
      const userId = 'A123456';

      const sub = service.loadSelected(userId, template).subscribe(next);
      subject.next(null);

      httpTestingController.expectOne(isRequest({
        url: SET_USER_VIEW_FROM_TEMPLATE,
        method: 'POST',
        body: template,
        params: { userId: 'A123456' },
      })).flush('');

      sub.unsubscribe();
    });

  });

  describe('save', () => {

    it('should request the server', fakeAsync(() => {
      const name = 'newTemplatesName';
      const templates = [
        generateTemplate({ type: TemplateType.PUBLIC }),
        generateTemplate({ type: TemplateType.GROUP }),
        generateTemplate({ type: TemplateType.USER }),
      ];

      service.save(name, templates);

      httpTestingController.expectOne(isRequest({
        url: SAVE_TEMPLATES_URL,
        method: 'POST',
        body: generateTemplate({ name: 'newTemplatesName', type: TemplateType.PUBLIC }),
      })).flush('');

      tick(2000);

      httpTestingController.expectOne(isRequest({
        url: SAVE_TEMPLATES_URL,
        method: 'POST',
        body: generateTemplate({ name: 'newTemplatesName', type: TemplateType.GROUP }),
      })).flush('');

      tick(2000);

      httpTestingController.expectOne(isRequest({
        url: SAVE_TEMPLATES_URL,
        method: 'POST',
        body: generateTemplate({ name: 'newTemplatesName', type: TemplateType.USER }),
      })).flush('');
    }));

  });

  describe('manage', () => {

    it('should request the server', fakeAsync(() => {
      const deletedId = 'IdToDelete';
      const deletedTemplates = [
        generateTemplate({ id: deletedId }),
      ];
      const updatedTemplates = [
        generateTemplate({ id: 'ID1', name: 'template 1' }),
        generateTemplate({ id: 'ID2', name: 'template 2' }),
        generateTemplate({ id: 'ID3', name: 'template 3' }),
      ];

      service.manage(deletedTemplates, updatedTemplates);

      httpTestingController.expectOne(isRequest({
        url: DELETE_TEMPLATES_URL + '/' + deletedId,
        method: 'DELETE',
      })).flush('');

      httpTestingController.expectOne(isRequest({
        url: SAVE_TEMPLATES_URL,
        method: 'PUT',
        body: generateTemplate({ id: 'ID1', name: 'template 1' }),
      })).flush('');

      tick(2000);

      httpTestingController.expectOne(isRequest({
        url: SAVE_TEMPLATES_URL,
        method: 'PUT',
        body: generateTemplate({ id: 'ID2', name: 'template 2' }),
      })).flush('');

      tick(2000);

      httpTestingController.expectOne(isRequest({
        url: SAVE_TEMPLATES_URL,
        method: 'PUT',
        body: generateTemplate({ id: 'ID3', name: 'template 3' }),
      })).flush('');

    }));

  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
