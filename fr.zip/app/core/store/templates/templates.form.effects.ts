import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { concat, of } from 'rxjs';
import { catchError, concatMap, map, switchMap, switchMapTo, take, tap, withLatestFrom } from 'rxjs/operators';
import { Node } from 'shared/models/node.model';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { getUserId$ } from '../auth/auth.selectors';
import { GetHierarchy, Ready, SaveNodes, UpdateLastRestore } from '../hierarchy/hierarchy.actions';
import { getHierarchyState } from '../hierarchy/hierarchy.selectors';
import { AddNewTemplate, CreateTemplates, LoadSelectedTemplate, LoadSelectedTemplateError, LoadTemplatesFormError, RemoveNewTemplate, SaveTemplatesFormError, SaveTemplatesFormSuccess, TemplatesFormActionTypes, UnloadTemplates, UpdateNewTemplate, UpdateTemplates } from './templates.form.actions';
import { getTemplatesValues, getUpdatedTemplates } from './templates.form.selectors';
import { TemplatesFormService } from './templates.form.service';

@Injectable()
export class TemplatesFormEffects {

  public static messages = {
    loadError: `
      Une erreur est survenue pendant le chargement de la configuration 'Templates': Veuillez réessayer
    `,
    loadSelectedError: `
      Une erreur est survenue pendant le chargement du template sélectionné : Veuillez réessayer ou contacter le support si le problème persiste
    `,
    saveSuccess: `
      Configuration sauvegardée
    `,
    saveError: `
      Une erreur est survenue pendant la sauvegarde, veuillez réessayer ou contacter le support si le problème persiste
    `,
  }

  userId$ = this.store$.pipe( getUserId$, take(1) );
  templatesValues$ = this.store$.select(getTemplatesValues);
  updatedTemplates$ = this.store$.select(getUpdatedTemplates).pipe(take(1));
  userView$ = this.store$.select(getHierarchyState).pipe(map(state => { return { nodes: Node.toJSONCollection(state.nodes), hiddenNodes: state.hiddenNodes, nodesPosition: state.nodesPosition } }));

  constructor(
    private store$: Store<AppState>,
    private actions$: Actions,
    private templatesFormService: TemplatesFormService,
    private snackbar: MessageHandler,
  ) { }

  @Effect({ dispatch: false })
  loadError$ = this.actions$.pipe(
    ofType<LoadTemplatesFormError>(TemplatesFormActionTypes.LoadTemplatesFormError),
    tap(action => { console.error(action.payload.error); this.snackbar.show({ message: TemplatesFormEffects.messages.loadError, action: 'OK', isError: true }) }),
  );

  @Effect()
  loadSelected$ = this.actions$.pipe(
    ofType<LoadSelectedTemplate>(TemplatesFormActionTypes.LoadSelectedTemplate),
    withLatestFrom(this.userId$),
    switchMap(([action, userId]) => this.templatesFormService.loadSelected(userId, action.payload.template)),
    concatMap(() => [
      new UpdateLastRestore(),
      new Ready(false),
      new GetHierarchy(),
      new UnloadTemplates(),
    ]),
    catchError((error, caught) => concat(of(new LoadSelectedTemplateError({ error })), caught)),
  );

  @Effect({ dispatch: false })
  loadSelectedError$ = this.actions$.pipe(
    ofType<LoadSelectedTemplateError>(TemplatesFormActionTypes.LoadSelectedTemplateError),
    tap(action => { console.error(action.payload.error); this.snackbar.show({ message: TemplatesFormEffects.messages.loadSelectedError, action: 'OK', isError: true }) }),
  );

  @Effect()
  save$ = this.actions$.pipe(
    ofType<CreateTemplates>(TemplatesFormActionTypes.CreateTemplates),
    withLatestFrom(this.templatesValues$),
    switchMap(([action, { newTemplates, newTemplatesName }]) => this.templatesFormService.save(newTemplatesName, newTemplates)),
    map(() => new SaveTemplatesFormSuccess()),
    catchError((error, caught) => concat(of(new SaveTemplatesFormError({ error })), caught)),
  );

  @Effect()
  update$ = this.actions$.pipe(
    ofType<UpdateTemplates>(TemplatesFormActionTypes.UpdateTemplates),
    switchMapTo(this.updatedTemplates$),
    withLatestFrom(this.templatesValues$),
    switchMap(([updatedTemplates, { deletedTemplates }]) => this.templatesFormService.manage(deletedTemplates, updatedTemplates)),
    map(() => new SaveTemplatesFormSuccess()),
    catchError((error, caught) => concat(of(new SaveTemplatesFormError({ error })), caught)),
  );

  @Effect()
  saveSuccess$ = this.actions$.pipe(
    ofType<SaveTemplatesFormSuccess>(TemplatesFormActionTypes.SaveTemplatesFormSuccess),
    tap(() => this.snackbar.show({ message: TemplatesFormEffects.messages.saveSuccess })),
    map(() => new UnloadTemplates()),
    concatMap(() => [
      new SaveNodes(),
      new UnloadTemplates(),
    ]),
  );

  @Effect({ dispatch: false })
  saveError$ = this.actions$.pipe(
    ofType<SaveTemplatesFormError>(TemplatesFormActionTypes.SaveTemplatesFormError),
    tap(action => { console.error(action.payload.error); this.snackbar.show({ message: TemplatesFormEffects.messages.saveError, action: 'OK', isError: true }) }),
  );

  @Effect()
  addNew$ = this.actions$.pipe(
    ofType<AddNewTemplate>(TemplatesFormActionTypes.AddNewTemplate),
    withLatestFrom(this.userView$),
    map(([{ payload: { type, owner } }, userView]) => new UpdateNewTemplate({type, owner, userView, checked: true})),
  );

  @Effect()
  removeNew$ = this.actions$.pipe(
    ofType<RemoveNewTemplate>(TemplatesFormActionTypes.RemoveNewTemplate),
    withLatestFrom(this.userView$),
    map(([{ payload: { type, owner } }, userView]) => new UpdateNewTemplate({type, owner, userView, checked: false})),
  );

}
