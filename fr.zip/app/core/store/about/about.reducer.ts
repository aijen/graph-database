import { META_TYPE } from '../notifications/notifications.model';
import { AboutActionTypes, AboutActionUnion } from './about.actions';
import { AboutState } from './about.model';

export const aboutState: AboutState = {
  about: {
    appCount: null,
    metas: {
      [META_TYPE.AVAILABILITY]: null,
      [META_TYPE.PERFORMANCE]: null,
      [META_TYPE.RISK]: null,
      [META_TYPE.USER_XP]: null,
    }
  },
  isLoading: false,
};

export function aboutReducer(
  state = aboutState,
  action: AboutActionUnion
): AboutState {

  switch( action.type ) {

    case AboutActionTypes.LoadAbout: {
      return {
        ...state,
        isLoading: true,
      };
    }
    case AboutActionTypes.LoadAboutError: {
      return {
        ...state,
        isLoading: false,
      };
    }
    // Optimistic save, assumes no change were done on the server between saves
    case AboutActionTypes.LoadAboutSuccess: {
      const { about } = action.payload;

      return {
        ...state,
        about,
        isLoading: false,
      };
    }

    default: {
      return state;
    }
  }
}
