import { aboutState } from '../about.reducer';
import { getAbout, isAboutLoading } from '../about.selectors';

describe('About Selectors', () => {

  describe('getAbout', () => {

    it('should return state.about', () => {
      expect(getAbout.projector(aboutState)).toBe(aboutState.about);
    });

  });

  describe('isAboutLoading', () => {

    it('should return state.isLoading', () => {
      expect(isAboutLoading.projector(aboutState)).toBe(aboutState.isLoading);
    });

  });

} );
