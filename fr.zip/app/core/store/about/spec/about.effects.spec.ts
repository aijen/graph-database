import { TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { META_TYPE } from 'core/store/notifications/notifications.model';
import { configureTestSuite } from 'ng-bullet';
import { NEVER, Observable, of, throwError } from 'rxjs';
import { marbles } from 'rxjs-marbles/jasmine';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { LoadAbout, LoadAboutError, LoadAboutSuccess } from '../about.actions';
import { AboutEffects } from '../about.effects';
import { AboutValue } from '../about.model';
import { AboutService } from '../about.service';

describe('AboutEffects', () => {
  let service: AboutEffects;
  let actions: Observable<any>;
  let aboutServiceStub: jasmine.SpyObj<AboutService>;
  let messageHandlerStub: jasmine.SpyObj<MessageHandler>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
      ],
      providers: [
        AboutEffects,
        provideMockStore<Partial<AppState>>({ initialState: {} }),
        provideMockActions(() => actions),
        { provide: AboutService, useFactory: () => jasmine.createSpyObj('AboutService', ['load'] as Array<keyof AboutService>) },
        { provide: MessageHandler, useFactory: () => jasmine.createSpyObj('MessageHandler', ['ngOnDestroy', 'show'] as Array<keyof MessageHandler>) },
      ],
    })
  });

  beforeEach( () => {
    actions = null;
    aboutServiceStub = TestBed.get(AboutService);
    messageHandlerStub = TestBed.get(MessageHandler);
    service = TestBed.get(AboutEffects);
  } );

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  describe('load$', () => {

    it('should call AboutService#load', () => {
      aboutServiceStub.load.and.returnValue( NEVER );
      actions = of(new LoadAbout);

      expect(aboutServiceStub.load).not.toHaveBeenCalled();
      const sub = service.load$.subscribe();
      expect(aboutServiceStub.load).toHaveBeenCalled();

      sub.unsubscribe();
    });

    it('should dispatch a LoadAboutSuccess Action', marbles( m => {
      const about = {
        appCount: 0,
        metas: {
          [META_TYPE.AVAILABILITY]: 0,
          [META_TYPE.PERFORMANCE]: 0,
          [META_TYPE.RISK]: 0,
          [META_TYPE.USER_XP]: 0,
        }
      };
      aboutServiceStub.load.and.returnValue( of<AboutValue>(about) );
      actions = m.hot('a', { a: new LoadAbout });
      const expected = m.hot('a', { a: new LoadAboutSuccess( { about } ) });

      m.expect(service.load$).toBeObservable(expected);

    }));

    it('should dispatch a LoadAboutError Action in case of error and not complete', marbles( m => {
      const error = new Error('LoadAboutError');
      aboutServiceStub.load.and.returnValue( throwError(error) );
      actions = m.hot('a', { a: new LoadAbout });
      const expected = m.hot('a', { a: new LoadAboutError( { error } ) });

      m.expect(service.load$).toBeObservable(expected);
    }));

  });

  describe('loadError$', () => {

    it('should log and show a message about the error', () => {
      const spy = spyOn(console, 'error');
      actions = of(new LoadAboutError({ error: new Error() }));

      expect(spy).not.toHaveBeenCalled();
      expect(messageHandlerStub.show).not.toHaveBeenCalled();
      const sub = service.loadError$.subscribe();
      expect(spy).toHaveBeenCalled();
      expect(messageHandlerStub.show).toHaveBeenCalled();

      sub.unsubscribe();
    });

  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
