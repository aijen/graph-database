import { META_TYPE } from 'core/store/notifications/notifications.model';
import { AppState } from 'shared/models/state.model';
import { LoadAbout, LoadAboutError, LoadAboutSuccess } from '../about.actions';
import { aboutReducer, aboutState } from '../about.reducer';

// necessary to avoid the error :
// Invalid module name in augmentation, module 'shared/models/state.model' cannot be found.
let happy_compiler: AppState; // tslint:disable-line

describe('About Reducer', () => {

  describe('undefined action', () => {

    it('should return the default state', () => {
      const action = { type: null, payload: null };
      const state = aboutReducer( undefined, action );

      expect(state).toBe(aboutState);
    });

  });

  describe('LoadAbout action', () => {

    it('should set `isLoading` to true', () => {
      const action = new LoadAbout;
      const state = aboutReducer( {...aboutState, isLoading: false}, action );

      expect(state).toEqual({...aboutState, isLoading: true});
    });

  });

  describe('LoadAboutError action', () => {

    it('should set `isLoading` to false', () => {
      const action = new LoadAboutError({ error: new Error() });
      const state = aboutReducer( {...aboutState, isLoading: true}, action );

      expect(state).toEqual({...aboutState, isLoading: false});
    });

  });

  describe('LoadAboutSuccess action', () => {

    it('should set `isLoading` to false and update `about`', () => {
      const about = {
        appCount: 0,
        metas: {
          [META_TYPE.AVAILABILITY]: 0,
          [META_TYPE.PERFORMANCE]: 0,
          [META_TYPE.RISK]: 0,
          [META_TYPE.USER_XP]: 0,
        }
      };
      const action = new LoadAboutSuccess({ about });
      const state = aboutReducer( {...aboutState, isLoading: true}, action );

      expect(state).toEqual({...aboutState, isLoading: false, about});
    });

  });



} );
