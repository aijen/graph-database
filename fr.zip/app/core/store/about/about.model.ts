import { META_TYPE } from '../notifications/notifications.model';

declare module 'shared/models/state.model' {
  export interface AppState {
    readonly about: AboutState;
  }
}
export interface AboutValue {
  appCount: number;
  metas: {
    [META_TYPE.AVAILABILITY]: number,
    [META_TYPE.PERFORMANCE]: number,
    [META_TYPE.RISK]: number,
    [META_TYPE.USER_XP]: number,
  }
}

export interface AboutState {
  about: AboutValue;
  isLoading: boolean;
}
