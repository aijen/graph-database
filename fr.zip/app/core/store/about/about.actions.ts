import { Action } from '@ngrx/store';
import { AboutValue } from './about.model';

export enum AboutActionTypes {
  LoadAbout = '[About] Load',
  LoadAboutSuccess = '[About] LoadSuccess',
  LoadAboutError = '[About] LoadError',
}

export class LoadAbout implements Action {
  readonly type = AboutActionTypes.LoadAbout;
  constructor() {}
}

export class LoadAboutSuccess implements Action {
  readonly type = AboutActionTypes.LoadAboutSuccess;
  constructor( public payload: { about: AboutValue } ) {}
}

export class LoadAboutError implements Action {
  readonly type = AboutActionTypes.LoadAboutError;
  constructor( public payload: { error: Error } ) {}
}

export type AboutActionUnion =
  | LoadAbout
  | LoadAboutSuccess
  | LoadAboutError
  ;
