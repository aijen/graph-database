import { TestBed } from '@angular/core/testing';
import { ApiNodesService } from 'core/services/api/api.nodes';
import { HierarchyService } from 'core/services/hierarchy/hierarchy.service';
import { environment } from 'env/environment';
import { configureTestSuite } from 'ng-bullet';
import { of } from 'rxjs';
import { marbles } from 'rxjs-marbles/jasmine';
import { Leaf } from 'shared/models/leaf.model';
import { META_TYPE } from '../notifications/notifications.model';
import { AboutService } from './about.service';

describe('AboutService', () => {
  let service: AboutService;
  let apiNodesServiceStub: jasmine.SpyObj<ApiNodesService>;
  let hierarchyServiceStub: jasmine.SpyObj<HierarchyService>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
      ],
      providers: [
        AboutService,
        { provide: ApiNodesService, useFactory: () => jasmine.createSpyObj('ApiNodesService', ['getUserNodes', 'getNodes', 'saveNodes', 'getLeavesByGivenCriteria', 'hideNodeFromTree', 'restoreDefaultsNodes'] as Array<keyof ApiNodesService>) },
        { provide: HierarchyService, useFactory: () => jasmine.createSpyObj('HierarchyService', ['hideNodeOnTree', 'getLeavesKeys', 'populateMetas', 'getLeavesUrl', 'calculatePercents', 'calculateNodesAlerts'] as Array<keyof HierarchyService>) },
      ],
    })
  });

  beforeEach( () => {
    apiNodesServiceStub = TestBed.get(ApiNodesService);
    hierarchyServiceStub = TestBed.get(HierarchyService);
    service = TestBed.get(AboutService);
  } );

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  describe('#load', () => {

    it('should load the about config', marbles(m => {
      apiNodesServiceStub.getNodes.and.returnValue( of({ nodes: [] }) );
      hierarchyServiceStub.getLeavesKeys.and.returnValue( ['leaf'] );
      apiNodesServiceStub.getLeavesByGivenCriteria.and.returnValue( of([ { metas: [{ metaType: META_TYPE.AVAILABILITY }] } as DeepPartial<Leaf> ]) );

      m.expect(service.load()).toBeObservable('(a|)', { a: {
        appCount: 1,
        metas: {
          AVAILABILITY: 1,
          PERFORMANCE: 0,
          RISK: 0,
          USER_XP: 0,
        }
      } })
    }));

    it('should log an error if finding an unknown metaType and not in production', () => {
      apiNodesServiceStub.getNodes.and.returnValue( of({ nodes: [] }) );
      hierarchyServiceStub.getLeavesKeys.and.returnValue( ['leaf'] );
      apiNodesServiceStub.getLeavesByGivenCriteria.and.returnValue( of([ { metas: [{ metaType: 'metaType' }] } as DeepPartial<Leaf> ]) );
      const spy = spyOn(console, 'error');
      const production = environment.production;

      environment.production = false;

      expect(spy).not.toHaveBeenCalled();
      service.load().subscribe();
      expect(spy).toHaveBeenCalled();

      environment.production = true;
      spy.calls.reset();

      expect(spy).not.toHaveBeenCalled();
      service.load().subscribe();
      expect(spy).not.toHaveBeenCalled();

      environment.production = production;
    });

  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
