import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { concat, of } from 'rxjs';
import { catchError, map, switchMap, tap } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { AboutActionTypes, LoadAbout, LoadAboutError, LoadAboutSuccess } from './about.actions';
import { AboutService } from './about.service';

@Injectable()
export class AboutEffects {

  public static messages = {
    loadError: `
      Une erreur est survenue pendant le chargement de la configuration 'About': Veuillez réessayer
    `,
  }

  constructor(
    private store$: Store<AppState>,
    private actions$: Actions,
    private aboutService: AboutService,
    private snackbar: MessageHandler,
  ) {}

  @Effect()
  load$ = this.actions$.pipe(
    ofType<LoadAbout>( AboutActionTypes.LoadAbout ),
    switchMap( () => this.aboutService.load() ),
    map( about => new LoadAboutSuccess( { about } ) ),
    catchError( (error, caught) => concat(of(new LoadAboutError( { error } )), caught) ),
  );

  @Effect({ dispatch: false })
  loadError$ = this.actions$.pipe(
    ofType<LoadAboutError>( AboutActionTypes.LoadAboutError ),
    tap( action => { console.error(action.payload.error); this.snackbar.show( { message: AboutEffects.messages.loadError, action: 'OK', isError: true } )} ),
  );

}
