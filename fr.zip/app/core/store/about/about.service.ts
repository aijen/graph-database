import { Injectable } from '@angular/core';
import { ApiNodesService } from 'core/services/api/api.nodes';
import { HierarchyService } from 'core/services/hierarchy/hierarchy.service';
import { environment } from 'env/environment';
import moment from 'moment';
import { Observable } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';
import { Leaf } from 'shared/models/leaf.model';
import { META_TYPE } from '../notifications/notifications.model';
import { AboutValue } from './about.model';

@Injectable({
  providedIn: 'root'
})
export class AboutService {

  constructor(
    private apiNodesService: ApiNodesService,
    private hierarchyService: HierarchyService,
  ) {}

  load(): Observable<AboutValue> {
    return this.apiNodesService.getNodes().pipe(
      switchMap( ({ nodes }) => {
        const leaves = this.hierarchyService.getLeavesKeys(nodes);
        return this.getMetas( leaves.join(',') ).pipe( map( metas => ({ appCount: leaves.length, metas }) ) );
      } )
    );
  }

  private getMetas( leaves: string ) {
    const oneDayInMinutes = 24*60;
    const now = moment();
    const nowUnix = now.unix();
    const oneDayAgoUnix = now.clone().subtract(oneDayInMinutes, 'minutes').unix();
    return this.apiNodesService.getLeavesByGivenCriteria( leaves, oneDayAgoUnix, nowUnix, oneDayInMinutes ).pipe( map( this.countMetas ));
  }

  private countMetas( leaves: Leaf[] ) {

    const metas = {
      [META_TYPE.AVAILABILITY]: 0,
      [META_TYPE.PERFORMANCE]: 0,
      [META_TYPE.RISK]: 0,
      [META_TYPE.USER_XP]: 0,
    }

    for( const leaf of leaves ) {
      for( const { metaType } of leaf.metas ) {
        if( metaType in metas ) {
          metas[metaType]++;
        } else if( !environment.production ) {
          console.error( new Error(`unknown meta: ${metaType}`) );
        }
      }
    }

    return metas;
  }

}
