import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { AboutEffects } from './about.effects';
import { aboutReducer } from './about.reducer';

@NgModule({
  declarations: [],
  imports: [
    StoreModule.forFeature('about', aboutReducer),
    EffectsModule.forFeature([AboutEffects]),
  ]
})
export class AboutStoreModule { }
