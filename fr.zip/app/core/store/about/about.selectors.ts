import { createFeatureSelector, createSelector } from '@ngrx/store';
import { AboutState } from './about.model';

export const aboutStateSelector = createFeatureSelector<AboutState>(
  'about'
);

export const getAbout = createSelector(
  aboutStateSelector,
  state => state.about,
);

export const isAboutLoading = createSelector(
  aboutStateSelector,
  state => state.isLoading,
);
