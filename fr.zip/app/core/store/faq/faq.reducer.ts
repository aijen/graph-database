import { FaqActionTypes, FaqActionUnion } from './faq.actions';
import { FaqState } from './faq.model';

export const faqState: FaqState = {
  faq: [],
  isLoading: false,
  isSaving: false,
};

export function faqReducer(
  state = faqState,
  action: FaqActionUnion
): FaqState {

  switch( action.type ) {

    case FaqActionTypes.LoadFaq: {
      return {
        ...state,
        isLoading: true,
      };
    }
    case FaqActionTypes.LoadFaqError: {
      return {
        ...state,
        isLoading: false,
      };
    }
    // Optimistic save, assumes no change were done on the server between saves
    case FaqActionTypes.LoadFaqSuccess: {
      const { faq } = action.payload;

      return {
        ...state,
        faq,
        isLoading: false,
      };
    }

    case FaqActionTypes.SaveFaq: {
      return {
        ...state,
        isSaving: true,
      };
    }
    case FaqActionTypes.SaveFaqError:
    case FaqActionTypes.SaveFaqSuccess: {
      return {
        ...state,
        isSaving: false,
      };
    }

    default: {
      return state;
    }
  }
}
