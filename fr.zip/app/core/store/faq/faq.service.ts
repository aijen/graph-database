import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LOAD_FAQ_URL, SAVE_FAQ_URL } from 'core/services/http/http-client.service';
import { FAQ } from './faq.model';

@Injectable({
  providedIn: 'root'
})
export class FaqService {

  constructor(
    private http: HttpClient,
  ) {}

  load() {
    return this.http.get<FAQ[]>(LOAD_FAQ_URL);
  }

  save(faq: FAQ[]) {
    return this.http.put(SAVE_FAQ_URL, faq, { responseType: 'text' });
  }

}
