
declare module 'shared/models/state.model' {
  export interface AppState {
    readonly faq: FaqState;
  }
}

export interface FAQ {
  title: string;
  description?: string;
  faq?: FAQ[];
}

export interface FaqState {
  faq: FAQ[];
  isLoading: boolean;
  isSaving: boolean;
}
