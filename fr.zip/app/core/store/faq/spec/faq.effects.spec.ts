import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { configureTestSuite } from 'ng-bullet';
import { Observable } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { FaqEffects } from '../faq.effects';
import { faqState } from '../faq.reducer';
import { FaqService } from '../faq.service';

describe('Faq Effects', () => {
  let service: FaqEffects;
  let actions: Observable<any>;
  let faqServiceStub: jasmine.SpyObj<FaqService>;
  let messageHandlerStub: jasmine.SpyObj<MessageHandler>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule
      ],
      providers: [
        FaqEffects,
        provideMockActions(() => actions),
        provideMockStore<Partial<AppState>>({ initialState: { faq: faqState } }),
        { provide: FaqService, useFactory: () => jasmine.createSpyObj('FaqService', ['load', 'save'] as Array<keyof FaqService>) },
        { provide: MessageHandler, useFactory: () => jasmine.createSpyObj('MessageHandler', ['ngOnDestroy', 'show'] as Array<keyof MessageHandler>) },
      ]
    });
  } );

  beforeEach(() => {
    actions = null;
    faqServiceStub = TestBed.get(FaqService);
    messageHandlerStub = TestBed.get(MessageHandler);
    service = TestBed.get(FaqEffects);
  });

  it('should work', () => {
    expect(service).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
} );
