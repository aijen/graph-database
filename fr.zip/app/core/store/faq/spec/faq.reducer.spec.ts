import { AppState } from 'shared/models/state.model';
import { faqReducer, faqState } from '../faq.reducer';

// necessary to avoid the error :
// Invalid module name in augmentation, module 'shared/models/state.model' cannot be found.
let happy_compiler: AppState; // tslint:disable-line

describe('Faq Reducer', () => {

  describe('undefined action', () => {

    it('should return the default state', () => {
      const action = { type: null, payload: null };
      const state = faqReducer( undefined, action );

      expect(state).toBe(faqState);
    });

  });

} );
