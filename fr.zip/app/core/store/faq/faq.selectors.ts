import { createFeatureSelector, createSelector } from '@ngrx/store';
import { FaqState } from './faq.model';

export const faqStateSelector = createFeatureSelector<FaqState>(
  'faq'
);

export const getFaq = createSelector(
  faqStateSelector,
  state => state.faq,
);

export const isFaqLoadingOrSaving = createSelector(
  faqStateSelector,
  state => state.isLoading || state.isSaving,
);
