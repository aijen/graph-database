import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { FaqEffects } from './faq.effects';
import { faqReducer } from './faq.reducer';

@NgModule({
  declarations: [],
  imports: [
    StoreModule.forFeature('faq', faqReducer),
    EffectsModule.forFeature([FaqEffects]),
  ]
})
export class FaqStoreModule { }
