import {Injectable} from '@angular/core';
import {Actions, Effect, ofType} from '@ngrx/effects';
import {concat, of} from 'rxjs';
import {catchError, concatMap, map, mapTo, switchMap, tap, withLatestFrom} from 'rxjs/operators';
import {MessageHandler} from 'shared/services/messageHandler.service';
import {
  FaqUploadActionTypes,
  LoadFaqFiles,
  LoadFaqFilesError,
  LoadFaqFilesSuccess,
  SaveFaqFiles,
  SaveFaqFilesError,
  SaveFaqFilesSuccess, UnloadFaqFiles,

} from './faq-upload.actions';
import {FaqUploadService} from './faq-upload.service';
import {Store} from "@ngrx/store";
import {AppState} from "shared/models/state.model";

import {faqUploadStateSelector} from "core/store/faq/faqUpload/faq-upload.selectors";


@Injectable()
export class FaqUploadEffects {

  public static messages = {
    loadError: `
      Une erreur est survenue pendant le chargement de la configuration 'Faq': Veuillez réessayer
    `,
    SaveError: `
      Une erreur est survenue pendant la sauvegarde de la configuration 'Faq': Veuillez réessayer ou contacter le support Cockpit
    `,
    saveSuccess: `
      Configuration 'Faq' sauvegardée
    `,
  }

  deletedFiles$ = this.store$.select(faqUploadStateSelector).pipe(map(state => state.deletedFiles));

  constructor(
    private store$: Store<AppState>,
    private actions$: Actions,
    private faqUploadService: FaqUploadService,
    private snackbar: MessageHandler,
  ) {
  }

  @Effect()
  load$ = this.actions$.pipe(
    ofType<LoadFaqFiles>(FaqUploadActionTypes.LoadFaqFiles),
    switchMap(() => this.faqUploadService.load()),
    map(userFiles => new LoadFaqFilesSuccess({userFiles})),
    catchError((error, caught) => concat(of(new LoadFaqFilesError({error})), caught)),
  );

  @Effect({dispatch: false})
  loadError$ = this.actions$.pipe(
    ofType<LoadFaqFilesError>(FaqUploadActionTypes.LoadFaqFilesError),
    tap(action => {
      console.error(action.payload.error);
      this.snackbar.show({message: FaqUploadEffects.messages.loadError, action: 'OK', isError: true})
    }),
  );
  @Effect()
  save$ = this.actions$.pipe(
    ofType<SaveFaqFiles>(FaqUploadActionTypes.SaveFaqFiles),
    withLatestFrom(this.deletedFiles$),
    switchMap(([{payload: {files}}, deletedFiles]) => this.faqUploadService.delete(deletedFiles).pipe(mapTo({
      files,
      deletedFiles
    }))),
    switchMap(({files, deletedFiles}) => this.faqUploadService.upload(files).pipe(mapTo(deletedFiles))),
    concatMap(deletedFiles => [
      new SaveFaqFilesSuccess(),
     ]),
    catchError((error, caught) => concat(of(new SaveFaqFilesError({error}), caught))),
  );

  @Effect()
  saveSuccess$ = this.actions$.pipe(
    ofType<SaveFaqFilesSuccess>(FaqUploadActionTypes.SaveFaqFilesSuccess),
    tap(() => this.snackbar.show({message: FaqUploadEffects.messages.saveSuccess})),
    concatMap(() => [
      new UnloadFaqFiles(),
      new LoadFaqFiles(),
    ]),
  );

  @Effect({dispatch: false})
  saveError$ = this.actions$.pipe(
    ofType<SaveFaqFilesError>(FaqUploadActionTypes.SaveFaqFilesError),
    tap(action => {
      console.error(action.payload.error);
      this.snackbar.show({message: FaqUploadEffects.messages.SaveError, action: 'OK', isError: true})
    }),
  );

}
