import {FaqUploadActionTypes, FaqUploadActionTypesUnion} from './faq-upload.actions';
import {FaqUploadState} from './faq-upload.model';
import {UserFilesActionTypes} from "../../../../pages/tab-perimeter/store/user-files/user-files.actions";
import {sortStringCaseInsensitiveStrategy} from "core/utils/sortStrategies";
import {userFilesState} from "../../../../pages/tab-perimeter/store/user-files/user-files.reducer";

export const faqUploadState: FaqUploadState = {
  userFiles: [],
  isLoading: false,
  isSaving: false,
  deletedFiles: [],
  isPristine:true
};

export function faqUploadReducer(
  state = faqUploadState,
  action: FaqUploadActionTypesUnion
): FaqUploadState {

  switch( action.type ) {

    case FaqUploadActionTypes.LoadFaqFiles: {
      return {
        ...state,
        isLoading: true,
      };
    }
    case FaqUploadActionTypes.LoadFaqFilesError: {
      return {
        ...state,
        isLoading: false,
      };
    }
    case FaqUploadActionTypes.LoadFaqFilesSuccess: {
      const { userFiles } = action.payload;

      return {
        ...state,
        userFiles,
        isLoading: false,
        isPristine: true,
      };
    }

    case FaqUploadActionTypes.SaveFaqFiles: {
      return {
        ...state,
        isSaving:true,
      };
    }
    case FaqUploadActionTypes.SaveFaqFilesSuccess:{
      return {
        ...state,
        isLoading: false,
        isSaving: false,
      };
    }
    case FaqUploadActionTypes.SaveFaqFilesError: {
      return {
        ...state,
        isLoading: false,
        isSaving: false,
      };
    }

    case FaqUploadActionTypes.MarkUserFilesAsDirty: {
      return {
        ...state,
        isPristine: false,
      };
    }
  case FaqUploadActionTypes.DeleteFile: {
    const { fileName } = action.payload;
    const userFiles = [...state.userFiles.filter(f => f !== fileName)];
    const deletedFiles = [...state.deletedFiles, fileName];

    return {
      ...state,
      userFiles,
      deletedFiles,
      isPristine: false,
    };
  }

  case FaqUploadActionTypes.UnloadFaqFiles: {
    return faqUploadState;
  }

  case FaqUploadActionTypes.ResetUserFiles: {
    const userFiles = [...state.userFiles, ...state.deletedFiles].sort(sortStringCaseInsensitiveStrategy);
    const deletedFiles = [];

    return {
      ...state,
      userFiles,
      deletedFiles,
      isLoading:false,
      isSaving: false,
      isPristine: true,
    }
  }
    default: {
      return state;
    }
  }
}




