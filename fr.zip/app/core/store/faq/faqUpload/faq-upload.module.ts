import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { FaqUploadEffects } from './faq-upload.effects';
import { faqUploadReducer } from './faq-upload.reducer';

@NgModule({
  declarations: [],
  imports: [
    StoreModule.forFeature('faqUpload', faqUploadReducer),
    EffectsModule.forFeature([FaqUploadEffects]),
  ]
})
export class FaqUploadStoreModule { }
