
declare module 'shared/models/state.model' {
  export interface AppState {
    readonly faqUpload: FaqUploadState;
  }
}

export interface FaqUploadState {
  userFiles: string[];
  isLoading: boolean;
  isSaving: boolean;
  deletedFiles: string[];
  isPristine: boolean;
}
