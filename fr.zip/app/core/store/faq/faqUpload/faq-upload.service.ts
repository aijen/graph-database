import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {
  DELETE_FAQ_FILE,
  LIST_UPLOAD_FAQ,
  UPLOAD_FAQ_URL
} from 'core/services/http/http-client.service';
import {combineLatest, Observable, of} from "rxjs";
import {map} from "rxjs/operators";
import {sortStringCaseInsensitiveStrategy} from "core/utils/sortStrategies";
const fromJson = (files: string[]): string[] => { if(files.length>0){
  return files.sort(sortStringCaseInsensitiveStrategy);}
  else return files;
}

@Injectable({
  providedIn: 'root'
})
export class FaqUploadService {

  constructor(
    private http: HttpClient,
  ) {}

  load() {
    return this.http.get<string[]>(LIST_UPLOAD_FAQ).pipe(map(fromJson));
  }
  upload(files: File[]) {

    if(files.length === 0) {
      return combineLatest([of('')]);
    }

    const result: Observable<string>[] = [];

    for (let file of files) {
      const form = new FormData();
      form.append('file', file, file.name);
      result.push(this.http.post(UPLOAD_FAQ_URL, form, {responseType: 'text'}));
    }

    return combineLatest(result);

  }

  delete(fileNames: string[]) {
    if(fileNames.length === 0) {
      return combineLatest([of('')]);
    }

    const result: Observable<string>[] = [];

    for (let fileName of fileNames) {
      result.push(this.http.delete(DELETE_FAQ_FILE + '/' + fileName, {responseType: 'text'}));
    }

    return combineLatest(result);
  }

}
