import {Action} from '@ngrx/store';

export enum FaqUploadActionTypes {
  LoadFaqFiles = '[FaqUploadFiles] Load',
  UnloadFaqFiles = '[FaqUploadFiles] Unload',
  LoadFaqFilesSuccess = '[FaqUploadFiles] LoadSuccess',
  LoadFaqFilesError = '[FaqUploadFiles] LoadError',
  SaveFaqFiles = '[FaqUploadFiles] Save',
  SaveFaqFilesSuccess = '[FaqUploadFiles] SaveSuccess',
  SaveFaqFilesError = '[FaqUploadFiles] SaveError',
  DeleteFile = '[FaqUploadFiles] Delete',
  UnloadUserFiles = '[FaqUploadFiles] Unload',
  ResetUserFiles = '[FaqUploadFiles] Reset',
  MarkUserFilesAsDirty = '[FaqUploadFiles] MarkAsDirty',
}

export class LoadFaqFiles implements Action {
  readonly type = FaqUploadActionTypes.LoadFaqFiles;

  constructor() {
  }
}

export class UnloadFaqFiles implements Action {
  readonly type = FaqUploadActionTypes.UnloadFaqFiles;

  constructor() {
  }
}

export class LoadFaqFilesSuccess implements Action {
  readonly type = FaqUploadActionTypes.LoadFaqFilesSuccess;

  constructor(public payload: { userFiles: string[] }) {
  }
}

export class LoadFaqFilesError implements Action {
  readonly type = FaqUploadActionTypes.LoadFaqFilesError;

  constructor(public payload: { error: Error }) {
  }
}

export class SaveFaqFiles implements Action {
  readonly type = FaqUploadActionTypes.SaveFaqFiles;

  constructor(public payload: { files: File[] }) {
  }
}

export class SaveFaqFilesSuccess implements Action {
  readonly type = FaqUploadActionTypes.SaveFaqFilesSuccess;

  constructor() {
  }
}

export class SaveFaqFilesError implements Action {
  readonly type = FaqUploadActionTypes.SaveFaqFilesError;

  constructor(public payload: { error: Error }) {
  }
}

export class DeleteFile implements Action {

  readonly type = FaqUploadActionTypes.DeleteFile;

  constructor(public payload: { fileName: string }) {
  }
}

export class UnloadUserFiles implements Action {
  readonly type = FaqUploadActionTypes.UnloadUserFiles;

  constructor() {
  }
}

export class ResetUserFiles implements Action {
  readonly type = FaqUploadActionTypes.ResetUserFiles;

  constructor() {
  }
}

export class MarkUserFilesAsDirty implements Action {
  readonly type = FaqUploadActionTypes.MarkUserFilesAsDirty;

  constructor() {
  }
}


export type FaqUploadActionTypesUnion =
  | LoadFaqFiles
  | UnloadFaqFiles
  | LoadFaqFilesSuccess
  | LoadFaqFilesError
  | SaveFaqFiles
  | SaveFaqFilesSuccess
  | SaveFaqFilesError
  | DeleteFile
  | UnloadUserFiles
  | ResetUserFiles
  | MarkUserFilesAsDirty
  ;
