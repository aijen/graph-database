import { createFeatureSelector, createSelector } from '@ngrx/store';
import { FaqUploadState } from './faq-upload.model';

export const faqUploadStateSelector = createFeatureSelector<FaqUploadState>(
  'faqUpload'
);

export const getFaqFile = createSelector(
  faqUploadStateSelector,
  state => state.userFiles,
);

export const isFaqLoadingOrSaving = createSelector(
  faqUploadStateSelector,
  state => state.isSaving,
);

export const isFaqPristine = createSelector(
  faqUploadStateSelector,
  state => state.isPristine,
);
