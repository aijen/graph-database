import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { concat, of } from 'rxjs';
import { catchError, map, switchMap, tap } from 'rxjs/operators';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { FaqActionTypes, LoadFaq, LoadFaqError, LoadFaqSuccess, SaveFaq, SaveFaqError, SaveFaqSuccess } from './faq.actions';
import { FaqService } from './faq.service';

@Injectable()
export class FaqEffects {

  public static messages = {
    loadError: `
      Une erreur est survenue pendant le chargement de la configuration 'Faq': Veuillez réessayer
    `,
    SaveError: `
      Une erreur est survenue pendant la sauvegarde de la configuration 'Faq': Veuillez réessayer ou contacter le support Cockpit
    `,
  }

  constructor(
    private actions$: Actions,
    private faqService: FaqService,
    private snackbar: MessageHandler,
  ) {}

  @Effect()
  load$ = this.actions$.pipe(
    ofType<LoadFaq>( FaqActionTypes.LoadFaq ),
    switchMap( () => this.faqService.load() ),
    map( faq => new LoadFaqSuccess( { faq } ) ),
    catchError( (error, caught) => concat(of(new LoadFaqError( { error } )), caught) ),
  );

  @Effect({ dispatch: false })
  loadError$ = this.actions$.pipe(
    ofType<LoadFaqError>( FaqActionTypes.LoadFaqError ),
    tap( action => { console.error(action.payload.error); this.snackbar.show( { message: FaqEffects.messages.loadError, action: 'OK', isError: true } )} ),
  );

  @Effect()
  save$ = this.actions$.pipe(
    ofType<SaveFaq>( FaqActionTypes.SaveFaq ),
    switchMap( ({ payload: { faq } }) => this.faqService.save(faq) ),
    map( faq => new SaveFaqSuccess() ),
    catchError( (error, caught) => concat(of(new SaveFaqError( { error } )), caught) ),
  );

  @Effect()
  saveSuccess$ = this.actions$.pipe(
    ofType<SaveFaqSuccess>( FaqActionTypes.SaveFaqSuccess ),
    map(() => new LoadFaq()),
  );

  @Effect({ dispatch: false })
  saveError$ = this.actions$.pipe(
    ofType<SaveFaqError>( FaqActionTypes.SaveFaqError ),
    tap( action => { console.error(action.payload.error); this.snackbar.show( { message: FaqEffects.messages.SaveError, action: 'OK', isError: true } )} ),
  );

}
