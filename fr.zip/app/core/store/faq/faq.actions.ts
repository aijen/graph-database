import { Action } from '@ngrx/store';
import { FAQ } from './faq.model';

export enum FaqActionTypes {
  LoadFaq = '[FAQ] Load',
  LoadFaqSuccess = '[FAQ] LoadSuccess',
  LoadFaqError = '[FAQ] LoadError',
  SaveFaq = '[FAQ] Save',
  SaveFaqSuccess = '[FAQ] SaveSuccess',
  SaveFaqError = '[FAQ] SaveError',
}

export class LoadFaq implements Action {
  readonly type = FaqActionTypes.LoadFaq;
  constructor() {}
}

export class LoadFaqSuccess implements Action {
  readonly type = FaqActionTypes.LoadFaqSuccess;
  constructor( public payload: { faq: FAQ[] } ) {}
}

export class LoadFaqError implements Action {
  readonly type = FaqActionTypes.LoadFaqError;
  constructor( public payload: { error: Error } ) {}
}

export class SaveFaq implements Action {
  readonly type = FaqActionTypes.SaveFaq;
  constructor(public payload: { faq: FAQ[] }) {}
}

export class SaveFaqSuccess implements Action {
  readonly type = FaqActionTypes.SaveFaqSuccess;
  constructor() {}
}

export class SaveFaqError implements Action {
  readonly type = FaqActionTypes.SaveFaqError;
  constructor( public payload: { error: Error } ) {}
}

export type FaqActionUnion =
  | LoadFaq
  | LoadFaqSuccess
  | LoadFaqError
  | SaveFaq
  | SaveFaqSuccess
  | SaveFaqError
  ;
