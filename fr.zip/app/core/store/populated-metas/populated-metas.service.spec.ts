import { HttpErrorResponse, HttpParams, HttpRequest } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { LOAD_POPULATED_METAS_URL } from 'core/services/http/http-client.service';
import isEqual from 'lodash/isEqual';
import { configureTestSuite } from 'ng-bullet';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { metasCheckState } from '../leaves/leaves.model';
import { LoadPopulatedMetasError, LoadPopulatedMetasSuccess } from './populated-metas.actions';
import { PopulatedMetasValue } from './populated-metas.model';
import { populatedMetasState } from './populated-metas.reducer';
import { PopulatedMetasService } from './populated-metas.service';

describe('PopulatedMetasService', () => {
  let service: PopulatedMetasService;
  let httpTestingController: HttpTestingController;
  let actions: Observable<any>;
  let store: MockStore<Partial<AppState>>;

  function fromHttpParams(params: HttpParams) {
    return params.keys()
      .map(k => ({ [k]: params.get(k) }))
      .reduce((acc, value) => ({ ...acc, ...value }), {});
  }

  function isParamsEqual(params: HttpParams, comp: any) {
    return isEqual(fromHttpParams(params), comp);
  }

  function isRequest(matcher: { url?: string, method?: string, params?: any, body?: any }) {
    return (req: HttpRequest<any>) =>
      (!matcher.url || req.url === matcher.url)
      && (!matcher.method || req.method === matcher.method)
      && (!matcher.params || isParamsEqual(req.params, matcher.params))
      && (!matcher.body || isEqual(req.body, matcher.body));
  }

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
      ],
      providers: [
        PopulatedMetasService,
        provideMockStore<Partial<AppState>>({ initialState: { populatedMetas: populatedMetasState } }),
        provideMockActions(() => actions),
      ],
    })
  });

  beforeEach( () => {
    actions = null;
    service = TestBed.get(PopulatedMetasService);
    httpTestingController = TestBed.get(HttpTestingController);
    store = TestBed.get(Store);
  } );

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  describe('load populated metas', () => {

    it('should dispatch LoadPopulatedMetasSuccess action', () => {
      const dispatchSpy = spyOn(store, 'dispatch');
      const subject = new Subject();
      const next = jasmine.createSpy('next');

      let sub = service.populatedMetas$.subscribe(next);
      subject.next(null);

      httpTestingController.expectOne(isRequest({
        url: LOAD_POPULATED_METAS_URL,
        method: 'GET',
      })).flush([{ leafKey: 'leafKey', metas: { AVAILABILITY: false, PERFORMANCE: false, RISK: false, USER_XP: false } }]);

      expect(dispatchSpy).toHaveBeenCalledWith(new LoadPopulatedMetasSuccess({ populatedMetas: [{ leafKey: 'leafKey', metas: metasCheckState }] }));

      sub.unsubscribe();
    });

    it('should dispatch LoadPopulatedMetasError action', () => {
      const dispatchSpy = spyOn(TestBed.get(Store), 'dispatch');
      const subject = new Subject();
      const next = jasmine.createSpy('next');

      let sub = service.populatedMetas$.subscribe(next);
      subject.next(null);

      httpTestingController.expectOne(isRequest({
        url: LOAD_POPULATED_METAS_URL,
        method: 'GET',
      })).flush(null, new HttpErrorResponse({ status: 500 }));

      expect(dispatchSpy).toHaveBeenCalledWith( jasmine.any(LoadPopulatedMetasError) );

      sub.unsubscribe();
    });

    it('should select data in store', () => {
      const updatedState: Partial<AppState> = { populatedMetas: { populatedMetas: [{ leafKey: 'leafKey', metas: metasCheckState }], isLoading: false, isLoaded: true } };
      const dispatchSpy = spyOn(TestBed.get(Store), 'dispatch');
      const result = new BehaviorSubject<PopulatedMetasValue[]>(null);
      const subject = new Subject();

      store.setState(updatedState);

      let sub = service.populatedMetas$.subscribe(result);
      subject.next(null);

      httpTestingController.expectNone(LOAD_POPULATED_METAS_URL);

      expect(dispatchSpy).not.toHaveBeenCalled();
      expect(result.value).toEqual(updatedState.populatedMetas.populatedMetas);

      sub.unsubscribe();
    });

  });

  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
