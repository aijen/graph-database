import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { LOAD_POPULATED_METAS_URL } from 'core/services/http/http-client.service';
import { of } from 'rxjs';
import { catchError, map, share, switchMap, switchMapTo, tap } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';
import { LoadPopulatedMetas, LoadPopulatedMetasError, LoadPopulatedMetasSuccess } from './populated-metas.actions';
import { PopulatedMetasDTO, PopulatedMetasValue } from './populated-metas.model';
import { getPopulatedMetas, isPopulatedMetasLoaded } from './populated-metas.selectors';

const fromJson = ( dtos: PopulatedMetasDTO[] ): PopulatedMetasValue[] => {
  const populatedMetas: PopulatedMetasValue[] = [];

  dtos.forEach(dto => {
    populatedMetas.push({
      leafKey: dto.leafKey,
      metas: {
        availability: dto.metas.AVAILABILITY,
        performance: dto.metas.PERFORMANCE,
        risk: dto.metas.RISK,
        userXp: dto.metas.USER_XP,
      },
    });
  });

  return populatedMetas;
};

@Injectable({
  providedIn: 'root'
})
export class PopulatedMetasService {

  constructor(
    private store$: Store<AppState>,
    private http: HttpClient,
  ) {}

  private getPopulatedMetas$ = this.http.get<PopulatedMetasDTO[]>(LOAD_POPULATED_METAS_URL).pipe( map( fromJson ), share() );

  private require$ = of<void>(null).pipe(
    tap( () => this.store$.dispatch( new LoadPopulatedMetas() ) ),
    switchMapTo( this.getPopulatedMetas$ ),
    tap( populatedMetas => this.store$.dispatch( new LoadPopulatedMetasSuccess( { populatedMetas } ) ) ),
    catchError( error => (this.store$.dispatch( new LoadPopulatedMetasError( { error } ) ), of<void>(null)) ),
    share(),
  );

  private selectPopulatedMetas$ = this.store$.pipe( select( getPopulatedMetas ) );

  private getAndSelectPopulatedMetas$ = this.require$.pipe( switchMapTo( this.selectPopulatedMetas$ ) );

  populatedMetas$ = this.store$.pipe(
    select( isPopulatedMetasLoaded ),
    switchMap( loaded => loaded ? this.selectPopulatedMetas$ : this.getAndSelectPopulatedMetas$ ),
  );

}
