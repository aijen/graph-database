import { PopulatedMetasState } from '../populated-metas.model';
import { populatedMetasState } from '../populated-metas.reducer';
import { getPopulatedMetas, getPopulatedMetasForLeaf, isPopulatedMetasLoaded, isPopulatedMetasLoading } from '../populated-metas.selectors';

const generatePopulateMetasState = (state: Partial<PopulatedMetasState>) => {
  return {
    ...populatedMetasState,
    ...state,
  };
};

describe('Populated Metas Selectors', () => {
  let afterLoadState: PopulatedMetasState = generatePopulateMetasState({ populatedMetas: [{ leafKey: 'leafKey', metas: { availability: true, performance: true, risk: false, userXp: false } }], isLoading: true });
  let afterLoadSuccessState: PopulatedMetasState = generatePopulateMetasState({ isLoaded: true });

  describe('isPopulatedMetasLoading', () => {

    it('should return the loading state', () => {
      expect(isPopulatedMetasLoading.projector(populatedMetasState)).toBe(false);
      expect(isPopulatedMetasLoading.projector(afterLoadState)).toBe(true);
      expect(isPopulatedMetasLoading.projector(afterLoadSuccessState)).toBe(false);
    });

  });

  describe('isPopulatedMetasLoaded', () => {

    it('should return the loaded state', () => {
      expect(isPopulatedMetasLoaded.projector(populatedMetasState)).toBe(false);
      expect(isPopulatedMetasLoaded.projector(afterLoadState)).toBe(false);
      expect(isPopulatedMetasLoaded.projector(afterLoadSuccessState)).toBe(true);
    });

  });

  describe('getPopulatedMetas', () => {

    it('should return the config', () => {
      expect(getPopulatedMetas.projector(populatedMetasState)).toEqual(populatedMetasState.populatedMetas);
      expect(getPopulatedMetas.projector(afterLoadState)).toEqual(afterLoadState.populatedMetas);
      expect(getPopulatedMetas.projector(afterLoadSuccessState)).toEqual(afterLoadSuccessState.populatedMetas);
    });

  });

  describe('getPopulatedMetasForLeaf ', () => {

    it('should return the config for a leaf', () => {
      expect(getPopulatedMetasForLeaf('leafKey').projector(populatedMetasState.populatedMetas)).toEqual(undefined);
      expect(getPopulatedMetasForLeaf('leafKey').projector(afterLoadState.populatedMetas)).toEqual({ availability: true, performance: true, risk: false, userXp: false });
      expect(getPopulatedMetasForLeaf('leafKey').projector(afterLoadSuccessState.populatedMetas)).toEqual(undefined);
    });

  });

});
