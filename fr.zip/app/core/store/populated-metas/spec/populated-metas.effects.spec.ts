import { HttpErrorResponse } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { configureTestSuite } from 'ng-bullet';
import { Observable, Subject } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { LoadPopulatedMetasError } from '../populated-metas.actions';
import { PopulatedMetasEffects } from '../populated-metas.effects';

describe('PopulatedMetasEffects', () => {
  let service: PopulatedMetasEffects;
  let actions: Observable<any>;
  let messageHandlerStub: jasmine.SpyObj<MessageHandler>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
      ],
      providers: [
        PopulatedMetasEffects,
        provideMockStore<Partial<AppState>>({ initialState: {} }),
        provideMockActions(() => actions),
        { provide: MessageHandler, useFactory: () => jasmine.createSpyObj('MessageHandler', ['ngOnDestroy', 'show'] as Array<keyof MessageHandler>) },
      ],
    })
  });

  beforeEach( () => {
    actions = null;
    messageHandlerStub = TestBed.get(MessageHandler);
    service = TestBed.get(PopulatedMetasEffects);
  } );

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  describe('LoadPopulatedMetasError action', () => {

    it('should display an error message', () => {
      spyOn(console, 'error');
      const error = new HttpErrorResponse({});
      const snackbar = TestBed.get(MessageHandler);
      const subject = actions = new Subject();
      const next = jasmine.createSpy('next');
      const sub = service.loadPopulatedMetasError$.subscribe(next);
      subject.next(new LoadPopulatedMetasError({ error }));

      expect(console.error).toHaveBeenCalled();
      expect(snackbar.show).toHaveBeenCalled();

      sub.unsubscribe();
    });

  });

  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
