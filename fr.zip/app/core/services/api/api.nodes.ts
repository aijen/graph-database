import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { getUserId$ } from 'core/store/auth/auth.selectors';
import { NODE_KEYS_POSITION } from 'core/store/hierarchy/hierarchy.model';
import { getLastRestore } from 'core/store/hierarchy/hierarchy.selectors';
import moment from 'moment';
import { combineLatest, Observable } from 'rxjs';
import { map, switchMap, take } from 'rxjs/operators';
import { CockpitLeafDTO, cockpitLeavesFromJson } from 'shared/models/cockpit-leaf.model';
import { HierarchyInterface } from 'shared/models/Hierarchy.interface';
import { Leaf, LeafDTO } from 'shared/models/leaf.model';
import { Node } from 'shared/models/node.model';
import { AppState } from 'shared/models/state.model';
import { HIDE_NODE, LEAVES_ARCHIVED_METAS_URL, LEAVES_METAS_URL, LOAD_COCKPIT_LEAVES_URL, LOAD_USER_ARBORESCENCE_URL, RESTORE_DEFAULTS_NODES, SAVE_USER_ARBORESCENCE_URL } from '../http/http-client.service';


@Injectable({providedIn: 'root'})
export class ApiNodesService {

  userid$ = this.store$.pipe( getUserId$, take(1) );

  lastRestore$ = this.store$.select( getLastRestore ).pipe( take(1) );

  constructor(
    private httpClient: HttpClient,
    private store$: Store<AppState>,
  ) {}

  public getUserNodes() {
    return combineLatest(
      this.userid$,
      this.lastRestore$
    ).pipe( switchMap( ([userId, lastRestore]) =>
      this.httpClient.get<HierarchyInterface>(LOAD_USER_ARBORESCENCE_URL, { params: { userId, lastRestore: lastRestore.toString() } })
    ) )
  }

  public getNodes() {
    return this.lastRestore$.pipe(
      switchMap( lastRestore => this.httpClient.get<HierarchyInterface>(LOAD_USER_ARBORESCENCE_URL, { params: { lastRestore: lastRestore.toString() } }) )
    );
  }

  public saveNodes( nodes: Node[], nodesPosition: NODE_KEYS_POSITION, templateName: string ) {
    nodes = nodes.filter( node => !node.readOnly );
    return this.userid$.pipe( switchMap( userId =>
      this.httpClient.post<void>(SAVE_USER_ARBORESCENCE_URL, { userId, nodes: Node.toJSONCollection(nodes), nodesPosition, templateName })
    ) );
  }

  public getLeavesByGivenCriteria(leavesKeys: string, fromDate: number, toDate: number, interval: number = 5, metaType?: string): Observable<Leaf[]> {
    const oneMonthAgo = moment().subtract(31, 'days').unix();
    const requests: Observable<Leaf[]>[] = [];
    if( (fromDate < oneMonthAgo) ) {
      requests.push( this.getLeaves(LEAVES_ARCHIVED_METAS_URL, leavesKeys, fromDate, toDate, interval, metaType) );
    }
    if( (toDate > oneMonthAgo) ) {
      requests.push( this.getLeaves(LEAVES_METAS_URL, leavesKeys, fromDate, toDate, interval, metaType) );
    }
    return combineLatest(
      requests
    ).pipe(
      map( responses => responses.reduce( ( archivedLeaves, currentLeaves ) => {
        for( const leaf of currentLeaves ) {
          const archived = archivedLeaves.find( ({key}) => key === leaf.key );
          if( !archived ) { archivedLeaves.push( leaf ); }
          else { archived.metas = [...archived.metas, ...leaf.metas]; }
        }
        return archivedLeaves;
      } ) ),
    );
  }

  public hideNodeFromTree(technicalKey: string) {
    return this.userid$.pipe( switchMap( userId =>
      this.httpClient.post<string>(HIDE_NODE, {technicalKey, userId})
    ) );
  }

  public restoreDefaultsNodes(technicalKey: string) {
    return this.userid$.pipe(
      switchMap(userId => this.httpClient.post<string>(RESTORE_DEFAULTS_NODES, {technicalKey, userId}))
    );
  }

  private getLeaves( url: string, leavesKeys: string, fromDate: number, toDate: number, interval: number, metaType?: string ) {
    let params = new HttpParams( {
      fromObject: {
        leafIds: leavesKeys,
        from: String(fromDate),
        to: String(toDate),
        interval: String(interval),
      }
    } );
    if( metaType ) params = params.set('metatype', metaType);

    return this.httpClient.get<LeafDTO[]>( url, { params } ).pipe( map(leaves => Leaf.fromJSONCollection(leaves)) );
  }

  public getCockpitLeaves() {
    return this.httpClient.get<CockpitLeafDTO[]>(LOAD_COCKPIT_LEAVES_URL).pipe((map(cockpitLeavesFromJson)));
  }
}
