import { HttpParams, HttpRequest } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { User } from 'core/models/user.model';
import { authState } from 'core/store/auth/auth.reducer';
import { HierarchyState } from 'core/store/hierarchy/hierarchy.model';
import isEqual from 'lodash/isEqual';
import merge from 'lodash/merge';
import moment from 'moment';
import { configureTestSuite } from 'ng-bullet';
import { Observable } from 'rxjs';
import { Leaf, LeafDTO } from 'shared/models/leaf.model';
import { MetaDTO, MetaState } from 'shared/models/meta.model';
import { Node, NodeDTO } from 'shared/models/node.model';
import { AppState } from 'shared/models/state.model';
import { HIDE_NODE, LEAVES_ARCHIVED_METAS_URL, LEAVES_METAS_URL, LOAD_USER_ARBORESCENCE_URL, RESTORE_DEFAULTS_NODES, SAVE_USER_ARBORESCENCE_URL } from '../http/http-client.service';
import { ApiNodesService } from './api.nodes';

describe('ApiNodesService', () => {
  let service: ApiNodesService;
  let httpTestingController: HttpTestingController;
  let actions: Observable<any>;
  let store: MockStore<Partial<AppState>>;
  const initialState = { hierarchy: new HierarchyState(), auth: authState };

  function fromHttpParams( params: HttpParams ) {
    return params.keys()
      .map( k => ({ [k]: params.get(k) }) )
      .reduce( (acc, value) => ({ ...acc, ...value }), {});
  }

  function isParamsEqual( params: HttpParams, comp: any ) {
    return isEqual( fromHttpParams( params), comp );
  }

  function setPartialState( partialState: DeepPartial<AppState> ) {
    const state = merge({}, initialState, partialState);
    store.setState(state);
    return state;
  }

  function isRequest(matcher: { url?: string, method?: string, params?: any, body?: any }) {
    return (req: HttpRequest<any>) =>
         (!matcher.url    || req.url === matcher.url)
      && (!matcher.method || req.method === matcher.method)
      && (!matcher.params || isParamsEqual(req.params, matcher.params))
      && (!matcher.body   || isEqual(req.body, matcher.body));
  }

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
      ],
      providers: [
        ApiNodesService,
        provideMockStore<Partial<AppState>>({ initialState }),
        provideMockActions(() => actions),
      ],
    })
  });

  beforeEach(() => {
    store = TestBed.get(Store);
    service = TestBed.get(ApiNodesService);
    httpTestingController = TestBed.get(HttpTestingController);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  describe('getUserNodes', () => {

    it('should fetch the user hierarchy', () => {
      setPartialState({
        hierarchy: { lastRestore: 1 },
        auth: { isUserAuthenticated: true, user: User.from({ userId: 'xxx' }) },
      });

      service.getUserNodes().subscribe();

      httpTestingController.expectOne( isRequest({
        url: LOAD_USER_ARBORESCENCE_URL,
        params: { userId: 'xxx', lastRestore: '1' },
      }) );
    });

  });

  describe('getNodes', () => {

    it('should fetch the global hierarchy', () => {
      setPartialState({
        hierarchy: { lastRestore: 1 },
      });

      service.getNodes().subscribe();

      httpTestingController.expectOne( isRequest({
        url: LOAD_USER_ARBORESCENCE_URL,
        params: { lastRestore: '1' },
      }) );
    });

  });

  describe('saveNodes', () => {

    it('should save the user hierarchy', () => {
      setPartialState({
        auth: { isUserAuthenticated: true, user: User.from({ userId: 'xxx' }) },
      });

      const readOnlyNode: NodeDTO = {
        description: '',
        fullname: '',
        isLeafWrapper: false,
        key: 'readonly',
        leaves: [],
        name: '',
        nodeId: '',
        nodes: [],
        readOnly: true,
        technicalKey: '',
        weight: 0,
      };
      const userNode: NodeDTO = {
        ...readOnlyNode,
        key: 'user',
        readOnly: false,
      }

      service.saveNodes( Node.fromJSONCollection([ readOnlyNode, userNode ]), [[],[],[],[]], '' ).subscribe();

      httpTestingController.expectOne( isRequest({
        url: SAVE_USER_ARBORESCENCE_URL,
        method: 'POST',
        body: { userId: 'xxx', nodes: [ Node.toJSON( Node.fromJSON( userNode ) ) ], nodesPosition: [[],[],[],[]], templateName: '' },
      }) );

    });

  });

  describe('getLeavesByGivenCriteria', () => {

    const emptyLeafDTO = ( leaf?: Partial<LeafDTO> ): LeafDTO => ({
      leafId:       'leafId',
      key:          'key',
      name:         'name',
      metas:        [],
      fullname:     'fullname',
      description:  'description',
      weight:       1,
      technicalKey: 'technicalKey',
      ...leaf,
    })

    const emptyMeta = ( meta?: Partial<MetaDTO> ): MetaDTO => ({
      metaType: 'metaType',
      value:    1,
      date:     '2',
      state:    MetaState.NO,
      source:   [],
      weight:   3,
      timeBox:  {
        startDate:  '4',
        endDate:    '5',
        resolution: 6,
      },
      ...meta,
    })

    beforeEach(() => {
      jasmine.clock().install();
      jasmine.clock().mockDate( new Date(2000, 6, 15) );
    });

    afterEach(() => {
      jasmine.clock().uninstall();
    });

    it('should fetch the recent metas if the requested data are less than a month old', () => {
      const fromDate = moment().subtract(10, 'days').unix();
      const toDate = moment().subtract(5, 'days').unix();
      const spy = jasmine.createSpy('response');
      const leafDTO = emptyLeafDTO();
      const leaf = Leaf.fromJSON(leafDTO);

      service.getLeavesByGivenCriteria('leavesKeys', fromDate, toDate, 5).subscribe(spy);

      httpTestingController.expectOne( isRequest({
        url: LEAVES_METAS_URL,
      }) ).flush([leafDTO]);

      expect(spy).toHaveBeenCalledWith([leaf]);
    });

    it('should fetch the archived metas if the requested data are more than a month old', () => {
      const fromDate = moment().subtract(45, 'days').unix();
      const toDate = moment().subtract(40, 'days').unix();
      const spy = jasmine.createSpy('response');
      const leafDTO = emptyLeafDTO();
      const leaf = Leaf.fromJSON(leafDTO);

      service.getLeavesByGivenCriteria('leavesKeys', fromDate, toDate, 5).subscribe(spy);

      httpTestingController.expectOne( isRequest({
        url: LEAVES_ARCHIVED_METAS_URL,
      }) ).flush([leafDTO]);

      expect(spy).toHaveBeenCalledWith([leaf]);
    });

    it('should fetch both recent and archived metas if the requested data are both less than a month old and more than a month old', () => {
      const fromDate = moment().subtract(45, 'days').unix();
      const toDate = moment().subtract(25, 'days').unix();
      const spy = jasmine.createSpy('response');
      const leafDTO = emptyLeafDTO({ key: 'leaf' });
      const leaf = Leaf.fromJSON(leafDTO);
      const archivedLeafDTO = emptyLeafDTO({ key: 'archived' });
      const archivedLeaf = Leaf.fromJSON(archivedLeafDTO);

      service.getLeavesByGivenCriteria('leavesKeys', fromDate, toDate, 5).subscribe(spy);

      httpTestingController.expectOne( isRequest({
        url: LEAVES_METAS_URL,
      }) ).flush([leafDTO]);
      httpTestingController.expectOne( isRequest({
        url: LEAVES_ARCHIVED_METAS_URL,
      }) ).flush([archivedLeafDTO]);

      expect(spy).toHaveBeenCalledWith(jasmine.arrayWithExactContents([leaf, archivedLeaf]));
    });

    it('should optionnally be able to request by metatype', () => {
      const fromDate = moment().subtract(10, 'days').unix();
      const toDate = moment().subtract(5, 'days').unix();
      const spy = jasmine.createSpy('response');
      const leafDTO = emptyLeafDTO();
      const leaf = Leaf.fromJSON(leafDTO);

      service.getLeavesByGivenCriteria('leavesKeys', fromDate, toDate, 5, 'meta').subscribe(spy);

      const req = httpTestingController.expectOne( isRequest({
        url: LEAVES_METAS_URL,
      }) );
      expect(req.request.params.get('metatype')).toBe('meta');
      req.flush([leafDTO]);

      expect(spy).toHaveBeenCalledWith([leaf]);
    });

    it('should merge the metas from both archived and recent leaves', () => {
      const fromDate = moment().subtract(45, 'days').unix();
      const toDate = moment().subtract(25, 'days').unix();
      const spy = jasmine.createSpy('response');
      const leafDTO = emptyLeafDTO({ key: 'leaf', metas: [ emptyMeta({ value: 1 }) ] });
      const archivedLeafDTO = emptyLeafDTO({ key: 'leaf', metas: [ emptyMeta({ value: 2 }) ] });
      const leaf = Leaf.fromJSON(emptyLeafDTO({ key: 'leaf', metas: [ emptyMeta({ value: 2 }), emptyMeta({ value: 1 }) ] }));

      service.getLeavesByGivenCriteria('leavesKeys', fromDate, toDate).subscribe(spy);

      httpTestingController.expectOne( isRequest({
        url: LEAVES_METAS_URL,
      }) ).flush([leafDTO]);
      httpTestingController.expectOne( isRequest({
        url: LEAVES_ARCHIVED_METAS_URL,
      }) ).flush([archivedLeafDTO]);

      expect(spy).toHaveBeenCalledWith([leaf]);
    })

  });

  describe('hideNodeFromTree', () => {

    it('should request to hide a node for the user', () => {
      setPartialState({
        auth: { isUserAuthenticated: true, user: User.from({ userId: 'xxx' }) },
      });

      service.hideNodeFromTree('key').subscribe();

      httpTestingController.expectOne( isRequest({
        url: HIDE_NODE,
        method: 'POST',
        body: { userId: 'xxx', technicalKey: 'key' },
      }) );
    });

  });

  describe('restoreDefaultsNodes', () => {

    it('should request to restore all nodes for the user', () => {
      setPartialState({
        auth: { isUserAuthenticated: true, user: User.from({ userId: 'xxx' }) },
      });

      let sub = service.restoreDefaultsNodes('key').subscribe();

      httpTestingController.expectOne( isRequest({
        url: RESTORE_DEFAULTS_NODES,
        method: 'POST',
        body: { userId: 'xxx', technicalKey: 'key' },
      }) );

      sub.unsubscribe();
    });

  });



  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
