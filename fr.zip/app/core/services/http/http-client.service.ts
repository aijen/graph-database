import { environment } from 'env/environment';

export const LEAVES_METAS_URL = environment.API_URL + '/api/leaves/metas/';
export const LEAVES_ARCHIVED_METAS_URL = environment.API_URL + '/api/leaves/metas/history';
export const HIDE_NODE = environment.API_URL + '/api/nodes/hide/node';
export const RESTORE_DEFAULTS_NODES = environment.API_URL + '/api/nodes/restore';
export const LOAD_ADAPTERS_CONFIG = environment.API_URL + '/api/adapters/config';
export const LOAD_POPULATED_METAS_URL = environment.API_URL + '/api/leaves/metas/populated';
export const LOAD_COLD_ANALYSIS_DATA_URL = environment.API_URL + '/api/coldAnalysis';
export const LOAD_COCKPIT_LEAVES_URL = environment.API_URL + '/api/leaves';
export const LOAD_EXISTING_METRICS_URL = environment.API_URL + '/api/baselines/existingMetrics';

export const LOAD_NOTIFICATIONS_URL = environment.API_URL + '/api/notifications';
export const SAVE_NOTIFICATIONS_URL = environment.API_URL + '/api/notifications';
export const DELETE_NOTIFICATIONS_URL = environment.API_URL + '/api/notifications';

export const LOAD_ADMIN_ALERTS_URL = environment.API_URL + '/api/admin/configuration/alert';
export const SAVE_ADMIN_ALERTS_URL = environment.API_URL + '/api/admin/configuration/alert';

export const LOAD_SNOOZE_URL = environment.API_URL + '/api/snooze';
export const SAVE_SNOOZE_URL = environment.API_URL + '/api/snooze';
export const LOAD_ADMIN_SNOOZE_URL = environment.API_URL + '/api/admin/configuration/snooze';
export const SAVE_ADMIN_SNOOZE_URL = environment.API_URL + '/api/admin/configuration/snooze';

export const LOAD_SYNTHESIS_URL = environment.API_URL + '/api/synthesis';
export const LOAD_ADMIN_SYNTHESIS_URL = environment.API_URL + '/api/admin/configuration/synthesis';
export const SAVE_ADMIN_SYNTHESIS_URL = environment.API_URL + '/api/admin/configuration/synthesis';

export const LOAD_BASELINES_URL = environment.API_URL + '/api/baselines';
export const LOAD_ADMIN_BASELINES_URL = environment.API_URL + '/api/admin/configuration/baselines';
export const SAVE_ADMIN_BASELINES_URL = environment.API_URL + '/api/admin/configuration/baselines';

export const LOAD_HOLIDAYS_URL = environment.API_URL + '/api/publicHolidays';
export const LOAD_ADMIN_HOLIDAYS_URL = environment.API_URL + '/api/admin/configuration/publicHolidays';
export const SAVE_ADMIN_HOLIDAYS_URL = environment.API_URL + '/api/admin/configuration/publicHolidays';

export const LOAD_ADMIN_BASELINES_IMPORT_URL = environment.API_URL + '/api/adapters/config';
export const SAVE_ADMIN_BASELINES_IMPORT_URL = environment.API_URL + '/api/admin/configuration/baselines/import';

export const LOAD_ADMIN_PERIMETER_NODES_URL = environment.API_URL + '/api/admin/configuration/nodes';
export const SAVE_ADMIN_PERIMETER_NODES_URL = environment.API_URL + '/api/admin/configuration/nodes';

export const LOAD_ADMIN_PERIMETER_LEAVES_URL = environment.API_URL + '/api/admin/configuration/leaves';
export const SAVE_ADMIN_PERIMETER_LEAVES_URL = environment.API_URL + '/api/admin/configuration/leaves';

export const LOAD_USER_ARBORESCENCE_URL = environment.API_URL + '/api/nodes/config';
export const SAVE_USER_ARBORESCENCE_URL = environment.API_URL + '/api/nodes/config';
export const LOAD_ADMIN_ARBORESCENCE_URL = environment.API_URL + '/api/admin/configuration/nodes/config';
export const SAVE_ADMIN_ARBORESCENCE_URL = environment.API_URL + '/api/admin/configuration/nodes/config';
export const IMPORT_ADMIN_ARBORESCENCE_URL = environment.API_URL + '/api/admin/configuration/nodes/config/import';

export const LOAD_METRICS_URL = environment.API_URL + '/api/admin/configuration/baselines';
export const SAVE_METRICS_URL = environment.API_URL + '/api/admin/configuration/baselines';
export const DELETE_METRICS_URL = environment.API_URL + '/api/admin/configuration/baselines';

export const LOAD_TEMPLATES_URL = environment.API_URL + '/api/templates';
export const SAVE_TEMPLATES_URL = environment.API_URL + '/api/templates';
export const DELETE_TEMPLATES_URL = environment.API_URL + '/api/templates';

export const LOAD_GROUPS_URL = environment.API_URL + '/api/usergroups';
export const SAVE_GROUPS_URL = environment.API_URL + '/api/usergroups';
export const DELETE_GROUPS_URL = environment.API_URL + '/api/usergroups';

export const LOAD_PIT_USERS_URL = environment.API_URL + '/api/users';
export const SAVE_PIT_USERS_URL = environment.API_URL + '/api/users';
export const DELETE_PIT_USERS_URL = environment.API_URL + '/api/users';
export const SET_USER_VIEW_FROM_TEMPLATE = environment.API_URL + '/api/users/template';

export const LOAD_ADAPTERS_MAPPING_URL = environment.API_URL + '/api/leaves/mapping';
export const SAVE_ADAPTERS_MAPPING_URL = environment.API_URL + '/api/leaves/mapping';

export const LOAD_ADMIN_ADAPTERS_MAPPING_IMPORT_URL = environment.API_URL + '/api/adapters/config';
export const SAVE_ADMIN_ADAPTERS_MAPPING_IMPORT_URL = environment.API_URL + '/api/leaves/mapping/import';

export const GET_USER_FILE_URL = environment.API_URL + '/api/files';
export const LOAD_USER_FILES_URL = environment.API_URL + '/api/files/list';
export const SAVE_USER_FILES_URL = environment.API_URL + '/api/files/upload';
export const DELETE_USER_FILES_URL = environment.API_URL + '/api/files';

export const LOAD_FAQ_URL = environment.API_URL + '/api/faq';
export const SAVE_FAQ_URL = environment.API_URL + '/api/faq';
export const UPLOAD_FAQ_URL = environment.API_URL + '/api/faq/upload';
export const LIST_UPLOAD_FAQ= environment.API_URL + '/api/faq/list';
export const GET_FAQ_FILE= environment.API_URL + '/api/faq/view';
export const DELETE_FAQ_FILE= environment.API_URL + '/api/faq';

export const LOAD_ADMIN_LOGS_URL = environment.API_URL + '/api/adminlogs';
export const SAVE_ADMIN_LOGS_URL = environment.API_URL + '/api/adminlogs';
export const GET_ADMIN_IMPORT_FILE_URL = environment.API_URL + '/api/files/imported';

export const INTERVAL = 60000; // 60 * 1000
export const PULLER_INTERVAL = 60000;
