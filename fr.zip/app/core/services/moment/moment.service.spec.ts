import { async, TestBed } from '@angular/core/testing';
import { configureTestSuite } from 'ng-bullet';
import { DateTimeService } from './moment.service';

describe('DateTimeService', () => {
  let service: DateTimeService;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [
        DateTimeService,
      ],
    })
  });

  beforeEach(async( async () => {
    service = TestBed.get(DateTimeService);
  } ));

  it('should create', () => {
    expect(service).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
