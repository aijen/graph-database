import { async, TestBed } from '@angular/core/testing';
import { configureTestSuite } from 'ng-bullet';
import { utils, WorkBook } from 'xlsx';
import { ExcelService } from './excel.service';

describe('ExcelService', () => {
  let service: ExcelService;
  let writeFile: jasmine.Spy;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [
        ExcelService,
      ],
    })
  });

  beforeEach(async( async () => {
    service = TestBed.get(ExcelService);
    writeFile = spyOn(service, 'writeFile');
  } ));

  it('should create', () => {
    expect(service).toBeTruthy();
  });

  describe('saveAsExcel', () => {

    it('should save the data provided as excel', () => {
      const cols = [{ wch: 10 }];
      const merges = [{
        s: { c: 0, r: 0 },
        e: { c: 5, r: 0 },
      }];

      service.saveAsExcel('fileName', [
        {
          name: 'sheet',
          data: [[1,2,3]],
          cols,
          merges,
        }
      ]);

      expect(service.writeFile).toHaveBeenCalled();

      const [ workbook, filename ] = writeFile.calls.mostRecent().args as [WorkBook, string];

      expect( filename ).toBe('fileName.xlsx');
      expect( workbook.SheetNames ).toEqual(['sheet']);
      expect( workbook.Sheets['sheet'] ).toBeDefined();
      expect( utils.sheet_to_csv(workbook.Sheets['sheet']) ).toBe('1,2,3\n');
      expect( workbook.Sheets['sheet']['!cols'] ).toEqual(cols);
      expect( workbook.Sheets['sheet']['!merges'] ).toEqual(merges);
    });

  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
