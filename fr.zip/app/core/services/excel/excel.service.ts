import { Injectable } from '@angular/core';
import { ColInfo, ParsingOptions, Range, read, utils, WorkBook, WorkSheet, writeFile } from 'xlsx';

export interface ExcelSheet {
  name: string,
  data: any[][],
  cols?: ColInfo[],
  merges?: Range[],
}

@Injectable({
  providedIn: 'root'
})
export class ExcelService {

  writeFile = writeFile;

  constructor() {
  }

  saveAsExcel(fileName: string, sheets: ExcelSheet[]) {
    const wb = utils.book_new();

    for(const { name, data, cols, merges } of sheets) {
      const ws = utils.aoa_to_sheet( data, { dateNF: 'm/d/yy h:mm' } );
      ws['!cols'] = cols;
      ws['!merges'] = merges;
      utils.book_append_sheet( wb, ws, name.slice(0, 31) );
    }

    this.writeFile( wb, `${fileName}.xlsx` );
  }

  fileToWorkbook(file: string, opts?: ParsingOptions): WorkBook {
    return read(file, opts);
  }

  sheetToJson(worksheet: WorkSheet, header: number, blankrows: boolean): any[] {
    return utils.sheet_to_json( worksheet, { header, blankrows } ).slice(header);
  }
}
