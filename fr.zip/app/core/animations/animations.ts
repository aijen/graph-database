import { animate, group, keyframes, state, style, transition, trigger } from '@angular/animations';

export  function fadeAnimation(timerToLoader: number = 1) {
  return (
    trigger('fade', [
    state('true', style({ opacity: 1 })),
    state('false', style({ opacity: 0, 'pointer-events': 'none' }) ),
    transition('* => true', animate(`.4s ${timerToLoader}s ease-in-out`, style({ opacity: 1 }) )),
    transition('* => false, :leave', group([
      animate('.4s ease-in-out', style({ opacity: 0 })),
      animate('.4s ease-in-out',
        keyframes([
          style({ 'pointer-events': 'none', offset: 0 }),
          style({ 'pointer-events': 'none', offset: .5 }),
          style({ 'pointer-events': 'none', offset: 1 }),
        ])),
      ]) ),
    ])
  );
}

export function fadeInOut() {
  return (
    trigger('fadeInOut', [
      transition(':enter', [
        style({ opacity: 0 }),
        animate(200, style({ opacity: 1 }))
      ]),
        transition(':leave', [
        animate(200, style({ opacity: 0 }))
      ])
    ])
  );
}

export function highlight() {
  return (
    trigger('highlight', [
      transition(':enter', []),
      transition(':leave', []),
      transition('* => *',
        animate('1000ms linear',
          keyframes([
            style({ background: 'hsla(50, 100%, 42%, 0)', offset: 0 }),
            style({ background: 'hsla(50, 100%, 42%, 1)', offset: .25 }),
            style({ background: 'hsla(50, 100%, 42%, 1)', offset: .75 }),
            style({ background: 'hsla(50, 100%, 42%, 0)', offset: 1 }),
          ])
        )
      ),
    ])
  );
}
