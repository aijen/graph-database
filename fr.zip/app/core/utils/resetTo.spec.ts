import { marbles } from 'rxjs-marbles/jasmine';
import { resetTo } from './resetTo';

describe('resetTo', () => {

  it('should briefly emit the source value before emitting the `reset` value', marbles(m => {
    const actual   = m.hot('-a----b----c----d', {})
    const expected = m.hot('-(ar)-(br)-(cr)-(dr)', { r: '' })

    m.expect(actual.pipe(resetTo(''))).toBeObservable(expected)
  }))

})
