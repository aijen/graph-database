import { Observable, pipe } from 'rxjs';
import { filter } from 'rxjs/operators';

export const notNull: <T>(source: Observable<T> ) => Observable<T> = pipe( filter( value => value !== null ) );
