import { ElementRef } from '@angular/core';
import { Observable, ReplaySubject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';


export function untilViewDestroyed<T>(element: ElementRef): (source: Observable<T>) => Observable<T> {
  const destroyed$ = watchElementDestroyed(element.nativeElement);
  return (source: Observable<T>) => source.pipe(takeUntil(destroyed$));
}

const destroy$ = 'destroy$';

function watchElementDestroyed(nativeEl: Element, delay: number = 50): Observable<boolean> {
  if (!nativeEl[destroy$] && typeof MutationObserver !== 'undefined') {

      const stop$ = new ReplaySubject<boolean>();
      const hasBeenRemoved = isElementRemoved(nativeEl);

      nativeEl[destroy$] = stop$.asObservable();
      setTimeout(() => {
        const domObserver = new MutationObserver((records: MutationRecord[]) => {
          if (records.some(hasBeenRemoved)) {
            stop$.next(true);
            stop$.complete();

            domObserver.disconnect();
            nativeEl[destroy$] = null;
          }
        });

         if(nativeEl.parentNode ) {
            domObserver.observe(nativeEl.parentNode as Node, { childList: true });
         }    
      
      }, delay);
  }

  return nativeEl[destroy$];
}

function isElementRemoved(nativeEl) {
  return (record: MutationRecord) => {
    return Array.from(record.removedNodes).indexOf(nativeEl) > -1;
  };
}