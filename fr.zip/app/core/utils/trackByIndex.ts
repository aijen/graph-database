
export const trackByIndex = index => index;
