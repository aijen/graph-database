import { of, OperatorFunction, pipe } from 'rxjs';
import { delay, mergeMap } from 'rxjs/operators';

export const resetTo = <T>( reset: T ): OperatorFunction<T, T> => pipe(
  mergeMap( value => of(value, reset)),
  mergeMap( value => of(value).pipe(delay(0))),
)
