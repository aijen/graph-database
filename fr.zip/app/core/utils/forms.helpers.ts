import { AbstractControlState, disable, enable, FormArrayState, FormGroupState } from 'ngrx-forms';
import { map } from 'rxjs/operators';

type FormState = FormGroupState<any> | FormArrayState<any>;
type FormStates = FormState | FormState[];

const isValidAndEnabled = ( form: FormState ) => form.isValid && form.isEnabled;
const isDirty = ( form: FormState ) => form.isDirty;

const _canSaveForm = (forms : FormStates): boolean => Array.isArray( forms ) ? forms.every( isValidAndEnabled ) && forms.some( isDirty ) : _canSaveForm( [forms] );
export const canSaveForm = map<FormStates, boolean>( _canSaveForm );

const isEnabled = ( form: FormState ) => form.isEnabled;

const _canResetForm = (forms : FormStates): boolean => Array.isArray( forms ) ? forms.every( isEnabled ) && forms.some( isDirty ) : _canResetForm( [forms] );
export const canResetForm = map<FormStates, boolean>( _canResetForm );

export const isFormPristine = map<FormState, boolean>( form => form.isPristine );
export const isFormEnabled = map<FormState, boolean>( form => form.isEnabled );
export const isFormDisabled = map<FormState, boolean>( form => form.isDisabled );

export const enableIfStable = <T>( control: AbstractControlState<T>, { isLoading, isSaving }: { isLoading: boolean, isSaving: boolean } ) => ( isLoading || isSaving ) ? disable( control ) : enable( control );
