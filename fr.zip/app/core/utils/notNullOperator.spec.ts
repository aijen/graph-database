import { marbles } from 'rxjs-marbles/jasmine';
import { notNull } from './notNullOperator';

describe('notNull', () => {

  it('should emit values only when the values are not null', marbles(m => {
    const obs      = m.hot('-a-b-c-d', { a: null, b: 'b', c: null, d: 'd' })
    const expected = m.hot('---b---d', {          b: 'b',          d: 'd' })

    m.expect(obs.pipe( notNull )).toBeObservable(expected)
  }))

})
