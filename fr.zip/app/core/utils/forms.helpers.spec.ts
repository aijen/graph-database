import { createFormGroupState, disable, markAsDirty, markAsPristine, setErrors } from 'ngrx-forms';
import { marbles } from 'rxjs-marbles/jasmine';
import { canResetForm, canSaveForm, enableIfStable, isFormDisabled, isFormEnabled, isFormPristine } from './forms.helpers';

describe('forms.helpers', () => {

  describe('canSaveForm', () => {

    it('should return true if the form can be saved', marbles(m => {
      const state = markAsDirty(createFormGroupState('', { foo: 'bar' }))
      const input = m.hot('abcd', {
        a: state,
        b: markAsPristine(state),
        c: setErrors(state, { required: { actual: null } }),
        d: disable(state),
      })
      const expected = m.hot('abcd', {
        a: true,
        b: false,
        c: false,
        d: false,
      })

      m.expect(input.pipe( canSaveForm )).toBeObservable(expected)
    }))

    it('should accept array of formstate and return true if all the forms can be saved', marbles(m => {
      const state1 = markAsDirty(createFormGroupState('', { foo: 'bar' }))
      const state2 = markAsDirty(createFormGroupState('', { bar: 'foo' }))
      const input = m.hot('abcde', {
        a: [ state1, state2 ],
        b: [ markAsPristine(state1), state2 ],
        c: [ markAsPristine(state1), markAsPristine(state2) ],
        d: [ setErrors(state1, { required: { actual: null } }), state2 ],
        e: [ disable(state1), state2 ],
      })
      const expected = m.hot('abcde', {
        a: true,
        b: true,
        c: false,
        d: false,
        e: false,
      })

      m.expect(input.pipe( canSaveForm )).toBeObservable(expected)
    }))

  })

  describe('canResetForm', () => {

    it('should accept array of formstate and return true if all the forms can be reset', marbles(m => {
      const state1 = markAsDirty(createFormGroupState('', { foo: 'bar' }))
      const state2 = markAsDirty(createFormGroupState('', { bar: 'foo' }))
      const input = m.hot('abcd', {
        a: [ state1, state2 ],
        b: [ markAsPristine(state1), state2 ],
        c: [ markAsPristine(state1), markAsPristine(state2) ],
        d: [ disable(state1), state2 ],
      })
      const expected = m.hot('abcd', {
        a: true,
        b: true,
        c: false,
        d: false,
      })

      m.expect(input.pipe( canResetForm )).toBeObservable(expected)
    }))

    it('should accept a formstate and return true if it can be reset', marbles(m => {
      const state = markAsDirty(createFormGroupState('', { foo: 'bar' }))
      const input = m.hot('abc', {
        a: state,
        b: markAsPristine(state),
        c: disable(state),
      })
      const expected = m.hot('abc', {
        a: true,
        b: false,
        c: false,
      })

      m.expect(input.pipe( canResetForm )).toBeObservable(expected)
    }))

  })

  describe('isFormPristine', () => {

    it('should return true is the form is pristine', marbles(m => {
      const state = createFormGroupState('', { foo: 'bar' })
      const input = m.hot('ab', {
        a: state,
        b: markAsDirty(state),
      })
      const expected = m.hot('ab', {
        a: true,
        b: false,
      })

      m.expect(input.pipe( isFormPristine )).toBeObservable(expected)
    }))

  })

  describe('isFormEnabled', () => {

    it('should return true is the form is enabled', marbles(m => {
      const state = createFormGroupState('', { foo: 'bar' })
      const input = m.hot('ab', {
        a: state,
        b: disable(state),
      })
      const expected = m.hot('ab', {
        a: true,
        b: false,
      })

      m.expect(input.pipe( isFormEnabled )).toBeObservable(expected)
    }))

  })

  describe('isFormDisabled', () => {

    it('should return true is the form is disabled', marbles(m => {
      const state = createFormGroupState('', { foo: 'bar' })
      const input = m.hot('ab', {
        a: state,
        b: disable(state),
      })
      const expected = m.hot('ab', {
        a: false,
        b: true,
      })

      m.expect(input.pipe( isFormDisabled )).toBeObservable(expected)
    }))

  })

  describe('enableIfStable', () => {

    it('should enable the form if not saving or loading', () => {
      const state = createFormGroupState('', { foo: 'bar' })

      expect( enableIfStable( state, { isLoading: false, isSaving: false } ).isEnabled ).toBe( true )
      expect( enableIfStable( state, { isLoading: true,  isSaving: false } ).isEnabled ).toBe( false )
      expect( enableIfStable( state, { isLoading: false, isSaving: true  } ).isEnabled ).toBe( false )
      expect( enableIfStable( state, { isLoading: true,  isSaving: true  } ).isEnabled ).toBe( false )

    })

  })


})
