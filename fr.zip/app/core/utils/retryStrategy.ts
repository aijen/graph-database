import { throwError, timer } from 'rxjs';
import { mergeMap } from 'rxjs/operators';

export const retryStrategy =
  ( { maxAttempts = 3, delay = 10000 } = {} ) =>
    ( errors ) => errors.pipe(
      mergeMap( (error, attempt) => {
        if( attempt + 1 >= maxAttempts  )
          return throwError(error);
        return timer( delay );
      } )
    );
