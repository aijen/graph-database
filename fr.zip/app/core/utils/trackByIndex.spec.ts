import { trackByIndex } from './trackByIndex';

describe('trackByIndex', () => {

  it('should return the index argument from the trackByFunction of an *ngFor', () => {

    expect(trackByIndex( 1 )).toBe(1)

  })

})
