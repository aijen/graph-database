import { Component, Input } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { MatSelectModule } from '@angular/material/select';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { ExcelService } from 'core/services/excel/excel.service';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { Observable } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { metricsFormState } from '../../store/metrics/metrics.form.reducer';
import { ExportMappingsComponent } from './export-mappings.component';

@Component({
  selector: 'pit-close-modal',
  template: '',
})
class PitCloseModalStubComponent {
  @Input() class: any;
}

describe('ExportMappingsComponent', () => {
  let context: TestCtx<ExportMappingsComponent>;
  let actions: Observable<any>;
  let excelServiceStub: jasmine.SpyObj<ExcelService>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        MatSelectModule,
      ],
      declarations: [
        ExportMappingsComponent,
        PitCloseModalStubComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: {
          metricsForm: metricsFormState,
        } }),
        provideMockActions(() => actions),
        { provide: ExcelService, useFactory: () => jasmine.createSpyObj('ExcelService', ['saveAsExcel'] as Array<keyof ExcelService>) },
      ],
    })
  });

  beforeEach(async( async () => {
    actions = null;
    excelServiceStub = TestBed.get(ExcelService);
    context = await createStableTestContext(ExportMappingsComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
