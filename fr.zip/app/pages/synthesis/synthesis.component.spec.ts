import { Component, Input } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { initialState as initialNotificationsState } from 'core/store/notifications/notifications.reducer';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { Observable } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { initialState as initialSynthesisState } from './store/synthesis/synthesis.reducer';
import { SynthesisComponent } from './synthesis.component';

@Component({
  selector: 'pit-synthesis-list-view',
  template: '',
})
class PitSynthesisListViewStubComponent {
  @Input() leaves: any;
  @Input() options: any;
}

@Component({
  selector: 'pit-synthesis-charts-container',
  template: '',
})
class PitSynthesisChartsContainerStubComponent {
  @Input() options: any;
}

describe('SynthesisComponent', () => {
  let context: TestCtx<SynthesisComponent>;
  let actions: Observable<any>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        MatProgressSpinnerModule,
        NoopAnimationsModule,
      ],
      declarations: [
        SynthesisComponent,
        PitSynthesisListViewStubComponent,
        PitSynthesisChartsContainerStubComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: { synthesis: initialSynthesisState, notifications: initialNotificationsState } }),
        provideMockActions(() => actions),
      ],
    })
  });

  beforeEach(async( async () => {
    context = await createStableTestContext(SynthesisComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
