import { NgModule } from "@angular/core";
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTabsModule } from '@angular/material/tabs';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { SharedModule } from 'shared/shared.module';
import { SynthesisChartsContainerComponent } from './components/synthesis-charts-container/synthesis-charts-container.component';
import { SynthesisListViewComponent } from './components/synthesis-list-view/synthesis-list-view.component';
import { SynthesisEffects } from './store/synthesis/synthesis.effects';
import { synthesisReducer } from './store/synthesis/synthesis.reducer';
import { SynthesisRoutingModule } from './synthesis-routing.module';
import { SynthesisComponent } from './synthesis.component';
import { GetSelectedAdminLeaves } from './utils/getSelectedAdminLeaves.pipe';

@NgModule({
  declarations: [
    SynthesisComponent,
    SynthesisListViewComponent,
    SynthesisChartsContainerComponent,
    GetSelectedAdminLeaves,
  ],
  imports: [
    SharedModule,
    MatTabsModule,
    SynthesisRoutingModule,
    MatProgressSpinnerModule,
    StoreModule.forFeature('synthesis', synthesisReducer),
    EffectsModule.forFeature([SynthesisEffects]),
  ]
})
export class SynthesisModule { }
