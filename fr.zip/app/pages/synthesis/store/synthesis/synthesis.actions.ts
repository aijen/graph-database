import { Action } from '@ngrx/store';
import { SynthesisConfig } from './synthesis.model';

export enum SynthesisActionTypes {
  LoadSynthesis = '[Cockpit] Synthesis Load',
  LoadSynthesisSuccess = '[CockPit] Synthesis LoadSuccess',
  LoadSynthesisError = '[CockPit] Synthesis LoadError',
}

export class LoadSynthesis implements Action {
  readonly type = SynthesisActionTypes.LoadSynthesis;
  constructor() {}
}

export class LoadSynthesisSuccess implements Action {
  readonly type = SynthesisActionTypes.LoadSynthesisSuccess;
  constructor(public payload: { config: SynthesisConfig }) {}
}

export class LoadSynthesisError implements Action {
  readonly type = SynthesisActionTypes.LoadSynthesisError;
  constructor(public payload: { error: Error }) {}
}

export type SynthesisActionsUnion =
| LoadSynthesis
| LoadSynthesisSuccess
| LoadSynthesisError
;
