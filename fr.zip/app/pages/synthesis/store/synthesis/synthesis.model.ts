import { LeavesState } from 'core/store/leaves/leaves.model';

declare module 'shared/models/state.model' {
  export interface AppState {
    readonly synthesis: SynthesisState;
  }
}

export interface SynthesisConfig {
  leaves: LeavesState;
}

export interface SynthesisState {
  config: SynthesisConfig;
  isLoading: boolean;
}
