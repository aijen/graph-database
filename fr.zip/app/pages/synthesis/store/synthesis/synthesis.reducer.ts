import { leavesState } from 'core/store/leaves/leaves.model';
import { SynthesisActionsUnion, SynthesisActionTypes } from './synthesis.actions';
import { SynthesisState } from "./synthesis.model";

export const initialState: SynthesisState = {
  config: { leaves: leavesState },
  isLoading: false
};

export function synthesisReducer(
  state: SynthesisState = initialState,
  action: SynthesisActionsUnion
): SynthesisState {
  switch(action.type) {
    case SynthesisActionTypes.LoadSynthesis: {
      return {
        ...state,
        isLoading: true
      };
    }
    case SynthesisActionTypes.LoadSynthesisSuccess: {
      return {
        ...state,
        config: action.payload.config,
        isLoading: false
      };
    }
    case SynthesisActionTypes.LoadSynthesisError: {
      return {
        ...state,
        isLoading: false
      };
    }
    default:
      return state;
  }
}
