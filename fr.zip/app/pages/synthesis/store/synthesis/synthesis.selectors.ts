import { createFeatureSelector, createSelector } from '@ngrx/store';
import { getLeaves } from 'core/store/hierarchy/hierarchy.selectors';
import moment from 'moment';
import { Leaf } from 'shared/models/leaf.model';
import { Meta, MetaState } from 'shared/models/meta.model';
import { SynthesisState } from './synthesis.model';

export const getSynthesisState = createFeatureSelector<SynthesisState>(
  'synthesis'
);

export const isSynthesisLoading = createSelector(
  getSynthesisState,
  state => state.isLoading
)

export const selectSynthesisConfig = createSelector(
  getSynthesisState,
  state => state.config
)

/*
* -- Synthesis only state management --
* for meta included between now - 10 min and now - 5 min
* if all KO -> RED CROSS
* if all NOK -> ORANGE CROSS
* else -> GREEN CHECK
*
* the state is used to set the right icon
* clear -> cross icon
* done -> check icon
*/
export const getMetaState = (leafId: string, metaType: string) =>
  createSelector(
    getLeaves,
    leaves => {
      const tenMinutesAgo: number = moment().unix() - 600;
      const fiveMinutesAgo: number = moment().unix() - 300;
      let state: string = 'clear';

      const leaf: Leaf = leaves.find(leaf => leaf.key === leafId);
      const metas: Meta[] = leaf ?
        leaf.metas.filter(meta => meta.metaType === metaType
          && !((meta.timeBox.startDate < tenMinutesAgo && meta.timeBox.endDate <= tenMinutesAgo) || (meta.timeBox.startDate >= fiveMinutesAgo && meta.timeBox.endDate > fiveMinutesAgo))) :
        [];

      metas.forEach(meta => {
        if(meta.state === MetaState.OK) {
          state = 'done';
        }
      });

      if(metas.length === 0) {
        state = 'done';
      }

      return state;
    }
);
