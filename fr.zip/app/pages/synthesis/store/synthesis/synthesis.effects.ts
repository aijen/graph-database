import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { LOAD_SYNTHESIS_URL } from 'core/services/http/http-client.service';
import { sortByNameCaseInsensitive } from 'core/store/leaves/leaves.model';
import { catchError, map, switchMap, tap } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { LoadSynthesis, LoadSynthesisError, LoadSynthesisSuccess, SynthesisActionTypes } from './synthesis.actions';
import { SynthesisConfig } from './synthesis.model';

const confFromJson = (conf: SynthesisConfig): SynthesisConfig => {
  Object.keys(conf.leaves).forEach(bank => {
    conf.leaves[bank].sort(sortByNameCaseInsensitive);
  });
  return conf;
}

@Injectable({providedIn: 'root'})
export class SynthesisEffects {
  public static messages = {
    loadError: `
      Une erreur est survenue pendant le chargement de la configuration 'météo': la page de météo ne sera pas disponible
    `
  }

  constructor(
    private store$: Store<AppState>,
    private actions$: Actions,
    private http: HttpClient,
    private snackbar: MessageHandler
  ) {}

  @Effect()
  load$ = this.actions$.pipe(
    ofType<LoadSynthesis>(SynthesisActionTypes.LoadSynthesis),
    switchMap( () => this.http.get<SynthesisConfig>(LOAD_SYNTHESIS_URL)),
    map( confFromJson ),
    map( config => new LoadSynthesisSuccess( { config } )),
    catchError( (error, caught) => (this.store$.dispatch( new LoadSynthesisError( { error } )), caught))
  );

  @Effect({ dispatch: false })
  loadError$ = this.actions$.pipe(
    ofType<LoadSynthesisError>(SynthesisActionTypes.LoadSynthesisError),
    tap(action => { console.error(action.payload.error); this.snackbar.show({ message: SynthesisEffects.messages.loadError, action: 'OK', isError: true, id: action.type }) })
  )
}
