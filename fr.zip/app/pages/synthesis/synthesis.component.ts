import { Component, ElementRef, OnInit } from "@angular/core";
import { select, Store } from '@ngrx/store';
import { LoadSynthesis } from 'app/pages/synthesis/store/synthesis/synthesis.actions';
import { isSynthesisLoading, selectSynthesisConfig } from 'app/pages/synthesis/store/synthesis/synthesis.selectors';
import { fadeAnimation } from 'core/animations/animations';
import { AdminLeaf } from 'core/store/leaves/leaves.model';
import { ToggleNotifications } from 'core/store/notifications/notifications.actions';
import { getNotificationOpen } from 'core/store/notifications/notifications.selectors';
import { untilViewDestroyed } from 'core/utils/untilDestroyed';
import { map, skip, startWith, switchMap, take, tap } from 'rxjs/operators';
import { ChartOptions } from 'shared/models/chart.model';
import { AppState } from 'shared/models/state.model';
import { BANK } from 'shared/store/leaves/leaves.form.model';

@Component({
  selector: 'pit-synthesis',
  templateUrl: './synthesis.component.html',
  styleUrls: ['./synthesis.component.scss'],
  animations: [fadeAnimation()]
})
export class SynthesisComponent implements OnInit {

  banks$ = this.store$.pipe(
    select( selectSynthesisConfig ),
    select( config => config.leaves ),
    map( (banks) => (Object.keys( banks ) as BANK[]).map( bank => ({ name: bank, leaves: banks[bank] }) ) )
  );

  loading$ = this.store$.select(isSynthesisLoading);

  trackByName = ( index: number, { name }: {
    name: string;
    leaves: AdminLeaf[];
  } ) => name;

  options: ChartOptions;

  constructor(
    private store$: Store<AppState>,
    private element: ElementRef,
  ) {
    let notifWasOpen = true;
    this.store$.pipe(
      select( getNotificationOpen ),
      take(1),
      tap( () => this.store$.dispatch( new ToggleNotifications( true ) ) ),
      switchMap( open => this.store$.pipe( select( getNotificationOpen ), skip(1), startWith(open) ) ),
      untilViewDestroyed(this.element),
      tap( open => notifWasOpen = open )
    ).subscribe({
      complete: () => this.store$.dispatch( new ToggleNotifications( notifWasOpen ) ),
    });
  }

  ngOnInit() {
    this.store$.dispatch( new LoadSynthesis() );
  }

  onUpdateOptions(options: ChartOptions) {
    this.options = options;
  }
}
