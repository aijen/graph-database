import { Pipe, PipeTransform } from '@angular/core';
import { AdminLeaf } from 'core/store/leaves/leaves.model';

@Pipe({
  name: 'GetSelectedAdminLeaves',
  pure: false
})
export class GetSelectedAdminLeaves implements PipeTransform {
  transform(items: AdminLeaf[]): AdminLeaf[] {
    if(!items) {
      return items;
    }

    return items.filter(leaf => leaf.selected === true);
  }
}
