import { Component, Input } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTabsModule } from '@angular/material/tabs';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { ChartsService } from 'shared/services/charts.service';
import { SynthesisChartsContainerComponent } from './synthesis-charts-container.component';

@Component({
  selector: 'pit-chart-view',
  template: '',
})
class PitChartViewStubComponent {
  @Input() data: any;
  @Input() leafKey: any;
  @Input() fromDate: any;
  @Input() range: any;
  @Input() chartFullName: any;
  @Input() baselines: any;
  @Input() publicHolidays: any;
  @Input() baselinesHidden: any;
  @Input() isSynthesis: any;
}

describe('SynthesisChartsContainerComponent', () => {
  let context: TestCtx<SynthesisChartsContainerComponent>;
  let chartsServiceStub: jasmine.SpyObj<ChartsService>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        MatProgressSpinnerModule,
        NoopAnimationsModule,
        MatTabsModule,
      ],
      declarations: [
        SynthesisChartsContainerComponent,
        PitChartViewStubComponent,
      ],
      providers: [
        { provide: ChartsService, useFactory: () => jasmine.createSpyObj('ChartsService', ['print', 'saveImage', 'saveAsExcel', 'getDataSetConfig', 'getDataSetBaseLineConfig', 'getDataSetUpperTresholdConfig', 'getDataSetLowerTresholdConfig', 'getOptionTimeOnChartByRange', 'getconfigUserXpYaxis', 'prepareChart', 'setRangeAndPrepareChart', 'convertBaseLineToDataSet'] as Array<keyof ChartsService>) },
      ],
    })
  });

  beforeEach(async( async () => {
    chartsServiceStub = TestBed.get(ChartsService);
    context = await createStableTestContext(SynthesisChartsContainerComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
