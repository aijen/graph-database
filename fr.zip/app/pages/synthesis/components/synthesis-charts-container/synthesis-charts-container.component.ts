import { Component, Input, OnInit } from '@angular/core';
import { fadeAnimation } from 'core/animations/animations';
import { ChartContainerData, ChartOptions } from 'shared/models/chart.model';
import { ChartsService } from 'shared/services/charts.service';

@Component({
  selector: 'pit-synthesis-charts-container',
  templateUrl: './synthesis-charts-container.component.html',
  styleUrls: ['./synthesis-charts-container.component.scss'],
  animations: [fadeAnimation()]
})
export class SynthesisChartsContainerComponent implements OnInit {
  chartData: ChartContainerData = new ChartContainerData();
  chartOption: ChartOptions;

  @Input() set options(chartOption: ChartOptions) {
    this.chartOption = chartOption;

    if(chartOption) {
      this.chartsService.prepareChart(this.chartData, chartOption);
    }
  }

  constructor(
    public chartsService: ChartsService,
  ) {}

  ngOnInit() {}
}
