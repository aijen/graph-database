import { Pipe, PipeTransform } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { Observable } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { SynthesisListViewComponent } from './synthesis-list-view.component';

@Pipe({
  name: 'GetSelectedAdminLeaves',
})
export class GetSelectedAdminLeavesStubPipe implements PipeTransform {
  transform(v: any): any {
    return v;
  }
}

describe('SynthesisListViewComponent', () => {
  let context: TestCtx<SynthesisListViewComponent>;
  let actions: Observable<any>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        NgbTooltipModule,
      ],
      declarations: [
        SynthesisListViewComponent,
        GetSelectedAdminLeavesStubPipe,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: {} }),
        provideMockActions(() => actions),
      ],
    })
  });

  beforeEach(async( async () => {
    context = await createStableTestContext(SynthesisListViewComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
