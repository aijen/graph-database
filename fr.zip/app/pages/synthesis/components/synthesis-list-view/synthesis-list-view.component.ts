import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Store } from '@ngrx/store';
import { AdminLeaf } from 'core/store/leaves/leaves.model';
import { ChartOptions } from 'shared/models/chart.model';
import { AppState } from 'shared/models/state.model';
import { getMetaState } from '../../store/synthesis/synthesis.selectors';

@Component({
  selector: 'pit-synthesis-list-view',
  templateUrl: './synthesis-list-view.component.html',
  styleUrls: ['./synthesis-list-view.component.scss']
})
export class SynthesisListViewComponent implements OnInit {
  @Input()
  leaves: AdminLeaf[];

  @Input()
  options: ChartOptions;

  @Output() updateOptions = new EventEmitter<ChartOptions>();

  trackByLeafId = ( index: number, { leafId }: AdminLeaf ) => leafId;

  constructor(private store$: Store<AppState>) { }

  ngOnInit() {}

  getState(leafId: string, metaType: string) {
    // TODO : Optimize when have time
    return this.store$.select(getMetaState(leafId, metaType));
  }

  changeOptions(leafId: string, metaType: string) {
    const leaf = this.leaves.find(leaf => leaf.leafId === leafId);

    this.updateOptions.emit({
      fullName: leaf.name,
      key: leaf.leafId,
      metaType: metaType,
      name: leaf.leafId,
      type: "chart"
    });
  }
}
