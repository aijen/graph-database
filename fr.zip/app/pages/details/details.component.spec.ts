import { Component, EventEmitter, Input, Output } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { MatDialogModule } from '@angular/material/dialog';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
/* import { MatDialog } from '@angular/material/dialog'; */
import { RouterTestingModule } from '@angular/router/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { ApiNodesService } from 'core/services/api/api.nodes';
import { authState as initialAuthState } from 'core/store/auth/auth.reducer';
import { hierarchyState } from 'core/store/hierarchy/hierarchy.reducer';
import { configureTestSuite, createTestContext, TestCtx } from 'ng-bullet';
import { Observable } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { DetailsComponent } from './details.component';

@Component({
  selector: 'pit-hatched-bar',
  template: '',
})
class PitHatchedBarStubComponent {
  @Input() metaType: any;
  @Input() metas: any;
  @Input() endDate: any;
  @Input() showTime: any;
  @Input() populatedMeta: any;
}

@Component({
  selector: 'pit-date-picker',
  template: '',
})
class PitDatePickerStubComponent {
  @Input() displayType: any;
  @Output() dateChange = new EventEmitter<any>();
}

describe('DetailsComponent', () => {
  let context: TestCtx<DetailsComponent>;
  let actions: Observable<any>;
  /* let matDialogStub: jasmine.SpyObj<MatDialog>; */
  let apiNodesServiceStub: jasmine.SpyObj<ApiNodesService>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        MatDialogModule,
        MatProgressSpinnerModule,
        MatTooltipModule,
        NoopAnimationsModule,
        RouterTestingModule,
      ],
      declarations: [
        DetailsComponent,
        PitHatchedBarStubComponent,
        PitDatePickerStubComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: { hierarchy: hierarchyState, auth: initialAuthState } }),
        provideMockActions(() => actions),
        /* { provide: MatDialog, useFactory: () => jasmine.createSpyObj('MatDialog', [] as Array<keyof MatDialog>) }, */
        { provide: ApiNodesService, useFactory: () => jasmine.createSpyObj('ApiNodesService', ['getUserNodes', 'getNodes', 'saveNodes', 'getLeavesByGivenCriteria', 'hideNodeFromTree', 'restoreDefaultsNodes'] as Array<keyof ApiNodesService>) },
      ],
    })
  });

  beforeEach(async( async () => {
    /* matDialogStub = TestBed.get(MatDialog); */
    apiNodesServiceStub = TestBed.get(ApiNodesService);
    context = await createTestContext(DetailsComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
