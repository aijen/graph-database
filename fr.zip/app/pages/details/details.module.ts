import { NgModule } from '@angular/core';
import { MatDialogModule } from '@angular/material/dialog';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { SharedModule } from 'shared/shared.module';
import { ChartsContainerComponent } from './components/charts-container/charts-container.component';
import { ChartsDatepickerComponent } from './components/charts-datepicker/charts-datepicker.component';
import { EditorialDetailsModule } from './components/editorial-details/editorial-details.module';
import { PopupComponent } from './components/popup/popup.component';
import { DetailsRoutingModule } from './details-routing.module';
import { DetailsComponent } from './details.component';

@NgModule({
  declarations: [
    DetailsComponent,
    ChartsDatepickerComponent,
    ChartsContainerComponent,
    PopupComponent,
  ],
  entryComponents: [PopupComponent],
  imports: [
    DetailsRoutingModule,
    SharedModule,
    MatProgressSpinnerModule,
    MatDialogModule,
    EditorialDetailsModule,
  ],
})
export class DetailsModule {}
