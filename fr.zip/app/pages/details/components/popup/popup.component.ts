import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Moment } from 'moment';
import { ChartOptions } from 'shared/models/chart.model';

@Component({
  selector: 'cockpit-popup',
  templateUrl: './popup.component.html',
  styleUrls: ['./popup.component.scss']
})
export class PopupComponent {

  options: ChartOptions;
  date: Moment;

  constructor( @Inject(MAT_DIALOG_DATA) data: { options: ChartOptions, date: Moment } ) {
    this.options = data.options;
    this.date = data.date;
  }
}
