import { Component, Input } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import moment from 'moment';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { ChartOptions } from 'shared/models/chart.model';
import { PopupComponent } from './popup.component';

@Component({
  selector: 'pit-close-modal',
  template: '',
})
class CloseModalStubComponent {
}

@Component({
  selector: 'pit-charts-container',
  template: '',
})
class ChartsContainerStubComponent {
  @Input() options: any;
  @Input() start: any;
}

describe('PopupComponent', () => {
  let context: TestCtx<PopupComponent>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      declarations: [
        PopupComponent,
        CloseModalStubComponent,
        ChartsContainerStubComponent
      ],
      providers: [
        { provide: MAT_DIALOG_DATA, useValue: { options: {} as ChartOptions, date: moment() } },
      ],
    })
  });

  beforeEach(async( async () => {
    context = await createStableTestContext(PopupComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
