import { Component, Input } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { CockpitLeaf } from 'shared/models/cockpit-leaf.model';
import { EditorialDetailsComponent } from './editorial-details.component';

@Component({
  selector: 'pit-close-modal',
  template: '',
})
class PitCloseModalStubComponent {}

@Component({
  selector: 'pit-working-hours-bloc',
  template: '',
})
class PitWorkingHoursBlocStubComponent {
  @Input() workingHours: any;
}

@Component({
  selector: 'pit-editorial-bloc',
  template: '',
})
class PitEditorialBlocStubComponent {
  @Input() editorial: any;
}

describe('EditorialDetailsComponent', () => {
  let context: TestCtx<EditorialDetailsComponent>;
  const leaf: CockpitLeaf = {
    id: undefined,
    key: 'key',
    fullname: 'fullname',
    description: 'description',
    workingHours: {
      MON: { start: 0, end: 0, enabled: true },
      TUE: { start: 0, end: 0, enabled: true },
      WED: { start: 0, end: 0, enabled: true },
      THU: { start: 0, end: 0, enabled: true },
      FRI: { start: 0, end: 0, enabled: true },
      SAT: { start: 0, end: 0, enabled: true },
      SUN: { start: 0, end: 0, enabled: true },
    },
    irtCode: '',
    editorialData: []
  };

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
      ],
      declarations: [
        EditorialDetailsComponent,
        PitCloseModalStubComponent,
        PitWorkingHoursBlocStubComponent,
        PitEditorialBlocStubComponent,
      ],
      providers: [
        { provide: MAT_DIALOG_DATA, useValue: { leaf } },
      ],
    })
  });

  beforeEach(async( async () => {
    context = await createStableTestContext(EditorialDetailsComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
