import { NgModule } from '@angular/core';
import { MatDialogModule } from '@angular/material/dialog';
import { SharedModule } from 'shared/shared.module';
import { EditorialBlocComponent } from '../editorial-bloc/editorial-bloc.component';
import { WorkingHoursBlocComponent } from '../working-hours-bloc/working-hours-bloc.component';
import { EditorialDetailsComponent } from './editorial-details.component';

@NgModule({
  declarations: [
    EditorialDetailsComponent,
    WorkingHoursBlocComponent,
    EditorialBlocComponent,
  ],
  entryComponents: [ EditorialDetailsComponent ],
  imports: [
    SharedModule,
    MatDialogModule,
  ],
})
export class EditorialDetailsModule { }
