import { Component, Inject, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CockpitLeaf, EditorialDataType, getTypeLabel } from 'shared/models/cockpit-leaf.model';

@Component({
  selector: 'pit-editorial-details',
  templateUrl: './editorial-details.component.html',
  styleUrls: ['./editorial-details.component.scss']
})
export class EditorialDetailsComponent implements OnInit {

  isWorkingHoursOpen = true;
  isIrtCodeOpen = true;
  isEditorialOpen: boolean[] = [];

  static openDialog( dialog: MatDialog, config: MatDialogConfig<{ leaf: CockpitLeaf }> ) {
    return dialog.open<EditorialDetailsComponent, { leaf: CockpitLeaf }>(EditorialDetailsComponent, config);
  }

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: { leaf: CockpitLeaf },
  ) {
    data.leaf.editorialData.forEach(() => this.isEditorialOpen.push(true));
  }

  ngOnInit() {
  }

  getTypeLabel(type: EditorialDataType): string {
    return getTypeLabel(type);
  }

  toggleWorkingHours() {
    this.isWorkingHoursOpen = !this.isWorkingHoursOpen;
  }

  toggleIrtCode() {
    this.isIrtCodeOpen = !this.isIrtCodeOpen;
  }

  toggleEditorial(index: number) {
    this.isEditorialOpen[index] = !this.isEditorialOpen[index];
  }
}
