import { Component, Input, OnInit } from '@angular/core';
import { fadeAnimation } from 'core/animations/animations';
import { Moment } from 'moment';
import { ChartContainerData, ChartDate, ChartOptions, RangeTime } from 'shared/models/chart.model';
import { ChartsService } from 'shared/services/charts.service';

@Component({
  selector: 'pit-charts-container',
  templateUrl: './charts-container.component.html',
  styleUrls: ['./charts-container.component.scss'],
  animations: [fadeAnimation()],
})
export class ChartsContainerComponent implements OnInit {
  chartData: ChartContainerData = new ChartContainerData();
  public dropdownIsOpen: boolean[] = [];

  @Input() options: ChartOptions;
  @Input() start: Moment;

  constructor(
    public chartsService: ChartsService,
  ) {}

  ngOnInit() {
    this.chartsService.setRangeAndPrepareChart(this.chartData, this.options, { range: RangeTime.SixHours, start: this.start });
  }

  onChangeDate(date: ChartDate) {
    this.chartsService.setRangeAndPrepareChart(this.chartData, this.options, date);
  }

  toggleDropdown( index: number, state = !this.dropdownIsOpen[index] ) {
    this.dropdownIsOpen[index] = state;
  }
}
