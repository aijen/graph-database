import { Component, Directive, EventEmitter, Input, Output } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { ChartsService } from 'shared/services/charts.service';
import { ChartsContainerComponent } from './charts-container.component';

@Component({
  selector: 'pit-charts-datepicker',
  template: '',
})
class PitChartsDatepickerStubComponent {
  @Output() changeDate = new EventEmitter<any>();
  @Input() start: any;
  @Input() range: any;
}

@Component({
  selector: 'pit-chart-view',
  template: '',
})
class PitChartViewStubComponent {
  @Input() data: any;
  @Input() leafKey: any;
  @Input() fromDate: any;
  @Input() range: any;
  @Input() chartFullName: any;
  @Input() baselines: any;
  @Input() publicHolidays: any;
}

@Directive({
  selector: '[cockpitOnClickOutside]',
})
class CockpitOnClickOutsideStubDirective {
  @Output() cockpitOnClickOutside = new EventEmitter<any>();
}

describe('ChartsContainerComponent', () => {
  let context: TestCtx<ChartsContainerComponent>;
  let chartsServiceStub: jasmine.SpyObj<ChartsService>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        MatProgressSpinnerModule,
        NoopAnimationsModule,
      ],
      declarations: [
        ChartsContainerComponent,
        PitChartsDatepickerStubComponent,
        PitChartViewStubComponent,
        CockpitOnClickOutsideStubDirective,
      ],
      providers: [
        { provide: ChartsService, useFactory: () => jasmine.createSpyObj('ChartsService', ['print', 'saveImage', 'saveAsExcel', 'getDataSetConfig', 'getDataSetBaseLineConfig', 'getDataSetUpperTresholdConfig', 'getDataSetLowerTresholdConfig', 'getOptionTimeOnChartByRange', 'getconfigUserXpYaxis', 'prepareChart', 'setRangeAndPrepareChart', 'convertBaseLineToDataSet'] as Array<keyof ChartsService>) },
      ],
    })
  });

  beforeEach(async( async () => {
    chartsServiceStub = TestBed.get(ChartsService);
    context = await createStableTestContext(ChartsContainerComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
