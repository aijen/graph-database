import { Component, ViewChild } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { configureTestSuite } from 'ng-bullet';
import { EditorialData, EditorialDataType } from 'shared/models/cockpit-leaf.model';
import { EditorialBlocComponent } from './editorial-bloc.component';

@Component({
  selector: `host-component`,
  template: `<pit-editorial-bloc></pit-editorial-bloc>`
})
class TestHostComponent {
  @ViewChild(EditorialBlocComponent)
  public component: EditorialBlocComponent;
}

describe('EditorialBlocComponent', () => {
  let testHostFixture: ComponentFixture<TestHostComponent>;
  let testHostComponent: TestHostComponent;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
      ],
      declarations: [
        TestHostComponent,
        EditorialBlocComponent,
      ],
    })
  });

  beforeEach(async( async () => {
    testHostFixture = TestBed.createComponent(TestHostComponent);
    testHostComponent = testHostFixture.componentInstance;
    testHostComponent.component.editorial = { type: EditorialDataType.TRIGRAM, text: 'TRI' } as EditorialData;
    testHostFixture.detectChanges();
  } ));

  it('should create', () => {
    expect(testHostComponent).toBeTruthy();
    expect(testHostComponent.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
