import { Component, Input } from '@angular/core';
import { GET_USER_FILE_URL } from 'core/services/http/http-client.service';
import { EditorialData, isFileType } from 'shared/models/cockpit-leaf.model';

@Component({
  selector: 'pit-editorial-bloc',
  templateUrl: './editorial-bloc.component.html',
  styleUrls: ['./editorial-bloc.component.scss']
})
export class EditorialBlocComponent {
  @Input()
  editorial: EditorialData;

  constructor() { }

  isFileType(): boolean {
    return isFileType(this.editorial.type);
  }

  getFileUrl(fileName: string) {
    return `${GET_USER_FILE_URL}?fileName=${fileName}`;
  }
}
