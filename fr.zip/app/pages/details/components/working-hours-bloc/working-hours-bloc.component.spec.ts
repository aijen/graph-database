import { Component, ViewChild } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { configureTestSuite } from 'ng-bullet';
import { WorkingHoursBlocComponent } from './working-hours-bloc.component';

@Component({
  selector: `host-component`,
  template: `<pit-working-hours-bloc></pit-working-hours-bloc>`
})
class TestHostComponent {
  @ViewChild(WorkingHoursBlocComponent)
  public component: WorkingHoursBlocComponent;
}

describe('WorkingHoursBlocComponent', () => {
  let testHostFixture: ComponentFixture<TestHostComponent>;
  let testHostComponent: TestHostComponent;
  const workingHours = {
    MON: { start: 0, end: 0, enabled: true },
    TUE: { start: 0, end: 0, enabled: true },
    WED: { start: 0, end: 0, enabled: true },
    THU: { start: 0, end: 0, enabled: true },
    FRI: { start: 0, end: 0, enabled: true },
    SAT: { start: 0, end: 0, enabled: true },
    SUN: { start: 0, end: 0, enabled: true },
  };

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
      ],
      declarations: [
        TestHostComponent,
        WorkingHoursBlocComponent,
      ],
    })
  });

  beforeEach(async( async () => {
    testHostFixture = TestBed.createComponent(TestHostComponent);
    testHostComponent = testHostFixture.componentInstance;
    testHostComponent.component.workingHours = workingHours;
    testHostFixture.detectChanges();
  } ));

  it('should create', () => {
    expect(testHostComponent).toBeTruthy();
    expect(testHostComponent.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
