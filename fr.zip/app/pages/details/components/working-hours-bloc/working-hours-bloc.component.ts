import { Component, Input } from '@angular/core';
import { WorkingHours } from 'shared/models/cockpit-leaf.model';

@Component({
  selector: 'pit-working-hours-bloc',
  templateUrl: './working-hours-bloc.component.html',
  styleUrls: ['./working-hours-bloc.component.scss']
})
export class WorkingHoursBlocComponent {
  @Input()
  workingHours: {
    MON: WorkingHours,
    TUE: WorkingHours,
    WED: WorkingHours,
    THU: WorkingHours,
    FRI: WorkingHours,
    SAT: WorkingHours,
    SUN: WorkingHours,
  };

  constructor() { }
}
