import { Component, EventEmitter, Input, Output } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { ChartsDatepickerComponent } from './charts-datepicker.component';

@Component({
  selector: 'pit-date-picker',
  template: '',
})
class DatePickerStubComponent {
  @Input() selectedDate: any;
  @Input() displayType: any;
  @Output() dateChange = new EventEmitter<any>();
}

describe('ChartsDatepickerComponent', () => {
  let context: TestCtx<ChartsDatepickerComponent>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule
      ],
      declarations: [
        ChartsDatepickerComponent,
        DatePickerStubComponent,
      ],
    })
  });

  beforeEach(async( async () => {
    context = await createStableTestContext(ChartsDatepickerComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
