import { Component, EventEmitter, Input, Output } from '@angular/core';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { UnitDateTime } from 'core/services/moment/moment.service';
import moment from 'moment';
import { ChartDate } from 'shared/models/chart.model';
import { DatepickerDisplayType } from 'shared/models/datepicker.models';

moment.locale('fr');

@Component({
  selector: 'pit-charts-datepicker',
  templateUrl: './charts-datepicker.component.html',
  styleUrls: ['./charts-datepicker.component.scss'],
})
export class ChartsDatepickerComponent {
  selectedHour: string;
  selectedPeriod = '6';
  selectedDate: moment.Moment;
  datepickerDisplayType = DatepickerDisplayType;
  hours: string[] = [
    '00:00',
    '01:00',
    '02:00',
    '03:00',
    '04:00',
    '05:00',
    '06:00',
    '07:00',
    '08:00',
    '09:00',
    '10:00',
    '11:00',
    '12:00',
    '13:00',
    '14:00',
    '15:00',
    '16:00',
    '17:00',
    '18:00',
    '19:00',
    '20:00',
    '21:00',
    '22:00',
    '23:00'
  ];

  @Input() range: number

  @Input() set start(date: moment.Moment) {
    this.selectedHour = date.format('HH:00');
    this.selectedDate = date;
  }

  @Output() changeDate = new EventEmitter<ChartDate>();

  constructor() {
  }

  onDateSelect(event: MatDatepickerInputEvent<moment.Moment>) {
    this.selectedDate = event.value.clone().hour(this.selectedDate.hour()).minute(this.selectedDate.minute());

    this.changeDate.emit({ start: this.selectedDate, range: this.range });
  }

  onHourSelect(hour: string) {
    this.selectedDate.minute(0);
    this.selectedDate.hour(
      hour.substring(1, 2) === ':'
        ? parseInt(hour.substring(0, 1), 10)
        : parseInt(hour.substring(0, 2), 10)
    );

    this.changeDate.emit({ start: this.selectedDate, range: this.range });
  }

  onPrevious() {
    this.selectedDate.subtract(this.range, UnitDateTime.SECONDS);

    this.changeDate.emit({ start: this.selectedDate, range: this.range });
  }

  onChangeRange(range: number, period: string) {
    this.selectedPeriod = period;
    this.range = range;

    this.changeDate.emit({ start: this.selectedDate, range: range });
  }

  onNext() {
    this.selectedDate.add(this.range, UnitDateTime.SECONDS);

    this.changeDate.emit({ start: this.selectedDate, range: this.range });
  }
}
