import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { Store } from '@ngrx/store';
import { fadeAnimation } from 'core/animations/animations';
import { ApiNodesService } from 'core/services/api/api.nodes';
import { INTERVAL } from 'core/services/http/http-client.service';
import { getCockpitLeaves, getNodeByKey } from 'core/store/hierarchy/hierarchy.selectors';
import { MetasCheck } from 'core/store/leaves/leaves.model';
import { getPopulatedMetasForLeaf } from 'core/store/populated-metas/populated-metas.selectors';
import { SubscriptionAwareComponent } from 'core/utils/subscription-aware.component';
import moment from 'moment';
import { BehaviorSubject, Observable, of, Subject, timer } from 'rxjs';
import { filter, map, startWith, switchMap, switchMapTo, take, tap } from 'rxjs/operators';
import { HatchedBarService } from 'shared/components/hatched-bar/hatched-bar.service';
import { ChartOptions } from 'shared/models/chart.model';
import { CockpitLeaf } from 'shared/models/cockpit-leaf.model';
import { DatepickerDisplayType } from 'shared/models/datepicker.models';
import { Leaf } from 'shared/models/leaf.model';
import { AppState } from 'shared/models/state.model';
import { AdminLeafMetaType } from 'shared/store/leaves/leaves.form.model';
import { EditorialDetailsComponent } from './components/editorial-details/editorial-details.component';
import { PopupComponent } from './components/popup/popup.component';

interface DateRange {
  from: moment.Moment,
  to: moment.Moment,
  selected?: moment.Moment
}

@Component({
  selector: 'cockpit-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.scss'],
  animations: [fadeAnimation(0)],
})
export class DetailsComponent extends SubscriptionAwareComponent implements OnInit {

  id: string
  metaType: string
  isModalDisplayed = false;

  public leaf: Leaf = new Leaf();
  public fromDate = moment().subtract(5, 'minutes');
  public toDate = moment().subtract(5, 'minutes');
  public selectedDate = moment().subtract(5, 'minutes');
  public datepickerDisplayType = DatepickerDisplayType;

  private options: ChartOptions
  private loaderSubject$: BehaviorSubject<boolean> = new BehaviorSubject(true);
  public loaderObserver$: Observable<boolean> = this.loaderSubject$.asObservable();

  private dateSelect$ = new Subject<DateRange>()
  public isEndDate = false
  public endDate = moment().subtract(5, 'minutes')
  public startRange = moment().subtract(5, 'minutes')
  public canForward = false
  public canBackward = false

  private leafKey$ = new BehaviorSubject<string>('')
  populatedMeta$ = this.leafKey$.pipe( switchMap( leafKey => this.store$.select(getPopulatedMetasForLeaf(leafKey)) ) )
  cockpitLeaves$ = this.store$.select(getCockpitLeaves);

  constructor(
    private dialog: MatDialog,
    private activatedRoute: ActivatedRoute,
    private store$: Store<AppState>,
    private apiNodesService: ApiNodesService,
  ) {
    super();
    this.leaf.description = '';
  }

  ngOnInit() {

    this.subscription.add(
      this.activatedRoute.params.subscribe(params => {
        const { id, graph } = params;
        this.id = id;
        this.metaType = graph;
        this.leafKey$.next(id)
      })
    );

    this.subscription.add(
      this.store$.select(getNodeByKey, this.id).pipe(
        filter(leaf => Boolean(leaf)),
        filter(Leaf.isLeaf),
        take(1),
        tap(leaf => {
          this.leaf = Leaf.clone(leaf);
          this.leaf.metas = []
          this.computeLeafTitle();
          this.shouldDisplayGraph();
        }),
        switchMapTo(
          this.dateSelect$
        ),
        startWith( this.getNow( true ) ),
        switchMap( ( { from, to, selected } ) => moment().isSame(selected, 'day') ? timer(0, INTERVAL).pipe( map( count => count === 0 ? { from, to, selected } : this.getNow() ) ) : of({ from, to, selected }) ),
        switchMap( ( range ) =>
          this.apiNodesService.getLeavesByGivenCriteria(this.id, range.from.clone().subtract(35, 'minutes').unix(), range.to.clone().unix(), 1).pipe(
            map( leaves => ({ metas: leaves && leaves[0] ? leaves[0].metas : [], range }) )
          )
        ),
        tap( ({ metas, range: { from, to, selected } }) => {
          if( !selected && this.selectedDate.isSame(this.toDate) ) selected = to.clone()
          this.leaf.metas = metas
          this.fromDate = from
          this.toDate = to
          this.setSelectedDate( selected || this.selectedDate )
          this.loaderSubject$.next(false);
        })
      ).subscribe()
    )
  }

  private getNow( withSelected = false ): DateRange {
    const to = moment().subtract( HatchedBarService.TIME_TO_AVOID_GREY_BARS, 'seconds' )
    const from = to.clone().subtract(1, 'day')
    const selected = withSelected ? to.clone() : undefined
    return { from, to, selected }
  }

  onDateSelect( date: moment.Moment ) {
    this.loaderSubject$.next(true);

    if(moment().isSame(date, 'date')) {
      this.dateSelect$.next( this.getNow( true ) )
    }
    else {
      const selected = date.clone().hours(12).startOf('hour')
      const from = selected.clone().startOf('day')
      const to = from.clone().add(1, 'day')
      this.dateSelect$.next({ from, to, selected })
    }

  }


  private shouldDisplayGraph() {
    if( this.metaType && !this.isModalDisplayed ) {
      this.setOptionsGraph(this.metaType, true)
      this.isModalDisplayed = true
    }
  }

  public setOptionsGraph(metaType: string, showGraphAfterSetOptions: boolean = false): void {
    this.options = {
      type: 'chart',
      key: this.leaf.key || this.id,
      name: this.leaf.name,
      fullName: this.leaf.fullname,
      metaType
    };

    setTimeout(() => {
      if(showGraphAfterSetOptions) this.displayPopup(this.options);
    });
  }

  private setSelectedDate( selected: moment.Moment ) {
    const fromDate = this.fromDate.clone().add(3, 'hours')

    if( selected.isBefore(fromDate) ) selected = fromDate
    if( selected.isAfter(this.toDate) ) selected = this.toDate.clone()

    this.selectedDate = selected;
    this.startRange = selected.clone().subtract(3, 'hours')
    this.isEndDate = this.selectedDate.isSame(this.endDate)
    this.canForward = this.selectedDate.diff(this.toDate) < 0
    this.canBackward = this.startRange.diff(this.fromDate, 'hours') > 0
  }

  public getPreviousRange() {
    this.setSelectedDate( this.selectedDate.clone().subtract(3, 'hours') )
  }

  public getNextRange() {
    this.setSelectedDate( this.selectedDate.clone().add(3, 'hours') )
  }

  public goFirstRange() {
    this.setSelectedDate(this.toDate.clone())
  }

  public goLastRange() {
    this.setSelectedDate(this.fromDate.clone().add(3, 'hours'))
  }

  private displayPopup(options: ChartOptions) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.position = { top: '75px' };
    dialogConfig.disableClose = true;
    dialogConfig.minHeight = 'calc(100vh - 150px)';
    dialogConfig.maxHeight = 'calc(100vh - 80px)';
    dialogConfig.width = '80vw';
    dialogConfig.data = {
      options,
      date: this.selectedDate.clone(),
    };

    this.dialog.open(PopupComponent, dialogConfig);
  }

  private computeLeafTitle(): void {
    this.leaf.title =
      this.leaf.fullname ||
      this.leaf.name ||
      this.leaf.key ||
      'Pas de titre dans les données';
  }

  hasMetaType(metaType: AdminLeafMetaType, metas: MetasCheck) {
    return metas && metas[metaType];
  }

  private getCockpitLeafByKey(cockpitLeaves: CockpitLeaf[], leafKey: string): CockpitLeaf {
    const matchedLeaves = cockpitLeaves.filter(l => l.key === leafKey);

    if(matchedLeaves.length > 1) {
      const matchedLeaf = matchedLeaves.find(l => l.source ? l.source.toLocaleUpperCase() !== 'BAD' : true);

      if(matchedLeaf) {
        return matchedLeaf;
      }
      else {
        return matchedLeaves[0];
      }
    }
    else if(matchedLeaves.length === 1) {
      return matchedLeaves[0];
    }

    return undefined;
  }

  getLeafDescription(cockpitLeaves: CockpitLeaf[], leafKey: string): string {
    const leaf = this.getCockpitLeafByKey(cockpitLeaves, leafKey);

    return leaf === undefined ? '' : leaf.description;
  }

  async openEditorialDetails() {
    const cockpitLeaves = await this.cockpitLeaves$.pipe(take(1)).toPromise();

    const leaf = this.getCockpitLeafByKey(cockpitLeaves, this.leaf.key);

    const config = new MatDialogConfig();
    config.disableClose = true;
    config.maxHeight = '95vh';
    config.width = '80vw';
    config.data = { leaf };

    EditorialDetailsComponent.openDialog(this.dialog, config);
  }
}
