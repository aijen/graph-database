import { async, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSelectModule } from '@angular/material/select';
import { MatTooltipModule } from '@angular/material/tooltip';
import { provideMockActions } from '@ngrx/effects/testing';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { User } from 'core/models/user.model';
import { UserRole } from 'core/models/userRoles.model';
import { GroupsValue } from 'core/store/groups/groups.model';
import { DeleteTemplate, ResetTemplatesForm, SaveTemplatesFormError, SaveTemplatesFormSuccess, UpdateTemplates } from 'core/store/templates/templates.form.actions';
import { PUBLIC_GROUP, Template, TemplatesFormValue, TemplateType } from 'core/store/templates/templates.form.model';
import { templatesFormState } from 'core/store/templates/templates.form.reducer';
import { TemplatesFormService } from 'core/store/templates/templates.form.service';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { createFormGroupState, FormGroupState, NgrxFormsModule } from 'ngrx-forms';
import { Observable, of } from 'rxjs';
import { marbles } from 'rxjs-marbles/marbles';
import { AppState } from 'shared/models/state.model';
import { ManageTemplatesComponent } from './manage-templates.component';

const generateUser = (user?: Partial<User>): User => {
  return {
    ...User.from(),
    ...user,
  }
};

const generateTemplatesForm = (templatesForm?: Partial<TemplatesFormValue>) => createFormGroupState<TemplatesFormValue>('ADMIN_TEMPLATES_FORM', {
  ...templatesFormState.templatesForm.value,
  ...templatesForm,
});

const generateTemplate = (template?: Partial<Template>): Template => {
  return {
    id: 'id',
    name: 'name',
    type: TemplateType.USER,
    owner: 'userId',
    nodes: [],
    hiddenNodes: {},
    nodesPosition: [[], [], [], []],
    ...template,
  }
};

const generateGroup = (group?: Partial<GroupsValue>): GroupsValue => {
  return {
    id: 'id',
    name: 'name',
    description: 'description',
    users: [],
    admins: [],
    defaultTemplate: '',
    ...group,
  };
};

describe('ManageTemplatesComponent', () => {
  let context: TestCtx<ManageTemplatesComponent>;
  let store: MockStore<AppState>;
  let actions: Observable<any>;
  let dialogRef: jasmine.SpyObj<MatDialogRef<ManageTemplatesComponent>>;
  const templates = [
    generateTemplate({ id: 'ID1', name: 'template 1', type: TemplateType.USER, owner: 'A123456' }),
    generateTemplate({ id: 'ID2', name: 'template 2', type: TemplateType.GROUP, owner: 'ID1' }),
    generateTemplate({ id: 'ID3', name: 'template 3', type: TemplateType.PUBLIC, owner: undefined }),
  ];
  const form = generateTemplatesForm({ templates });

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        MatSelectModule,
        NgrxFormsModule,
        MatTooltipModule,
      ],
      declarations: [
        ManageTemplatesComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: {
          auth: { user: generateUser({ userId: 'A123456' }), isUserAuthenticated: true, profil: { profiles: [UserRole.PUBLIC], permissions: [] } },
        } }),
        provideMockActions(() => actions),
        { provide: TemplatesFormService, useFactory: () => ({ form$: of(form) }) },
        { provide: MatDialogRef, useFactory: () => jasmine.createSpyObj('MatDialogRef', ['close'] as Array<keyof MatDialogRef<ManageTemplatesComponent>>) },
        { provide: MAT_DIALOG_DATA, useValue: { userId: 'A123456', groups: [generateGroup({ id: 'ID2', name: 'group 2', admins: ['A123456'] }), generateGroup({ id: 'ID3', name: 'group 3', users: ['A123456'], admins: ['A123456'] })] } },
      ],
    })
  });

  beforeEach(async( async () => {
    store = TestBed.get(Store);
    actions = null;
    dialogRef = TestBed.get(MatDialogRef);
    context = await createStableTestContext(ManageTemplatesComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });

  describe('getGroupTemplates', () => {

    it('should return an empty array', () => {
      context.component.selectedGroup = PUBLIC_GROUP;

      expect(context.component.getGroupTemplates(null)).toEqual([]);
    });

    it('should return an array of groups', () => {
      const result = createFormGroupState<Template>('ADMIN_TEMPLATES_FORM.templates.0', generateTemplate({ id: 'ID1', name: 'template 1', type: TemplateType.USER, owner: 'A123456' }));

      expect(context.component.getGroupTemplates(form.controls.templates.controls as FormGroupState<Template>[])).toEqual([result]);
    });

  });

  describe('formatError', () => {

    it('should be unique', () => {
      expect(context.component.formatError({ notUnique: true })).toEqual('La valeur doit être unique');
    });

    it('should not be empty', () => {
      expect(context.component.formatError({ required: { actual: true } })).toEqual('La valeur ne peut pas être vide');
    });

    it('should be undefined', () => {
      expect(context.component.formatError({})).toBe(undefined);
    });

  });

  describe('delete', () => {

    it('should dispatch a DeleteTemplate action', () => {
      const dispatchSpy = spyOn(store, 'dispatch');
      const template = generateTemplate({ id: 'ID1', name: 'template 1', type: TemplateType.USER, owner: 'A123456' });

      context.component.delete(template);

      expect(dispatchSpy).toHaveBeenCalledWith(new DeleteTemplate({ template }));
    });

  });

  describe('save', () => {

    it('should save and close', marbles(m => {
      const dispatchSpy = spyOn(store, 'dispatch');

      actions =         m.hot('a', {
        a: new SaveTemplatesFormSuccess()
      });

      context.component.save().then(() => {
        expect(dispatchSpy).toHaveBeenCalledWith(new UpdateTemplates());
        expect(dialogRef.close).toHaveBeenCalled();
      });
    }));

    it('should not save due to error', marbles(m => {
      const dispatchSpy = spyOn(store, 'dispatch');

      actions =         m.hot('a', {
        a: new SaveTemplatesFormError({ error: new Error() })
      });

      context.component.save().then(() => {
        expect(dispatchSpy).toHaveBeenCalledWith(new UpdateTemplates());
        expect(dialogRef.close).not.toHaveBeenCalled();
      });
    }));

  });

  describe('reset', () => {

    it('should dispatch a ResetTemplatesForm action', () => {
      const dispatchSpy = spyOn(store, 'dispatch');

      context.component.reset();

      expect(dispatchSpy).toHaveBeenCalledWith(new ResetTemplatesForm());
    });

  });

  describe('quit', () => {

    it('should reset then close', () => {
      const dispatchSpy = spyOn(store, 'dispatch');

      context.component.quit();

      expect(dispatchSpy).toHaveBeenCalledWith(new ResetTemplatesForm());
      expect(dialogRef.close).toHaveBeenCalled();
    });

  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
