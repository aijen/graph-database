import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Actions, ofType } from '@ngrx/effects';
import { select, Store } from '@ngrx/store';
import { canCreatePublicTemplates } from 'core/store/auth/auth.selectors';
import { GroupsValue } from 'core/store/groups/groups.model';
import { SetTemplateName } from 'core/store/hierarchy/hierarchy.actions';
import { getTemplateName } from 'core/store/hierarchy/hierarchy.selectors';
import { DeleteTemplate, ResetTemplatesForm, TemplatesFormActionTypes, TemplatesFormActionUnion, UpdateTemplates } from 'core/store/templates/templates.form.actions';
import { PRIVATE_GROUP, PUBLIC_GROUP, Template } from 'core/store/templates/templates.form.model';
import { getDeletedTemplates } from 'core/store/templates/templates.form.selectors';
import { TemplatesFormService } from 'core/store/templates/templates.form.service';
import { canResetForm, canSaveForm, isFormDisabled } from 'core/utils/forms.helpers';
import { FormGroupState, ValidationErrors } from 'ngrx-forms';
import { of } from 'rxjs';
import { filter, map, switchMapTo, take, tap } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';

@Component({
  selector: 'pit-manage-templates',
  templateUrl: './manage-templates.component.html',
  styleUrls: ['./manage-templates.component.scss']
})
export class ManageTemplatesComponent implements OnInit {

  PUBLIC_GROUP = PUBLIC_GROUP;
  PRIVATE_GROUP = PRIVATE_GROUP;

  selectedGroup = this.dialogData.userId;
  form$ = this.templatesFormService.form$;
  templates$ = this.form$.pipe(select(form => form.controls.templates.controls));
  canCreatePublicTemplates$ = this.store$.select(canCreatePublicTemplates);
  templateName$ = this.store$.select(getTemplateName);
  deletedTemplates$ = this.store$.select(getDeletedTemplates);

  trackByName = (index: number, { name }: Template | GroupsValue) => name;

  canSave$ = this.form$.pipe(
    canSaveForm
  );

  canReset$ = this.form$.pipe(
    canResetForm
  );

  isDisabled$ = this.form$.pipe(
    isFormDisabled
  );

  constructor(
    private store$: Store<AppState>,
    private templatesFormService: TemplatesFormService,
    private actions$: Actions,
    private dialogRef: MatDialogRef<ManageTemplatesComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData: { userId: string, groups: GroupsValue[] },
  ) { }

  ngOnInit() {
  }

  getGroupTemplates(templates: FormGroupState<Template>[]) {
    const owner = this.selectedGroup === PUBLIC_GROUP ? undefined : this.selectedGroup;

    return templates === null ? [] : templates.filter(template => template.value.owner === owner);
  }

  formatError( errors: ValidationErrors ) {
    if( errors.notUnique ) return 'La valeur doit être unique';
    if( errors.required ) return 'La valeur ne peut pas être vide';
  }

  delete(template: Template) {
    this.store$.dispatch(new DeleteTemplate({ template }));
  }

  async save() {
    const templates = await this.templates$.pipe(take(1)).toPromise();
    const deletedTemplates = await this.deletedTemplates$.pipe(take(1)).toPromise();
    const templateName = await this.templateName$.pipe(take(1), map(n => n && n.charAt(n.length - 1) === '*' ? n.substr(0, n.length - 1) : n)).toPromise();

    const templatesNames = deletedTemplates.map(template => template.value.name);
    const nbTemplatesWithActualName = templates.filter(t => t.value.name === templateName).length;

    if(templatesNames.includes(templateName) && nbTemplatesWithActualName === 0) {
      this.store$.dispatch(new SetTemplateName({ templateName: undefined }));
    }

    await of( new UpdateTemplates() ).pipe(
      tap( ( save ) => this.store$.dispatch( save ) ),
      switchMapTo( this.actions$ ),
      ofType<TemplatesFormActionUnion>( TemplatesFormActionTypes.SaveTemplatesFormSuccess, TemplatesFormActionTypes.SaveTemplatesFormError ),
      take(1),
      filter( ( action ) => action.type === TemplatesFormActionTypes.SaveTemplatesFormSuccess ),
      tap( () => this.dialogRef.close() ),
    ).toPromise();
  }

  reset() {
    this.store$.dispatch(new ResetTemplatesForm());
  }

  quit() {
    this.reset();
    this.dialogRef.close();
  }

}
