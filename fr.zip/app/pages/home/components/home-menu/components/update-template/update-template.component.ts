import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Actions, ofType } from '@ngrx/effects';
import { select, Store } from '@ngrx/store';
import { canCreatePublicTemplates } from 'core/store/auth/auth.selectors';
import { GroupsValue } from 'core/store/groups/groups.model';
import { SetTemplateName } from 'core/store/hierarchy/hierarchy.actions';
import { getHierarchyState } from 'core/store/hierarchy/hierarchy.selectors';
import { ResetTemplatesForm, TemplatesFormActionTypes, TemplatesFormActionUnion, ToggleUpdateTemplate, UpdateTemplates } from 'core/store/templates/templates.form.actions';
import { PRIVATE_GROUP, PUBLIC_GROUP, Template } from 'core/store/templates/templates.form.model';
import { getUpdatedTemplates } from 'core/store/templates/templates.form.selectors';
import { TemplatesFormService } from 'core/store/templates/templates.form.service';
import { canResetForm, canSaveForm, isFormDisabled } from 'core/utils/forms.helpers';
import { FormGroupState } from 'ngrx-forms';
import { of } from 'rxjs';
import { filter, map, switchMapTo, take, tap } from 'rxjs/operators';
import { Node } from 'shared/models/node.model';
import { AppState } from 'shared/models/state.model';

@Component({
  selector: 'pit-update-template',
  templateUrl: './update-template.component.html',
  styleUrls: ['./update-template.component.scss']
})
export class UpdateTemplateComponent implements OnInit {

  PUBLIC_GROUP = PUBLIC_GROUP;
  PRIVATE_GROUP = PRIVATE_GROUP;

  selectedGroup = this.dialogData.userId;
  form$ = this.templatesFormService.form$;
  templates$ = this.form$.pipe(select(form => form.controls.templates.controls));
  canCreatePublicTemplates$ = this.store$.select(canCreatePublicTemplates);
  userView$ = this.store$.select(getHierarchyState).pipe(map(state => { return { nodes: Node.toJSONCollection(state.nodes), hiddenNodes: state.hiddenNodes, nodesPosition: state.nodesPosition } }));
  updatedTemplates$ = this.store$.select(getUpdatedTemplates);

  trackByName = (index: number, { name }: Template | GroupsValue) => name;

  canSave$ = this.form$.pipe(
    canSaveForm
  );

  canReset$ = this.form$.pipe(
    canResetForm
  );

  isDisabled$ = this.form$.pipe(
    isFormDisabled
  );

  constructor(
    private store$: Store<AppState>,
    private templatesFormService: TemplatesFormService,
    private actions$: Actions,
    private dialogRef: MatDialogRef<UpdateTemplateComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData: { userId: string, groups: GroupsValue[] },
  ) { }

  ngOnInit() {
  }

  getGroupTemplates(templates: FormGroupState<Template>[]) {
    const owner = this.selectedGroup === PUBLIC_GROUP ? undefined : this.selectedGroup;

    return templates === null ? [] : templates.filter(template => template.value.owner === owner);
  }

  isChecked(templateId: string, updatedTemplates: Template[]) {
    return updatedTemplates.find(t => t.id === templateId) !== undefined;
  }

  async toggleUpdateTemplate(checked: boolean, updatedTemplate: Template) {
    const userView = await this.userView$.pipe(take(1)).toPromise();

    this.store$.dispatch(new ToggleUpdateTemplate({checked, updatedTemplate, userView}));
  }

  async save() {
    let updatedTemplates = await this.updatedTemplates$.pipe(take(1)).toPromise();

    this.store$.dispatch(new SetTemplateName({ templateName: updatedTemplates[0].name }));

    await of( new UpdateTemplates() ).pipe(
      tap( ( save ) => this.store$.dispatch( save ) ),
      switchMapTo( this.actions$ ),
      ofType<TemplatesFormActionUnion>( TemplatesFormActionTypes.SaveTemplatesFormSuccess, TemplatesFormActionTypes.SaveTemplatesFormError ),
      take(1),
      filter( ( action ) => action.type === TemplatesFormActionTypes.SaveTemplatesFormSuccess ),
      tap( () => this.dialogRef.close() ),
    ).toPromise();
  }

  reset() {
    this.store$.dispatch(new ResetTemplatesForm());
  }

  quit() {
    this.reset();
    this.dialogRef.close();
  }

}
