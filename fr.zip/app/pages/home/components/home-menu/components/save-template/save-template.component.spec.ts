import { async, TestBed } from '@angular/core/testing';
import { MatCheckboxChange, MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatTooltipModule } from '@angular/material/tooltip';
import { provideMockActions } from '@ngrx/effects/testing';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { User } from 'core/models/user.model';
import { UserRole } from 'core/models/userRoles.model';
import { GroupsValue } from 'core/store/groups/groups.model';
import { AddNewTemplate, CreateTemplates, RemoveNewTemplate, ResetTemplatesForm, SaveTemplatesFormError, SaveTemplatesFormSuccess } from 'core/store/templates/templates.form.actions';
import { Template, TemplatesFormValue, TemplateType } from 'core/store/templates/templates.form.model';
import { templatesFormState } from 'core/store/templates/templates.form.reducer';
import { TemplatesFormService } from 'core/store/templates/templates.form.service';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { createFormGroupState, NgrxFormsModule } from 'ngrx-forms';
import { Observable, of } from 'rxjs';
import { marbles } from 'rxjs-marbles/marbles';
import { AppState } from 'shared/models/state.model';
import { SaveTemplateComponent } from './save-template.component';

const generateUser = (user?: Partial<User>): User => {
  return {
    ...User.from(),
    ...user,
  }
};

const generateTemplatesForm = (templatesForm?: Partial<TemplatesFormValue>) => createFormGroupState<TemplatesFormValue>('ADMIN_TEMPLATES_FORM', {
  ...templatesFormState.templatesForm.value,
  ...templatesForm,
});

const generateTemplate = (template?: Partial<Template>): Template => {
  return {
    id: 'id',
    name: 'name',
    type: TemplateType.USER,
    owner: 'userId',
    nodes: [],
    hiddenNodes: {},
    nodesPosition: [[], [], [], []],
    ...template,
  }
};

const generateGroup = (group?: Partial<GroupsValue>): GroupsValue => {
  return {
    id: 'id',
    name: 'name',
    description: 'description',
    users: [],
    admins: [],
    defaultTemplate: '',
    ...group,
  };
};

describe('SaveTemplateComponent', () => {
  let context: TestCtx<SaveTemplateComponent>;
  let store: MockStore<AppState>;
  let actions: Observable<any>;
  let dialogRef: jasmine.SpyObj<MatDialogRef<SaveTemplateComponent>>;
  const templates = [
    generateTemplate({ id: 'ID1', name: 'template 1', type: TemplateType.USER, owner: 'A123456' }),
    generateTemplate({ id: 'ID2', name: 'template 2', type: TemplateType.GROUP, owner: 'ID1' }),
    generateTemplate({ id: 'ID3', name: 'template 3', type: TemplateType.PUBLIC, owner: undefined }),
  ];
  const newTemplates = [
    generateTemplate({ id: undefined, name: undefined, type: TemplateType.GROUP, owner: 'ID2' }),
  ];
  const form = generateTemplatesForm({ templates, newTemplates });

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        MatCheckboxModule,
        NgrxFormsModule,
        MatTooltipModule,
      ],
      declarations: [
        SaveTemplateComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: {
          auth: { user: generateUser({ userId: 'A123456' }), isUserAuthenticated: true, profil: { profiles: [UserRole.PUBLIC], permissions: [] } }
        } }),
        provideMockActions(() => actions),
        { provide: TemplatesFormService, useFactory: () => ({ form$: of(form) }) },
        { provide: MatDialogRef, useFactory: () => jasmine.createSpyObj('MatDialogRef', ['close'] as Array<keyof MatDialogRef<SaveTemplateComponent>>) },
        { provide: MAT_DIALOG_DATA, useValue: { userId: 'A123456', groups: [
          generateGroup({ id: 'A123456', name: 'A123456', description: '', users: ['A123456'], admins: ['A123456'] }),
          generateGroup({ id: 'ID2', name: 'group 2', admins: ['A123456'] }),
          generateGroup({ id: 'ID3', name: 'group 3', users: ['A123456'], admins: ['A123456'] })] } },
      ],
    })
  });

  beforeEach(async( async () => {
    store = TestBed.get(Store);
    actions = null;
    dialogRef = TestBed.get(MatDialogRef);
    context = await createStableTestContext(SaveTemplateComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });

  describe('getTemplateInfos', () => {

    it('should return the template info', () => {
      expect(context.component.getTemplateInfos(generateGroup({ id: 'ID2', name: 'group 2', admins: ['A123456'] }))).toEqual({ type: TemplateType.GROUP, owner: 'ID2' });
      expect(context.component.getTemplateInfos(generateGroup({ id: 'A123456', name: 'A123456', description: '', users: ['A123456'], admins: ['A123456'] }))).toEqual({ type: TemplateType.USER, owner: 'A123456' });
    });

  });

  describe('isChecked', () => {

    it('should be checked', () => {
      expect(context.component.isChecked({ type: TemplateType.GROUP, owner: 'ID2' }, form.controls.newTemplates)).toBe(true);
    });

    it('shouldn\'t be checked', () => {
      expect(context.component.isChecked({ type: TemplateType.USER, owner: 'A123456' }, form.controls.newTemplates)).toBe(false);
    });

  });

  describe('onToogle', () => {

    it('should dispatch an AddNewTemplate action', () => {
      const dispatchSpy = spyOn(store, 'dispatch');
      const event = new MatCheckboxChange();
      const templateInfos = { type: TemplateType.USER, owner: 'A123456' };

      event.checked = true;
      context.component.onToogle(event, templateInfos);

      expect(dispatchSpy).toHaveBeenCalledWith(new AddNewTemplate(templateInfos));
    });

    it('should dispatch a RemoveNewTemplate action', () => {
      const dispatchSpy = spyOn(store, 'dispatch');
      const event = new MatCheckboxChange();
      const templateInfos = { type: TemplateType.USER, owner: 'A123456' };

      event.checked = false;
      context.component.onToogle(event, templateInfos);

      expect(dispatchSpy).toHaveBeenCalledWith(new RemoveNewTemplate(templateInfos));
    });

  });

  describe('isNameValid', () => {

    it('should check if control is valid', () => {
      const name = form.controls.newTemplatesName;

      expect(context.component.isNameValid(undefined)).toBe(true);

      (name as any).isInvalid = true;
      expect(context.component.isNameValid(name)).toBe(true);

      (name as any).isInvalid = false;
      expect(context.component.isNameValid(name)).toBe(false);
    });

  });

  describe('formatError', () => {

    it('should be unique', () => {
      const name = form.controls.newTemplatesName;

      (name as any).errors = { notUnique: true };
      expect(context.component.formatError(name)).toEqual('La valeur doit être unique');
    });

    it('should be undefined', () => {
      const name = form.controls.newTemplatesName;

      (name as any).errors = {};
      expect(context.component.formatError(name)).toBe(undefined);
    });

  });

  describe('canSave', () => {

    it('should check if the form can be saved', () => {
      const name = form.controls.newTemplatesName;
      const templates = form.controls.newTemplates;

      expect(context.component.canSave(true, name, templates)).toBe(false);

      (name as any).value = undefined;
      expect(context.component.canSave(true, name, templates)).toBe(false);

      (name as any).value = 'newName';
      expect(context.component.canSave(true, name, templates)).toBe(true);

      (templates as any).value = undefined;
      expect(context.component.canSave(true, name, templates)).toBe(false);

      (templates as any).value = [];
      expect(context.component.canSave(true, name, templates)).toBe(false);
    });

  });

  describe('save', () => {

    it('should save and close', marbles(m => {
      const dispatchSpy = spyOn(store, 'dispatch');

      actions =         m.hot('a', {
        a: new SaveTemplatesFormSuccess()
      });

      context.component.save().then(() => {
        expect(dispatchSpy).toHaveBeenCalledWith(new CreateTemplates());
        expect(dialogRef.close).toHaveBeenCalled();
      });
    }));

    it('should not save due to error', marbles(m => {
      const dispatchSpy = spyOn(store, 'dispatch');

      actions =         m.hot('a', {
        a: new SaveTemplatesFormError({ error: new Error() })
      });

      context.component.save().then(() => {
        expect(dispatchSpy).toHaveBeenCalledWith(new CreateTemplates());
        expect(dialogRef.close).not.toHaveBeenCalled();
      });
    }));

  });

  describe('reset', () => {

    it('should dispatch a ResetTemplatesForm action', () => {
      const dispatchSpy = spyOn(store, 'dispatch');

      context.component.reset();

      expect(dispatchSpy).toHaveBeenCalledWith(new ResetTemplatesForm());
    });

  });

  describe('quit', () => {

    it('should reset then close', () => {
      const dispatchSpy = spyOn(store, 'dispatch');

      context.component.quit();

      expect(dispatchSpy).toHaveBeenCalledWith(new ResetTemplatesForm());
      expect(dialogRef.close).toHaveBeenCalled();
    });

  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
