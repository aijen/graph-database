import { Component, Inject, OnInit } from '@angular/core';
import { MatCheckboxChange } from '@angular/material/checkbox';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Actions, ofType } from '@ngrx/effects';
import { select, Store } from '@ngrx/store';
import { canCreatePublicTemplates } from 'core/store/auth/auth.selectors';
import { GroupsValue } from 'core/store/groups/groups.model';
import { SetTemplateName } from 'core/store/hierarchy/hierarchy.actions';
import { AddNewTemplate, CreateTemplates, RemoveNewTemplate, ResetTemplatesForm, TemplatesFormActionTypes, TemplatesFormActionUnion } from 'core/store/templates/templates.form.actions';
import { PRIVATE_GROUP, PUBLIC_GROUP, Template, TemplateType } from 'core/store/templates/templates.form.model';
import { TemplatesFormService } from 'core/store/templates/templates.form.service';
import { canResetForm, canSaveForm, isFormDisabled } from 'core/utils/forms.helpers';
import { FormArrayState, FormControlState } from 'ngrx-forms';
import { of } from 'rxjs';
import { filter, map, switchMapTo, take, tap } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';

@Component({
  selector: 'pit-save-template',
  templateUrl: './save-template.component.html',
  styleUrls: ['./save-template.component.scss']
})
export class SaveTemplateComponent implements OnInit {

  TemplateType = TemplateType;
  PUBLIC_GROUP = PUBLIC_GROUP;
  PRIVATE_GROUP = PRIVATE_GROUP;

  publicTemplateInfos = { type: TemplateType.PUBLIC, owner: undefined };

  form$ = this.templatesFormService.form$;
  canCreatePublicTemplates$ = this.store$.select(canCreatePublicTemplates);
  newTemplates$ = this.form$.pipe(select(form => form.controls.newTemplates));
  newTemplatesName$ = this.form$.pipe(select(form => form.controls.newTemplatesName));

  trackByName = (index: number, { name }: GroupsValue) => name;

  canSave$ = this.form$.pipe(
    canSaveForm
  );

  canReset$ = this.form$.pipe(
    canResetForm
  );

  isDisabled$ = this.form$.pipe(
    isFormDisabled
  );

  constructor(
    private store$: Store<AppState>,
    private templatesFormService: TemplatesFormService,
    private actions$: Actions,
    private dialogRef: MatDialogRef<SaveTemplateComponent>,
    @Inject(MAT_DIALOG_DATA) public dialogData: { userId: string, groups: GroupsValue[] },
  ) { }

  ngOnInit() {
  }

  getTemplateInfos(group: GroupsValue) {
    return (group.name === this.dialogData.userId) ? { type: TemplateType.USER, owner: this.dialogData.userId } : { type: TemplateType.GROUP, owner: group.id };
  }

  isChecked(templateInfos: { type: TemplateType, owner: string }, newTemplates: FormArrayState<Template>) {
    const { type, owner } = templateInfos;
    return newTemplates.value.find(t => t.type === type && t.owner === owner) !== undefined;
  }

  onToogle(event: MatCheckboxChange, templateInfos: { type: TemplateType, owner: string }) {
    if(event.checked) {
      this.store$.dispatch(new AddNewTemplate(templateInfos));
    }
    else {
      this.store$.dispatch(new RemoveNewTemplate(templateInfos));
    }
  }

  isNameValid(name: FormControlState<string>) {
    return name !== undefined ? name.isInvalid : true;
  }

  formatError(name: FormControlState<string>) {
    if( name !== undefined && name.errors.notUnique ) return 'La valeur doit être unique';
  }

  canSave(canSave: boolean, name: FormControlState<string>, templates: FormArrayState<Template>) {
    return canSave && !this.isvalueUndefined(name) && name.value.length > 0 && !this.isvalueUndefined(templates) && templates.value.length > 0;
  }

  private isvalueUndefined(control: FormControlState<string> | FormArrayState<Template>) {
    return control === undefined || control.value === undefined;
  }

  async save() {
    const templateName = await this.newTemplatesName$.pipe(take(1), map(ctrl => ctrl.value)).toPromise();

    this.store$.dispatch(new SetTemplateName({ templateName }));

    await of( new CreateTemplates() ).pipe(
      tap( ( create ) => this.store$.dispatch( create ) ),
      switchMapTo( this.actions$ ),
      ofType<TemplatesFormActionUnion>( TemplatesFormActionTypes.SaveTemplatesFormSuccess, TemplatesFormActionTypes.SaveTemplatesFormError ),
      take(1),
      filter( ( action ) => action.type === TemplatesFormActionTypes.SaveTemplatesFormSuccess ),
      tap( () => this.quit() ),
    ).toPromise();
  }

  reset() {
    this.store$.dispatch(new ResetTemplatesForm());
  }

  quit() {
    this.reset();
    this.dialogRef.close();
  }

}
