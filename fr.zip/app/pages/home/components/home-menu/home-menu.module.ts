import { NgModule } from '@angular/core';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialogModule } from '@angular/material/dialog';
import { MatMenuModule } from '@angular/material/menu';
import { MatSelectModule } from '@angular/material/select';
import { NgrxFormsModule } from 'ngrx-forms';
import { SharedModule } from 'shared/shared.module';
import { ManageTemplatesComponent } from './components/manage-templates/manage-templates.component';
import { SaveTemplateComponent } from './components/save-template/save-template.component';
import { UpdateTemplateComponent } from './components/update-template/update-template.component';
import { HomeMenuComponent } from './home-menu.component';

@NgModule({
  declarations: [
    HomeMenuComponent,
    SaveTemplateComponent,
    UpdateTemplateComponent,
    ManageTemplatesComponent,
  ],
  entryComponents: [
    SaveTemplateComponent,
    UpdateTemplateComponent,
    ManageTemplatesComponent,
  ],
  imports: [
    SharedModule,
    MatMenuModule,
    MatDialogModule,
    MatCheckboxModule,
    MatSelectModule,
    NgrxFormsModule,
  ],
  exports: [
    HomeMenuComponent,
  ]
})
export class HomeMenuModule { }
