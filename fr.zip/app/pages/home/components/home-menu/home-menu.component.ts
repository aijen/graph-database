import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { MatMenu } from '@angular/material/menu';
import { select, Store } from '@ngrx/store';
import { getUserId$ } from 'core/store/auth/auth.selectors';
import { GroupsValue } from 'core/store/groups/groups.model';
import { getGroups } from 'core/store/groups/groups.selectors';
import { RestoreDefaultsNodes } from 'core/store/hierarchy/hierarchy.actions';
import { SaveSnooze, UnmuteAll } from 'core/store/snooze/snooze.actions';
import { LoadSelectedTemplate } from 'core/store/templates/templates.form.actions';
import { PUBLIC_GROUP, Template, TemplateType } from 'core/store/templates/templates.form.model';
import { TemplatesFormService } from 'core/store/templates/templates.form.service';
import { combineLatest } from 'rxjs';
import { map, take, withLatestFrom } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';
import { ManageTemplatesComponent } from './components/manage-templates/manage-templates.component';
import { SaveTemplateComponent } from './components/save-template/save-template.component';
import { UpdateTemplateComponent } from './components/update-template/update-template.component';

@Component({
  selector: 'pit-home-menu',
  templateUrl: './home-menu.component.html',
  styleUrls: ['./home-menu.component.scss']
})
export class HomeMenuComponent implements OnInit {

  @ViewChild('rootMenu')
  menu: MatMenu;

  values$ = this.templatesFormService.values$;
  userId$ = this.store$.pipe( getUserId$, take(1) );
  groupList$ = this.store$.select(getGroups);
  publicTemplates$ = this.values$.pipe(
    withLatestFrom(combineLatest(this.userId$, this.groupList$)),
    map(([values, [userId, groups]]) => {
      const groupsIds = groups.filter(group => group.users.includes(userId)).map(group => group.id);
      return values.templates.filter(template => template.type !== TemplateType.USER && (template.owner === undefined || groupsIds.includes(template.owner)));
    })
  );
  privateTemplates$ = this.values$.pipe(select(values => values.templates.filter(template => template.type === TemplateType.USER)));

  constructor(
    private store$: Store<AppState>,
    private templatesFormService: TemplatesFormService,
    private dialog: MatDialog,
  ) { }

  ngOnInit() {
  }

  restoreAllNodes() {
    this.store$.dispatch(new RestoreDefaultsNodes('all'));
  }

  unMuteAll() {
    this.store$.dispatch(new UnmuteAll());
    this.store$.dispatch(new SaveSnooze());
  }

  loadTemplate(template: Template) {
    this.store$.dispatch(new LoadSelectedTemplate({ template }));
  }

  isDisabled(templates: Template[]) {
    return !Boolean(templates) || templates.length === 0;
  }

  getGroupName(groups: GroupsValue[], groupId: string) {
    return !Boolean(groupId) ? PUBLIC_GROUP : groups.find(group => group.id === groupId).name;
  }

  async saveTemplate() {
    const userId = await this.userId$.toPromise();
    const groups = await this.groupList$.pipe(take(1)).toPromise();
    const dialogConfig = new MatDialogConfig();

    dialogConfig.minWidth = '60rem';
    dialogConfig.disableClose = true;
    dialogConfig.data = { userId, groups: groups.filter(group => group.admins.includes(userId)) };

    this.dialog.open(SaveTemplateComponent, dialogConfig);
  }

  async udateTemplate() {
    const userId = await this.userId$.toPromise();
    const groups = await this.groupList$.pipe(take(1)).toPromise();
    const dialogConfig = new MatDialogConfig();

    dialogConfig.minWidth = '60rem';
    dialogConfig.disableClose = true;
    dialogConfig.data = { userId, groups: groups.filter(group => group.admins.includes(userId)) };

    this.dialog.open(UpdateTemplateComponent, dialogConfig);
  }

  async manageTemplates() {
    const userId = await this.userId$.toPromise();
    const groups = await this.groupList$.pipe(take(1)).toPromise();
    const dialogConfig = new MatDialogConfig();

    dialogConfig.minWidth = '60rem';
    dialogConfig.disableClose = true;
    dialogConfig.data = { userId, groups: groups.filter(group => group.admins.includes(userId)) };

    this.dialog.open(ManageTemplatesComponent, dialogConfig);
  }
}
