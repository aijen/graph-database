import { async, TestBed } from '@angular/core/testing';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { provideMockActions } from '@ngrx/effects/testing';
import { Store } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { User } from 'core/models/user.model';
import { UserRole } from 'core/models/userRoles.model';
import { GroupsValue } from 'core/store/groups/groups.model';
import { RestoreDefaultsNodes } from 'core/store/hierarchy/hierarchy.actions';
import { SnoozeActionTypes } from 'core/store/snooze/snooze.actions';
import { LoadSelectedTemplate } from 'core/store/templates/templates.form.actions';
import { PUBLIC_GROUP, Template, TemplatesFormValue, TemplateType } from 'core/store/templates/templates.form.model';
import { TemplatesFormService } from 'core/store/templates/templates.form.service';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { Observable, Subject } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { ManageTemplatesComponent } from './components/manage-templates/manage-templates.component';
import { SaveTemplateComponent } from './components/save-template/save-template.component';
import { UpdateTemplateComponent } from './components/update-template/update-template.component';
import { HomeMenuComponent } from './home-menu.component';

const generateUser = (user?: Partial<User>): User => {
  return {
    ...User.from(),
    ...user,
  }
};

const generateTemplate = (template?: Partial<Template>): Template => {
  return {
    id: 'id',
    name: 'name',
    type: TemplateType.USER,
    owner: 'userId',
    nodes: [],
    hiddenNodes: {},
    nodesPosition: [[], [], [], []],
    ...template,
  }
};

const generateGroup = (group?: Partial<GroupsValue>): GroupsValue => {
  return {
    id: 'id',
    name: 'name',
    description: 'description',
    users: [],
    admins: [],
    defaultTemplate: '',
    ...group,
  };
};

describe('HomeMenuComponent', () => {
  let context: TestCtx<HomeMenuComponent>;
  let actions: Observable<any>;
  let store: MockStore<Partial<AppState>>;
  let dialog: jasmine.SpyObj<MatDialog>;
  const values$ = new Subject<TemplatesFormValue>();
  const userId = 'A123456';
  const templates = [
    generateTemplate({ id: 'ID1', name: 'template 1', type: TemplateType.USER, owner: userId }),
    generateTemplate({ id: 'ID2', name: 'template 2', type: TemplateType.GROUP, owner: 'ID1' }),
    generateTemplate({ id: 'ID3', name: 'template 3', type: TemplateType.PUBLIC, owner: undefined }),
  ];
  const groups = [
    generateGroup({ id: 'ID1', name: 'group 1', users: ['A123456'] }),
    generateGroup({ id: 'ID2', name: 'group 2', admins: ['A123456'] }),
    generateGroup({ id: 'ID3', name: 'group 3', users: ['A123456'], admins: ['A123456'] }),
  ];

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        MatMenuModule,
        MatTooltipModule,
      ],
      declarations: [
        HomeMenuComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: {
          auth: { user: generateUser({ userId }), isUserAuthenticated: true, profil: { profiles: [UserRole.PUBLIC], permissions: [] } },
          groups: { groups },
        } }),
        provideMockActions(() => actions),
        { provide: TemplatesFormService, useFactory: () => ({ values$ }) },
        { provide: MatDialog, useFactory: () => jasmine.createSpyObj('MatDialog', ['open'] as Array<keyof MatDialog>) },
      ],
    })
  });

  beforeEach(async( async () => {
    actions = null;
    store = TestBed.get(Store);
    dialog = TestBed.get(MatDialog);
    context = await createStableTestContext(HomeMenuComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  describe('privateTemplates$', () => {

    it('should return the public templates', () => {
      const next = jasmine.createSpy('next');
      const sub = context.component.publicTemplates$.subscribe(next);
      values$.next({ templates });

      expect(next).toHaveBeenCalledWith([
        generateTemplate({ id: 'ID2', name: 'template 2', type: TemplateType.GROUP, owner: 'ID1' }),
        generateTemplate({ id: 'ID3', name: 'template 3', type: TemplateType.PUBLIC, owner: undefined }),
      ]);

      sub.unsubscribe();
    });

  })

  describe('privateTemplates$', () => {

    it('should return the private templates', () => {
      const next = jasmine.createSpy('next');
      const sub = context.component.privateTemplates$.subscribe(next);
      values$.next({ templates });

      expect(next).toHaveBeenCalledWith([
        generateTemplate({ id: 'ID1', name: 'template 1', type: TemplateType.USER, owner: userId }),
      ]);

      sub.unsubscribe();
    });

  })

  describe('restoreAllNodes', () => {

    it('should dispatch a RestoreDefaultsNodes action', () => {
      const dispatchSpy = spyOn(store, 'dispatch');

      context.component.restoreAllNodes();

      expect(dispatchSpy).toHaveBeenCalledWith(new RestoreDefaultsNodes('all'));
    });

  });

  describe('unMuteAll', () => {

    it('should dispatch UnmuteAll and SaveSnooze actions', () => {
      const dispatchSpy = spyOn(store, 'dispatch');

      context.component.unMuteAll();

      expect(dispatchSpy).toHaveBeenCalled();
      expect(dispatchSpy.calls.all().find(call => call.args[0].type === SnoozeActionTypes.UnmuteAll)).not.toBe(undefined);
      expect(dispatchSpy.calls.all().find(call => call.args[0].type === SnoozeActionTypes.SaveSnooze)).not.toBe(undefined);
    });

  });

  describe('loadTemplate', () => {

    it('should dispatch a LoadSelectedTemplate action', () => {
      const dispatchSpy = spyOn(store, 'dispatch');
      const template = generateTemplate({ id: 'ID1', name: 'template 1' });

      context.component.loadTemplate(template);

      expect(dispatchSpy).toHaveBeenCalledWith(new LoadSelectedTemplate({ template }));
    });

  });

  describe('isDisabled', () => {

    it('should return false', () => {
      expect(context.component.isDisabled(undefined)).toBe(true);
      expect(context.component.isDisabled([])).toBe(true);
    });

    it('should return true', () => {
      expect(context.component.isDisabled([generateTemplate({ id: 'ID1', name: 'template 1' })])).toBe(false);
    });

  });

  describe('getGroupName', () => {

    it('should return the group name', () => {
      expect(context.component.getGroupName(groups, 'ID2')).toEqual('group 2');
    });

    it('should return the public group name', () => {
      expect(context.component.getGroupName(groups, undefined)).toEqual(PUBLIC_GROUP);
    });

  });

  describe('saveTemplate', () => {

    it('should open the save template dialog', () => {
      const dialogConfig = new MatDialogConfig();

      dialogConfig.minWidth = '60rem';
      dialogConfig.disableClose = true;
      dialogConfig.data = { userId, groups: [generateGroup({ id: 'ID2', name: 'group 2', admins: ['A123456'] }), generateGroup({ id: 'ID3', name: 'group 3', users: ['A123456'], admins: ['A123456'] })] };

      context.component.saveTemplate().then(() => {
        expect(dialog.open).toHaveBeenCalledWith(SaveTemplateComponent, dialogConfig);
      });
    });

  });

  describe('udateTemplate', () => {

    it('should open the update template dialog', () => {
      const dialogConfig = new MatDialogConfig();

      dialogConfig.minWidth = '60rem';
      dialogConfig.disableClose = true;
      dialogConfig.data = { userId, groups: [generateGroup({ id: 'ID2', name: 'group 2', admins: ['A123456'] }), generateGroup({ id: 'ID3', name: 'group 3', users: ['A123456'], admins: ['A123456'] })] };

      context.component.udateTemplate().then(() => {
        expect(dialog.open).toHaveBeenCalledWith(UpdateTemplateComponent, dialogConfig);
      });
    });

  });

  describe('manageTemplates', () => {

    it('should open the manage template dialog', () => {
      const dialogConfig = new MatDialogConfig();

      dialogConfig.minWidth = '60rem';
      dialogConfig.disableClose = true;
      dialogConfig.data = { userId, groups: [generateGroup({ id: 'ID2', name: 'group 2', admins: ['A123456'] }), generateGroup({ id: 'ID3', name: 'group 3', users: ['A123456'], admins: ['A123456'] })] };

      context.component.manageTemplates().then(() => {
        expect(dialog.open).toHaveBeenCalledWith(ManageTemplatesComponent, dialogConfig);
      });
    });

  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
