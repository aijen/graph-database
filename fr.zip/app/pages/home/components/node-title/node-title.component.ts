import { Component, ContentChild, Input, OnInit, TemplateRef } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { fadeInOut } from 'core/animations/animations';
import {CloseLeaves, DeleteNode, RenameLeaf, RenameNode, SetOpenLeaves} from 'core/store/hierarchy/hierarchy.actions';
import { getIsSupervising, getOpenLeaves, getRenamedNodeKey } from 'core/store/hierarchy/hierarchy.selectors';
import { merge, Observable, of, Subject, timer } from 'rxjs';
import { filter, map, scan, shareReplay, switchMap } from 'rxjs/operators';
import { DropListProxy } from 'shared/features/ndrop/services/droplist-proxy';
import { Leaf } from 'shared/models/leaf.model';
import { Node } from 'shared/models/node.model';
import { AppState } from 'shared/models/state.model';

// Might need to refactor this with node component as they share the same logic

@Component({
  selector: 'cockpit-node-title',
  templateUrl: './node-title.component.html',
  styleUrls: ['./node-title.component.scss'],
  animations: [fadeInOut()],
  providers: [{ provide: DropListProxy, useClass: DropListProxy }],
})
export class NodeTitleComponent implements OnInit {
  @Input()
  set leaf( value: Leaf | Node ) {
    this._leaf   = value;
    this.isNode  = Node.isNode( value );

    // if leaf does have not a name we show a key
    const { fullname, name, key } = value;
    this.title = fullname || name || key;
  }
  get leaf() { return this._leaf; }
  private _leaf: Leaf | Node;

  isNode = false;

  get isNew()     { return this.isNode ? (this._leaf as Node).isNew : false };
  get nbAlert()   { return this.isNode ? (this._leaf as Node).nbAlert : 0 };
  get nodes()     { return this.isNode ? (this._leaf as Node).nodes : [] };
  get leaves()    { return this.isNode ? (this._leaf as Node).leaves : [] };
  get hasAlert()  { return !this.isNode ? (this._leaf as Leaf).hasAlert : false };

  title: string;

  @ContentChild(TemplateRef)
  content: TemplateRef<any>;

  isSubNodeDisplayed$: Observable<boolean | void>;

  isOver$ = new Subject<boolean>();
  isDraggingOver$ = this.isOver$.pipe(
    switchMap( isOver => isOver ? timer( 1000 ) : of() ),
    map( isOver => this.store$.dispatch( new SetOpenLeaves([this.leaf.technicalKey], true) ) ),
    filter( () => false ),
  );

  isSupervising$ = this.store$.pipe(select(getIsSupervising));

  isRenaming$ = this.store$.select( getRenamedNodeKey ).pipe(
    map( key => this.leaf && this.leaf.technicalKey === key ),
  )

  constructor(
    private store$: Store<AppState>,
    public proxy: DropListProxy,
  ) {}

  ngOnInit() {

    const isOpen = (openLeaves: string[]) => openLeaves.includes(this.leaf.technicalKey);

    const toggleDisplay$ = merge(
      this.store$.pipe(
        select(getOpenLeaves),
        map( isOpen )
      ),
      this.isDraggingOver$,
    ).pipe(
      scan( (acc, value) => value === undefined ? !acc : value, false )
    );

    this.isSubNodeDisplayed$ = this.store$.pipe(
      select(getIsSupervising),
      switchMap( supervising => supervising ? of(true) : toggleDisplay$ ),
      shareReplay({ bufferSize: 1, refCount: true }),
    );

  }

  toggleDisplay() {
    const isFirstNode = this.leaf.parent == null ? true : false;
    if(isFirstNode){
      this.store$.dispatch(new CloseLeaves(this.leaf as Node));
    }else{
      this.store$.dispatch(new SetOpenLeaves([this.leaf.technicalKey]));
    }
  }

  setName( name: string ) {
    const node = this._leaf;

    if(!name) {
      return this.store$.dispatch(new DeleteNode( { node } ));
    }

    if( Node.isNode( node ) ) {
      this.store$.dispatch( new RenameNode( { node, name } ) );
    } else {
      this.store$.dispatch( new RenameLeaf( { node, name } ) );
    }
  }

  dragEnter() {
    this.isOver$.next( true );
  }

  dragLeave() {
    this.isOver$.next( false );
  }



}
