import { Component, Directive, Input } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { MatMenuModule } from '@angular/material/menu';
import { NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { HierarchyState } from 'core/store/hierarchy/hierarchy.model';
import { configureTestSuite, createTestContext, TestCtx } from 'ng-bullet';
import { Observable } from 'rxjs';
import { DropListProxy } from 'shared/features/ndrop/services/droplist-proxy';
import { AppState } from 'shared/models/state.model';
import { NodeTitleComponent } from './node-title.component';

@Component({
  selector: 'cockpit-node-menu',
  template: '',
})
class CockpitNodeMenuStubComponent {
  @Input() node: any;
}

@Directive({
  selector: '[pitDragListener]',
})
class PitDragListenerStubDirective {}

@Directive({
  selector: '[pitDragHandler]',
})
class PitDragHandlerStubDirective {}

@Directive({
  selector: '[dropProxy]',
})
class DropProxyStubDirective {
  @Input() dropProxy: any;
}

@Directive({
  selector: '[cockpitAutoScroll]',
})
class CockpitAutoScrollStubDirective {
  @Input() cockpitAutoScroll: any;
  @Input() autoScrollTo: any;
}

describe('NodeTitleComponent', () => {
  let context: TestCtx<NodeTitleComponent>;
  let actions: Observable<any>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        NgbTooltipModule,
        MatMenuModule,
      ],
      declarations: [
        NodeTitleComponent,
        CockpitNodeMenuStubComponent,
        PitDragListenerStubDirective,
        PitDragHandlerStubDirective,
        DropProxyStubDirective,
        CockpitAutoScrollStubDirective,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: { hierarchy: new HierarchyState() } }),
        provideMockActions(() => actions),
        { provide: DropListProxy, useFactory: () => ({}) },
      ],
    })
  });

  beforeEach(async( async () => {
    context = await createTestContext(NodeTitleComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
