import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { MatMenu } from '@angular/material/menu';
import { Store } from '@ngrx/store';
import { AddNode, DeleteNode, HideNodeFromTree, RestoreDefaultsNodes, SetOpenLeaves, StartRenameNode } from 'core/store/hierarchy/hierarchy.actions';
import { getPopulatedMetasForLeaf } from 'core/store/populated-metas/populated-metas.selectors';
import { ToggleSnoozeLeafMeta } from 'core/store/snooze/snooze.actions';
import { selectSnoozeConfig } from 'core/store/snooze/snooze.selectors';
import { SnoozeService } from 'core/store/snooze/snooze.service';
import { map } from 'rxjs/operators';
import { Hierarchy, MAX_TREE_DEPTH } from 'shared/constants/constants';
import { Leaf } from 'shared/models/leaf.model';
import { Node } from 'shared/models/node.model';
import { AppState } from 'shared/models/state.model';
import { AdminLeafMetaType } from 'shared/store/leaves/leaves.form.model';

@Component({
  selector: 'cockpit-node-menu',
  templateUrl: './node-menu.component.html',
  styleUrls: ['./node-menu.component.scss']
})
export class NodeMenuComponent implements OnInit {

  public canHide = false;
  public canRestore = false;
  public canAddNode = false;
  public canDelete = false;
  public canRename = false;
  public isLeaf = false;

  @Input()
  set node( node: Node | Leaf ) {
    const isRoot = !node.parent;
    const isReadonly = node.readOnly;
    const isNode = Node.isNode( node );
    const depth = this.getDepth( node );

    this._node = node;
    this.canHide = isReadonly;
    this.canRestore = isRoot && isReadonly;
    this.canAddNode = isNode && !isReadonly && (depth < (MAX_TREE_DEPTH - 1));
    this.canDelete = !isReadonly;
    this.canRename = !isReadonly;
    this.isLeaf = this._node.type === Hierarchy.Leaf;
  }
  private _node: Node | Leaf;

  @ViewChild('rootMenu')
  menu: MatMenu;

  isMuted(metaType: AdminLeafMetaType) {
    return this.store$.select(selectSnoozeConfig).pipe(
      map(({ leaves }) => SnoozeService.findLeafByKey(leaves, this._node.key)),
      map(leaf => leaf ? leaf[metaType].enabled : false),
    )
  };

  isAdmin(metaType: AdminLeafMetaType) {
    return this.store$.select(selectSnoozeConfig).pipe(
      map(({ leaves }) => SnoozeService.findLeafByKey(leaves, this._node.key)),
      map(leaf => leaf ? leaf[metaType].admin : false),
    )
  };

  isPopulated(metaType: AdminLeafMetaType) {
    return this.store$.select(getPopulatedMetasForLeaf(this._node.key)).pipe(
      map(metas => (metas !== undefined && metas[metaType] !== undefined) ? metas[metaType] : false),
    );
  }

  constructor(
    private store$: Store<AppState>,
  ) { }

  ngOnInit() {
  }

  hideNodeFromTree() {
    this.store$.dispatch(new HideNodeFromTree(this._node.technicalKey));
  }

  restoreDefaultsNodes() {
    this.store$.dispatch(new RestoreDefaultsNodes(this._node.technicalKey));
  }

  addNode() {
    const node = new Node({ assignRandomKey: true });
    const parent = this._node as Node;
    const offset = 0;
    this.store$.dispatch(new SetOpenLeaves([parent.technicalKey], true));
    this.store$.dispatch(new AddNode({ node, parent, offset }));
  }

  deleteNode() {
    const node = this._node;
    this.store$.dispatch(new DeleteNode({ node }));
  }

  renameNode() {
    const node = this._node;
    this.store$.dispatch(new StartRenameNode({ node }));
  }

  muteMeta(metaType: AdminLeafMetaType) {
    this.store$.dispatch(new ToggleSnoozeLeafMeta({ leafKey: this._node.key, metaType }));
  }

  private getDepth( node: Node | Leaf ) {
    if( !Node.isNode( node ) ) return 0;

    let depth = 1;
    let parent = node;
    while( parent = parent.parent ) depth++;
    return depth;
  }
}
