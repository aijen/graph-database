import { Component, Directive, Input } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { configureTestSuite, createTestContext, TestCtx } from 'ng-bullet';
import { Observable } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { TreeComponent } from './tree.component';

@Component({
  selector: 'cockpit-node',
  template: '',
})
class CockpitNodeStubComponent {
  @Input() nodeData: any;
}

@Component({
  selector: 'cockpit-leaf',
  template: '',
})
class CockpitLeafStubComponent {
  @Input() leaf: any;
}

@Directive({
  selector: '[pitDropList]',
})
class PitDropListStubDirective {
  @Input() canReceive: any;
}

@Directive({
  selector: '[pitDrag]',
})
class PitDragStubDirective {
  @Input() dragData: any;
}

describe('TreeComponent', () => {
  let context: TestCtx<TreeComponent>;
  let actions: Observable<any>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      declarations: [
        TreeComponent,
        CockpitNodeStubComponent,
        CockpitLeafStubComponent,
        PitDropListStubDirective,
        PitDragStubDirective,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: {} }),
        provideMockActions(() => actions),
      ],
    })
  });

  beforeEach(async( async () => {
    context = await createTestContext(TreeComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
