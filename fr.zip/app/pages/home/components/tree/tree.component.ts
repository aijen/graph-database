import { Component, Input, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { AddNode } from 'core/store/hierarchy/hierarchy.actions';
import { MAX_TREE_DEPTH } from 'shared/constants/constants';
import { Leaf } from 'shared/models/leaf.model';
import { Node } from 'shared/models/node.model';
import { AppState } from 'shared/models/state.model';

@Component({
  selector: 'cockpit-tree',
  templateUrl: './tree.component.html',
  styleUrls: ['./tree.component.scss']
})
export class TreeComponent implements OnInit {

  @Input()
  tree: Node;

  trackByNodeKey = Node.trackByKey;
  trackByLeafKey = Leaf.trackByKey;

  private depth = 1;

  constructor(
    private store$: Store<AppState>,
  ) { }

  ngOnInit() {
    let parent = this.tree;
    while( parent = parent.parent ) this.depth++;
  }

  canReceive = ( node: Node | Leaf ) => {
    if(this.tree.readOnly) return false;

    if( Node.isNode( node ) ) {
      let parent = this.tree;
      do {
        if( parent === node ) return false;
      } while( parent = parent.parent )
    }

    if( Node.isNode( node ) ) {
      let getMaxDepth =
        ( node: Node, depth = 0 ): number =>
          node.nodes.reduce( (acc, curr) => Math.max( getMaxDepth( curr, depth + 1 ), acc ), depth )

      const maxDepth = getMaxDepth( node, 1 );

      if( (maxDepth + this.depth) > (MAX_TREE_DEPTH - 1) ) return false;
    }

    return true;

  }

  addNodeAtPath(node: Node | Leaf, offset: number) {
    const parent = this.tree;
    if( Leaf.isLeaf( node ) ) offset -= parent.nodes.length;
    this.store$.dispatch( new AddNode({ node, offset, parent }) );
  }

}
