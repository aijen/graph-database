import { Component, Input } from '@angular/core';
import { Leaf } from 'shared/models/leaf.model';

@Component({
  selector: 'cockpit-leaf',
  templateUrl: './leaf.component.html',
  styleUrls: ['./leaf.component.scss'],
})
export class LeafComponent  {
  @Input() leaf: Leaf;
}
