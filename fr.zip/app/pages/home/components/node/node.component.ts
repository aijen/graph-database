import { Component, Input, OnInit } from '@angular/core';
import { Node } from 'shared/models/node.model';

@Component({
  selector: 'cockpit-node',
  templateUrl: './node.component.html',
  styleUrls: ['./node.component.scss'],
})
export class NodeComponent implements OnInit {

  @Input()
  nodeData: Node;

  // tslint:disable-next-line: no-input-rename
  @Input('class')
  cssClass = 'node';

  constructor(
  ) {}

  ngOnInit() {
  }

}
