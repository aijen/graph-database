import { NgModule } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { RouterModule } from '@angular/router';
import { NdropModule } from 'shared/features/ndrop/ndrop.module';
import { SharedModule } from 'shared/shared.module';
import { HomeMenuModule } from './components/home-menu/home-menu.module';
import { LeafComponent } from './components/leaf/leaf.component';
import { MetricDetailsComponent } from './components/metric-details/metric-details.component';
import { NodeMenuComponent } from './components/node-menu/node-menu.component';
import { NodeTitleComponent } from './components/node-title/node-title.component';
import { NodeComponent } from './components/node/node.component';
import { TreeComponent } from './components/tree/tree.component';
import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home.component';


@NgModule({
  declarations: [
    HomeComponent,
    LeafComponent,
    MetricDetailsComponent,
    NodeTitleComponent,
    NodeComponent,
    TreeComponent,
    NodeMenuComponent,
  ],
  imports: [
    RouterModule,
    HomeRoutingModule,
    SharedModule,
    MatIconModule,
    NdropModule,
    MatMenuModule,
    HomeMenuModule,
  ]
})
export class HomeModule {}
