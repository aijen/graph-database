import { Directive, ElementRef, Input, OnDestroy, OnInit } from '@angular/core';
import bezier from 'bezier-easing';
import { BehaviorSubject, of, Subject, timer } from 'rxjs';
import { distinctUntilChanged, switchMap, takeUntil, tap } from 'rxjs/operators';
import { SCROLL_DURATION, SCROLL_INTERVAL } from 'shared/constants/constants';

@Directive({
  selector: '[cockpitAutoScroll]'
})
export class AutoScrollDirective implements OnInit, OnDestroy {

  private start = new BehaviorSubject<boolean>(true);

  @Input('cockpitAutoScroll')
  set cockpitAutoScroll( value: any ) {
    this.start.next( Boolean(value) );
  }

  @Input()
  autoScrollTo = null;

  private destroy$ = new Subject<void>();

  constructor(
    private elementRef: ElementRef,
  ) {}

  ngOnInit() {

    const autoScroll = timer( SCROLL_INTERVAL, SCROLL_INTERVAL ).pipe(
      tap( () => {
        const element: HTMLElement = this.elementRef.nativeElement;
        const { scrollHeight, scrollTop, offsetHeight } = element;
        const scrollRemaining = scrollHeight - scrollTop;

        const isBottom = scrollRemaining <= offsetHeight;
        const lastStep = scrollHeight - offsetHeight;
        const nextStep = this.findLastVisibleChildOffset({ element, selector: this.autoScrollTo });

        const goto = isBottom ? 0 : Math.min(nextStep, lastStep);

        if(goto === scrollTop) return;

        this.scrollTo( goto, element );

      } )
    );

    this.start.pipe(
      distinctUntilChanged(),
      switchMap( start => start ? autoScroll : of() ),
      takeUntil(this.destroy$), // Not using unitilViewDestroyed because the view may not be destroyed if it is replaced by angular
    ).subscribe();

  }

  ngOnDestroy() {
    this.destroy$.next();
  }

  /**
   * Gives the offsetTop difference between {child} and {parent}
   */
  private relativeOffsetTop(
    child: HTMLElement,
    parent: HTMLElement
  ): number {
    const { offsetTop, offsetParent } = child;
    const isSameParent = offsetParent && offsetParent === parent.offsetParent;
    return offsetTop + (isSameParent ? -parent.offsetTop : this.relativeOffsetTop(offsetParent as HTMLElement, parent));
  }


  /**
   * Finds the last child element from {element} that satisfies the css selector {selector}
   * and that is not fully displayed inside the viewport of {element}.
   * If there is no selector, or no element that satisfies it, or it cannot find a suitable
   * element, returns the bottom position of the content in the viewport.
   */
  private findLastVisibleChildOffset({ element, selector }: { element: HTMLElement; selector: string; }) {
    const { scrollTop, offsetHeight } = element;
    const viewportBottom = scrollTop + offsetHeight;
    try {
      if( !selector ) return viewportBottom;

      const children = Array.from(element.querySelectorAll<HTMLElement>(selector));

      if( !children.length ) return viewportBottom;

      let nextChild = children.slice().reverse().find( (child) => this.relativeOffsetTop(child, element) <= viewportBottom );
      if( !nextChild || this.relativeOffsetTop(nextChild, element) <= scrollTop) nextChild = children.find( (child) => this.relativeOffsetTop(child, element) > viewportBottom );
      if( !nextChild ) return viewportBottom;

      const offset = this.relativeOffsetTop(nextChild, element);
      return offset !== scrollTop ? offset : viewportBottom;
    } catch(e) {
      return viewportBottom;
    }
  }

  private scrollTo( toScroll: number, element: HTMLElement ) {

    const startDate = Date.now();
    const fromScroll = element.scrollTop;
    const difference = toScroll - fromScroll;

    const timingFunction = bezier(.42,0,.58,1);

    const step = () => {
      const now = Date.now();
      const elapsed = now - startDate;
      const progress = Math.min(elapsed / SCROLL_DURATION, 1);

      element.scrollTop = timingFunction(progress) * difference + fromScroll;

      if(progress < 1) requestAnimationFrame(step);
    }

    requestAnimationFrame(step);

  }

}
