import { Component, ViewChild } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { AutoScrollDirective } from './auto-scroll.directive';

@Component({
  template: `<div cockpitAutoScroll></div>`
})
class TestComponent {

  @ViewChild(AutoScrollDirective)
  directive: AutoScrollDirective;

}

describe('AutoScrollDirective', () => {
  let context: TestCtx<TestComponent>;
  let directive: AutoScrollDirective;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      declarations: [
        AutoScrollDirective,
        TestComponent,
      ],
    })
  });

  beforeEach(async( async () => {
    context = await createStableTestContext(TestComponent);
    directive = context.component.directive;
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
    expect(directive).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
