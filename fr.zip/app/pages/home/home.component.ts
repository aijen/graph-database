import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatMenuTrigger } from '@angular/material/menu';
import { ActivatedRoute } from '@angular/router';
import { select, Store } from '@ngrx/store';
import { SearchResult, SearchService, SearchToken } from 'core/components/search/search.service';
import { AddNode, SetOpenLeaves, ToggleIsSupervising } from 'core/store/hierarchy/hierarchy.actions';
import { SubscriptionAwareComponent } from 'core/utils/subscription-aware.component';
import { trackByIndex } from 'core/utils/trackByIndex';
import groupBy from 'lodash/groupBy';
import uniq from 'lodash/uniq';
import { Observable, pipe } from 'rxjs';
import { distinctUntilChanged, map, switchMap, take, withLatestFrom } from 'rxjs/operators';
import { CockpitLeaf, isFileType } from 'shared/models/cockpit-leaf.model';
import { Leaf } from 'shared/models/leaf.model';
import { Node } from 'shared/models/node.model';
import { AppState } from 'shared/models/state.model';
import { getCockpitLeaves, getFlattenHierarchy, getIsSupervising, getPositionedNodes } from '../../core/store/hierarchy/hierarchy.selectors';

const isListEqual = <T extends any[]>(x: T, y: T): boolean => x.length === y.length && x.every( (node, index) => y[index] === node );

@Component({
  selector: 'cockpit-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent extends SubscriptionAwareComponent implements OnInit, OnDestroy {

  static readonly searchToken = new SearchToken('Home');

  @ViewChild(MatMenuTrigger)
  contextMenu: MatMenuTrigger;
  contextMenuPosition = { x: '0px', y: '0px' };

  trackByNodeKey = Node.trackByKey;
  trackByLeafKey = Leaf.trackByKey;
  trackByIndex = trackByIndex;

  isSupervising$ = this.store$.pipe(select(getIsSupervising));

  leafsCols$: Observable<Node[][]> = this.store$.pipe( select( getPositionedNodes ) );

  flatHierarchy$ = this.store$.select( getFlattenHierarchy ).pipe(
    distinctUntilChanged( isListEqual ),
    map( flatten => Object.entries(groupBy( flatten, ( v ) => v.fullname || v.name )) ),
  );

  constructor(
    private store$: Store<AppState>,
    route: ActivatedRoute,
    private searchService: SearchService<Array<Node | Leaf>>,
  ) {
    super();
    this.store$.dispatch(new ToggleIsSupervising(Boolean(route.snapshot.data.supervising)));

    this.subscription.add(
      this.searchService.getSelectedFor(HomeComponent.searchToken).subscribe(
        results => {
          const getParentsKeys = (node: Node | Leaf): string[] => {
            if(!node) return [];
            return [node.technicalKey, ...getParentsKeys(node.parent)];
          }
          const keys = results.data.reduce( (acc, node) => [...acc, ...getParentsKeys(node)], [] as string[] );
          const keys_uniq = uniq(keys);
          this.store$.dispatch(new SetOpenLeaves(keys_uniq, true));
        }
      )
    );
  }

  ngOnInit() {
    this.subscription.add(
      this.isSupervising$.subscribe(
        ( supervising ) => supervising ? this.searchService.unregister( HomeComponent.searchToken ) : this.searchService.register( HomeComponent.searchToken, pipe( switchMap( search => this.searchFilter( search ) ) ) )
      )
    );
  }

  ngOnDestroy() {
    super.ngOnDestroy();
    this.searchService.unregister( HomeComponent.searchToken );
  }

  searchFilter( search: string ) {
    const editorialFilter = (l: CockpitLeaf) => l.editorialData.find(e => !isFileType(e.type) && e.text.toLocaleLowerCase().includes(search.toLocaleLowerCase())) !== undefined;
    const fullnameFilter = (f: string) => f.toLocaleLowerCase().includes(search.toLocaleLowerCase());
    const fullFilter: (n: [string, (Node | Leaf)[]], pitLeaves: CockpitLeaf[]) => boolean = ([fullname, value], pitLeaves) => {
      const pitLeaf = pitLeaves.find(l => l.fullname === fullname);

      return fullnameFilter(fullname) || (pitLeaf && editorialFilter(pitLeaf));
    };
    const toSearchResult: (n: [string, (Node | Leaf)[]]) => SearchResult<Array<Node | Leaf>> = ([fullname, value]) => ({
      label: fullname,
      token: HomeComponent.searchToken,
      data: value,
    });

    return this.flatHierarchy$.pipe(
      withLatestFrom(this.store$.select(getCockpitLeaves)),
      map( ([nodes, pitLeaves]) => nodes.filter( n => fullFilter(n, pitLeaves) ).map( toSearchResult ) ),
      distinctUntilChanged( (x, y) => x.length === y.length && x.every( ( result, index ) => y[index].label === result.label && isListEqual( result.data, y[index].data ) ) ),
    );
  }

  addNode( node: Node | Leaf, column: number, offset: number ) {
    this.store$.dispatch( new AddNode({ node, offset, column }) );
  }

  async onContextMenu(x: number, y: number) {
    const supervising = await this.isSupervising$.pipe(take(1)).toPromise();

    if(!supervising) {
      event.preventDefault();
      this.contextMenuPosition.x = `${x}px`;
      this.contextMenuPosition.y = `${y}px`;
      this.contextMenu.openMenu();
    }
  }

}
