import { Component, Directive, Input, ViewChild } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { MatMenu, MatMenuModule } from '@angular/material/menu';
import { RouterTestingModule } from '@angular/router/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { SearchResult, SearchService } from 'core/components/search/search.service';
import { HierarchyState } from 'core/store/hierarchy/hierarchy.model';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { Observable, Subject } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { HomeComponent } from './home.component';

@Component({
  selector: 'cockpit-leaf',
  template: '',
})
class CockpitLeafStubComponent {
  @Input() leaf: any;
}

@Component({
  selector: 'cockpit-node',
  template: '',
})
class CockpitNodeStubComponent {
  @Input() nodeData: any;
}

@Component({
  selector: 'pit-home-menu',
  template: '<mat-menu #rootMenu="matMenu" overlapTrigger class="pit-menu-panel"></mat-menu>',
})
class HomeMenuComponent {
  @ViewChild('rootMenu')
  menu: MatMenu;
}

@Directive({
  selector: '[pitDropList]',
})
class PitDropListStubDirective {
  @Input() canReceive: any;
}

@Directive({
  selector: '[pitDrag]',
})
class PitDragStubDirective {
  @Input() dragData: any;
}

describe('HomeComponent', () => {
  let context: TestCtx<HomeComponent>;
  let actions: Observable<any>;
  let searchServiceStub: jasmine.SpyObj<SearchService<any>>;
  let selected$: Subject<SearchResult<any>>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        MatMenuModule,
      ],
      declarations: [
        HomeComponent,
        CockpitLeafStubComponent,
        CockpitNodeStubComponent,
        HomeMenuComponent,
        PitDropListStubDirective,
        PitDragStubDirective,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: { hierarchy: new HierarchyState() } }),
        provideMockActions(() => actions),
        { provide: SearchService, useFactory: () => jasmine.createSpyObj('SearchService', ['register', 'unregister', 'search', 'select', 'getSelectedFor'] as Array<keyof SearchService<any>>) },
      ],
    })
  });

  beforeEach(async( async () => {
    searchServiceStub = TestBed.get(SearchService);
    selected$ = new Subject<SearchResult<any>>();
    searchServiceStub.getSelectedFor.and.returnValue(selected$);
    context = await createStableTestContext(HomeComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
