import { NgModule } from '@angular/core';
import { MatTabsModule } from '@angular/material/tabs';
import { AlertAdminRoutingModule } from './admin-routing.module';
import { AdminComponent } from './admin.component';
import { SharedAdminModule } from 'shared/shared-admin.module';


@NgModule({
  declarations: [
    AdminComponent,
  ],
  imports: [
    SharedAdminModule,
    MatTabsModule,
    AlertAdminRoutingModule,
  ],
})
export class AdminModule { }
