import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Permissions } from 'core/models/user.model';
import { FormDeactivateDialogModule } from 'shared/components/form-deactivate-dialog/form-deactivate-dialog.module';
import { AdminTabGuard } from 'shared/guards/admin/admin-tab.guard';
import { AdminGuard } from 'shared/guards/admin/admin.guard';
import { CanDeactivateWithFormGuard } from 'shared/services/canDeactivateWithFormGuard';
import { TabAlertsComponent } from '../tab-alerts/tab-alerts.component';
import { TabAlertsModule } from '../tab-alerts/tab-alerts.module';
import { TabArborescenceComponent } from '../tab-arborescence/tab-arborescence.component';
import { TabArborescenceModule } from '../tab-arborescence/tab-arborescence.module';
import { TabBaselinesComponent } from '../tab-baselines/tab-baselines.component';
import { TabBaselinesModule } from '../tab-baselines/tab-baselines.module';
import { TabEventsComponent } from '../tab-events/tab-events.component';
import { TabEventsModule } from '../tab-events/tab-events.module';
import { TabMetricsComponent } from '../tab-metrics/tab-metrics.component';
import { TabMetricsModule } from '../tab-metrics/tab-metrics.module';
import { TabNotificationsComponent } from '../tab-notifications/tab-notifications.component';
import { TabNotificationsModule } from '../tab-notifications/tab-notifications.module';
import { TabProfilsComponent } from '../tab-profils/tab-profils.component';
import { TabProfilsModule } from '../tab-profils/tab-profils.module';
import { TabSynthesisComponent } from '../tab-synthesis/tab-synthesis.component';
import { TabSynthesisModule } from '../tab-synthesis/tab-synthesis.module';
import { TabPerimeterComponent } from './../tab-perimeter/tab-perimeter.component';
import { TabPerimeterModule } from './../tab-perimeter/tab-perimeter.module';
import { AdminComponent } from './admin.component';

const routes: Routes = [
  {
    path: '',
    component: AdminComponent,
    children: [
      {
        path: '',
        pathMatch: 'full',
        canActivate: [AdminGuard],
      },
      {
        path: 'alerts',
        component: TabAlertsComponent,
        canDeactivate: [CanDeactivateWithFormGuard],
        data: { permission : Permissions.ADMIN_ALERT_TAB },
        canActivate: [AdminTabGuard],
      },
      {
        path: 'mute',
        component: TabNotificationsComponent,
        canDeactivate: [CanDeactivateWithFormGuard],
        data: { permission : Permissions.ADMIN_MUTE_TAB },
        canActivate: [AdminTabGuard],
      },
      {
        path: 'baselines',
        component: TabBaselinesComponent,
        canDeactivate: [CanDeactivateWithFormGuard],
        data: { permission : Permissions.ADMIN_BASELINES_TAB },
        canActivate: [AdminTabGuard],
      },
      {
        path: 'synthesis',
        component: TabSynthesisComponent,
        canDeactivate: [CanDeactivateWithFormGuard],
        data: { permission : Permissions.ADMIN_METEO_TAB },
        canActivate: [AdminTabGuard],
      },
      {
        path: 'perimeter',
        component: TabPerimeterComponent,
        canDeactivate: [CanDeactivateWithFormGuard],
        data: { permission : Permissions.ADMIN_PERIMETER_TAB },
        canActivate: [AdminTabGuard],
      },
      {
        path: 'arborescence',
        component: TabArborescenceComponent,
        canDeactivate: [CanDeactivateWithFormGuard],
        data: { permission : Permissions.ADMIN_ARBORESCENCE_TAB },
        canActivate: [AdminTabGuard],
      },
      {
        path: 'metrics',
        component: TabMetricsComponent,
        canDeactivate: [CanDeactivateWithFormGuard],
        data: { permission : Permissions.ADMIN_METRICS_TAB },
        canActivate: [AdminTabGuard],
      },
      {
        path: 'profils',
        component: TabProfilsComponent,
        canDeactivate: [CanDeactivateWithFormGuard],
        data: { permission : Permissions.ADMIN_PROFILS_TAB },
        canActivate: [AdminTabGuard],
      },
      {
        path: 'events',
        component: TabEventsComponent,
        data: { permission : Permissions.ADMIN_EVENTS_TAB },
        canActivate: [AdminTabGuard],
      },
    ],
  },
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    TabAlertsModule,
    TabNotificationsModule,
    TabBaselinesModule,
    TabPerimeterModule,
    TabArborescenceModule,
    TabSynthesisModule,
    TabMetricsModule,
    TabProfilsModule,
    TabEventsModule,
    FormDeactivateDialogModule,
  ],
  exports: [RouterModule],
  providers: [
    CanDeactivateWithFormGuard,
  ],
})
export class AlertAdminRoutingModule { }
