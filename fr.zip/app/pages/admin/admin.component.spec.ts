import { async, TestBed } from '@angular/core/testing';
import { MatTabsModule } from '@angular/material/tabs';
import { RouterTestingModule } from '@angular/router/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { authState } from 'core/store/auth/auth.reducer';
import { initialState as initialNotificationsState } from 'core/store/notifications/notifications.reducer';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { Observable } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { AdminComponent } from './admin.component';

describe('AdminComponent', () => {
  let context: TestCtx<AdminComponent>;
  let actions: Observable<any>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [ RouterTestingModule, MatTabsModule ],
      declarations: [
        AdminComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: { notifications: initialNotificationsState, auth: authState } }),
        provideMockActions(() => actions),
      ],
    })
  });

  beforeEach(async( async () => {
    context = await createStableTestContext(AdminComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
