import { Component, ElementRef, OnInit } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { hasAlertTabAccess, hasArborescenceTabAccess, hasBaselinesTabAccess, hasEventsTabAccess, hasMeteoTabAccess, hasMetricsTabAccess, hasMuteTabAccess, hasPerimeterTabAccess, hasProfilsTabAccess } from 'core/store/auth/auth.selectors';
import { ToggleNotifications } from 'core/store/notifications/notifications.actions';
import { getNotificationOpen } from 'core/store/notifications/notifications.selectors';
import { untilViewDestroyed } from 'core/utils/untilDestroyed';
import { skip, startWith, switchMap, take, tap } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';

@Component({
  selector: 'cockpit-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminComponent implements OnInit {

  hasAlertAccess$ = this.store$.select(hasAlertTabAccess);
  hasMuteAccess$ = this.store$.select(hasMuteTabAccess);
  hasBaselinesAccess$ = this.store$.select(hasBaselinesTabAccess);
  hasMeteoAccess$ = this.store$.select(hasMeteoTabAccess);
  hasPerimeterAccess$ = this.store$.select(hasPerimeterTabAccess);
  hasArborescenceAccess$ = this.store$.select(hasArborescenceTabAccess);
  hasMetricsAccess$ = this.store$.select(hasMetricsTabAccess);
  hasProfilsAccess$ = this.store$.select(hasProfilsTabAccess);
  hasEventsAccess$ = this.store$.select(hasEventsTabAccess);

  constructor(
    private store$: Store<AppState>,
    private element: ElementRef,
  ) {

    let notifWasOpen = false;
    this.store$.pipe(
      select( getNotificationOpen ),
      take(1),
      tap( () => this.store$.dispatch( new ToggleNotifications( false ) ) ),
      switchMap( open => this.store$.pipe( select( getNotificationOpen ), skip(1), startWith(open) ) ),
      untilViewDestroyed(this.element),
      tap( open => notifWasOpen = open )
    ).subscribe({
      complete: () => this.store$.dispatch( new ToggleNotifications( notifWasOpen ) ),
    });

  }

  ngOnInit() {
  }

}
