import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Actions, ofType } from '@ngrx/effects';
import { select, Store } from '@ngrx/store';
import { fadeAnimation } from 'core/animations/animations';
import { canResetForm, canSaveForm, isFormPristine } from 'core/utils/forms.helpers';
import { merge, of } from 'rxjs';
import { map, mapTo, switchMapTo, tap } from 'rxjs/operators';
import { BaselineGenerationType } from 'shared/models/baselines.model';
import { AppState } from 'shared/models/state.model';
import { CanComponentWithFormDeactivate } from 'shared/services/CanComponentWithFormDeactivate.interface';
import { ExportBaselinesComponent } from './components/export-baselines/export-baselines.component';
import { ImportBaselinesComponent } from './components/import-baselines/import-baselines.component';
import { BaselinesFormActionTypes, LoadBaselinesForm, ResetBaselinesForm, SaveBaselinesForm } from './store/baselines/baselines.form.actions';
import { getBaselinesForm, isBaselinesFormLoadingOrSaving, isModified, selectedGenerationTypeSelector } from './store/baselines/baselines.form.selectors';
import { tabBaselineAnimation } from './tab-baselines.animations';

@Component({
  selector: 'pit-tab-baselines',
  templateUrl: './tab-baselines.component.html',
  styleUrls: ['./tab-baselines.component.scss'],
  animations: [
    fadeAnimation(),
    tabBaselineAnimation(),
  ],
})
export class TabBaselinesComponent implements OnInit, CanComponentWithFormDeactivate {

  form$ = this.store$.pipe(
    select( getBaselinesForm ),
  );

  loading$ = this.store$.pipe(
    select( isBaselinesFormLoadingOrSaving ),
  );

  canSave$ = this.form$.pipe(
    canSaveForm
  );

  canReset$ = this.form$.pipe(
    canResetForm
  );

  isPristine$ = this.form$.pipe(
    isFormPristine
  );

  isAuto$ = this.store$.pipe(
    select( selectedGenerationTypeSelector ),
    map( type => type.value === null ? null : type.value === BaselineGenerationType.AUTO ),
  );

  constructor(
    private store$: Store<AppState>,
    private actions$: Actions,
    private router: Router,
    private dialog: MatDialog,
  ) { }

  ngOnInit() {
    this.store$.dispatch( new LoadBaselinesForm() );
  }

  isModified() {
    return this.store$.pipe( select( isModified ) );
  }

  getSaveAction() {
    const saveResult = merge(
      this.actions$.pipe( ofType( BaselinesFormActionTypes.SaveBaselinesFormSuccess ), mapTo(true) ),
      this.actions$.pipe( ofType( BaselinesFormActionTypes.SaveBaselinesFormError ), mapTo(false) ),
    );

    return of(null).pipe(
      tap( () => this.save() ),
      switchMapTo( saveResult ),
    );
  }

  canSave() {
    return this.canSave$;
  }

  import() {
    this.dialog.open(ImportBaselinesComponent);
  }

  export() {
    this.dialog.open(ExportBaselinesComponent);
  }

  save() {
    this.store$.dispatch( new SaveBaselinesForm() );
  }

  saveAndQuit() {
    this.store$.dispatch( new SaveBaselinesForm( { andQuit: true } ) );
  }

  reset() {
    this.store$.dispatch( new ResetBaselinesForm() );
  }

  quit() {
    this.reset();
    this.router.navigateByUrl('/');
  }

}
