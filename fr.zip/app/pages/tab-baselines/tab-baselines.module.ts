import { NgModule } from '@angular/core';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { SharedAdminModule } from 'shared/shared-admin.module';
import { BaselinesFormEffects } from './store/baselines/baselines.form.effects';
import { baselinesFormReducer } from './store/baselines/baselines.form.reducer';
import { BaselinesChartPreviewModule } from './components/baselines-chart-preview/baselines-chart-preview.module';
import { BaselinesGainsModule } from './components/baselines-gains/baselines-gains.module';
import { BaselinesMetricsModule } from './components/baselines-metrics/baselines-metrics.module';
import { BaselinesValuesModule } from './components/baselines-values/baselines-values.module';
import { ExportBaselinesComponent } from './components/export-baselines/export-baselines.component';
import { ExportBaselinesModule } from './components/export-baselines/export-baselines.module';
import { ImportBaselinesComponent } from './components/import-baselines/import-baselines.component';
import { ImportBaselinesModule } from './components/import-baselines/import-baselines.module';
import { TabBaselinesComponent } from './tab-baselines.component';

@NgModule({
  declarations: [
    TabBaselinesComponent,
  ],
  imports: [
    SharedAdminModule,
    BaselinesMetricsModule,
    BaselinesGainsModule,
    BaselinesValuesModule,
    BaselinesChartPreviewModule,
    ImportBaselinesModule,
    ExportBaselinesModule,
    MatProgressSpinnerModule,
    StoreModule.forFeature('baselinesForm', baselinesFormReducer),
    EffectsModule.forFeature([BaselinesFormEffects]),
  ],
  entryComponents: [
    ImportBaselinesComponent,
    ExportBaselinesComponent,
  ],
})
export class TabBaselinesModule { }
