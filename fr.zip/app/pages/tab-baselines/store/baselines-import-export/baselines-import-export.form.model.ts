import { FormGroupState } from 'ngrx-forms';

declare module 'shared/models/state.model' {
  export interface AppState {
    readonly baselinesImportExportForm: BaselinesImportExportFormState;
  }
}
export interface BaselinesImportExportFormValue {
  source: string;
}

export interface MetricSource {
  name: string;
  baselines: boolean;
  hasAutoBaselines: boolean;
}

export type BaselinesImportDTO = MetricSource[];

export interface BaselinesImport {
  sources: string[];
}

export interface BaselinesImportExportFormState {
  form: FormGroupState<BaselinesImportExportFormValue>;
  defaultForm: BaselinesImportExportFormValue;
  isSaving: boolean;
  isLoading: boolean;
  sources: string[];
}
