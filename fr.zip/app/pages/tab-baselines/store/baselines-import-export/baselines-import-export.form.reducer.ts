import { enableIfStable } from 'core/utils/forms.helpers';
import { createFormGroupState, createFormStateReducerWithUpdate, disable, FormGroupState, reset, setValue, updateGroup, validate } from 'ngrx-forms';
import { required } from 'ngrx-forms/validation';
import { BaselinesImportExportFormActionTypes, BaselinesImportExportFormActionUnion } from './baselines-import-export.form.actions';
import { BaselinesImportExportFormState, BaselinesImportExportFormValue } from './baselines-import-export.form.model';

const FORM_ID = 'ADMIN_BASELINES_IMPORT_EXPORT_FORM';

const initialFormState = createFormGroupState<BaselinesImportExportFormValue>(FORM_ID, {
  source: null,
});

const formUpdate = updateGroup<BaselinesImportExportFormValue>( {
} );

const formValidation = updateGroup<BaselinesImportExportFormValue>( {
  source: validate( required ),
} );

const updateAndValidate = ( form: FormGroupState<BaselinesImportExportFormValue> ) => formValidation(formUpdate(form));

const formReducer = createFormStateReducerWithUpdate(updateAndValidate);

export const baselinesImportExportFormState: BaselinesImportExportFormState = {
  form: updateAndValidate(initialFormState),
  defaultForm: null,
  isSaving: false,
  isLoading: false,
  sources: [],
};

export function baselinesImportExportFormReducer(
  state = baselinesImportExportFormState,
  action: BaselinesImportExportFormActionUnion
): BaselinesImportExportFormState {

  const form = formReducer(state.form, action);

  if(form !== state.form) {
    state = { ...state, form };
  }

  switch( action.type ) {

    case BaselinesImportExportFormActionTypes.LoadBaselinesImportExportForm: {
      return {
        ...state,
        form: disable(state.form),
        isLoading: true,
      };
    }
    case BaselinesImportExportFormActionTypes.LoadBaselinesImportExportFormError: {
      return {
        ...state,
        isLoading: false,
      };
    }
    // Optimistic save, assumes no change were done on the server between saves
    case BaselinesImportExportFormActionTypes.LoadBaselinesImportExportFormSuccess: {
      const { baselinesImportExport: { sources } } = action.payload;
      let { source } = state.form.value;
      // tslint:disable-next-line: prefer-const
      let { isSaving, isLoading } = state;
      isLoading = false;

      if( !sources.includes(source) ) source = null;

      const defaultForm: BaselinesImportExportFormValue = { source };

      return {
        ...state,
        form: updateAndValidate(enableIfStable(reset(setValue(state.form, defaultForm)), { isSaving, isLoading } )),
        defaultForm,
        isLoading: false,
        sources,
      };
    }

    case BaselinesImportExportFormActionTypes.SaveBaselinesImportExportForm: {
      return {
        ...state,
        form: disable(state.form),
        isSaving: true,
      };
    }
    case BaselinesImportExportFormActionTypes.SaveBaselinesImportExportFormSuccess: {
      // tslint:disable-next-line: prefer-const
      let { isSaving, isLoading } = state;
      isSaving = false;

      return {
        ...state,
        form: updateAndValidate(enableIfStable(reset(state.form), { isSaving, isLoading } )),
        defaultForm: state.form.value,
        isSaving: false,
      };
    }
    case BaselinesImportExportFormActionTypes.SaveBaselinesImportExportFormError: {
      // tslint:disable-next-line: prefer-const
      let { isSaving, isLoading } = state;
      isSaving = false;

      return {
        ...state,
        form: updateAndValidate(enableIfStable(state.form, { isSaving, isLoading } )),
        isSaving: false,
      };
    }

    default: {
      return state;
    }
  }
}
