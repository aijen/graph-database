import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { BaselinesImportExportFormEffects } from './baselines-import-export.form.effects';
import { baselinesImportExportFormReducer } from './baselines-import-export.form.reducer';

@NgModule({
  declarations: [],
  imports: [
    StoreModule.forFeature('baselinesImportExportForm', baselinesImportExportFormReducer),
    EffectsModule.forFeature([BaselinesImportExportFormEffects]),
  ]
})
export class BaselinesImportExportModule { }
