import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { async, TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { configureTestSuite } from 'ng-bullet';
import { Observable } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { BaselinesImportExportFormEffects } from '../baselines-import-export.form.effects';
import { baselinesImportExportFormState as initialBaselinesImportExportFormState } from '../baselines-import-export.form.reducer';

describe('BaselinesImportExportFormEffects', () => {
  let service: BaselinesImportExportFormEffects;
  let httpTestingController: HttpTestingController;
  let actions: Observable<any>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
      ],
      providers: [
        BaselinesImportExportFormEffects,
        provideMockStore<Partial<AppState>>({ initialState: { baselinesImportExportForm: initialBaselinesImportExportFormState } }),
        provideMockActions(() => actions),
        { provide: MessageHandler, useFactory: () => jasmine.createSpyObj('MessageHandler', ['ngOnDestroy', 'show']) },
      ],
    })
  });

  beforeEach(async( async () => {
    service = TestBed.get(BaselinesImportExportFormEffects);
    httpTestingController = TestBed.get(HttpTestingController);
  } ));

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should create', () => {
    expect(service).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
