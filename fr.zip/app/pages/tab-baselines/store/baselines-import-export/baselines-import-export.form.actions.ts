import { Action } from '@ngrx/store';
import { BaselinesImport } from './baselines-import-export.form.model';

export enum BaselinesImportExportFormActionTypes {
  LoadBaselinesImportExportForm = '[BaselinesImportExport] LoadForm',
  LoadBaselinesImportExportFormSuccess = '[BaselinesImportExport] LoadFormSuccess',
  LoadBaselinesImportExportFormError = '[BaselinesImportExport] LoadFormError',
  SaveBaselinesImportExportForm = '[BaselinesImportExport] SaveForm',
  SaveBaselinesImportExportFormSuccess = '[BaselinesImportExport] SaveFormSuccess',
  SaveBaselinesImportExportFormError = '[BaselinesImportExport] SaveFormError',
}

export class LoadBaselinesImportExportForm implements Action {
  readonly type = BaselinesImportExportFormActionTypes.LoadBaselinesImportExportForm;
  constructor() {}
}

export class LoadBaselinesImportExportFormSuccess implements Action {
  readonly type = BaselinesImportExportFormActionTypes.LoadBaselinesImportExportFormSuccess;
  constructor( public payload: { baselinesImportExport: BaselinesImport } ) {}
}

export class LoadBaselinesImportExportFormError implements Action {
  readonly type = BaselinesImportExportFormActionTypes.LoadBaselinesImportExportFormError;
  constructor( public payload: { error: Error } ) {}
}

export class SaveBaselinesImportExportForm implements Action {
  readonly type = BaselinesImportExportFormActionTypes.SaveBaselinesImportExportForm;
  constructor( public payload: { file: File } ) {}
}

export class SaveBaselinesImportExportFormSuccess implements Action {
  readonly type = BaselinesImportExportFormActionTypes.SaveBaselinesImportExportFormSuccess;
  constructor() {}
}

export class SaveBaselinesImportExportFormError implements Action {
  readonly type = BaselinesImportExportFormActionTypes.SaveBaselinesImportExportFormError;
  constructor( public payload: { error: Error } ) {}
}

export type BaselinesImportExportFormActionUnion =
  | LoadBaselinesImportExportForm
  | LoadBaselinesImportExportFormSuccess
  | LoadBaselinesImportExportFormError
  | SaveBaselinesImportExportForm
  | SaveBaselinesImportExportFormSuccess
  | SaveBaselinesImportExportFormError
  ;
