import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { select, Store } from '@ngrx/store';
import { LOAD_ADMIN_BASELINES_IMPORT_URL, SAVE_ADMIN_BASELINES_IMPORT_URL } from 'core/services/http/http-client.service';
import { getUser } from 'core/store/auth/auth.selectors';
import { combineLatest } from 'rxjs';
import { catchError, map, switchMap, tap, withLatestFrom } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { LoadBaselinesForm } from '../baselines/baselines.form.actions';
import { BaselinesImportExportFormActionTypes, LoadBaselinesImportExportForm, LoadBaselinesImportExportFormError, LoadBaselinesImportExportFormSuccess, SaveBaselinesImportExportForm, SaveBaselinesImportExportFormError, SaveBaselinesImportExportFormSuccess } from './baselines-import-export.form.actions';
import { BaselinesImport, BaselinesImportDTO } from './baselines-import-export.form.model';
import { getBaselinesImportExportForm } from './baselines-import-export.form.selectors';

const fromJson = ( dto: BaselinesImportDTO ): BaselinesImport => {
  return {
    sources: dto.map( source => source.name )
  };
}

@Injectable({providedIn: 'root'})
export class BaselinesImportExportFormEffects {

  public static messages = {
    loadError: `
      Une erreur est survenue pendant le chargement de la configuration 'BaselinesImportExport': Veuillez réessayer
    `,
    saveSuccess: `
      Configuration sauvegardée
    `,
    saveError: `
      Une erreur est survenue pendant l'import', veuillez réessayer ou contacter le support si le problème persiste
    `,
  }

  form$ = this.store$.pipe(
    select( getBaselinesImportExportForm ),
    map( form => form.value ),
  );

  user$ = this.store$.select(getUser);

  constructor(
    private store$: Store<AppState>,
    private actions$: Actions,
    private http: HttpClient,
    private snackbar: MessageHandler,
  ) {}

  @Effect()
  load$ = this.actions$.pipe(
    ofType<LoadBaselinesImportExportForm>( BaselinesImportExportFormActionTypes.LoadBaselinesImportExportForm ),
    switchMap( () => this.http.get<BaselinesImportDTO>(LOAD_ADMIN_BASELINES_IMPORT_URL) ),
    map( fromJson ),
    map( baselinesImportExport => new LoadBaselinesImportExportFormSuccess( { baselinesImportExport } ) ),
    catchError( (error, caught) => (this.store$.dispatch(new LoadBaselinesImportExportFormError( { error } )), caught) ),
  );

  @Effect({ dispatch: false })
  loadError$ = this.actions$.pipe(
    ofType<LoadBaselinesImportExportFormError>( BaselinesImportExportFormActionTypes.LoadBaselinesImportExportFormError ),
    tap( action => { console.error(action.payload.error); this.snackbar.show( { message: BaselinesImportExportFormEffects.messages.loadError, action: 'OK', isError: true } )} ),
  );

  @Effect()
  save$ = this.actions$.pipe(
    ofType<SaveBaselinesImportExportForm>( BaselinesImportExportFormActionTypes.SaveBaselinesImportExportForm ),
    withLatestFrom(combineLatest(
      this.form$,
      this.user$
    )),
    switchMap( ([{ payload: { file } }, [{ source }, { userId }]]) => {
      const form = new FormData();
      form.append( 'file', file, file.name );
      return this.http.put(SAVE_ADMIN_BASELINES_IMPORT_URL, form, { responseType: 'text', params: { source, userId } });
    } ),
    map( () => new SaveBaselinesImportExportFormSuccess() ),
    catchError( (error, caught) => (this.store$.dispatch(new SaveBaselinesImportExportFormError( { error } )), caught) ),
  );

  @Effect()
  saveSuccess$ = this.actions$.pipe(
    ofType<SaveBaselinesImportExportFormSuccess>( BaselinesImportExportFormActionTypes.SaveBaselinesImportExportFormSuccess ),
    tap( () => this.snackbar.show( { message: BaselinesImportExportFormEffects.messages.saveSuccess } ) ),
    map( () => new LoadBaselinesForm() ),
  );

  @Effect( { dispatch: false } )
  saveError$ = this.actions$.pipe(
    ofType<SaveBaselinesImportExportFormError>( BaselinesImportExportFormActionTypes.SaveBaselinesImportExportFormError ),
    tap( action => { console.error(action.payload.error); this.snackbar.show( { message: BaselinesImportExportFormEffects.messages.saveError, action: 'OK', isError: true } )} ),
  );

}
