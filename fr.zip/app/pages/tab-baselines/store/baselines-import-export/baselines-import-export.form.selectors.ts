import { createFeatureSelector, createSelector } from '@ngrx/store';
import { sortStringCaseInsensitiveStrategy } from 'core/utils/sortStrategies';
import { BaselinesImportExportFormState } from './baselines-import-export.form.model';

export const baselinesImportExportFormStateSelector = createFeatureSelector<BaselinesImportExportFormState>(
  'baselinesImportExportForm'
);

export const getBaselinesImportExportForm = createSelector(
  baselinesImportExportFormStateSelector,
  state => state.form,
);

export const isBaselinesImportExportFormLoading = createSelector(
  baselinesImportExportFormStateSelector,
  state => state.isLoading,
);

export const isBaselinesImportExportFormLoadingOrSaving = createSelector(
  baselinesImportExportFormStateSelector,
  state => state.isLoading || state.isSaving,
);

export const isModified = createSelector(
  getBaselinesImportExportForm,
  isBaselinesImportExportFormLoading,
  ( form, loading ) => !(form.isPristine || loading),
);


export const baselinesImportExportSourcesSelector = createSelector(
  baselinesImportExportFormStateSelector,
  ( state ) => state.sources.sort( sortStringCaseInsensitiveStrategy ),
);
