import { createFeatureSelector, createSelector } from '@ngrx/store';
import { combineSortStrategies, sortByPropStrategy, sortStringCaseInsensitiveStrategy } from 'core/utils/sortStrategies';
import uniq from 'lodash/uniq';
import uniqBy from 'lodash/uniqBy';
import { FormControlState } from 'ngrx-forms';
import { BaselineDayMultiplier, BaselineGenerationType } from 'shared/models/baselines.model';
import { BaselinesFormState, BaselinesFormValue, BaselinesMetricsLeaf, BaselineType } from './baselines.form.model';

export const baselinesFormStateSelector = createFeatureSelector<BaselinesFormState>(
  'baselinesForm'
);

export const getBaselinesForm = createSelector(
  baselinesFormStateSelector,
  state => state.form,
);

export const isBaselinesFormLoading = createSelector(
  baselinesFormStateSelector,
  state => state.isLoading,
);

export const isBaselinesFormLoadingOrSaving = createSelector(
  baselinesFormStateSelector,
  state => state.isLoading || state.isSaving,
);


export const baselinesSelector = createSelector(
  baselinesFormStateSelector,
  state => state.baselines,
);

export const leavesSelector = createSelector(
  baselinesFormStateSelector,
  state => state.leaves,
)

export const getLeavesNames = createSelector(
  leavesSelector,
  ( leaves ) => {
    const leavesNames = new Map<string, string>();

    for(const leaf of leaves) {
      leavesNames.set( leaf.key, leaf.fullname )
    }

    return leavesNames;
  }
);


export const selectedBaselineSelector = createSelector(
  getBaselinesForm,
  form => form.controls.selectedBaseline,
);

export const selectedLeafIdSelector = createSelector(
  selectedBaselineSelector,
  baseline => baseline.value.leaf,
);

export const selectedSourceSelector = createSelector(
  selectedBaselineSelector,
  baseline => baseline.value.source,
);

export const selectedMetricSelector = createSelector(
  selectedBaselineSelector,
  baseline => baseline.value.metricType,
);

export const selectedMetricNameSelector = createSelector(
  selectedBaselineSelector,
  baseline => baseline.value.metricName,
);

export const selectedMetricUnitSelector = createSelector(
  selectedBaselineSelector,
  baseline => baseline.value.metricUnit,
);

export const selectedCalendarSelector = createSelector(
  getBaselinesForm,
  form => form.controls.calendarType as FormControlState<BaselineType>,
);

export const selectedGenerationTypeSelector = createSelector(
  selectedBaselineSelector,
  ( baseline ) => baseline.controls.generationType as FormControlState<BaselineGenerationType>,
);

export const selectedResolutionSelector = createSelector(
  selectedBaselineSelector,
  ( baseline ) => baseline.controls.resolution,
);


export const leafIdsSelector = createSelector(
  baselinesSelector,
  getLeavesNames,
  ( baselines, names ) => uniqBy( baselines.map<BaselinesMetricsLeaf>( baseline => ({ key: baseline.leaf, name: names.get(baseline.leaf) || '' }) ), 'key' ).sort( combineSortStrategies( [ [ sortByPropStrategy('name') ], [ sortByPropStrategy('key') ] ] ) ),
);

export const baselinesWithIdSelector = createSelector(
  baselinesSelector,
  selectedLeafIdSelector,
  ( baselines, leafId ) => baselines.filter( baseline => baseline.leaf === leafId ),
);

export const sourcesSelector = createSelector(
  baselinesWithIdSelector,
  ( baselines ) => uniq( baselines.map( baseline => baseline.source ) ).sort( sortStringCaseInsensitiveStrategy ),
);

export const baselinesWithSourceSelector = createSelector(
  baselinesSelector,
  selectedLeafIdSelector,
  selectedSourceSelector,
  ( baselines, leafId, source ) => baselines.filter( baseline => (baseline.leaf === leafId) && (baseline.source === source) ),
);

export const metricsSelector = createSelector(
  baselinesWithSourceSelector,
  ( baselines ) =>
    uniqBy(baselines, baseline => baseline.metricType)
      .map( ({ metricType, metricName }) => ({ metricType, metricName }) )
      .sort( (metricA, metricB) => sortStringCaseInsensitiveStrategy( metricA.metricName, metricB.metricName ) ),
);


export const baselineValuesSelector = createSelector(
  selectedBaselineSelector,
  selectedCalendarSelector,
  ( baseline, calendarType ) => baseline.controls.values.controls[calendarType.value],
);

export const baselineMultiplierSelector = createSelector(
  selectedBaselineSelector,
  ( baseline ) => baseline.controls.multiplier,
);

export const baselineSelectedDayMultiplierSelector = createSelector(
  baselineMultiplierSelector,
  ( multiplier ) => multiplier.controls[multiplier.userDefinedProperties.selectedKey as keyof BaselineDayMultiplier],
);

export const isModified = createSelector(
  selectedBaselineSelector,
  isBaselinesFormLoading,
  ( baseline, loading ) => !(baseline.isPristine || loading),
);

export const canHaveAutoBaselines = createSelector(
  ( form: BaselinesFormValue ) => form.selectedBaseline.source,
  ( form: BaselinesFormValue ) => form.adapters,
  ( source, adapters ) => {
    const adapter = adapters.find( _adapter => _adapter.name === source )
    return adapter && adapter.hasAutoBaselines || false;
  }
)
