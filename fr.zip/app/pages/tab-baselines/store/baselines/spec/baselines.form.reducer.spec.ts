import { AppState } from 'shared/models/state.model';
import { baselinesFormReducer, baselinesFormState } from '../baselines.form.reducer';

// necessary to avoid the error :
// Invalid module name in augmentation, module 'shared/models/state.model' cannot be found.
let happy_compiler: AppState; // tslint:disable-line

describe('BaselinesForm Reducer', () => {

  describe('undefined action', () => {

    it('should return the default state', () => {
      const action = { type: null, payload: null };
      const state = baselinesFormReducer( undefined, action );

      expect(state).toBe(baselinesFormState);
    })

  });

} );
