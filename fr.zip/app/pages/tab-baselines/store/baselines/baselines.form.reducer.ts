import { combineSortStrategies, sortByPropStrategy } from 'core/utils/sortStrategies';
import { createFormGroupState, createFormStateReducerWithUpdate, disable, enable, FormGroupState, reset, setUserDefinedProperty, SetUserDefinedPropertyAction, setValue, updateGroup, updateRecursive, validate } from 'ngrx-forms';
import { required } from 'ngrx-forms/validation';
import { BaselineDayMultiplier, BaselineGenerationType } from 'shared/models/baselines.model';
import { BaselinesFormActionTypes, BaselinesFormActionUnion } from './baselines.form.actions';
import { AdminBaselineLeaf, BaselinesFormState, BaselinesFormValue, BaselineType } from './baselines.form.model';
import { canHaveAutoBaselines } from './baselines.form.selectors';
import { emptyBaseline } from './baselines.form.utils';

const FORM_ID = 'ADMIN_BASELINES_FORM';

const initialFormState = createFormGroupState<BaselinesFormValue>(FORM_ID, {
  selectedBaseline: emptyBaseline(),
  calendarType: BaselineType.BUSINESS_DAY,
  adapters: [],
});

const formUpdate = updateGroup<BaselinesFormValue>(
{
  selectedBaseline: ( baseline, { value } ) => updateGroup<AdminBaselineLeaf>( baseline, {
    values: ( values, { value: { generationType } } ) => generationType === BaselineGenerationType.AUTO ? disable(values) : enable(values),
    multiplier: ( multiplier, { value: { generationType } } ) => generationType === BaselineGenerationType.AUTO ? updateGroup<BaselineDayMultiplier>( enable(multiplier), {
      MON: ( day ) => value.calendarType === BaselineType.BUSINESS_DAY ? enable( day ) : disable( day ),
      TUE: ( day ) => value.calendarType === BaselineType.BUSINESS_DAY ? enable( day ) : disable( day ),
      WED: ( day ) => value.calendarType === BaselineType.BUSINESS_DAY ? enable( day ) : disable( day ),
      THU: ( day ) => value.calendarType === BaselineType.BUSINESS_DAY ? enable( day ) : disable( day ),
      FRI: ( day ) => value.calendarType === BaselineType.BUSINESS_DAY ? enable( day ) : disable( day ),
      SAT: ( day ) => value.calendarType === BaselineType.BUSINESS_DAY ? disable( day ) : enable( day ),
      SUN: ( day ) => value.calendarType === BaselineType.BUSINESS_DAY ? disable( day ) : enable( day ),
    } ) : disable(multiplier),
    generationType: ( type ) => canHaveAutoBaselines(value) ? enable(type) : disable(type),
  } )
}, {
  selectedBaseline: updateGroup<AdminBaselineLeaf>( {
    multiplier: ( multiplier ) => {
      const controls = Object.entries( multiplier.controls );
      const enabledControls = controls.filter( ([,control]) => control.isEnabled );
      const enabledControl = enabledControls.find( ([,control]) => control.id === multiplier.userDefinedProperties.selected );
      const focusedControls = enabledControls.find( ([,control]) => Object.values( control.controls ).some( childControl => childControl.isFocused ) );

      if( focusedControls ) {
        const [controlKey, { id: controlId }] = focusedControls;
        let control = setUserDefinedProperty(multiplier, 'selected', controlId);
        control = setUserDefinedProperty(control, 'selectedKey', controlKey);
        return control;
      }
      if( !enabledControl && enabledControls.length ) {
        const [controlKey, { id: controlId }] = enabledControls[0];
        let control = setUserDefinedProperty(multiplier, 'selected', controlId);
        control = setUserDefinedProperty(control, 'selectedKey', controlKey);
        return control;
      }
      if( !multiplier.userDefinedProperties.selected ) {
        const [controlKey, { id: controlId }] = controls[0];
        let control = setUserDefinedProperty(multiplier, 'selected', controlId);
        control = setUserDefinedProperty(control, 'selectedKey', controlKey);
        return control;
      }

      return multiplier;
    },
    generationType: ( type ) => type.value === BaselineGenerationType.AUTO && type.isDisabled ? setValue( type, BaselineGenerationType.MANUAL ) : type,
  } )
} );

const formValidation = updateGroup<BaselinesFormValue>( {
  selectedBaseline: updateGroup<AdminBaselineLeaf>( {
    values: updateGroup<AdminBaselineLeaf['values']>( {
      BUSINESS_DAY: updateRecursive( validate( required ) ),
      PUBLIC_HOLIDAY: updateRecursive( validate( required ) ),
    } ),
    multiplier: updateRecursive( validate( required ) ),
  } )
} );

const updateAndValidate = ( form: FormGroupState<BaselinesFormValue> ) => formValidation(formUpdate(form));

const formReducer = createFormStateReducerWithUpdate(updateAndValidate);

export const baselinesFormState: BaselinesFormState = {
  form: updateAndValidate(initialFormState),
  defaultForm: null,
  isSaving: false,
  isLoading: false,
  baselines: [],
  leaves: [],
};

export function baselinesFormReducer(
  state = baselinesFormState,
  action: BaselinesFormActionUnion
): BaselinesFormState {

  const form = formReducer(state.form, action);

  if(form !== state.form) {
    state = { ...state, form };
  }

  switch( action.type ) {

    case BaselinesFormActionTypes.ResetBaselinesForm: {
      const defaultForm = state.defaultForm;
      return {
        ...state,
        form: updateAndValidate(reset(setValue(state.form, defaultForm ))),
      }
    }

    case BaselinesFormActionTypes.LoadBaselinesForm: {
      return {
        ...state,
        form: disable(state.form),
        isLoading: true,
      };
    }
    case BaselinesFormActionTypes.LoadBaselinesFormError: {
      return {
        ...state,
        isLoading: false,
      };
    }
    // Optimistic save, assumes no change were done on the server between saves
    case BaselinesFormActionTypes.LoadBaselinesFormSuccess: {
      const { baselines, adapters, leaves } = action.payload;
      let selectedBaseline: AdminBaselineLeaf;
      if( state.form.value.selectedBaseline.id ) {
        selectedBaseline = baselines.find( baseline => baseline.id === state.form.value.selectedBaseline.id );
      }
      if( !selectedBaseline ) {
        // find first baseline sorted by alpha on leaf key, source and metric
        selectedBaseline = baselines.sort( combineSortStrategies( [
          [sortByPropStrategy( 'leaf' )],
          [sortByPropStrategy( 'source' )],
          [sortByPropStrategy( 'metricName' )]
        ] ) )[0];
      }
      if( !selectedBaseline ) selectedBaseline = emptyBaseline();
      const defaultForm: BaselinesFormValue = { ...state.form.value, selectedBaseline, adapters };
      return {
        ...state,
        form: updateAndValidate(enable(reset(setValue(state.form, defaultForm)))),
        defaultForm,
        isLoading: false,
        baselines,
        leaves,
      };
    }

    case BaselinesFormActionTypes.SaveBaselinesForm: {
      return {
        ...state,
        form: disable(state.form),
        isSaving: true,
      };
    }
    case BaselinesFormActionTypes.SaveBaselinesFormSuccess: {
      let baselines = state.baselines.filter( baseline => baseline.id !== state.form.value.selectedBaseline.id );
      baselines = [ ...baselines, state.form.value.selectedBaseline ];
      return {
        ...state,
        form: updateAndValidate(enable(reset(state.form))),
        defaultForm: state.form.value,
        isSaving: false,
        baselines,
      };
    }
    case BaselinesFormActionTypes.SaveBaselinesFormError: {
      return {
        ...state,
        form: updateAndValidate(enable(state.form)),
        isSaving: false,
      };
    }

    case BaselinesFormActionTypes.SetLeaf: {
      let {
        // tslint:disable: prefer-const
        leafId = state.defaultForm.selectedBaseline.leaf,
        source = state.defaultForm.selectedBaseline.source,
        metric = state.defaultForm.selectedBaseline.metricType,
        // tslint:enable: prefer-const
      } = action.payload;

      const baselines = state.baselines.filter( baseline => baseline.leaf === leafId );
      let withSources = baselines.filter( baseline => baseline.source === source );
      if( !withSources.length ) {
        source = baselines[0].source;
        withSources = baselines.filter( baseline => baseline.source === source );
      }
      let selectedBaseline = withSources.find( baseline => baseline.metricType === metric);
      if( !selectedBaseline ) {
        metric = withSources[0].metricType;
        selectedBaseline = withSources.find( baseline => baseline.metricType === metric);
      }

      const defaultForm: BaselinesFormValue = { ...state.form.value, selectedBaseline };
      return {
        ...state,
        form: updateAndValidate(reset(setValue(state.form, defaultForm))),
        defaultForm,
      }
    }

    case BaselinesFormActionTypes.SetSelectedDay: {
      const { controlId, controlKey } = action.payload;
      let _form = formReducer( form, new SetUserDefinedPropertyAction( form.controls.selectedBaseline.controls.multiplier.id, 'selected', controlId ) );
      _form = formReducer( _form, new SetUserDefinedPropertyAction( _form.controls.selectedBaseline.controls.multiplier.id, 'selectedKey', controlKey ) );

      return {
        ...state,
        form: _form,
      };
    }

    default: {
      return state;
    }
  }
}
