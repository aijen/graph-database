import { Action } from '@ngrx/store';
import { CockpitLeaf } from 'shared/models/cockpit-leaf.model';
import { MetricSource } from '../baselines-import-export/baselines-import-export.form.model';
import { AdminBaselineLeaf } from './baselines.form.model';

export enum BaselinesFormActionTypes {
  LoadBaselinesForm = '[Admin] LoadBaselinesForm',
  LoadBaselinesFormSuccess = '[Admin] LoadBaselinesFormSuccess',
  LoadBaselinesFormError = '[Admin] LoadBaselinesFormError',
  ResetBaselinesForm = '[Admin] ResetBaselinesForm',
  SaveBaselinesForm = '[Admin] SaveBaselinesForm',
  SaveBaselinesFormSuccess = '[Admin] SaveBaselinesFormSuccess',
  SaveBaselinesFormError = '[Admin] SaveBaselinesFormError',
  SetLeaf = '[Admin] SetLeaf',
  SetSelectedDay = '[Admin] SetSelectedDay',
}

export class LoadBaselinesForm implements Action {
  readonly type = BaselinesFormActionTypes.LoadBaselinesForm;
  constructor() {}
}

export class LoadBaselinesFormSuccess implements Action {
  readonly type = BaselinesFormActionTypes.LoadBaselinesFormSuccess;
  constructor( public payload: { baselines: AdminBaselineLeaf[], adapters: MetricSource[], leaves: CockpitLeaf[] } ) {}
}

export class LoadBaselinesFormError implements Action {
  readonly type = BaselinesFormActionTypes.LoadBaselinesFormError;
  constructor( public payload: { error: Error } ) {}
}

export class ResetBaselinesForm implements Action {
  readonly type = BaselinesFormActionTypes.ResetBaselinesForm;
  constructor() {}
}

export class SaveBaselinesForm implements Action {
  readonly type = BaselinesFormActionTypes.SaveBaselinesForm;
  constructor( public payload: { andQuit?: boolean } = {} ) {}
}

export class SaveBaselinesFormSuccess implements Action {
  readonly type = BaselinesFormActionTypes.SaveBaselinesFormSuccess;
  constructor( public payload: { andQuit?: boolean } = {} ) {}
}

export class SaveBaselinesFormError implements Action {
  readonly type = BaselinesFormActionTypes.SaveBaselinesFormError;
  constructor( public payload: { error: Error } ) {}
}

export class SetLeaf implements Action {
  readonly type = BaselinesFormActionTypes.SetLeaf;
  constructor( public payload: { leafId?: string, metric?: string, source?: string } ) {}
}

export class SetSelectedDay implements Action {
  readonly type = BaselinesFormActionTypes.SetSelectedDay;
  constructor( public payload: { controlId: string, controlKey: string } ) {}
}

export type BaselinesFormActionUnion =
  | LoadBaselinesForm
  | LoadBaselinesFormSuccess
  | LoadBaselinesFormError
  | ResetBaselinesForm
  | SaveBaselinesForm
  | SaveBaselinesFormSuccess
  | SaveBaselinesFormError
  | SetLeaf
  | SetSelectedDay
  ;
