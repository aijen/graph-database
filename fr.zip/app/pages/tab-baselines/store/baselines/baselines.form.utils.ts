import { BaselineDayMultiplier, BaselineDays, BaselineGenerationType, BaselineHour, BaselineHours } from 'shared/models/baselines.model';
import { AdminBaselineLeaf } from './baselines.form.model';


export const initialThreshold = () => ({ value: 0, lowerTreshold: 0, upperTreshold: 0 });

export const emptyBaselineHours =
  () => {
    const baseline = {};
    for( const hour of BaselineHours ) baseline[hour] = initialThreshold();
    return baseline as BaselineHour;
  }

export const emptyBaselineDays =
  () => {
    const baseline = {};
    for( const hour of BaselineDays ) baseline[hour] = initialThreshold();
    return baseline as BaselineDayMultiplier;
  }

export const emptyBaseline = (): AdminBaselineLeaf => ({
    id: '',
    leaf: '',
    source: '',
    generationType: BaselineGenerationType.MANUAL,
    metricType: '',
    metricName: '',
    metricUnit: '',
    metaType: null,
    metricDescription: '',
    resolution: 1,
    values: {
      PUBLIC_HOLIDAY: emptyBaselineHours(),
      BUSINESS_DAY: emptyBaselineHours(),
    },
    multiplier: emptyBaselineDays(),
    weight: 0,
  });
