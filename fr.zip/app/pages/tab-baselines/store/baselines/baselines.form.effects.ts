import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { select, Store } from '@ngrx/store';
import { SaveEvent } from 'app/pages/tab-events/store/events/events.actions';
import { EventsService } from 'app/pages/tab-events/store/events/events.service';
import { PerimeterFormService } from 'app/pages/tab-perimeter/store/perimeter/perimeter.form.service';
import { LOAD_ADMIN_BASELINES_IMPORT_URL, LOAD_ADMIN_BASELINES_URL, SAVE_ADMIN_BASELINES_URL } from 'core/services/http/http-client.service';
import { getAuthState } from 'core/store/auth/auth.selectors';
import { combineLatest, of } from 'rxjs';
import { catchError, map, switchMap, tap, withLatestFrom } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { BaselinesImportDTO } from '../baselines-import-export/baselines-import-export.form.model';
import { BaselinesFormActionTypes, LoadBaselinesForm, LoadBaselinesFormError, LoadBaselinesFormSuccess, SaveBaselinesForm, SaveBaselinesFormError, SaveBaselinesFormSuccess } from './baselines.form.actions';
import { AdminBaselineLeaf } from './baselines.form.model';
import { getBaselinesForm } from './baselines.form.selectors';

@Injectable({providedIn: 'root'})
export class BaselinesFormEffects {

  public static messages = {
    loadError: `
      Une erreur est survenue pendant le chargement de la configuration 'Baselines': Veuillez réessayer
    `,
    saveSuccess: `
      Configuration sauvegardée
    `,
    saveError: `
      Une erreur est survenue pendant la sauvegarde, veuillez réessayer ou contacter le support si le problème persiste
    `,
  }

  form$ = this.store$.pipe(
    select( getBaselinesForm ),
    map( form => form.value.selectedBaseline ),
  );

  auth$ = this.store$.select(getAuthState);

  constructor(
    private store$: Store<AppState>,
    private actions$: Actions,
    private http: HttpClient,
    private router: Router,
    private snackbar: MessageHandler,
    private perimeterFormService: PerimeterFormService,
    private eventsService: EventsService,
  ) {}

  @Effect()
  load$ = this.actions$.pipe(
    ofType<LoadBaselinesForm>( BaselinesFormActionTypes.LoadBaselinesForm ),
    switchMap( () =>
      combineLatest(
        this.http.get<AdminBaselineLeaf[]>(LOAD_ADMIN_BASELINES_URL),
        this.http.get<BaselinesImportDTO>(LOAD_ADMIN_BASELINES_IMPORT_URL),
        this.perimeterFormService.loadLeaves(),
      )
    ),
    map( ([baselines, adapters, leaves]) => new LoadBaselinesFormSuccess( { baselines, adapters, leaves } ) ),
    catchError( (error, caught) => (this.store$.dispatch(new LoadBaselinesFormError( { error } )), caught) ),
  );

  @Effect({ dispatch: false })
  loadError$ = this.actions$.pipe(
    ofType<LoadBaselinesFormError>( BaselinesFormActionTypes.LoadBaselinesFormError ),
    tap( action => { console.error(action.payload.error); this.snackbar.show( { message: BaselinesFormEffects.messages.loadError, action: 'OK', isError: true } )} ),
  );

  @Effect()
  save$ = this.actions$.pipe(
    ofType<SaveBaselinesForm>( BaselinesFormActionTypes.SaveBaselinesForm ),
    withLatestFrom( this.form$ ),
    switchMap( ([{ payload: { andQuit } }, _form]) => of(_form).pipe(
      switchMap( form => this.http.put(SAVE_ADMIN_BASELINES_URL, [form], { responseType: 'text' }) ),
      map( () => new SaveBaselinesFormSuccess( { andQuit } ) ),
      catchError( error => of(new SaveBaselinesFormError( { error } )) ),
    ) ),
  );

  // Optimistic save, assumes no change were done on the server between saves
  @Effect()
  saveSuccess$ = this.actions$.pipe(
    ofType<SaveBaselinesFormSuccess>( BaselinesFormActionTypes.SaveBaselinesFormSuccess ),
    tap( () => this.snackbar.show( { message: BaselinesFormEffects.messages.saveSuccess } ) ),
    tap( action => action.payload.andQuit ? this.router.navigate(['/']) : null ),
    withLatestFrom(this.auth$),
    map(([, auth]) => this.eventsService.createEvent(auth, '[Baselines]')),
    map(event => new SaveEvent({ event })),
  );

  @Effect( { dispatch: false } )
  saveError$ = this.actions$.pipe(
    ofType<SaveBaselinesFormError>( BaselinesFormActionTypes.SaveBaselinesFormError ),
    tap( action => { console.error(action.payload.error); this.snackbar.show( { message: BaselinesFormEffects.messages.saveError, action: 'OK', isError: true } )} ),
  );

}
