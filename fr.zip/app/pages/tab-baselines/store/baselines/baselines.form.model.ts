import { FormGroupState } from 'ngrx-forms';
import { Baselines } from 'shared/models/baselines.model';
import { CockpitLeaf } from 'shared/models/cockpit-leaf.model';
import { MetricSource } from '../baselines-import-export/baselines-import-export.form.model';

declare module 'shared/models/state.model' {
  export interface AppState {
    readonly baselinesForm: BaselinesFormState;
  }
}

export enum BaselineType {
  'PUBLIC_HOLIDAY' = 'PUBLIC_HOLIDAY',
  'BUSINESS_DAY' = 'BUSINESS_DAY',
}

export type AdminBaselineLeaf = Baselines;

export interface BaselinesFormValue {
  selectedBaseline: AdminBaselineLeaf,
  calendarType: BaselineType,
  adapters: MetricSource[],
}

export interface BaselinesFormState {
  form: FormGroupState<BaselinesFormValue>;
  defaultForm: BaselinesFormValue;
  isSaving: boolean;
  isLoading: boolean;
  baselines: AdminBaselineLeaf[];
  leaves: CockpitLeaf[];
}

export interface BaselinesMetricsLeaf {
  key: string;
  name: string;
}
