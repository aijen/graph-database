import { Action } from '@ngrx/store';
import { HolidaysFormValue } from './holidays.form.model';

export enum HolidaysFormActionTypes {
  LoadHolidaysForm = '[Admin] LoadHolidaysForm',
  LoadHolidaysFormSuccess = '[Admin] LoadHolidaysFormSuccess',
  LoadHolidaysFormError = '[Admin] LoadHolidaysFormError',
  ResetHolidaysForm = '[Admin] ResetHolidaysForm',
  SaveHolidaysForm = '[Admin] SaveHolidaysForm',
  SaveHolidaysFormSuccess = '[Admin] SaveHolidaysFormSuccess',
  SaveHolidaysFormError = '[Admin] SaveHolidaysFormError',
}

export class LoadHolidaysForm implements Action {
  readonly type = HolidaysFormActionTypes.LoadHolidaysForm;
  constructor() {}
}

export class LoadHolidaysFormSuccess implements Action {
  readonly type = HolidaysFormActionTypes.LoadHolidaysFormSuccess;
  constructor( public payload: { holidays: HolidaysFormValue } ) {}
}

export class LoadHolidaysFormError implements Action {
  readonly type = HolidaysFormActionTypes.LoadHolidaysFormError;
  constructor( public payload: { error: Error } ) {}
}

export class ResetHolidaysForm implements Action {
  readonly type = HolidaysFormActionTypes.ResetHolidaysForm;
  constructor() {}
}

export class SaveHolidaysForm implements Action {
  readonly type = HolidaysFormActionTypes.SaveHolidaysForm;
  constructor() {}
}

export class SaveHolidaysFormSuccess implements Action {
  readonly type = HolidaysFormActionTypes.SaveHolidaysFormSuccess;
  constructor() {}
}

export class SaveHolidaysFormError implements Action {
  readonly type = HolidaysFormActionTypes.SaveHolidaysFormError;
  constructor( public payload: { error: Error } ) {}
}

export type HolidaysFormActionUnion =
  | LoadHolidaysForm
  | LoadHolidaysFormSuccess
  | LoadHolidaysFormError
  | ResetHolidaysForm
  | SaveHolidaysForm
  | SaveHolidaysFormSuccess
  | SaveHolidaysFormError
  ;
