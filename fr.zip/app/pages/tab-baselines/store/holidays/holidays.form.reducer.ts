import { enableIfStable } from 'core/utils/forms.helpers';
import { createFormGroupState, createFormStateReducerWithUpdate, disable, FormGroupState, reset, setValue, updateGroup } from 'ngrx-forms';
import { HolidaysFormActionTypes, HolidaysFormActionUnion } from './holidays.form.actions';
import { HolidaysFormState, HolidaysFormValue } from './holidays.form.model';

const FORM_ID = 'ADMIN_HOLIDAYS_FORM';

const initialFormState = createFormGroupState<HolidaysFormValue>(FORM_ID, {
  id: '',
  publicHolidays: [],
});

const formUpdate = updateGroup<HolidaysFormValue>( {
} );

const formValidation = updateGroup<HolidaysFormValue>( {
} );

const updateAndValidate = ( form: FormGroupState<HolidaysFormValue> ) => formValidation(formUpdate(form));

const formReducer = createFormStateReducerWithUpdate(updateAndValidate);

export const holidaysFormState: HolidaysFormState = {
  form: updateAndValidate(initialFormState),
  defaultForm: null,
  isSaving: false,
  isLoading: false,
};

export function holidaysFormReducer(
  state = holidaysFormState,
  action: HolidaysFormActionUnion
): HolidaysFormState {

  const form = formReducer(state.form, action);

  if(form !== state.form) {
    state = { ...state, form };
  }

  switch( action.type ) {

    case HolidaysFormActionTypes.ResetHolidaysForm: {
      const defaultForm = state.defaultForm;
      return {
        ...state,
        form: updateAndValidate(reset(setValue(state.form, defaultForm ))),
      }
    }

    case HolidaysFormActionTypes.LoadHolidaysForm: {
      return {
        ...state,
        form: disable(state.form),
        isLoading: true,
      };
    }
    case HolidaysFormActionTypes.LoadHolidaysFormError: {
      return {
        ...state,
        isLoading: false,
      };
    }
    // Optimistic save, assumes no change were done on the server between saves
    case HolidaysFormActionTypes.LoadHolidaysFormSuccess: {
      const { holidays: defaultForm } = action.payload;
      // tslint:disable-next-line: prefer-const
      let { isSaving, isLoading } = state;
      isLoading = false;

      return {
        ...state,
        form: updateAndValidate(enableIfStable(reset(setValue(state.form, defaultForm)), { isSaving, isLoading } )),
        defaultForm,
        isLoading: false,
      };
    }

    case HolidaysFormActionTypes.SaveHolidaysForm: {
      return {
        ...state,
        form: disable(state.form),
        isSaving: true,
      };
    }
    case HolidaysFormActionTypes.SaveHolidaysFormSuccess: {
      // tslint:disable-next-line: prefer-const
      let { isSaving, isLoading } = state;
      isSaving = false;

      return {
        ...state,
        form: updateAndValidate(enableIfStable(reset(state.form), { isSaving, isLoading } )),
        defaultForm: state.form.value,
        isSaving: false,
      };
    }
    case HolidaysFormActionTypes.SaveHolidaysFormError: {
      // tslint:disable-next-line: prefer-const
      let { isSaving, isLoading } = state;
      isSaving = false;

      return {
        ...state,
        form: updateAndValidate(enableIfStable(state.form, { isSaving, isLoading } )),
        isSaving: false,
      };
    }

    default: {
      return state;
    }
  }
}
