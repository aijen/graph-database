import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { select, Store } from '@ngrx/store';
import { LOAD_ADMIN_HOLIDAYS_URL, SAVE_ADMIN_HOLIDAYS_URL } from 'core/services/http/http-client.service';
import { UnloadHolidays } from 'core/store/holidays/holidays.actions';
import { of } from 'rxjs';
import { catchError, map, switchMap, tap, withLatestFrom } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { HolidaysFormActionTypes, LoadHolidaysForm, LoadHolidaysFormError, LoadHolidaysFormSuccess, SaveHolidaysForm, SaveHolidaysFormError, SaveHolidaysFormSuccess } from './holidays.form.actions';
import { HolidaysDTO, HolidaysFormValue } from './holidays.form.model';
import { getHolidaysForm } from './holidays.form.selectors';

const toJson = ( conf: HolidaysFormValue ): HolidaysDTO => {
  const zeroPad = ( n: number ) => n < 10 ? `0${n}` : `${n}`;
  return {
    ...conf,
    publicHolidays: conf.publicHolidays.map( ({ day, month, year }) => `${year}-${zeroPad(month+1)}-${zeroPad(day)}` ),
  };
}

const fromJson = ( dto: HolidaysDTO ): HolidaysFormValue => {
  const publicHolidays = dto.publicHolidays || [];
  return {
    ...dto,
    publicHolidays: publicHolidays.map( ( date ) => date.split('-').map( Number ) ).map( ( [ year, month, day ] ) => ({ day, month: month - 1, year }) ),
  };
}

@Injectable({providedIn: 'root'})
export class HolidaysFormEffects {

  public static messages = {
    loadError: `
      Une erreur est survenue pendant le chargement de la configuration 'Holidays': Veuillez réessayer
    `,
    saveSuccess: `
      Configuration sauvegardée
    `,
    saveError: `
      Une erreur est survenue pendant la sauvegarde, veuillez réessayer ou contacter le support si le problème persiste
    `,
  }

  form$ = this.store$.pipe(
    select( getHolidaysForm ),
    map( form => form.value ),
  );

  constructor(
    private store$: Store<AppState>,
    private actions$: Actions,
    private http: HttpClient,
    private snackbar: MessageHandler,
  ) {}

  @Effect()
  load$ = this.actions$.pipe(
    ofType<LoadHolidaysForm>( HolidaysFormActionTypes.LoadHolidaysForm ),
    switchMap( () => this.http.get<HolidaysDTO>(LOAD_ADMIN_HOLIDAYS_URL) ),
    map( fromJson ),
    map( holidays => new LoadHolidaysFormSuccess( { holidays } ) ),
    catchError( (error, caught) => (this.store$.dispatch(new LoadHolidaysFormError( { error } )), caught) ),
  );

  @Effect({ dispatch: false })
  loadError$ = this.actions$.pipe(
    ofType<LoadHolidaysFormError>( HolidaysFormActionTypes.LoadHolidaysFormError ),
    tap( action => { console.error(action.payload.error); this.snackbar.show( { message: HolidaysFormEffects.messages.loadError, action: 'OK', isError: true } )} ),
  );

  @Effect()
  save$ = this.actions$.pipe(
    ofType<SaveHolidaysForm>( HolidaysFormActionTypes.SaveHolidaysForm ),
    withLatestFrom( this.form$ ),
    switchMap( ([, _form]) => of(_form).pipe(
      map( toJson ),
      switchMap( form => this.http.put(SAVE_ADMIN_HOLIDAYS_URL, form, { responseType: 'text' }) ),
      map( () => new SaveHolidaysFormSuccess() ),
      catchError( error => of(new SaveHolidaysFormError( { error } )) ),
    ) ),
  );

  // Optimistic save, assumes no change were done on the server between saves
  @Effect()
  saveSuccess$ = this.actions$.pipe(
    ofType<SaveHolidaysFormSuccess>( HolidaysFormActionTypes.SaveHolidaysFormSuccess ),
    tap( () => this.snackbar.show( { message: HolidaysFormEffects.messages.saveSuccess } ) ),
    map(() => new UnloadHolidays()),
  );

  @Effect( { dispatch: false } )
  saveError$ = this.actions$.pipe(
    ofType<SaveHolidaysFormError>( HolidaysFormActionTypes.SaveHolidaysFormError ),
    tap( action => { console.error(action.payload.error); this.snackbar.show( { message: HolidaysFormEffects.messages.saveError, action: 'OK', isError: true } )} ),
  );

}
