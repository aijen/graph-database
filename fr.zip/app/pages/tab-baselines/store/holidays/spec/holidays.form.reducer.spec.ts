import { AppState } from 'shared/models/state.model';
import { holidaysFormReducer, holidaysFormState } from '../holidays.form.reducer';

// necessary to avoid the error :
// Invalid module name in augmentation, module 'shared/models/state.model' cannot be found.
let happy_compiler: AppState; // tslint:disable-line

describe('HolidaysForm Reducer', () => {

  describe('undefined action', () => {

    it('should return the default state', () => {
      const action = { type: null, payload: null };
      const state = holidaysFormReducer( undefined, action );

      expect(state).toBe(holidaysFormState);
    })

  });

} );
