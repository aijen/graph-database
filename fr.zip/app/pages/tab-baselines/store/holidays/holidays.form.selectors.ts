import { createFeatureSelector, createSelector } from '@ngrx/store';
import { HolidaysFormState } from './holidays.form.model';

export const holidaysFormStateSelector = createFeatureSelector<HolidaysFormState>(
  'holidaysForm'
);

export const getHolidaysForm = createSelector(
  holidaysFormStateSelector,
  state => state.form,
);

export const isHolidaysFormLoading = createSelector(
  holidaysFormStateSelector,
  state => state.isLoading,
);

export const isHolidaysFormLoadingOrSaving = createSelector(
  holidaysFormStateSelector,
  state => state.isLoading || state.isSaving,
);


export const holidaysSelector = createSelector(
  holidaysFormStateSelector,
  state => state.form.controls.publicHolidays,
);

export const isModified = createSelector(
  getHolidaysForm,
  isHolidaysFormLoading,
  ( form, loading ) => !(form.isPristine || loading),
);
