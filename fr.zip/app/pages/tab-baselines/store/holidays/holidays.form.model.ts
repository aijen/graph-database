import { FormGroupState } from 'ngrx-forms';

declare module 'shared/models/state.model' {
  export interface AppState {
    readonly holidaysForm: HolidaysFormState;
  }
}

export interface DateStruct {
  day: number;
  month: number;
  year: number;
}

export interface HolidaysFormValue {
  id: string;
  publicHolidays: DateStruct[],
}

export interface HolidaysDTO {
  id: string;
  publicHolidays: string[],
}

export interface HolidaysFormState {
  form: FormGroupState<HolidaysFormValue>;
  defaultForm: HolidaysFormValue;
  isSaving: boolean;
  isLoading: boolean;
}
