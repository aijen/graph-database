import { Component } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { MatDialog } from '@angular/material/dialog';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { Observable } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { baselinesFormState } from './store/baselines/baselines.form.reducer';
import { TabBaselinesComponent } from './tab-baselines.component';

@Component({
  selector: 'pit-baselines-metrics',
  template: '',
})
class PitBaselinesMetricsStubComponent {}

@Component({
  selector: 'pit-baselines-gains',
  template: '',
})
class PitBaselinesGainsStubComponent {}

@Component({
  selector: 'pit-baselines-values',
  template: '',
})
class PitBaselinesValuesStubComponent {}

@Component({
  selector: 'pit-baselines-chart-preview',
  template: '',
})
class PitBaselinesChartPreviewStubComponent {}

describe('TabBaselinesComponent', () => {
  let context: TestCtx<TabBaselinesComponent>;
  let actions: Observable<any>;
  let matDialogStub: jasmine.SpyObj<MatDialog>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        MatProgressSpinnerModule,
        NoopAnimationsModule,
        RouterTestingModule,
      ],
      declarations: [
        TabBaselinesComponent,
        PitBaselinesMetricsStubComponent,
        PitBaselinesGainsStubComponent,
        PitBaselinesValuesStubComponent,
        PitBaselinesChartPreviewStubComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: { baselinesForm: baselinesFormState } }),
        provideMockActions(() => actions),
        { provide: MatDialog, useFactory: () => jasmine.createSpyObj('MatDialog', ['open'] as Array<keyof MatDialog>) },
      ],
    })
  });

  beforeEach(async( async () => {
    matDialogStub = TestBed.get(MatDialog);
    context = await createStableTestContext(TabBaselinesComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
