import { animate, state, style, transition, trigger } from '@angular/animations';

export function tabBaselineAnimation() {
  return (
    trigger('slideInOut', [
      state('opened', style({
        transform: 'translate3d(0px, 0px, 0px)',
        zIndex: 1,
      })),
      state('closed', style({
        transform: 'translate3d(0px, 0px, -200px)',
        opacity: 0,
        zIndex: 0,
        pointerEvents: 'none',
      })),
      transition('opened => closed', [
        animate('.35s ease-out'),
      ]),
      transition('closed => opened', [
        animate('.35s ease-out'),
      ]),
    ])
  );
}
