import { Component, Input } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { Observable } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { baselinesFormState } from '../../store/baselines/baselines.form.reducer';
import { BaselinesChartPreviewComponent } from './baselines-chart-preview.component';

@Component({
  selector: 'pit-chart-view',
  template: '',
})
class PitChartViewStubComponent {
  @Input() data: any;
  @Input() leafKey: any;
  @Input() fromDate: any;
  @Input() range: any;
  @Input() chartFullName: any;
  @Input() baselines: any;
  @Input() baselinesHidden: any;
  @Input() showUserXpBaselines: any;
}

describe('BaselinesChartPreviewComponent', () => {
  let context: TestCtx<BaselinesChartPreviewComponent>;
  let actions: Observable<any>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
      ],
      declarations: [
        BaselinesChartPreviewComponent,
        PitChartViewStubComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: { baselinesForm: baselinesFormState } }),
        provideMockActions(() => actions),
      ],
    })
  });

  beforeEach(async( async () => {
    context = await createStableTestContext(BaselinesChartPreviewComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
