import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import isEqual from 'lodash/isEqual';
import { distinctUntilChanged, map } from 'rxjs/operators';
import { BaselineDaysEnum } from 'shared/models/baselines.model';
import { RangeTime } from 'shared/models/chart.model';
import { AppState } from 'shared/models/state.model';
import { AdminBaselineLeaf } from '../../store/baselines/baselines.form.model';
import { baselineMultiplierSelector, selectedBaselineSelector, selectedLeafIdSelector, selectedMetricSelector, selectedMetricUnitSelector } from '../../store/baselines/baselines.form.selectors';

@Component({
  selector: 'pit-baselines-chart-preview',
  templateUrl: './baselines-chart-preview.component.html',
  styleUrls: ['./baselines-chart-preview.component.scss']
})
export class BaselinesChartPreviewComponent implements OnInit {

  leaf$ = this.store$.select( selectedLeafIdSelector ).pipe( distinctUntilChanged( isEqual ) );
  unit$ = this.store$.select( selectedMetricUnitSelector ).pipe( distinctUntilChanged( isEqual ) );
  metric$ = this.store$.select( selectedMetricSelector ).pipe( distinctUntilChanged( isEqual ) );
  baselines$ = this.store$.select( selectedBaselineSelector ).pipe( map( formControl => formControl.value ), distinctUntilChanged<AdminBaselineLeaf>( isEqual ) );

  selectedDay$ = this.store$.select( baselineMultiplierSelector ).pipe(
    map( calendar => calendar.userDefinedProperties.selectedKey as BaselineDaysEnum )
  );

  range = RangeTime.TwentyFourHours;

  fromDate$ = this.selectedDay$.pipe(
    map( day => {
      switch( day ) {
        case BaselineDaysEnum.MON: return Math.floor((new Date(2000, 0, 3, 0, 0, 0)).getTime() / 1000);
        case BaselineDaysEnum.TUE: return Math.floor((new Date(2000, 0, 4, 0, 0, 0)).getTime() / 1000);
        case BaselineDaysEnum.WED: return Math.floor((new Date(2000, 0, 5, 0, 0, 0)).getTime() / 1000);
        case BaselineDaysEnum.THU: return Math.floor((new Date(2000, 0, 6, 0, 0, 0)).getTime() / 1000);
        case BaselineDaysEnum.FRI: return Math.floor((new Date(2000, 0, 7, 0, 0, 0)).getTime() / 1000);
        case BaselineDaysEnum.SAT: return Math.floor((new Date(2000, 0, 8, 0, 0, 0)).getTime() / 1000);
        case BaselineDaysEnum.SUN: return Math.floor((new Date(2000, 0, 9, 0, 0, 0)).getTime() / 1000);
      }
    } )
  )

  constructor(
    private store$: Store<AppState>,
  ) { }

  ngOnInit() {
  }

}
