import { NgModule } from '@angular/core';
import { SharedAdminModule } from 'shared/shared-admin.module';
import { BaselinesChartPreviewComponent } from './baselines-chart-preview.component';

@NgModule({
  declarations: [
    BaselinesChartPreviewComponent,
  ],
  exports: [
    BaselinesChartPreviewComponent,
  ],
  imports: [
    SharedAdminModule,
  ]
})
export class BaselinesChartPreviewModule { }
