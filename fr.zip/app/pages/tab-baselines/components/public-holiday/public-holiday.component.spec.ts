import { Component, Input } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { MatDialogRef } from '@angular/material/dialog';
import { MatTooltipModule } from '@angular/material/tooltip';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { Observable } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { holidaysFormState } from '../../store/holidays/holidays.form.reducer';
import { PublicHolidayComponent } from './public-holiday.component';

@Component({
  selector: 'pit-date-picker',
  template: '',
})
class PitDatePickerStubComponent {
  @Input() selectedDate: any;
  @Input() displayType: any;
  @Input() matIcon: any;
  @Input() toggleClasses: any;
  @Input() disabled: any;
  @Input() pitIcon: any;
}

describe('PublicHolidayComponent', () => {
  let context: TestCtx<PublicHolidayComponent>;
  let actions: Observable<any>;
  let matDialogRefStub: jasmine.SpyObj<MatDialogRef<any>>;
  let messageHandlerStub: jasmine.SpyObj<MessageHandler>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        MatTooltipModule,
      ],
      declarations: [
        PublicHolidayComponent,
        PitDatePickerStubComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: { holidaysForm: holidaysFormState } }),
        provideMockActions(() => actions),
        { provide: MatDialogRef, useFactory: () => jasmine.createSpyObj('MatDialogRef', ['close'] as Array<keyof MatDialogRef<any>>) },
        { provide: MessageHandler, useFactory: () => jasmine.createSpyObj('MessageHandler', ['ngOnDestroy', 'show'] as Array<keyof MessageHandler>) },
      ],
    })
  });

  beforeEach(async( async () => {
    matDialogRefStub = TestBed.get(MatDialogRef);
    messageHandlerStub = TestBed.get(MessageHandler);
    context = await createStableTestContext(PublicHolidayComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
