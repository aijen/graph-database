import { Component, OnInit } from '@angular/core';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { MatDialogRef } from '@angular/material/dialog';
import { Actions, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { canResetForm, canSaveForm, isFormDisabled } from 'core/utils/forms.helpers';
import { sortNumberStrategy } from 'core/utils/sortStrategies';
import isEqual from 'lodash/isEqual';
import moment from 'moment';
import { MarkAsDirtyAction, SetValueAction } from 'ngrx-forms';
import { of } from 'rxjs';
import { filter, map, switchMapTo, take, tap } from 'rxjs/operators';
import { DatepickerDisplayType } from 'shared/models/datepicker.models';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { HolidaysFormActionTypes, HolidaysFormActionUnion, ResetHolidaysForm, SaveHolidaysForm } from '../../store/holidays/holidays.form.actions';
import { DateStruct } from '../../store/holidays/holidays.form.model';
import { getHolidaysForm, holidaysSelector } from '../../store/holidays/holidays.form.selectors';

@Component({
  selector: 'pit-public-holiday',
  templateUrl: './public-holiday.component.html',
  styleUrls: ['./public-holiday.component.scss']
})
export class PublicHolidayComponent implements OnInit {

  form$ = this.store$.select(
    getHolidaysForm,
  );

  canSave$ = this.form$.pipe(
    canSaveForm
  );

  canReset$ = this.form$.pipe(
    canResetForm
  );

  isDisabled$ = this.form$.pipe(
    isFormDisabled
  );

  holidays$ = this.store$.select( holidaysSelector );

  holidaysWithLabel$ = this.holidays$.pipe(
    map( holidays =>
      holidays.controls
        .map( control => ({ control, label: moment( control.value ).format( 'DD MMMM YYYY' ) }) )
        .sort( ( {control: { value: valueA }}, {control: { value: valueB }} ) => sortNumberStrategy(valueA.year, valueB.year) || sortNumberStrategy(valueA.month, valueB.month) || sortNumberStrategy(valueA.day, valueB.day) )
    )
  );

  currentDate = moment();
  datepickerDisplayType = DatepickerDisplayType;

  constructor(
    private dialogRef: MatDialogRef<PublicHolidayComponent>,
    private store$: Store<AppState>,
    private snackbar: MessageHandler,
    private actions$: Actions,
  ) {
    // this.store$.dispatch( new LoadHolidaysForm() );
  }

  ngOnInit() {
  }

  async addDate(event: MatDatepickerInputEvent<moment.Moment>) {
    const date = { year: event.value.year(), month: event.value.month(), day: event.value.date() };
    if(!date) return;

    const holidays = await this.holidays$.pipe( take(1) ).toPromise();

    if( holidays.value.find( holiday => isEqual(holiday, date) ) ) {
      this.snackbar.show( { message: 'Cette date est déjà enregistrée', action: 'OK', isError: true } )
      return;
    }

    this.store$.dispatch( new SetValueAction( holidays.id, [...holidays.value, date] ) );
    this.store$.dispatch( new MarkAsDirtyAction( holidays.id ) );

  }

  async editDate(event: MatDatepickerInputEvent<moment.Moment>, id: string, startDate: DateStruct ) {
    const date = { year: event.value.year(), month: event.value.month(), day: event.value.date() };
    if(!date) return;
    if( isEqual( startDate, date ) ) return;

    const holidays = await this.holidays$.pipe( take(1) ).toPromise();

    if( holidays.value.find( holiday => isEqual(holiday, date) ) ) {
      this.snackbar.show( { message: 'Cette date est déjà enregistrée', action: 'OK', isError: true } )
      return;
    }

    this.store$.dispatch( new MarkAsDirtyAction( id ) );
    this.store$.dispatch( new SetValueAction( id, date ) );

  }

  async deleteDate( id: string ) {
    const holidays = await this.holidays$.pipe( take(1) ).toPromise();

    const newValues = holidays.controls.filter( day => day.id !== id ).map( day => day.value );

    this.store$.dispatch( new MarkAsDirtyAction( holidays.id ) );
    this.store$.dispatch( new SetValueAction( holidays.id, newValues ) );
  }

  async save() {
    await of( new SaveHolidaysForm() ).pipe(
      tap( ( save ) => this.store$.dispatch( save ) ),
      switchMapTo( this.actions$ ),
      ofType<HolidaysFormActionUnion>( HolidaysFormActionTypes.SaveHolidaysFormSuccess, HolidaysFormActionTypes.SaveHolidaysFormError ),
      take(1),
      filter( ( action ) => action.type === HolidaysFormActionTypes.SaveHolidaysFormSuccess ),
      tap( () => this.quit() ),
    ).toPromise();
  }

  reset() {
    this.store$.dispatch( new ResetHolidaysForm() );
  }

  quit() {
    this.dialogRef.close();
  }

  dateStructToMoment(date: DateStruct) {
    return moment().year(date.year).month(date.month).date(date.day);
  }
}
