import { NgModule } from '@angular/core';
import { MatTooltipModule } from '@angular/material/tooltip';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { SharedModule } from 'shared/shared.module';
import { HolidaysFormEffects } from '../../store/holidays/holidays.form.effects';
import { holidaysFormReducer } from '../../store/holidays/holidays.form.reducer';
import { PublicHolidayComponent } from './public-holiday.component';

@NgModule({
  declarations: [
    PublicHolidayComponent,
  ],
  imports: [
    SharedModule,
    MatTooltipModule,
    StoreModule.forFeature('holidaysForm', holidaysFormReducer),
    EffectsModule.forFeature([HolidaysFormEffects]),
  ],
  exports: [
    PublicHolidayComponent,
  ],
  entryComponents: [
    PublicHolidayComponent,
  ]
})
export class PublicHolidayModule { }
