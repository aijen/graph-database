import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { ExcelService } from 'core/services/excel/excel.service';
import { sortStringCaseInsensitiveStrategy } from 'core/utils/sortStrategies';
import uniq from 'lodash/uniq';
import { map, take } from 'rxjs/operators';
import { BaselineDays, BaselineHours, BaselineValues } from 'shared/models/baselines.model';
import { AppState } from 'shared/models/state.model';
import { BaselineType } from '../../store/baselines/baselines.form.model';
import { baselinesSelector } from '../../store/baselines/baselines.form.selectors';
import { emptyBaseline } from '../../store/baselines/baselines.form.utils';

@Component({
  selector: 'pit-export-baselines',
  templateUrl: './export-baselines.component.html',
  styleUrls: ['./export-baselines.component.scss']
})
export class ExportBaselinesComponent implements OnInit {

  baselines$ = this.store$.select( baselinesSelector );
  sources = this.baselines$.pipe( map( baselines => uniq(baselines.map( baseline => baseline.source )).sort( sortStringCaseInsensitiveStrategy ) ) );

  constructor(
    private store$: Store<AppState>,
    private excelService: ExcelService,
  ) { }

  ngOnInit() {
  }

  async export( source: string ) {

    let baselines = await this.baselines$.pipe( take(1) ).toPromise();

    baselines = baselines.filter( baseline => baseline.source === source ).map( baseline => ({ ...emptyBaseline(), ...baseline }) );

    const baselinesData = baselines.map( baseline => {
      const { leaf, metaType, metricType, metricUnit, metricName, metricDescription, weight, generationType, resolution, values } = baseline;
      const data = [];

      for( const type of [BaselineType.BUSINESS_DAY, BaselineType.PUBLIC_HOLIDAY] ) {
        for( const range of ['value', 'upperTreshold', 'lowerTreshold'] as Array<keyof BaselineValues> ) {
          const hours = BaselineHours.map( (hour) => values[type][hour][range] );
          data.push( [ leaf, metaType, metricType, metricUnit, metricName, metricDescription, weight, generationType, resolution, type, range, ...hours ] );
        }
      }

      return data;

    } ).reduce( (acc, item) => [...acc, ...item], [] );

    const multiplierData = baselines.map( baseline => {
      const { leaf, metricType, multiplier } = baseline;
      const data = [];

      for( const range of ['value', 'upperTreshold', 'lowerTreshold'] as Array<keyof BaselineValues> ) {
        const days = BaselineDays.map( (day) => multiplier[day][range] );
        data.push( [ leaf, metricType, range, ...days ] );
      }

      return data;

    } ).reduce( (acc, item) => [...acc, ...item], [] );

    this.excelService.saveAsExcel(`baselines_export_${source}`, [
      {
        name: 'Baselines',
        data: [
          ['Leaf', 'MetaType', 'Metric', 'Unit', 'Label', 'Description', 'Poids', 'Mode', 'Timebox', 'Type de baseline', 'Baseline', ...BaselineHours],
          ...baselinesData
        ],
      },
      {
        name: 'Gains',
        data: [
          ['Leaf', 'Metric', 'Baseline', ...BaselineDays],
          ...multiplierData,
        ]
      }
    ]);

  }

}
