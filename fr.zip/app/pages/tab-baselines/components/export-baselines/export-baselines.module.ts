import { NgModule } from '@angular/core';
import { MatSelectModule } from '@angular/material/select';
import { SharedAdminModule } from 'shared/shared-admin.module';
import { ExportBaselinesComponent } from './export-baselines.component';

@NgModule({
  declarations: [ExportBaselinesComponent],
  imports: [
    SharedAdminModule,
    MatSelectModule,
  ],
})
export class ExportBaselinesModule { }
