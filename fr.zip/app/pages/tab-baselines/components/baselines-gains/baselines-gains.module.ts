import { NgModule } from '@angular/core';
import { NgrxFormsModule } from 'ngrx-forms';
import { SharedAdminModule } from 'shared/shared-admin.module';
import { BaselinesGainsComponent } from './baselines-gains.component';

@NgModule({
  declarations: [
    BaselinesGainsComponent,
  ],
  exports: [
    BaselinesGainsComponent,
  ],
  imports: [
    SharedAdminModule,
    NgrxFormsModule,
  ]
})
export class BaselinesGainsModule { }
