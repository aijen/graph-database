import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { FormGroupState } from 'ngrx-forms';
import { map, shareReplay } from 'rxjs/operators';
import { BaselineDays, BaselineDaysEnum, BaselineValues } from 'shared/models/baselines.model';
import { AppState } from 'shared/models/state.model';
import { SetSelectedDay } from '../../store/baselines/baselines.form.actions';
import { baselineMultiplierSelector, selectedMetricUnitSelector } from '../../store/baselines/baselines.form.selectors';

const daysMap = {
  [BaselineDaysEnum.MON]: 'Lundi',
  [BaselineDaysEnum.TUE]: 'Mardi',
  [BaselineDaysEnum.WED]: 'Mercredi',
  [BaselineDaysEnum.THU]: 'Jeudi',
  [BaselineDaysEnum.FRI]: 'Vendredi',
  [BaselineDaysEnum.SAT]: 'Samedi',
  [BaselineDaysEnum.SUN]: 'Dimanche',
};

@Component({
  selector: 'pit-baselines-gains',
  templateUrl: './baselines-gains.component.html',
  styleUrls: ['./baselines-gains.component.scss']
})
export class BaselinesGainsComponent implements OnInit {

  calendars$ = this.store$.select( baselineMultiplierSelector ).pipe(
    map( calendar => BaselineDays.map( hour => calendar.controls[hour] ) ),
    shareReplay({ bufferSize: 1, refCount: true })
  );

  selectedDay$ = this.store$.select( baselineMultiplierSelector ).pipe(
    map( calendar => calendar.userDefinedProperties.selected )
  );

  selectedMetricUnit$ = this.store$.select( selectedMetricUnitSelector ).pipe( shareReplay({ bufferSize: 1, refCount: true }) );

  BaselineDays = BaselineDays.map( day => [day, daysMap[day]] );

  constructor(
    private store$: Store<AppState>,
  ) { }

  ngOnInit() {
  }

  setSelectedDay( controlId, controlKey ) {
    this.store$.dispatch( new SetSelectedDay( { controlId, controlKey } ) );
  }

  trackByIndex( index: number ) {
    return index;
  }

  trackById( index: number, s: FormGroupState<BaselineValues> ) {
    return s.id;
  }

}
