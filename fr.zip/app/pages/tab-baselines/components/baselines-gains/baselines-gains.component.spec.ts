import { async, TestBed } from '@angular/core/testing';
import { MatTooltipModule } from '@angular/material/tooltip';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { NgrxFormsModule } from 'ngrx-forms';
import { Observable } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { baselinesFormState } from '../../store/baselines/baselines.form.reducer';
import { BaselinesGainsComponent } from './baselines-gains.component';

describe('BaselinesGainsComponent', () => {
  let context: TestCtx<BaselinesGainsComponent>;
  let actions: Observable<any>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        NgrxFormsModule,
        MatTooltipModule,
      ],
      declarations: [
        BaselinesGainsComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: { baselinesForm: baselinesFormState } }),
        provideMockActions(() => actions),
      ],
    })
  });

  beforeEach(async( async () => {
    context = await createStableTestContext(BaselinesGainsComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
