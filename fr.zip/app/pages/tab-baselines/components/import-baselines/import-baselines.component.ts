import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Store } from '@ngrx/store';
import { canSaveForm } from 'core/utils/forms.helpers';
import { MarkAsDirtyAction } from 'ngrx-forms';
import { map, take, tap } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';
import { LoadBaselinesImportExportForm, SaveBaselinesImportExportForm } from '../../store/baselines-import-export/baselines-import-export.form.actions';
import { baselinesImportExportSourcesSelector, getBaselinesImportExportForm } from '../../store/baselines-import-export/baselines-import-export.form.selectors';

@Component({
  selector: 'pit-import-baselines',
  templateUrl: './import-baselines.component.html',
  styleUrls: ['./import-baselines.component.scss']
})
export class ImportBaselinesComponent implements OnInit {

  form$ = this.store$.select( getBaselinesImportExportForm )
    .pipe(
      tap( form => form.isPristine && this.clearFile() ),
    );

  canSave$ = this.form$.pipe(
    canSaveForm
  );

  sources = this.store$.select( baselinesImportExportSourcesSelector );

  sourceForm = this.form$.pipe(
    map( form => form.controls.source ),
  );

  file: File;
  fileName = '';
  fileSize = '';


  @ViewChild('f')
  private fileInput: ElementRef<HTMLInputElement>;

  constructor(
    private store$: Store<AppState>,
  ) {
    this.store$.dispatch( new LoadBaselinesImportExportForm() );
  }

  ngOnInit() {
  }

  async fileChange( file: File ) {
    const { name = '', size = 0 } = file || {};

    const form = await this.form$.pipe( take(1) ).toPromise();

    this.fileName = name;
    this.fileSize = this.getfilesize(size);
    this.file = file;

    this.store$.dispatch( new MarkAsDirtyAction( form.id ) );
  }

  import() {
    const file = this.file;
    this.store$.dispatch( new SaveBaselinesImportExportForm( { file } ) );
  }

  getfilesize( size: number ) {
    const units = ['o', 'Ko', 'Mo', 'Go', 'To'];
    let unit = units.shift();

    while( units.length && size > 2**10 ) {
      size = size / 2**10;
      unit = units.shift();
    }

    return `${+size.toFixed(2)} ${unit}`;
  }

  private clearFile() {
    this.fileName = this.fileSize = this.fileInput.nativeElement.value = '';
    delete this.file;
  }
}
