import { NgModule } from '@angular/core';
import { MatSelectModule } from '@angular/material/select';
import { NgrxFormsModule } from 'ngrx-forms';
import { SharedAdminModule } from 'shared/shared-admin.module';
import { BaselinesImportExportModule } from '../../store/baselines-import-export/baselines-import-export.form.module';
import { ImportBaselinesComponent } from './import-baselines.component';

@NgModule({
  declarations: [ImportBaselinesComponent],
  imports: [
    SharedAdminModule,
    MatSelectModule,
    NgrxFormsModule,
    BaselinesImportExportModule,
  ],
})
export class ImportBaselinesModule { }
