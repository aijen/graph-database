import { Component } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { MatSelectModule } from '@angular/material/select';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { NgrxFormsModule } from 'ngrx-forms';
import { Observable } from 'rxjs';
import { NgrxMatSelectViewAdapterDirective } from 'shared/directives/mat-select-view-adapter/mat-select-view-adapter.directive';
import { AppState } from 'shared/models/state.model';
import { baselinesImportExportFormState } from '../../store/baselines-import-export/baselines-import-export.form.reducer';
import { ImportBaselinesComponent } from './import-baselines.component';

@Component({
  selector: 'pit-close-modal',
  template: '',
})
class PitCloseModalStubComponent {
  // @Input() class: any;
}

describe('ImportBaselinesComponent', () => {
  let context: TestCtx<ImportBaselinesComponent>;
  let actions: Observable<any>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        MatSelectModule,
        NgrxFormsModule,
      ],
      declarations: [
        ImportBaselinesComponent,
        NgrxMatSelectViewAdapterDirective,
        PitCloseModalStubComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: { baselinesImportExportForm: baselinesImportExportFormState } }),
        provideMockActions(() => actions),
      ],
    })
  });

  beforeEach(async( async () => {
    context = await createStableTestContext(ImportBaselinesComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
