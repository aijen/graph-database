import { async, TestBed } from '@angular/core/testing';
import { MatTooltipModule } from '@angular/material/tooltip';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { NgrxFormsModule } from 'ngrx-forms';
import { Observable } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { baselinesFormState } from '../../store/baselines/baselines.form.reducer';
import { BaselinesValuesComponent } from './baselines-values.component';

describe('BaselinesValuesComponent', () => {
  let context: TestCtx<BaselinesValuesComponent>;
  let actions: Observable<any>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        NoopAnimationsModule,
        NgrxFormsModule,
        MatTooltipModule,
      ],
      declarations: [
        BaselinesValuesComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: { baselinesForm: baselinesFormState } }),
        provideMockActions(() => actions),
      ],
    })
  });

  beforeEach(async( async () => {
    context = await createStableTestContext(BaselinesValuesComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
