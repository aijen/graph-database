import { animate, state, style, transition, trigger } from '@angular/animations';
import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { FormGroupState } from 'ngrx-forms';
import { map, shareReplay } from 'rxjs/operators';
import { BaselineHours, BaselineValues } from 'shared/models/baselines.model';
import { AppState } from 'shared/models/state.model';
import { baselineValuesSelector, selectedMetricUnitSelector } from '../../store/baselines/baselines.form.selectors';

@Component({
  selector: 'pit-baselines-values',
  templateUrl: './baselines-values.component.html',
  styleUrls: ['./baselines-values.component.scss'],
  animations: [
    trigger('focus', [
      state('0', style({ position: '*', zIndex: 1 })),
      state('1', style({ position: 'absolute', width: '200%', transform: 'translate3d(-25%,0px,0px)', zIndex: 2 })),
      transition('0 => 1', [
        style({ position: 'absolute' }),
        animate('200ms ease-in-out', style({ width: '200%', transform: 'translate3d(-25%,0px,0px)' })),
      ]),
      transition('1 => 0', [
        animate('200ms ease-in-out', style({ width: '100%', transform: 'translate3d(0%,0px,0px)' })),
        style({ position: '*' }),
      ])
    ])
  ]
})
export class BaselinesValuesComponent implements OnInit {

  calendars$ = this.store$.select( baselineValuesSelector ).pipe(
    map( calendar => BaselineHours.map( hour => calendar.controls[hour] ) ),
    map( calendar => Array(2).fill(null).map( (_, index) => calendar.slice( index / 2 * calendar.length, (index +1) / 2 * calendar.length ) ) ),
    shareReplay({ bufferSize: 1, refCount: true })
  );

  selectedMetricUnit$ = this.store$.select( selectedMetricUnitSelector ).pipe( shareReplay({ bufferSize: 1, refCount: true }) );

  BaselineHours = BaselineHours;

  constructor(
    private store$: Store<AppState>,
  ) { }

  ngOnInit() {
  }

  trackByIndex( index: number ) {
    return index;
  }

  trackById( index: number, s: FormGroupState<BaselineValues> ) {
    return s.id;
  }

}
