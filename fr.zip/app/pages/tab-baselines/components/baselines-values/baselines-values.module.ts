import { NgModule } from '@angular/core';
import { NgrxFormsModule } from 'ngrx-forms';
import { SharedAdminModule } from 'shared/shared-admin.module';
import { BaselinesValuesComponent } from './baselines-values.component';

@NgModule({
  declarations: [
    BaselinesValuesComponent,
  ],
  exports: [
    BaselinesValuesComponent,
  ],
  imports: [
    SharedAdminModule,
    NgrxFormsModule,
  ]
})
export class BaselinesValuesModule { }
