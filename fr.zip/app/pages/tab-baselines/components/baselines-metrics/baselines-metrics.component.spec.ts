import { Component, Input } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { MatDialogModule } from '@angular/material/dialog';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatTooltipModule } from '@angular/material/tooltip';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { SearchResult, SearchService } from 'core/components/search/search.service';
import { HierarchyState } from 'core/store/hierarchy/hierarchy.model';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { NgrxFormsModule } from 'ngrx-forms';
import { Observable, Subject } from 'rxjs';
import { NgrxMatSelectViewAdapterDirective } from 'shared/directives/mat-select-view-adapter/mat-select-view-adapter.directive';
import { AppState } from 'shared/models/state.model';
import { CanDeactivateWithFormGuard } from 'shared/services/canDeactivateWithFormGuard';
import { baselinesFormState } from '../../store/baselines/baselines.form.reducer';
import { holidaysFormState } from '../../store/holidays/holidays.form.reducer';
import { BaselinesMetricsComponent } from './baselines-metrics.component';

@Component({
  selector: 'pit-slide-toggle',
  template: '',
})
class PitSlideToggleStubComponent {
  @Input() formControlState: any;
  @Input() valueConverter: any;
  @Input() labels: any;

}

describe('BaselinesMetricsComponent', () => {
  let context: TestCtx<BaselinesMetricsComponent>;
  let actions: Observable<any>;
  let canDeactivateWithFormGuardStub: jasmine.SpyObj<CanDeactivateWithFormGuard>;
  let searchServiceStub: jasmine.SpyObj<SearchService<any>>;
  let selected$: Subject<SearchResult<any>>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        MatTooltipModule,
        MatDialogModule,
        MatSelectModule,
        NgrxFormsModule,
        MatProgressSpinnerModule,
      ],
      declarations: [
        BaselinesMetricsComponent,
        PitSlideToggleStubComponent,
        NgrxMatSelectViewAdapterDirective,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: { baselinesForm: baselinesFormState, holidaysForm: holidaysFormState, hierarchy: new HierarchyState() } }),
        provideMockActions(() => actions),
        { provide: CanDeactivateWithFormGuard, useFactory: () => jasmine.createSpyObj('CanDeactivateWithFormGuard', ['canDeactivate'] as Array<keyof CanDeactivateWithFormGuard>) },
        { provide: SearchService, useFactory: () => jasmine.createSpyObj('SearchService', ['register', 'unregister', 'search', 'select', 'getSelectedFor'] as Array<keyof SearchService<any>>) },
      ],
    })
  });

  beforeEach(async( async () => {
    canDeactivateWithFormGuardStub = TestBed.get(CanDeactivateWithFormGuard);
    searchServiceStub = TestBed.get(SearchService);
    selected$ = new Subject<SearchResult<any>>();
    searchServiceStub.getSelectedFor.and.returnValue(selected$);
    context = await createStableTestContext(BaselinesMetricsComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
