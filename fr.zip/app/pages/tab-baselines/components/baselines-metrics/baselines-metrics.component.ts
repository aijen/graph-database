import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Actions, ofType } from '@ngrx/effects';
import { select, Store } from '@ngrx/store';
import { SearchResult, SearchService, SearchToken } from 'core/components/search/search.service';
import { getCockpitLeaves } from 'core/store/hierarchy/hierarchy.selectors';
import { canSaveForm } from 'core/utils/forms.helpers';
import { SubscriptionAwareComponent } from 'core/utils/subscription-aware.component';
import { NgrxValueConverter } from 'ngrx-forms';
import { combineLatest, merge, Observable, of, pipe, Subject, timer } from 'rxjs';
import { map, mapTo, shareReplay, startWith, switchMap, switchMapTo, take, tap, withLatestFrom } from 'rxjs/operators';
import { BaselineGenerationType } from 'shared/models/baselines.model';
import { CockpitLeaf, isFileType } from 'shared/models/cockpit-leaf.model';
import { AppState } from 'shared/models/state.model';
import { CanComponentWithFormDeactivate } from 'shared/services/CanComponentWithFormDeactivate.interface';
import { CanDeactivateWithFormGuard } from 'shared/services/canDeactivateWithFormGuard';
import { BaselinesFormActionTypes, SaveBaselinesForm, SetLeaf } from '../../store/baselines/baselines.form.actions';
import { BaselinesMetricsLeaf, BaselineType } from '../../store/baselines/baselines.form.model';
import { getBaselinesForm, isModified, leafIdsSelector, metricsSelector, selectedCalendarSelector, selectedGenerationTypeSelector, selectedLeafIdSelector, selectedMetricSelector, selectedSourceSelector, sourcesSelector } from '../../store/baselines/baselines.form.selectors';
import { HolidaysFormActionTypes, HolidaysFormActionUnion, LoadHolidaysForm } from '../../store/holidays/holidays.form.actions';
import { isHolidaysFormLoading } from '../../store/holidays/holidays.form.selectors';
import { PublicHolidayComponent } from '../public-holiday/public-holiday.component';

@Component({
  selector: 'pit-baselines-metrics',
  templateUrl: './baselines-metrics.component.html',
  styleUrls: ['./baselines-metrics.component.scss']
})
export class BaselinesMetricsComponent extends SubscriptionAwareComponent implements OnInit, OnDestroy, CanComponentWithFormDeactivate {

  readonly searchToken = new SearchToken('BaselinesMetrics');

  private revert$ = new Subject<void>();

  form$ = this.store$.select( getBaselinesForm );

  leaves$: Observable<BaselinesMetricsLeaf[]> = this.store$.select( leafIdsSelector );
  sources$ = this.store$.select( sourcesSelector );
  metrics$ = this.store$.select( metricsSelector );

  selectedLeafId$ = combineLatest(
    this.store$.select( selectedLeafIdSelector ),
    this.revert$.pipe( startWith(null) )
  ).pipe(
    switchMap( ( [value] ) => timer(0).pipe( mapTo( value ), startWith( null ) ) ),
  );

  selectedSource$ = combineLatest(
    this.store$.select( selectedSourceSelector ),
    this.revert$.pipe( startWith(null) )
  ).pipe(
    switchMap( ( [value] ) => timer(0).pipe( mapTo( value ), startWith( null ) ) ),
  );

  selectedMetric$ = combineLatest(
    this.store$.select( selectedMetricSelector ),
    this.revert$.pipe( startWith(null) )
  ).pipe(
    switchMap( ( [value] ) => timer(0).pipe( mapTo( value ), startWith( null ) ) ),
    shareReplay({ bufferSize: 1, refCount: true }),
  );

  selectedCalendar$ = this.store$.select( selectedCalendarSelector );
  selectedGenerationType$ = this.store$.select( selectedGenerationTypeSelector );

  isDisabled$ = this.form$.pipe( map( form => form.isDisabled ) );

  holidaysLoading$ = this.store$.select( isHolidaysFormLoading ).pipe( shareReplay({ bufferSize: 1, refCount: true }) );

  BaselineType = BaselineType;

  generationTypeValueConverter: NgrxValueConverter<boolean, BaselineGenerationType> = {
    convertStateToViewValue: (value) => {
      switch(value) {
        case BaselineGenerationType.AUTO: return false;
        case BaselineGenerationType.MANUAL: return true;
        default: return null;
      }
    },
    convertViewToStateValue: (value) => value ? BaselineGenerationType.MANUAL : BaselineGenerationType.AUTO,
  };

  constructor(
    private store$: Store<AppState>,
    private actions$: Actions,
    private canDeactivateWithFormGuard: CanDeactivateWithFormGuard,
    private dialog: MatDialog,
    private searchService: SearchService<BaselinesMetricsLeaf>,
  ) {
    super();
  }

  ngOnInit() {
    this.searchService.register( this.searchToken, pipe( switchMap( search => this.searchFilter( search ) ) ) );
    this.subscription.add(
      this.searchService.getSelectedFor( this.searchToken ).pipe( tap( result => this.change( { leafId: result.data.key } ) ) ).subscribe()
    );
  }

  ngOnDestroy() {
    super.ngOnDestroy();
    this.searchService.unregister( this.searchToken );
  }

  searchFilter( search: string ) {
    const editorialFilter = (l: CockpitLeaf) => l.editorialData.find(e => !isFileType(e.type) && e.text.toLocaleLowerCase().includes(search.toLocaleLowerCase())) !== undefined;
    const fullnameFilter = (name: string, key: string) => name.toLocaleLowerCase().includes(search.toLocaleLowerCase()) || key.toLocaleLowerCase().includes(search.toLocaleLowerCase());
    const fullFilter: (l: BaselinesMetricsLeaf, pitLeaves: CockpitLeaf[]) => boolean = ({ name, key }, pitLeaves) =>{
      const pitLeaf = pitLeaves.find(l => l.key === key);

      return fullnameFilter(name, key) || (pitLeaf && editorialFilter(pitLeaf));
    };
    const toSearchResult: (l: BaselinesMetricsLeaf) => SearchResult<BaselinesMetricsLeaf> = (value) => ({
      label: `${value.name || value.key}`,
      token: this.searchToken,
      data: value,
    });

    return this.leaves$.pipe(
      withLatestFrom(this.store$.select(getCockpitLeaves)),
      map( ([leaves, pitLeaves]) => leaves.filter( l => fullFilter(l, pitLeaves) ).map( toSearchResult ) )
    );
  }

  isModified() {
    return this.store$.pipe( select( isModified ) );
  }

  getSaveAction() {
    const saveResult = merge(
      this.actions$.pipe( ofType( BaselinesFormActionTypes.SaveBaselinesFormSuccess ), mapTo(true) ),
      this.actions$.pipe( ofType( BaselinesFormActionTypes.SaveBaselinesFormError ), mapTo(false) ),
    );

    return of(null).pipe(
      tap( () => this.save() ),
      switchMapTo( saveResult ),
    );
  }

  canSave() {
    return this.form$.pipe( canSaveForm );
  }

  save() {
    this.store$.dispatch( new SaveBaselinesForm() );
  }

  async change( value: { leafId?: string, metric?: string, source?: string, calendarType?: BaselineType } ) {

    this.revert$.next(null);

    const canDeactivate = await this.canDeactivateWithFormGuard.canDeactivate( this ).toPromise();

    if(canDeactivate) {
      this.store$.dispatch( new SetLeaf( value ) );
    }

  }

  showCalendar() {
    this.store$.dispatch( new LoadHolidaysForm() );
    this.subscription.add(
      this.actions$.pipe(
        ofType<HolidaysFormActionUnion>( HolidaysFormActionTypes.LoadHolidaysFormSuccess, HolidaysFormActionTypes.LoadHolidaysFormError ),
        take(1),
        tap( () => this.dialog.open(PublicHolidayComponent, { disableClose: true, maxHeight: '80vh', panelClass: 'has-inner-overflow' }) ),
      ).subscribe()
    );
  }

}
