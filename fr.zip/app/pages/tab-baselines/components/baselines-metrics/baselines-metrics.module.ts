import { NgModule } from '@angular/core';
import { MatDialogModule } from '@angular/material/dialog';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { NgrxFormsModule } from 'ngrx-forms';
import { SharedAdminModule } from 'shared/shared-admin.module';
import { FormDeactivateDialogModule } from 'shared/components/form-deactivate-dialog/form-deactivate-dialog.module';
import { PublicHolidayModule } from '../public-holiday/public-holiday.module';
import { SlideToggleModule } from 'shared/components/slide-toggle/slide-toggle.module';
import { BaselinesMetricsComponent } from './baselines-metrics.component';

@NgModule({
  declarations: [
    BaselinesMetricsComponent,
  ],
  exports: [
    BaselinesMetricsComponent,
  ],
  imports: [
    SharedAdminModule,
    PublicHolidayModule,
    SlideToggleModule,
    MatSelectModule,
    NgrxFormsModule,
    FormDeactivateDialogModule,
    MatDialogModule,
    MatProgressSpinnerModule,
  ],
})
export class BaselinesMetricsModule { }
