import { NgModule } from '@angular/core';
import { MatDialogModule } from '@angular/material/dialog';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { SharedAdminModule } from 'shared/shared-admin.module';
import { ArborescenceBranchCreateModule } from './components/arborescence-branch-create/arborescence-branch-create.module';
import { ArborescenceListModule } from './components/arborescence-list/arborescence-list.module';
import { ImportArborescenceComponent } from './components/import-arborescence/import-arborescence.component';
import { ArborescenceModule } from './store/arborescence/arborescence.form.module';
import { TabArborescenceComponent } from './tab-arborescence.component';
@NgModule({
  declarations: [
    TabArborescenceComponent,
    ImportArborescenceComponent,
  ],
  imports: [
    SharedAdminModule,
    MatProgressSpinnerModule,
    ArborescenceModule,
    ArborescenceBranchCreateModule,
    ArborescenceListModule,
    MatDialogModule,
  ],
  entryComponents: [
    ImportArborescenceComponent,
  ],
})
export class TabArborescenceModule { }
