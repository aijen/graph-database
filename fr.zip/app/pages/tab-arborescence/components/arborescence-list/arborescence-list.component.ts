import { Component, Input, OnDestroy, OnInit, QueryList, ViewChildren } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { Store } from '@ngrx/store';
import { highlight } from 'core/animations/animations';
import { SearchResult, SearchService, SearchToken } from 'core/components/search/search.service';
import { getCockpitLeaves } from 'core/store/hierarchy/hierarchy.selectors';
import { resetTo } from 'core/utils/resetTo';
import { of, pipe } from 'rxjs';
import { filter, map, share, startWith, switchMap, tap, withLatestFrom } from 'rxjs/operators';
import { ElementMarkerDirective } from 'shared/directives/element-marker/element-marker.directive';
import { CockpitLeaf, isFileType } from 'shared/models/cockpit-leaf.model';
import { Leaf } from 'shared/models/leaf.model';
import { Node } from 'shared/models/node.model';
import { AppState } from 'shared/models/state.model';
import { ArborescenceBranchEditComponent } from '../arborescence-branch-edit/arborescence-branch-edit.component';

@Component({
  selector: 'pit-arborescence-list',
  templateUrl: './arborescence-list.component.html',
  styleUrls: ['./arborescence-list.component.scss'],
  animations: [ highlight() ],
})
export class ArborescenceListComponent implements OnInit, OnDestroy {

  readonly searchToken = new SearchToken('ArborescenceList');

  @Input()
  set nodes( nodes: Node[] ) {
    this._nodes = nodes;
    const findLeavesReducer = (acc: Leaf[], {nodes: children, leaves}: Node): Leaf[] => [...acc, ...leaves, ...children.reduce(findLeavesReducer, [])]
    this._leaves = nodes.reduce( findLeavesReducer, [] );
  }
  get nodes() { return this._nodes; }
  private _nodes: Node[];
  private _leaves: Leaf[] = [];

  @ViewChildren(ElementMarkerDirective)
  lines: QueryList<ElementMarkerDirective<Leaf>>;

  search$ = this.searchService.getSelectedFor( this.searchToken ).pipe(
    map( result => this.lines.find( _line => _line.data.technicalKey === result.data.technicalKey ) ),
    filter( line => Boolean(line) ),
    tap( ( line ) => line.scrollTo() ),
    map( ( line ) => line.data.technicalKey ),
    resetTo(''),
    startWith( null ),
    share(),
  );

  trackByNodeKey = ( index: number, { key }: Node) => key;
  trackByLeafKey = ( index: number, { key }: Leaf) => key;

  constructor(
    private dialog: MatDialog,
    private store$: Store<AppState>,
    private searchService: SearchService<Leaf>,
  ) { }

  ngOnInit() {
    this.searchService.register( this.searchToken, pipe( switchMap( search => this.searchFilter( search ) ) ) );
  }

  ngOnDestroy() {
    this.searchService.unregister( this.searchToken );
  }

  searchFilter( search: string ) {
    const editorialFilter = (l: CockpitLeaf) => l.editorialData.find(e => !isFileType(e.type) && e.text.toLocaleLowerCase().includes(search.toLocaleLowerCase())) !== undefined;
    const fullnameFilter = ( leaf: Leaf ) => leaf.fullname.toLocaleLowerCase().includes(search.toLocaleLowerCase());
    const fullFilter = ( leaf: Leaf, pitLeaves: CockpitLeaf[] ) => {
      const pitLeaf = pitLeaves.find(l => l.key === leaf.key);

      return fullnameFilter(leaf) || (pitLeaf && editorialFilter(pitLeaf));
    };
    const toPath: ( leaf: Leaf ) => string[] = (leaf) => {
      const path: string[] = [leaf.fullname];
      let parent: Node | Leaf = leaf;
      while ( parent = parent.parent ) {
        path.unshift( parent.fullname );
      }
      return path;
    }
    const toSearchResult: ( leaf: Leaf ) => SearchResult<Leaf> = (leaf) => ({
      label: `${leaf.fullname}`,
      token: this.searchToken,
      data: leaf,
      hint: toPath(leaf).join(' -> '),
    });

    return of(this._leaves).pipe(
      withLatestFrom(this.store$.select(getCockpitLeaves)),
      map(([leaves, pitLeaves]) => leaves.filter( l => fullFilter(l, pitLeaves) ).map( toSearchResult ))
    );
  }

  edit(technicalKey: string) {
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.maxHeight = '80vh';
    dialogConfig.width = '1140px';
    dialogConfig.maxWidth = '1140px';
    dialogConfig.data = {
      technicalKey: technicalKey,
      nodes: this.nodes,
    };

    this.dialog.open(ArborescenceBranchEditComponent, dialogConfig);
  }
}
