import { Component, Directive, Input } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { MatDialogModule } from '@angular/material/dialog';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { provideMockStore } from '@ngrx/store/testing';
import { SearchResult, SearchService } from 'core/components/search/search.service';
import { hierarchyState } from 'core/store/hierarchy/hierarchy.reducer';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { Subject } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { ArborescenceListComponent } from './arborescence-list.component';

@Component({
  selector: 'pit-arborescence-list-line',
  template: '',
})
class PitArborescenceListLineStubComponent {

  @Input() node1Name: any;
  @Input() node2Name: any;
  @Input() node3Name: any;
  @Input() node4Name: any;
  @Input() leaf: any;
}

@Directive({
  selector: '[pitElementMarker]',
})
class PitElementMarkerStubDirective {
  @Input() pitElementMarker: any;
}

@Directive({
  selector: '[pitElementMarkerOffset]',
})
class PitElementMarkerOffsetStubDirective {
  @Input() pitElementMarkerOffset: any;
}

describe('ArborescenceListComponent', () => {
  let context: TestCtx<ArborescenceListComponent>;
  let searchServiceStub: jasmine.SpyObj<SearchService<any>>;
  let selected$: Subject<SearchResult<any>>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        MatDialogModule,
        NoopAnimationsModule,
      ],
      declarations: [
        ArborescenceListComponent,
        PitArborescenceListLineStubComponent,
        PitElementMarkerStubDirective,
        PitElementMarkerOffsetStubDirective,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: {
          hierarchy: hierarchyState,
        } }),
        { provide: SearchService, useFactory: () => jasmine.createSpyObj('SearchService', ['register', 'unregister', 'search', 'select', 'getSelectedFor'] as Array<keyof SearchService<any>>) },
      ],
    })
  });

  beforeEach(async( async () => {
    searchServiceStub = TestBed.get(SearchService);
    selected$ = new Subject<SearchResult<any>>();
    searchServiceStub.getSelectedFor.and.returnValue(selected$);
    context = await createStableTestContext(ArborescenceListComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
