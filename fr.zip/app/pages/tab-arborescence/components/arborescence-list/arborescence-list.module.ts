import { NgModule } from '@angular/core';
import { MatDialogModule } from '@angular/material/dialog';
import { SharedAdminModule } from 'shared/shared-admin.module';
import { ArborescenceBranchEditModule } from '../arborescence-branch-edit/arborescence-branch-edit.module';
import { ArborescenceListLineModule } from '../arborescence-list-line/arborescence-list-line.module';
import { ArborescenceListComponent } from './arborescence-list.component';

@NgModule({
  declarations: [
    ArborescenceListComponent,
  ],
  exports: [
    ArborescenceListComponent,
  ],
  imports: [
    SharedAdminModule,
    ArborescenceListLineModule,
    ArborescenceBranchEditModule,
    MatDialogModule,
  ],
})
export class ArborescenceListModule {}
