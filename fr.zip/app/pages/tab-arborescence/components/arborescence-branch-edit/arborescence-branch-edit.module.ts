import { NgModule } from '@angular/core';
import { SharedAdminModule } from 'shared/shared-admin.module';
import { ArborescenceModule } from '../../store/arborescence/arborescence.form.module';
import { ArborescenceNodeLevelSelectModule } from '../arborescence-node-level-select/abrorescence-node-level-select.module';
import { ArborescenceBranchEditComponent } from './arborescence-branch-edit.component';

@NgModule({
  declarations: [
    ArborescenceBranchEditComponent,
  ],
  exports: [
    ArborescenceBranchEditComponent,
  ],
  imports: [
    SharedAdminModule,
    ArborescenceModule,
    ArborescenceNodeLevelSelectModule,
  ],
  entryComponents: [
    ArborescenceBranchEditComponent,
  ]
})
export class ArborescenceBranchEditModule { }
