import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSelectChange } from '@angular/material/select';
import { Store } from '@ngrx/store';
import { getPerimeterNodesByRankSorted } from 'app/pages/tab-perimeter/store/perimeter/perimeter.form.selectors';
import { SORT_DIRECTION } from 'core/utils/sortStrategies';
import { Node } from 'shared/models/node.model';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { UpdateBranch } from '../../store/arborescence/arborescence.form.actions';
import { ArborescenceFormEffects } from '../../store/arborescence/arborescence.form.effects';
import { Branch } from '../../store/arborescence/arborescence.form.model';
import { ArborescenceService } from '../../store/arborescence/arborescence.form.service';

@Component({
  selector: 'pit-arborescence-branch-edit',
  templateUrl: './arborescence-branch-edit.component.html',
  styleUrls: ['./arborescence-branch-edit.component.scss']
})
export class ArborescenceBranchEditComponent implements OnInit {

  level1$ = this.store$.select( getPerimeterNodesByRankSorted(), { rank: 1, sortConfig: [["key", SORT_DIRECTION.ASCENDING]] } );
  level2$ = this.store$.select( getPerimeterNodesByRankSorted(), { rank: 2, sortConfig: [["key", SORT_DIRECTION.ASCENDING]] } );
  level3$ = this.store$.select( getPerimeterNodesByRankSorted(), { rank: 3, sortConfig: [["key", SORT_DIRECTION.ASCENDING]] } );
  level4$ = this.store$.select( getPerimeterNodesByRankSorted(), { rank: 4, sortConfig: [["key", SORT_DIRECTION.ASCENDING]] } );

  branch: Branch;
  nodes: Node[];
  emptyNode = ArborescenceService.emptyNode;
  isPristine = true;

  constructor(
    private store$: Store<AppState>,
    private snackbar: MessageHandler,
    private dialogRef: MatDialogRef<ArborescenceBranchEditComponent>,
    @Inject(MAT_DIALOG_DATA) data: { technicalKey: string, nodes: Node[] }) {
      this.branch = ArborescenceService.findBranch(data.nodes, data.technicalKey);
      this.nodes = data.nodes;
  }

  ngOnInit() {
  }

  onChangeLevel1(event: MatSelectChange) {
    this.branch.nodeLevel1 = event.value;
    this.isPristine = false;
  }

  onChangeLevel2(event: MatSelectChange) {
    this.branch.nodeLevel2 = event.value;
    this.isPristine = false;
  }

  onChangeLevel3(event: MatSelectChange) {
    this.branch.nodeLevel3 = event.value;
    this.isPristine = false;
  }

  onChangeLevel4(event: MatSelectChange) {
    this.branch.nodeLevel4 = event.value;
    this.isPristine = false;
  }

  canSave() {
    if(!this.isPristine) {
      if(this.branch.nodeLevel2.key == this.emptyNode.key && (this.branch.nodeLevel3.key != this.emptyNode.key || this.branch.nodeLevel4.key != this.emptyNode.key)) {
        return false;
      }

      if(this.branch.nodeLevel3.key == this.emptyNode.key && this.branch.nodeLevel4.key != this.emptyNode.key) {
        return false;
      }

      return true;
    }

    return false;
  }

  save() {
    if(ArborescenceService.branchExists(this.nodes, this.branch)) {
      this.snackbar.show( { message: ArborescenceFormEffects.messages.addError, action: 'OK', isError: true } )
    }
    else {
      this.store$.dispatch( new UpdateBranch( { branch: this.branch} ) );
      this.quit();
    }
  }

  quit() {
    this.dialogRef.close();
  }
}
