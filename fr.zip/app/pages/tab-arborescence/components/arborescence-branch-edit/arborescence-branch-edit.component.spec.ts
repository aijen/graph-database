import { Component, Input } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatTooltipModule } from '@angular/material/tooltip';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { configureTestSuite, createTestContext, TestCtx } from 'ng-bullet';
import { Observable } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { ArborescenceBranchEditComponent } from './arborescence-branch-edit.component';

@Component({
  selector: 'pit-arborescence-node-level-select',
  template: '',
})
class PitArborescenceNodeLevelSelectStubComponent {
  @Input() nodes: any;
  @Input() hasEmptyChoice: any;
  @Input() forceEmpty: any;
  @Input() selectedNodeKey: any;
}

describe('ArborescenceBranchEditComponent', () => {
  let context: TestCtx<ArborescenceBranchEditComponent>;
  let actions: Observable<any>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        MatTooltipModule,
      ],
      declarations: [
        ArborescenceBranchEditComponent,
        PitArborescenceNodeLevelSelectStubComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: {} }),
        provideMockActions(() => actions),
        { provide: MessageHandler, useFactory: () => jasmine.createSpyObj('MessageHandler', ['ngOnDestroy', 'show'] as Array<keyof MessageHandler>) },
        { provide: MatDialogRef, useFactory: () => jasmine.createSpyObj('MatDialogRef', ['close'] as Array<keyof MatDialogRef<any>>) },
        { provide: MAT_DIALOG_DATA, useFactory: () => ({ technicalKey: '', nodes: [] }) },
      ],
    })
  });

  beforeEach(async( async () => {
    context = await createTestContext(ArborescenceBranchEditComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
