import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MatSelectChange } from '@angular/material/select';
import { PerimeterNode } from 'app/pages/tab-perimeter/store/perimeter/perimeter.form.model';
import { FormGroupState } from 'ngrx-forms';
import { ArborescenceService } from '../../store/arborescence/arborescence.form.service';

@Component({
  selector: 'pit-arborescence-node-level-select',
  templateUrl: './abrorescence-node-level-select.component.html',
  styleUrls: ['./abrorescence-node-level-select.component.scss']
})
export class ArborescenceNodeLevelSelectComponent implements OnInit {

  @Input() nodes: FormGroupState<PerimeterNode>[];
  @Input() hasEmptyChoice: boolean;
  @Input() forceEmpty = true;

  @Input() set selectedNodeKey(key: string) {
    if(key === this.emptyNode.key) {
      this.selectedNode = this.emptyNode;
    }
    else {
      const node = this.nodes.find(node => node.value.key === key);
      this.selectedNode = node ? node.value : (this.forceEmpty && this.hasEmptyChoice ? this.emptyNode : null);
    }
  }

  @Output() onChange = new EventEmitter<MatSelectChange>();

  selectedNode: PerimeterNode;
  emptyNode = ArborescenceService.emptyNode;

  constructor() { }

  ngOnInit() {
  }

}
