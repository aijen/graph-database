import { NgModule } from '@angular/core';
import { MatSelectModule } from '@angular/material/select';
import { SharedAdminModule } from 'shared/shared-admin.module';
import { ArborescenceNodeLevelSelectComponent } from './abrorescence-node-level-select.component';

@NgModule({
  declarations: [
    ArborescenceNodeLevelSelectComponent,
  ],
  exports: [
    ArborescenceNodeLevelSelectComponent,
  ],
  imports: [
    SharedAdminModule,
    MatSelectModule,
  ],
})
export class ArborescenceNodeLevelSelectModule { }
