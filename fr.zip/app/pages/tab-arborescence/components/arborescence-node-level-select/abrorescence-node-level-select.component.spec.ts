import { async, TestBed } from '@angular/core/testing';
import { MatSelectModule } from '@angular/material/select';
import { MatTooltipModule } from '@angular/material/tooltip';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { ArborescenceNodeLevelSelectComponent } from './abrorescence-node-level-select.component';

describe('ArborescenceNodeLevelSelectComponent', () => {
  let context: TestCtx<ArborescenceNodeLevelSelectComponent>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        MatSelectModule,
        MatTooltipModule,
      ],
      declarations: [
        ArborescenceNodeLevelSelectComponent,
      ],
    })
  });

  beforeEach(async( async () => {
    context = await createStableTestContext(ArborescenceNodeLevelSelectComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
