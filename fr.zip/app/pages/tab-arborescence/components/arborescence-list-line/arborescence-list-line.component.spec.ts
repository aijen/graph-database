import { async, TestBed } from '@angular/core/testing';
import { MatDialogModule } from '@angular/material/dialog';
import { MatTooltipModule } from '@angular/material/tooltip';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { configureTestSuite, createTestContext, TestCtx } from 'ng-bullet';
import { Observable } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { ArborescenceListLineComponent } from './arborescence-list-line.component';

describe('ArborescenceListLineComponent', () => {
  let context: TestCtx<ArborescenceListLineComponent>;
  let actions: Observable<any>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        MatDialogModule,
        MatTooltipModule,
      ],
      declarations: [
        ArborescenceListLineComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: {} }),
        provideMockActions(() => actions),
      ],
    })
  });

  beforeEach(async( async () => {
    context = await createTestContext(ArborescenceListLineComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
