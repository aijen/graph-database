import { NgModule } from '@angular/core';
import { MatDialogModule } from '@angular/material/dialog';
import { DialogConfirmModule } from 'shared/components/dialog-confirm/dialog-confirm.module';
import { SharedAdminModule } from 'shared/shared-admin.module';
import { ArborescenceListLineComponent } from './arborescence-list-line.component';

@NgModule({
  declarations: [
    ArborescenceListLineComponent,
  ],
  exports: [
    ArborescenceListLineComponent,
  ],
  imports: [
    SharedAdminModule,
    MatDialogModule,
    DialogConfirmModule,
  ]
})
export class ArborescenceListLineModule { }
