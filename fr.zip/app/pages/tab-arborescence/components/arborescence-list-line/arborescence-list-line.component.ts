import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Store } from '@ngrx/store';
import { DialogConfirmActions, DialogConfirmComponent } from 'shared/components/dialog-confirm/dialog-confirm.component';
import { Leaf } from 'shared/models/leaf.model';
import { AppState } from 'shared/models/state.model';
import { DeleteBranch } from '../../store/arborescence/arborescence.form.actions';
import { isSaving } from '../../store/arborescence/arborescence.form.selectors';

@Component({
  selector: 'pit-arborescence-list-line',
  templateUrl: './arborescence-list-line.component.html',
  styleUrls: ['./arborescence-list-line.component.scss']
})
export class ArborescenceListLineComponent implements OnInit {

  @Input() node1Name: string;
  @Input() node2Name: string;
  @Input() node3Name: string;
  @Input() node4Name: string;
  @Input() leaf: Leaf;

  @Output() edit = new EventEmitter<string>();

  static removeBranchConfirmText = `Êtes-vous bien sûr de vouloir supprimer la branche {{branchName}} ?`

  isSaving$ = this.store$.select(isSaving);

  constructor(
    private store$: Store<AppState>,
    private dialog: MatDialog,
  ) { }

  ngOnInit() {
  }

  async delete(technicalKey: string) {
    const branchName = `"${this.node1Name}
      ${this.node2Name === '(vide)' ? '' : ' >> ' + this.node2Name}
      ${this.node3Name === '(vide)' ? '' : ' >> ' + this.node3Name}
      ${this.node4Name === '(vide)' ? '' : ' >> ' + this.node4Name}
      ${' >> ' + (this.leaf.fullname || this.leaf.name)}"`;

    const text = ArborescenceListLineComponent.removeBranchConfirmText.replace('{{branchName}}', branchName);
    const pass = this.leaf.fullname || this.leaf.name;

    const action = await DialogConfirmComponent.openDialog(
        this.dialog,
        { data: { text, pass } }
      ).afterClosed().toPromise();

    if( action !== DialogConfirmActions.CONFIRM) return;

    this.store$.dispatch( new DeleteBranch( { technicalKey} ) );
  }

}
