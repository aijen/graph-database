import { Component, Input, OnInit } from '@angular/core';
import { MatSelectChange } from '@angular/material/select';
import { Store } from '@ngrx/store';
import { PerimeterNode } from 'app/pages/tab-perimeter/store/perimeter/perimeter.form.model';
import { getPerimeterLeavesSorted, getPerimeterNodesByRankSorted } from 'app/pages/tab-perimeter/store/perimeter/perimeter.form.selectors';
import { SORT_DIRECTION } from 'core/utils/sortStrategies';
import { CockpitLeaf } from 'shared/models/cockpit-leaf.model';
import { Leaf } from 'shared/models/leaf.model';
import { Node } from 'shared/models/node.model';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { AddBranch } from '../../store/arborescence/arborescence.form.actions';
import { ArborescenceFormEffects } from '../../store/arborescence/arborescence.form.effects';
import { Branch } from '../../store/arborescence/arborescence.form.model';
import { isSaving } from '../../store/arborescence/arborescence.form.selectors';
import { ArborescenceService } from '../../store/arborescence/arborescence.form.service';

@Component({
  selector: 'pit-arborescence-branch-create',
  templateUrl: './arborescence-branch-create.component.html',
  styleUrls: ['./arborescence-branch-create.component.scss']
})
export class ArborescenceBranchCreateComponent implements OnInit {

  @Input() nodes: Node[];

  level1$ = this.store$.select( getPerimeterNodesByRankSorted(), { rank: 1, sortConfig: [["key", SORT_DIRECTION.ASCENDING]] } );
  level2$ = this.store$.select( getPerimeterNodesByRankSorted(), { rank: 2, sortConfig: [["key", SORT_DIRECTION.ASCENDING]] } );
  level3$ = this.store$.select( getPerimeterNodesByRankSorted(), { rank: 3, sortConfig: [["key", SORT_DIRECTION.ASCENDING]] } );
  level4$ = this.store$.select( getPerimeterNodesByRankSorted(), { rank: 4, sortConfig: [["key", SORT_DIRECTION.ASCENDING]] } );
  leaves$ = this.store$.select( getPerimeterLeavesSorted, { sortConfig: [["key", SORT_DIRECTION.ASCENDING]] } );

  isSaving$ = this.store$.select(isSaving);

  nodeInitialValue = { id: null, key: null, fullname: null, level: null } as PerimeterNode;
  emptyNode = ArborescenceService.emptyNode;

  branch: Branch = {
    nodeLevel1: this.nodeInitialValue,
    nodeLevel2: this.nodeInitialValue,
    nodeLevel3: this.nodeInitialValue,
    nodeLevel4: this.nodeInitialValue,
    leaf: null,
  };

  selectedLeaf: CockpitLeaf;

  constructor(
    private store$: Store<AppState>,
    private snackbar: MessageHandler,
  ) { }

  ngOnInit() {
  }

  onChangeLevel1(event: MatSelectChange) {
    this.branch.nodeLevel1 = event.value;
  }

  onChangeLevel2(event: MatSelectChange) {
    this.branch.nodeLevel2 = event.value;
  }

  onChangeLevel3(event: MatSelectChange) {
    this.branch.nodeLevel3 = event.value;
  }

  onChangeLevel4(event: MatSelectChange) {
    this.branch.nodeLevel4 = event.value;
  }

  onChangeLeaf(event: MatSelectChange) {
    this.selectedLeaf = event.value;
    this.branch.leaf = this.perimeterLeafToLeaf(event.value);
  }

  canAdd() {
    if(this.branch.nodeLevel1.key != null && this.branch.nodeLevel2.key != null && this.branch.nodeLevel3.key != null && this.branch.nodeLevel4.key != null && this.branch.leaf != null) {
      if(this.branch.nodeLevel2 == this.emptyNode && (this.branch.nodeLevel3 != this.emptyNode || this.branch.nodeLevel4 != this.emptyNode)) {
        return false;
      }

      if(this.branch.nodeLevel3 == this.emptyNode && this.branch.nodeLevel4 != this.emptyNode) {
        return false;
      }

      return true;
    }

    return false;
  }

  addBranch() {
    if(ArborescenceService.branchExists(this.nodes, this.branch)) {
      this.snackbar.show( { message: ArborescenceFormEffects.messages.addError, action: 'OK', isError: true } )
    }
    else {
      this.store$.dispatch( new AddBranch( { branch: this.branch } ) );

      this.branch.nodeLevel1 = this.nodeInitialValue;
      this.branch.nodeLevel2 = this.nodeInitialValue;
      this.branch.nodeLevel3 = this.nodeInitialValue;
      this.branch.nodeLevel4 = this.nodeInitialValue;
      this.selectedLeaf = null;
      this.branch.leaf = null;
    }
  }

  private perimeterLeafToLeaf(perimeterLeaf: CockpitLeaf): Leaf {
    return Leaf.fromJSON({
      leafId: perimeterLeaf.id,
      key: perimeterLeaf.key,
      name: perimeterLeaf.fullname,
      metas: [],
      fullname: perimeterLeaf.fullname,
      description: perimeterLeaf.description,
      weight: null,
      technicalKey: '',
    });
  }
}
