import { NgModule } from '@angular/core';
import { MatSelectModule } from '@angular/material/select';
import { SharedAdminModule } from 'shared/shared-admin.module';
import { ArborescenceNodeLevelSelectModule } from '../arborescence-node-level-select/abrorescence-node-level-select.module';
import { ArborescenceBranchCreateComponent } from './arborescence-branch-create.component';

@NgModule({
  declarations: [
    ArborescenceBranchCreateComponent,
  ],
  exports: [
    ArborescenceBranchCreateComponent,
  ],
  imports: [
    SharedAdminModule,
    MatSelectModule,
    ArborescenceNodeLevelSelectModule,
  ]
})
export class ArborescenceBranchCreateModule { }
