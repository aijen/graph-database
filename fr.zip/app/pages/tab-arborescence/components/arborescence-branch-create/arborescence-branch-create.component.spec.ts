import { Component, Input } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { MatSelectModule } from '@angular/material/select';
import { MatTooltipModule } from '@angular/material/tooltip';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { perimeterFormState } from 'app/pages/tab-perimeter/store/perimeter/perimeter.form.reducer';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { Observable } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { arborescenceFormState } from '../../store/arborescence/arborescence.form.reducer';
import { ArborescenceBranchCreateComponent } from './arborescence-branch-create.component';

@Component({
  selector: 'pit-arborescence-node-level-select',
  template: '',
})
class PitArborescenceNodeLevelSelectStubComponent {
  @Input() nodes: any;
  @Input() hasEmptyChoice: any;
  @Input() forceEmpty: any;
  @Input() selectedNodeKey: any;
}

describe('ArborescenceBranchCreateComponent', () => {
  let context: TestCtx<ArborescenceBranchCreateComponent>;
  let actions: Observable<any>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        MatSelectModule,
        MatTooltipModule,
      ],
      declarations: [
        ArborescenceBranchCreateComponent,
        PitArborescenceNodeLevelSelectStubComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: { perimeterForm: perimeterFormState, arborescenceForm: arborescenceFormState } }),
        provideMockActions(() => actions),
        { provide: MessageHandler, useFactory: () => jasmine.createSpyObj('MessageHandler', ['ngOnDestroy', 'show'] as Array<keyof MessageHandler>) },
      ],
    })
  });

  beforeEach(async( async () => {
    context = await createStableTestContext(ArborescenceBranchCreateComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
