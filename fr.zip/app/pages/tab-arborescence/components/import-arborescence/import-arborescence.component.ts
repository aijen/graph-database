import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { Actions, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { canSaveForm } from 'core/utils/forms.helpers';
import { MarkAsDirtyAction } from 'ngrx-forms';
import { of } from 'rxjs';
import { filter, switchMapTo, take, tap } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';
import { ArborescenceFormActionTypes, ArborescenceFormActionUnion, ImportArborescence } from '../../store/arborescence/arborescence.form.actions';
import { getArborescenceForm } from '../../store/arborescence/arborescence.form.selectors';

@Component({
  selector: 'pit-import-arborescence',
  templateUrl: './import-arborescence.component.html',
  styleUrls: ['./import-arborescence.component.scss']
})
export class ImportArborescenceComponent implements OnInit {

  form$ = this.store$.select(getArborescenceForm)
  .pipe(
    tap( form => form.isPristine && this.clearFile() ),
  );

  canSave$ = this.form$.pipe(
    canSaveForm
  );

  file: File;
  fileName = '';
  fileSize = '';

  @ViewChild('f')
  private fileInput: ElementRef<HTMLInputElement>;

  constructor(
    private store$: Store<AppState>,
    private actions$: Actions,
    private dialogRef: MatDialogRef<ImportArborescenceComponent>,
  ) { }

  ngOnInit() {
  }

  async fileChange(file: File) {
    const { name = '', size = 0 } = file || {};

    const form = await this.form$.pipe(take(1)).toPromise();

    this.fileName = name;
    this.fileSize = this.getfilesize(size);
    this.file = file;

    this.store$.dispatch(new MarkAsDirtyAction(form.id));
  }

  async import() {
    const file = this.file;

    await of( new ImportArborescence({ file }) ).pipe(
      tap( ( save ) => this.store$.dispatch( save ) ),
      switchMapTo( this.actions$ ),
      ofType<ArborescenceFormActionUnion>( ArborescenceFormActionTypes.LoadArborescenceForm, ArborescenceFormActionTypes.ImportArborescenceError ),
      take(1),
      filter( ( action ) => action.type === ArborescenceFormActionTypes.LoadArborescenceForm ),
      tap( () => this.dialogRef.close() ),
    ).toPromise();
  }

  getfilesize(size: number) {
    const units = ['o', 'Ko', 'Mo', 'Go', 'To'];
    let unit = units.shift();

    while (units.length && size > 2 ** 10) {
      size = size / 2 ** 10;
      unit = units.shift();
    }

    return `${+size.toFixed(2)} ${unit}`;
  }

  private clearFile() {
    this.fileName = this.fileSize = this.fileInput.nativeElement.value = '';
    delete this.file;
  }

}
