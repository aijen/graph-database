import { Component, Input } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { MatDialogRef } from '@angular/material/dialog';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { Observable } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { arborescenceFormState } from '../../store/arborescence/arborescence.form.reducer';
import { ImportArborescenceComponent } from './import-arborescence.component';

@Component({
  selector: 'pit-close-modal',
  template: '',
})
class PitCloseModalStubComponent {
  @Input() class: any;
}

describe('ImportArborescenceComponent', () => {
  let context: TestCtx<ImportArborescenceComponent>;
  let actions: Observable<any>;
  let matDialogRefStub: jasmine.SpyObj<MatDialogRef<ImportArborescenceComponent>>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
      ],
      declarations: [
        ImportArborescenceComponent,
        PitCloseModalStubComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: {
          arborescenceForm: arborescenceFormState,
        } }),
        provideMockActions(() => actions),
        { provide: MatDialogRef, useFactory: () => jasmine.createSpyObj('MatDialogRef', ['close'] as Array<keyof MatDialogRef<ImportArborescenceComponent>>) },
      ],
    })
  });

  beforeEach(async( async () => {
    actions = null;
    matDialogRefStub = TestBed.get(MatDialogRef);
    context = await createStableTestContext(ImportArborescenceComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
