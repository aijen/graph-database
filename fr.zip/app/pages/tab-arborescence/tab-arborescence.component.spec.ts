import { Component, Input } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { MatDialog } from '@angular/material/dialog';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
/* import { MatDialog } from '@angular/material/dialog'; */
import { ExcelService } from 'core/services/excel/excel.service';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { Observable } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { arborescenceFormState } from './store/arborescence/arborescence.form.reducer';
import { TabArborescenceComponent } from './tab-arborescence.component';

@Component({
  selector: 'pit-arborescence-branch-create',
  template: '',
})
class PitArborescenceBranchCreateStubComponent {
  @Input() nodes: any;
}

@Component({
  selector: 'pit-arborescence-list',
  template: '',
})
class PitArborescenceListStubComponent {
  @Input() nodes: any;
}

describe('TabArborescenceComponent', () => {
  let context: TestCtx<TabArborescenceComponent>;
  let actions: Observable<any>;
  let matDialogStub: jasmine.SpyObj<MatDialog>;
  let excelServiceStub: jasmine.SpyObj<ExcelService>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        MatProgressSpinnerModule,
        NoopAnimationsModule,
        RouterTestingModule,
      ],
      declarations: [
        TabArborescenceComponent,
        PitArborescenceBranchCreateStubComponent,
        PitArborescenceListStubComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: { arborescenceForm: arborescenceFormState } }),
        provideMockActions(() => actions),
        { provide: MatDialog, useFactory: () => jasmine.createSpyObj('MatDialog', ['open'] as Array<keyof MatDialog>) },
        { provide: ExcelService, useFactory: () => jasmine.createSpyObj('ExcelService', ['saveAsExcel'] as Array<keyof ExcelService>) },
      ],
    })
  });

  beforeEach(async( async () => {
    actions = null;
    matDialogStub = TestBed.get(MatDialog);
    excelServiceStub = TestBed.get(ExcelService);
    context = await createStableTestContext(TabArborescenceComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
