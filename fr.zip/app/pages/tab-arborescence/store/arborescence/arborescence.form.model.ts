import { PerimeterNode } from 'app/pages/tab-perimeter/store/perimeter/perimeter.form.model';
import { Boxed, FormGroupState } from 'ngrx-forms';
import { Leaf } from 'shared/models/leaf.model';
import { NodeDTO } from 'shared/models/node.model';

declare module 'shared/models/state.model' {
  export interface AppState {
    readonly arborescenceForm: ArborescenceFormState;
  }
}
export interface ArborescenceFormValue {
  nodes: Boxed<ArborescenceDTO>;
}

export type ArborescenceDTO = NodeDTO[];

export interface ArborescenceFormState {
  form: FormGroupState<ArborescenceFormValue>;
  defaultForm: ArborescenceFormValue;
  isSaving: boolean;
  isLoading: boolean;
}

export interface Branch {
  nodeLevel1: PerimeterNode;
  nodeLevel2: PerimeterNode;
  nodeLevel3: PerimeterNode;
  nodeLevel4: PerimeterNode;
  leaf: Leaf;
}
