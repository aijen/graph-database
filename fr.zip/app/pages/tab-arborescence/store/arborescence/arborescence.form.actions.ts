import { HttpErrorResponse } from '@angular/common/http';
import { Action } from '@ngrx/store';
import { ArborescenceFormValue, Branch } from './arborescence.form.model';

export enum ArborescenceFormActionTypes {
  LoadArborescenceForm = '[Arborescence] LoadForm',
  LoadArborescenceFormSuccess = '[Arborescence] LoadFormSuccess',
  LoadArborescenceFormError = '[Arborescence] LoadFormError',
  ResetArborescenceForm = '[Arborescence] ResetForm',
  SaveArborescenceForm = '[Arborescence] SaveForm',
  SaveArborescenceFormSuccess = '[Arborescence] SaveFormSuccess',
  SaveArborescenceFormError = '[Arborescence] SaveFormError',
  DeleteBranch = '[Arborescence] DeleteBranch',
  UpdateBranch = '[Arborescence] UpdateBranch',
  AddBranch = '[Arborescence] AddBranch',
  ImportArborescence = '[Arborescence] Import',
  ImportArborescenceSuccess = '[Arborescence] ImportSuccess',
  ImportArborescenceError = '[Arborescence] ImportError',
}

export class LoadArborescenceForm implements Action {
  readonly type = ArborescenceFormActionTypes.LoadArborescenceForm;
  constructor() {}
}

export class LoadArborescenceFormSuccess implements Action {
  readonly type = ArborescenceFormActionTypes.LoadArborescenceFormSuccess;
  constructor( public payload: { arborescence: ArborescenceFormValue } ) {}
}

export class LoadArborescenceFormError implements Action {
  readonly type = ArborescenceFormActionTypes.LoadArborescenceFormError;
  constructor( public payload: { error: Error } ) {}
}

export class ResetArborescenceForm implements Action {
  readonly type = ArborescenceFormActionTypes.ResetArborescenceForm;
  constructor() {}
}

export class SaveArborescenceForm implements Action {
  readonly type = ArborescenceFormActionTypes.SaveArborescenceForm;
  constructor(public payload: { andQuit?: boolean } = {}) {}
}

export class SaveArborescenceFormSuccess implements Action {
  readonly type = ArborescenceFormActionTypes.SaveArborescenceFormSuccess;
  constructor() {}
}

export class SaveArborescenceFormError implements Action {
  readonly type = ArborescenceFormActionTypes.SaveArborescenceFormError;
  constructor( public payload: { error: Error } ) {}
}

export class DeleteBranch implements Action {
  readonly type = ArborescenceFormActionTypes.DeleteBranch;
  constructor( public payload: { technicalKey: string } ) {}
}

export class UpdateBranch implements Action {
  readonly type = ArborescenceFormActionTypes.UpdateBranch;
  constructor( public payload: { branch: Branch } ) {}
}

export class AddBranch implements Action {
  readonly type = ArborescenceFormActionTypes.AddBranch;
  constructor( public payload: { branch: Branch } ) {}
}

export class ImportArborescence implements Action {
  readonly type = ArborescenceFormActionTypes.ImportArborescence;
  constructor( public payload: { file: File } ) {}
}

export class ImportArborescenceSuccess implements Action {
  readonly type = ArborescenceFormActionTypes.ImportArborescenceSuccess;
  constructor() {}
}

export class ImportArborescenceError implements Action {
  readonly type = ArborescenceFormActionTypes.ImportArborescenceError;
  constructor( public payload: { error: HttpErrorResponse } ) {}
}

export type ArborescenceFormActionUnion =
  | LoadArborescenceForm
  | LoadArborescenceFormSuccess
  | LoadArborescenceFormError
  | ResetArborescenceForm
  | SaveArborescenceForm
  | SaveArborescenceFormSuccess
  | SaveArborescenceFormError
  | DeleteBranch
  | UpdateBranch
  | AddBranch
  | ImportArborescence
  | ImportArborescenceSuccess
  | ImportArborescenceError
  ;
