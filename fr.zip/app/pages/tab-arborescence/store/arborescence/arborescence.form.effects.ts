import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { select, Store } from '@ngrx/store';
import { SaveEvent } from 'app/pages/tab-events/store/events/events.actions';
import { EventsService } from 'app/pages/tab-events/store/events/events.service';
import { IMPORT_ADMIN_ARBORESCENCE_URL, LOAD_ADMIN_ARBORESCENCE_URL, SAVE_ADMIN_ARBORESCENCE_URL } from 'core/services/http/http-client.service';
import { getAuthState } from 'core/store/auth/auth.selectors';
import { GetHierarchy, UpdateLastRestore } from 'core/store/hierarchy/hierarchy.actions';
import { box } from 'ngrx-forms';
import { of } from 'rxjs';
import { catchError, concatMap, map, switchMap, tap, withLatestFrom } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { ArborescenceFormActionTypes, ImportArborescence, ImportArborescenceError, ImportArborescenceSuccess, LoadArborescenceForm, LoadArborescenceFormError, LoadArborescenceFormSuccess, SaveArborescenceForm, SaveArborescenceFormError, SaveArborescenceFormSuccess } from './arborescence.form.actions';
import { ArborescenceDTO, ArborescenceFormValue } from './arborescence.form.model';
import { getArborescenceForm } from './arborescence.form.selectors';

const toJson = ( conf: ArborescenceFormValue ): ArborescenceDTO => {
  return conf.nodes.value;
}

const fromJson = ( dto: ArborescenceDTO ): ArborescenceFormValue => {
  return {
    nodes: box(dto),
  };
}

@Injectable()
export class ArborescenceFormEffects {

  public static messages = {
    loadError: `
      Une erreur est survenue pendant le chargement de la configuration 'Arborescence': Veuillez réessayer
    `,
    updateError: `
      Une erreur est survenue pendant la modification de la branche : Cette branche existe déjà
    `,
    addError: `
      Une erreur est survenue pendant la création de la branche : Cette branche existe déjà
    `,
    saveSuccess: `
      Configuration sauvegardée
    `,
    saveError: `
      Une erreur est survenue pendant la sauvegarde, veuillez réessayer ou contacter le support si le problème persiste
    `,
    importError: `
      Une erreur est survenue pendant l'import, veuillez réessayer ou contacter le support si le problème persiste
    `,
    imporFormatError: `
      Il y a une erreur dans le fichier que vous essayez d'importer
    `,
  }

  form$ = this.store$.pipe(
    select( getArborescenceForm ),
    map( form => form.value ),
  );

  auth$ = this.store$.select(getAuthState);

  constructor(
    private store$: Store<AppState>,
    private actions$: Actions,
    private http: HttpClient,
    private router: Router,
    private snackbar: MessageHandler,
    private eventsService: EventsService,
  ) {}

  @Effect()
  load$ = this.actions$.pipe(
    ofType<LoadArborescenceForm>( ArborescenceFormActionTypes.LoadArborescenceForm ),
    switchMap(() => this.http.get<{ nodes: ArborescenceDTO }>(LOAD_ADMIN_ARBORESCENCE_URL)),
    select(data => data.nodes),
    map( fromJson ),
    map( arborescence => new LoadArborescenceFormSuccess( { arborescence } ) ),
    catchError( (error, caught) => (this.store$.dispatch(new LoadArborescenceFormError( { error } )), caught) ),
  );

  @Effect({ dispatch: false })
  loadError$ = this.actions$.pipe(
    ofType<LoadArborescenceFormError>( ArborescenceFormActionTypes.LoadArborescenceFormError ),
    tap( action => { console.error(action.payload.error); this.snackbar.show( { message: ArborescenceFormEffects.messages.loadError, action: 'OK', isError: true } )} ),
  );

  @Effect()
  save$ = this.actions$.pipe(
    ofType<SaveArborescenceForm>( ArborescenceFormActionTypes.SaveArborescenceForm ),
    withLatestFrom( this.form$ ),
    switchMap( ([action, _form]) => of(_form).pipe(
      map( toJson ),
      switchMap( form => this.http.put(SAVE_ADMIN_ARBORESCENCE_URL, form, { responseType: 'text' }) ),
      map( () => new SaveArborescenceFormSuccess() ),
      tap( () => action.payload.andQuit ? this.router.navigate(['/']) : null ),
      catchError( error => of(new SaveArborescenceFormError( { error } )) ),
    ) ),
  );

  // Optimistic save, assumes no change were done on the server between saves
  @Effect()
  saveSuccess$ = this.actions$.pipe(
    ofType<SaveArborescenceFormSuccess>( ArborescenceFormActionTypes.SaveArborescenceFormSuccess ),
    tap( () => this.snackbar.show( { message: ArborescenceFormEffects.messages.saveSuccess } ) ),
    withLatestFrom(this.auth$),
    map(([, auth]) => this.eventsService.createEvent(auth, '[Arborescence]')),
    concatMap(event => [
      new SaveEvent({ event }),
      new UpdateLastRestore(),
      new GetHierarchy(),
    ]),
  );

  @Effect( { dispatch: false } )
  saveError$ = this.actions$.pipe(
    ofType<SaveArborescenceFormError>( ArborescenceFormActionTypes.SaveArborescenceFormError ),
    tap( action => { console.error(action.payload.error); this.snackbar.show( { message: ArborescenceFormEffects.messages.saveError, action: 'OK', isError: true } )} ),
  );

  @Effect()
  import$ = this.actions$.pipe(
    ofType<ImportArborescence>( ArborescenceFormActionTypes.ImportArborescence ),
    withLatestFrom(this.auth$),
    switchMap( ([{ payload: { file } }, { user: { userId } }]) => {
      const form = new FormData();
      form.append( 'file', file, file.name );
      return this.http.put(IMPORT_ADMIN_ARBORESCENCE_URL, form, { responseType: 'text', params: { userId } });
    } ),
    map( () => new ImportArborescenceSuccess() ),
    catchError( (error, caught) => (this.store$.dispatch(new ImportArborescenceError( { error } )), caught) ),
  );

  @Effect()
  importSuccess$ = this.actions$.pipe(
    ofType<ImportArborescenceSuccess>( ArborescenceFormActionTypes.ImportArborescenceSuccess ),
    tap( () => this.snackbar.show( { message: ArborescenceFormEffects.messages.saveSuccess } ) ),
    concatMap(() => [
      new LoadArborescenceForm(),
      new UpdateLastRestore(),
      new GetHierarchy(),
    ]),
  );

  @Effect( { dispatch: false } )
  importError$ = this.actions$.pipe(
    ofType<ImportArborescenceError>( ArborescenceFormActionTypes.ImportArborescenceError ),
    tap( ({ payload: { error } }) => { console.error(error); this.snackbar.show( { message: (error.status === 400) ? ArborescenceFormEffects.messages.imporFormatError : ArborescenceFormEffects.messages.importError, action: 'OK', isError: true } )} ),
  );
}
