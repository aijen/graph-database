import { enableIfStable } from 'core/utils/forms.helpers';
import { box, createFormGroupState, createFormStateReducerWithUpdate, disable, FormGroupState, markAsDirty, reset, setValue, unbox, updateGroup } from 'ngrx-forms';
import { Node } from 'shared/models/node.model';
import { ArborescenceFormActionTypes, ArborescenceFormActionUnion } from './arborescence.form.actions';
import { ArborescenceFormState, ArborescenceFormValue } from './arborescence.form.model';
import { ArborescenceService } from './arborescence.form.service';

const FORM_ID = 'ADMIN_ARBORESCENCE_FORM';

const initialFormState = createFormGroupState<ArborescenceFormValue>(FORM_ID, {
  nodes: box([]),
});

const formUpdate = updateGroup<ArborescenceFormValue>( {
} );

const formValidation = updateGroup<ArborescenceFormValue>( {
} );

const updateAndValidate = ( form: FormGroupState<ArborescenceFormValue> ) => formValidation(formUpdate(form));

const formReducer = createFormStateReducerWithUpdate(updateAndValidate);

export const arborescenceFormState: ArborescenceFormState = {
  form: updateAndValidate(initialFormState),
  defaultForm: null,
  isSaving: false,
  isLoading: false,
};

export function arborescenceFormReducer(
  state = arborescenceFormState,
  action: ArborescenceFormActionUnion,
): ArborescenceFormState {

  const form = formReducer(state.form, action);

  if(form !== state.form) {
    state = { ...state, form };
  }

  switch( action.type ) {

    case ArborescenceFormActionTypes.ResetArborescenceForm: {
      const defaultForm = state.defaultForm;
      return {
        ...state,
        form: updateAndValidate(reset(setValue(state.form, defaultForm ))),
      }
    }

    case ArborescenceFormActionTypes.LoadArborescenceForm: {
      return {
        ...state,
        form: disable(state.form),
        isLoading: true,
      };
    }
    case ArborescenceFormActionTypes.LoadArborescenceFormError: {
      return {
        ...state,
        isLoading: false,
      };
    }
    // Optimistic save, assumes no change were done on the server between saves
    case ArborescenceFormActionTypes.LoadArborescenceFormSuccess: {
      const { arborescence: defaultForm } = action.payload;
      // tslint:disable-next-line: prefer-const
      let { isSaving, isLoading } = state;
      isLoading = false;

      return {
        ...state,
        form: updateAndValidate(enableIfStable(reset(setValue(state.form, defaultForm)), { isSaving, isLoading } )),
        defaultForm,
        isLoading: false,
      };
    }

    case ArborescenceFormActionTypes.SaveArborescenceForm:
    case ArborescenceFormActionTypes.ImportArborescence: {
      return {
        ...state,
        form: disable(state.form),
        isSaving: true,
      };
    }
    case ArborescenceFormActionTypes.SaveArborescenceFormSuccess:
    case ArborescenceFormActionTypes.ImportArborescenceSuccess: {
      // tslint:disable-next-line: prefer-const
      let { isSaving, isLoading } = state;
      isSaving = false;

      return {
        ...state,
        form: updateAndValidate(enableIfStable(reset(state.form), { isSaving, isLoading } )),
        defaultForm: state.form.value,
        isSaving: false,
      };
    }
    case ArborescenceFormActionTypes.SaveArborescenceFormError:
    case ArborescenceFormActionTypes.ImportArborescenceError: {
      // tslint:disable-next-line: prefer-const
      let { isSaving, isLoading } = state;
      isSaving = false;

      return {
        ...state,
        form: updateAndValidate(enableIfStable(state.form, { isSaving, isLoading } )),
        isSaving: false,
      };
    }

    case ArborescenceFormActionTypes.DeleteBranch: {
      const value = ArborescenceService.deleteBranch(Node.fromJSONCollection(unbox(state.form.value.nodes)), action.payload.technicalKey);

      return {
        ...state,
        form: updateAndValidate(markAsDirty(setValue(state.form, value))),
      };
    }

    case ArborescenceFormActionTypes.UpdateBranch: {
      const value = ArborescenceService.updateBranch(Node.fromJSONCollection(unbox(state.form.value.nodes)), action.payload.branch);

      return {
        ...state,
        form: updateAndValidate(markAsDirty(setValue(state.form, value))),
      };
    }

    case ArborescenceFormActionTypes.AddBranch: {
      const value = ArborescenceService.addBranch(Node.fromJSONCollection(unbox(state.form.value.nodes)), action.payload.branch);

      return {
        ...state,
        form: updateAndValidate(markAsDirty(setValue(state.form, value))),
      };
    }

    default: {
      return state;
    }
  }
}
