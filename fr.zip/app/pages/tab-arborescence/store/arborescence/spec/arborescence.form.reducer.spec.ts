import { AppState } from 'shared/models/state.model';
import { arborescenceFormReducer, arborescenceFormState } from '../arborescence.form.reducer';

// necessary to avoid the error :
// Invalid module name in augmentation, module 'shared/models/state.model' cannot be found.
let happy_compiler: AppState; // tslint:disable-line

describe('ArborescenceForm Reducer', () => {

  describe('undefined action', () => {

    it('should return the default state', () => {
      const action = { type: null, payload: null };
      const state = arborescenceFormReducer( undefined, action );

      expect(state).toBe(arborescenceFormState);
    })

  });

} );
