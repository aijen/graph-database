import { createFeatureSelector, createSelector } from '@ngrx/store';
import { SortSelectorConfig } from 'app/pages/tab-perimeter/store/perimeter/perimeter.form.selectors';
import { combineSortStrategies, sortByPropStrategy, sortStrategyWithDirection, SORT_DIRECTION } from 'core/utils/sortStrategies';
import { FormGroupState, unbox } from 'ngrx-forms';
import { Leaf } from 'shared/models/leaf.model';
import { Node } from 'shared/models/node.model';
import { ArborescenceFormState, ArborescenceFormValue } from './arborescence.form.model';

export const arborescenceFormStateSelector = createFeatureSelector<ArborescenceFormState>(
  'arborescenceForm'
);

export const getArborescenceForm = createSelector(
  arborescenceFormStateSelector,
  state => state.form,
);

export const isArborescenceFormLoading = createSelector(
  arborescenceFormStateSelector,
  state => state.isLoading,
);

export const isArborescenceFormLoadingOrSaving = createSelector(
  arborescenceFormStateSelector,
  state => state.isLoading || state.isSaving,
);

export const isModified = createSelector(
  getArborescenceForm,
  isArborescenceFormLoading,
  ( form, loading ) => !(form.isPristine || loading),
);

export const isSaving = createSelector(
  arborescenceFormStateSelector,
  state => state.isSaving,
);

const sortArborescence = (node: Node, sortConfig: [keysOfType<Node | Leaf, string>, SORT_DIRECTION][]) => {
  node.nodes.sort(
    combineSortStrategies(
      sortConfig.map( ([column, direction]) => [ sortByPropStrategy(( node ) => node[column]), direction ] as sortStrategyWithDirection<Node> )
  ));

  node.leaves.sort(
    combineSortStrategies(
      sortConfig.map( ([column, direction]) => [ sortByPropStrategy(( leaf ) => leaf[column]), direction ] as sortStrategyWithDirection<Leaf> )
  ));

  node.nodes.forEach(node => sortArborescence(node, sortConfig));
}

export const getArborecenceSorted = createSelector<object, SortSelectorConfig<Node | Leaf>, Readonly<FormGroupState<ArborescenceFormValue>>, Node[]>(
  getArborescenceForm,
  ( form, { sortConfig = [] } ) => {
    const arbo = Node.fromJSONCollection(unbox(form.value.nodes));

    arbo.forEach(node => sortArborescence(node, sortConfig));

    return arbo;
  }
);

const generateBranches = (leaves: Leaf[]): (Node | Leaf)[][] => {
  const branches: (Node | Leaf)[][] = [];

  leaves.forEach(leaf => {
    let branch: (Node | Leaf)[] = [leaf];
    let parent: Node = leaf.parent;

    while(parent !== null) {
      branch = [parent, ...branch];

      parent = parent.parent;
    }

    branches.push(branch);
  })

  return branches;
}

export const getFlattenedArborecence = createSelector<object, SortSelectorConfig<Node | Leaf>, Readonly<FormGroupState<ArborescenceFormValue>>, (Node | Leaf)[][]>(
  getArborescenceForm,
  ( form, { sortConfig = [] } ) => {
    const arbo = Node.fromJSONCollection(unbox(form.value.nodes));

    arbo.forEach(node => sortArborescence(node, sortConfig));


    const reducer = ( acc: (Node | Leaf)[][], node: Node ): (Node | Leaf)[][] => [ ...acc, ...generateBranches(node.leaves), ...node.nodes.reduce( reducer, [] ) ];
    const flatten = arbo.reduce( reducer, [] as (Node | Leaf)[][] );

    return flatten;
  }
);
