import { async, TestBed } from '@angular/core/testing';
import { configureTestSuite } from 'ng-bullet';
import { ArborescenceService } from './arborescence.form.service';

describe('ArborescenceService', () => {
  let service: ArborescenceService;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      providers: [
        ArborescenceService,
      ],
    })
  });

  beforeEach(async( async () => {
    service = TestBed.get(ArborescenceService);
  } ));

  it('should create', () => {
    expect(service).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
