import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { ArborescenceFormEffects } from './arborescence.form.effects';
import { arborescenceFormReducer } from './arborescence.form.reducer';

@NgModule({
  declarations: [],
  imports: [
    StoreModule.forFeature('arborescenceForm', arborescenceFormReducer),
    EffectsModule.forFeature([ArborescenceFormEffects]),
  ]
})
export class ArborescenceModule { }
