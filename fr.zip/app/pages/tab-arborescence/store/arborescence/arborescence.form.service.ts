import { Injectable } from '@angular/core';
import { PerimeterNode } from 'app/pages/tab-perimeter/store/perimeter/perimeter.form.model';
import { box } from 'ngrx-forms';
import { Leaf } from 'shared/models/leaf.model';
import { Node } from 'shared/models/node.model';
import { ArborescenceFormValue, Branch } from './arborescence.form.model';

@Injectable({
  providedIn: 'root'
})
export class ArborescenceService {
  static emptyNode = {
    id: null,
    key: '(vide)',
    fullname: '(vide)',
    level: null
  } as PerimeterNode;

  constructor() {
  }

  static deleteBranch(nodes: Node[], technicalKey: string): ArborescenceFormValue {
    const leaf = this.findLeaf(nodes, technicalKey);
    return { nodes: box(Node.toJSONCollection(this.deleteLeaf(nodes, leaf))) };
  }

  static updateBranch(nodes: Node[], branch: Branch): ArborescenceFormValue {
    const leaf = this.findLeaf(nodes, branch.leaf.technicalKey);
    const newNodes = this.deleteLeaf(nodes, leaf);
    return { nodes: box(Node.toJSONCollection(this.createBranch(newNodes, branch))) };
  }

  static addBranch(nodes: Node[], branch: Branch): ArborescenceFormValue {
    return { nodes: box(Node.toJSONCollection(this.createBranch(nodes, branch))) };
  }

  static findBranch(nodes: Node[], technicalKey: string): Branch {
    for(let node1 of nodes) {
      const node1Leaf = node1.leaves.find(internal => internal.technicalKey === technicalKey);
      if(node1Leaf != null) return this.computeBranch(node1, null, null, null, node1Leaf);

      for(let node2 of node1.nodes) {
        const node2Leaf = node2.leaves.find(internal => internal.technicalKey === technicalKey);
        if(node2Leaf != null) return this.computeBranch(node1, node2, null, null, node2Leaf);

        for(let node3 of node2.nodes) {
          const node3Leaf = node3.leaves.find(internal => internal.technicalKey === technicalKey);
          if(node3Leaf != null) return this.computeBranch(node1, node2, node3, null, node3Leaf);

          for(let node4 of node3.nodes) {
            const node4Leaf = node4.leaves.find(internal => internal.technicalKey === technicalKey);
            if(node4Leaf != null) return this.computeBranch(node1, node2, node3, node4, node4Leaf);
          }
        }
      }
    }
  }

  static branchExists(nodes: Node[], branch: Branch): boolean {
    const technicalKey = this.getTechnicalKeyFragment(branch.nodeLevel1) +
      this.getTechnicalKeyFragment(branch.nodeLevel2) +
      this.getTechnicalKeyFragment(branch.nodeLevel3) +
      this.getTechnicalKeyFragment(branch.nodeLevel4) +
      branch.leaf.key.split(' ').join('_');

      const findedBranch = this.findBranch(nodes, technicalKey);

      return findedBranch != null && branch.nodeLevel1.key === findedBranch.nodeLevel1.key &&
        branch.nodeLevel2.key === findedBranch.nodeLevel2.key &&
        branch.nodeLevel3.key === findedBranch.nodeLevel3.key &&
        branch.nodeLevel4.key === findedBranch.nodeLevel4.key &&
        branch.leaf.key === findedBranch.leaf.key;

  }

  private static getTechnicalKeyFragment(node: PerimeterNode): string {
    return node === this.emptyNode ? '' : `${node.key.split(' ').join('_')}|`;
  }

  private static computeBranch(node1: Node, node2: Node, node3: Node, node4: Node, leaf: Leaf) {
    const nodeLevel1 = node1 != null ? this.nodeToPerimeterNode(node1, 1) : this.emptyNode;
    const nodeLevel2 = node2 != null ? this.nodeToPerimeterNode(node2, 2) : this.emptyNode;
    const nodeLevel3 = node3 != null ? this.nodeToPerimeterNode(node3, 3) : this.emptyNode;
    const nodeLevel4 = node4 != null ? this.nodeToPerimeterNode(node4, 4) : this.emptyNode;

    return {nodeLevel1, nodeLevel2, nodeLevel3, nodeLevel4, leaf};
  }

  private static nodeToPerimeterNode(node: Node, level: number): PerimeterNode {
    return { id: node.nodeId, key: node.key, fullname: node.fullname || node.name, level };
  }

  private static findLeaf(nodes: Node[], technicalKey: string): Leaf {
    return this.findBranch(nodes, technicalKey).leaf;
  }

  private static deleteLeaf(nodes: Node[], leaf: Leaf): Node[] {
    leaf.parent.leaves = leaf.parent.leaves.filter(internal => internal.technicalKey !== leaf.technicalKey);

    if(leaf.parent.leaves.length === 0 && leaf.parent.nodes.length === 0) {
      return this.deleteNode(nodes, leaf.parent);
    }
    else {
      return nodes;
    }
  }

  private static deleteNode(nodes: Node[], node: Node): Node[] {
    if(node.parent != null) {
      node.parent.nodes = node.parent.nodes.filter(internal => internal.technicalKey !== node.technicalKey);

      if(node.parent.leaves.length === 0 && node.parent.nodes.length === 0) {
        return this.deleteNode(nodes, node.parent);
      }
    }
    else {
      nodes = nodes.filter(internal => internal.key !== node.key);
    }

    return nodes;
  }

  private static createBranch(nodes: Node[], branch: Branch): Node[] {
    const nodeLevel1 = this.getOrCreateNode(nodes, branch.nodeLevel1)

    if(branch.nodeLevel2 != this.emptyNode) {
      const nodeLevel2 = this.getOrCreateNode(nodeLevel1.nodes, branch.nodeLevel2, nodeLevel1);

      if(branch.nodeLevel3 != this.emptyNode) {
        const nodeLevel3 = this.getOrCreateNode(nodeLevel2.nodes, branch.nodeLevel3, nodeLevel2);

        if(branch.nodeLevel4 != this.emptyNode) {
          const nodeLevel4 = this.getOrCreateNode(nodeLevel3.nodes, branch.nodeLevel4, nodeLevel3);
          this.addLeaf(nodeLevel4, branch.leaf);
        }
        else {
          this.addLeaf(nodeLevel3, branch.leaf);
        }
      }
      else {
        this.addLeaf(nodeLevel2, branch.leaf);
      }
    }
    else {
      this.addLeaf(nodeLevel1, branch.leaf);
    }

    return nodes;
  }

  private static getOrCreateNode(nodes: Node[], node: PerimeterNode, parent: Node = null): Node {
    let newNode = nodes.find(internal => internal.key === node.key);

    if(newNode == null) {
      newNode = Node.fromJSON({
        nodeId: node.id,
        isLeafWrapper: false,
        key : node.key,
        name : '',
        fullname : node.fullname,
        description : '',
        nodes: [],
        leaves: [],
        readOnly: true,
        technicalKey: (parent != null ? `${parent.technicalKey}|` : '') + `${node.key.split(' ').join('_')}`,
        weight : null,
      }, parent);

      nodes.push(newNode);
    }

    return newNode;
  }

  private static addLeaf(node: Node, leaf: Leaf) {
    leaf.technicalKey = `${node.technicalKey}|${leaf.key.split(' ').join('_')}`;
    node.leaves.push(leaf);
  }
}
