import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Actions, ofType } from '@ngrx/effects';
import { select, Store } from '@ngrx/store';
import { fadeAnimation } from 'core/animations/animations';
import { ExcelService } from 'core/services/excel/excel.service';
import { canResetForm, canSaveForm, isFormPristine } from 'core/utils/forms.helpers';
import { SORT_DIRECTION } from 'core/utils/sortStrategies';
import { merge, of } from 'rxjs';
import { mapTo, switchMapTo, take, tap } from 'rxjs/operators';
import { Hierarchy } from 'shared/constants/constants';
import { CockpitLeaf, WorkingHours } from 'shared/models/cockpit-leaf.model';
import { Leaf } from 'shared/models/leaf.model';
import { Node } from 'shared/models/node.model';
import { AppState } from 'shared/models/state.model';
import { CanComponentWithFormDeactivate } from 'shared/services/CanComponentWithFormDeactivate.interface';
import { LoadPerimeterForm } from '../tab-perimeter/store/perimeter/perimeter.form.actions';
import { PerimeterNode } from '../tab-perimeter/store/perimeter/perimeter.form.model';
import { getPerimeterForm } from '../tab-perimeter/store/perimeter/perimeter.form.selectors';
import { ImportArborescenceComponent } from './components/import-arborescence/import-arborescence.component';
import { ArborescenceFormActionTypes, LoadArborescenceForm, ResetArborescenceForm, SaveArborescenceForm } from './store/arborescence/arborescence.form.actions';
import { getArborecenceSorted, getArborescenceForm, getFlattenedArborecence, isArborescenceFormLoadingOrSaving, isModified } from './store/arborescence/arborescence.form.selectors';

@Component({
  selector: 'pit-tab-arborescence',
  templateUrl: './tab-arborescence.component.html',
  styleUrls: ['./tab-arborescence.component.scss'],
  animations: [
    fadeAnimation(),
  ],
})
export class TabArborescenceComponent implements OnInit, CanComponentWithFormDeactivate {

  form$ = this.store$.pipe(
    select( getArborescenceForm ),
  );

  nodes$ = this.store$.select( getArborecenceSorted, {sortConfig: [["fullname", SORT_DIRECTION.ASCENDING]] } )

  loading$ = this.store$.pipe(
    select( isArborescenceFormLoadingOrSaving ),
  );

  canSave$ = this.form$.pipe(
    canSaveForm
  );

  canReset$ = this.form$.pipe(
    canResetForm
  );

  isPristine$ = this.form$.pipe(
    isFormPristine
  );

  constructor(
    private store$: Store<AppState>,
    private actions$: Actions,
    private router: Router,
    private dialog: MatDialog,
    private excelService: ExcelService,
  ) { }

  ngOnInit() {
    this.store$.dispatch( new LoadArborescenceForm() );
    this.store$.dispatch( new LoadPerimeterForm() );
  }

  isModified() {
    return this.store$.pipe( select( isModified ) );
  }

  getSaveAction() {
    const saveResult = merge(
      this.actions$.pipe( ofType( ArborescenceFormActionTypes.SaveArborescenceFormSuccess ), mapTo(true) ),
      this.actions$.pipe( ofType( ArborescenceFormActionTypes.SaveArborescenceFormError ), mapTo(false) ),
    );

    return of(null).pipe(
      tap( () => this.save() ),
      switchMapTo( saveResult ),
    );
  }

  canSave() {
    return this.canSave$;
  }

  import() {
    this.dialog.open(ImportArborescenceComponent);
  }

  async export() {
    const perimeterForm = await this.store$.select(getPerimeterForm).pipe(take(1)).toPromise();
    const { nodes, leaves } = perimeterForm.value;
    const arbo: (Node | Leaf)[][] = await this.store$.select( getFlattenedArborecence, {sortConfig: [["fullname", SORT_DIRECTION.ASCENDING]] } ).pipe(take(1)).toPromise();

    this.excelService.saveAsExcel(`cockpit_arborescence`, [
      {
        name: 'Nœuds',
        data: [
          ['Clé', 'Nom', 'Niveau'],
          ...this.generateNodesLines(nodes)
        ],
      },
      {
        name: 'Feuilles',
        data: [
          ['Clé', 'Nom', 'Description', 'Code IRT', 'Début Lundi', 'Fin Lundi', 'Activé Lundi', 'Début Mardi', 'Fin Mardi', 'Activé Mardi', 'Début Mercredi', 'Fin Mercredi', 'Activé Mercredi', 'Début Jeudi', 'Fin Jeudi', 'Activé Jeudi', 'Début Vendredi', 'Fin Vendredi', 'Activé Vendredi', 'Début Samedi', 'Fin Samedi', 'Activé Samedi', 'Début Dimanche', 'Fin Dimanche', 'Activé Dimanche'],
          ...this.generateLeavesLines(leaves)
        ],
      },
      {
        name: 'Arborescence',
        data: [
          ['Clé Nœud 1', 'Nom Nœud 1', 'Clé Nœud 2', 'Nom Nœud 2', 'Clé Nœud 3', 'Nom Nœud 3', 'Clé Nœud 4', 'Nom Nœud 4', 'Clé Feuille', 'Nom Feuille'],
          ...this.generateArborescenceLines(arbo)
        ],
      }
    ]);
  }

  private generateNodesLines(nodes: PerimeterNode[]): (string | number)[][] {
    const lines: (string | number)[][] = [];

    nodes.forEach(node => {
      const line: (string | number)[] = [];

      line.push(node.key);
      line.push(node.fullname);
      line.push(node.level);

      lines.push(line);
    });

    return lines;
  }

  private generateLeavesLines(leaves: CockpitLeaf[]): (string | number)[][] {
    const lines: (string | number)[][] = [];

    leaves.forEach(leaf => {
      const line: (string | number)[] = [];

      line.push(leaf.key);
      line.push(leaf.fullname);
      line.push(leaf.description);
      line.push(leaf.irtCode);
      line.push(...this.getWorkingHoursForDay(leaf.workingHours.MON));
      line.push(...this.getWorkingHoursForDay(leaf.workingHours.TUE));
      line.push(...this.getWorkingHoursForDay(leaf.workingHours.WED));
      line.push(...this.getWorkingHoursForDay(leaf.workingHours.THU));
      line.push(...this.getWorkingHoursForDay(leaf.workingHours.FRI));
      line.push(...this.getWorkingHoursForDay(leaf.workingHours.SAT));
      line.push(...this.getWorkingHoursForDay(leaf.workingHours.SUN));

      lines.push(line);
    });

    return lines;
  }

  private getWorkingHoursForDay(workingHours: WorkingHours): (string | number)[] {
    return [workingHours.start, workingHours.end, workingHours.enabled ? 'Oui' : 'Non'];
  }

  private generateArborescenceLines(arbo: (Node | Leaf)[][]): (string | number)[][] {
    const lines: (string | number)[][] = [];

    arbo.forEach(branch => {
      const line: (string | number)[] = [];

      for(let i = 0; i < 4; i++) {
        const node = branch[i];

        if(node === undefined || node.type !== Hierarchy.Node) {
          line.push(...['', ''])
        }
        else {
          line.push(node.key);
          line.push(node.fullname);
        }
      }

      const leaf = branch[branch.length - 1];
      line.push(leaf.key);
      line.push(leaf.fullname);

      lines.push(line);
    });

    return lines;
  }

  save(quit: boolean = false) {
    this.store$.dispatch( new SaveArborescenceForm({ andQuit: quit }) );
  }

  saveAndQuit() {
    this.save(true);
  }

  reset() {
    this.store$.dispatch( new ResetArborescenceForm() );
  }

  quit() {
    this.reset();
    this.router.navigateByUrl('/');
  }
}
