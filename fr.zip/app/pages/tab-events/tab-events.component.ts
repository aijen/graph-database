import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { fadeAnimation } from 'core/animations/animations';
import { UserRole } from 'core/models/userRoles.model';
import { ExcelService } from 'core/services/excel/excel.service';
import { Moment } from 'moment';
import { take } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';
import { LoadEvents } from './store/events/events.actions';
import { Events } from './store/events/events.model';
import { getEvents, isEventsLoading } from './store/events/events.selectors';

@Component({
  selector: 'pit-tab-events',
  templateUrl: './tab-events.component.html',
  styleUrls: ['./tab-events.component.scss'],
  animations: [
    fadeAnimation(),
  ],
})
export class TabEventsComponent implements OnInit {

  events$ = this.store$.select(getEvents);
  loading$ = this.store$.select(isEventsLoading);

  constructor(
    private store$: Store<AppState>,
    private excelService: ExcelService,
    private router: Router,
  ) { }

  ngOnInit() {
    this.store$.dispatch(new LoadEvents());
  }

  async export() {
    const events = await this.events$.pipe(take(1)).toPromise();
    const titles = ['Date et heure', 'Id', 'Profiles', 'Email', 'Type', 'Détails'];

    this.excelService.saveAsExcel('Journal_des_événements', [
      {
        name: 'Événements',
        data: [
          titles,
          ...this.generateEventsLines(events)
        ],
      },
    ]);
  }

  private generateEventsLines(events: Events[]): string[][] {
    const lines: string[][] = [];

    events.forEach(event => {
      const line: string[] = [];

      line.push(this.formatDate(event.logDate));
      line.push(event.userId);
      line.push(this.formatProfiles(event.profiles));
      line.push(event.email);
      line.push(event.type);
      line.push(event.category);

      lines.push(line);
    });

    return lines;
  }

  private formatDate(date: Moment): string {
    return date.format('YYYY/MM/DD HH:mm:ss');
  }

  private formatProfiles(profiles: UserRole[]): string {
    let str = '';

    for(let profile of profiles) {
      switch(profile) {
        case UserRole.PUBLIC:
          str = str.length > 0 ? str.concat(', Public') : 'Public';
          break;
        case UserRole.ADMIN:
          str = str.length > 0 ? str.concat(', Admin') : 'Admin';
          break;
        case UserRole.SUPER_ADMIN:
          str = str.length > 0 ? str.concat(', SuperAdmin') : 'SuperAdmin';
          break;
        case UserRole.GROUP_MANAGER:
        default:
          break;
      }
    }

    return str;
  }

  quit() {
    this.router.navigateByUrl('/');
  }

}
