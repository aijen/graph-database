import { UserRole } from 'core/models/userRoles.model';
import { Moment } from 'moment';

declare module 'shared/models/state.model' {
  export interface AppState {
    readonly events: EventsState;
  }
}
export interface Events {
  logDate: Moment;
  userId: string;
  profiles: UserRole[];
  email: string;
  category: string;
  type?: string;
  baseFile?: string;
  importedFile?: string;
}

export interface EventsDTO {
  logDate: string;
  userId: string;
  profiles: UserRole[];
  email: string;
  category: string;
  type?: string;
  baseFile?: string;
  importedFile?: string;
}

export interface EventsState {
  events: Events[];
  isLoading: boolean;
}
