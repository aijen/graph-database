import { createFeatureSelector, createSelector } from '@ngrx/store';
import { EventsState } from './events.model';

export const eventsStateSelector = createFeatureSelector<EventsState>(
  'events'
);

export const getEvents = createSelector(
  eventsStateSelector,
  state => state.events,
);

export const isEventsLoading = createSelector(
  eventsStateSelector,
  state => state.isLoading,
);
