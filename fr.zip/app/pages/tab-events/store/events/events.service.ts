import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LOAD_ADMIN_LOGS_URL, SAVE_ADMIN_LOGS_URL } from 'core/services/http/http-client.service';
import { AuthState } from 'core/store/auth/auth.model';
import { combineSortStrategies, sortByPropStrategy, sortStringCaseInsensitiveStrategy, SORT_DIRECTION } from 'core/utils/sortStrategies';
import moment from 'moment';
import { map } from 'rxjs/operators';
import { Events, EventsDTO } from './events.model';

const fromJson = ( dtos: EventsDTO[] ): Events[] => {
  return dtos.sort(combineSortStrategies([[sortByPropStrategy('logDate', sortStringCaseInsensitiveStrategy), SORT_DIRECTION.DESCENDING]]))
  .map(dto => ({
    ...dto,
    logDate: moment(dto.logDate),
  }));
}

@Injectable({
  providedIn: 'root'
})
export class EventsService {

  constructor(
    private http: HttpClient,
  ) {}

  load() {
    return this.http.get<EventsDTO[]>(LOAD_ADMIN_LOGS_URL).pipe( map( fromJson ) );
  }

  save(event: Events) {
    return this.http.post(SAVE_ADMIN_LOGS_URL, event, { responseType: 'text' });
  }

  createEvent(auth: AuthState, category: string): Events {
    return {
      logDate: moment(),
      userId: auth.user.userId,
      profiles: auth.profil.profiles,
      email: auth.user.email,
      category,
    };
  }
}
