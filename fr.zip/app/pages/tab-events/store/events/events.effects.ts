import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { concat, of } from 'rxjs';
import { catchError, map, switchMap, tap } from 'rxjs/operators';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { EventsActionTypes, LoadEvents, LoadEventsError, LoadEventsSuccess, SaveEvent, SaveEventError, SaveEventSuccess } from './events.actions';
import { EventsService } from './events.service';

@Injectable()
export class EventsEffects {

  public static messages = {
    loadError: `
      Une erreur est survenue pendant le chargement de la configuration 'Events': Veuillez réessayer
    `,
    saveError: `
      Une erreur est survenue pendant la sauvegarde d'un événement: Veuillez contacter le support Cockpit
    `,
  }

  constructor(
    private actions$: Actions,
    private eventsService: EventsService,
    private snackbar: MessageHandler,
  ) {}

  @Effect()
  load$ = this.actions$.pipe(
    ofType<LoadEvents>( EventsActionTypes.LoadEvents ),
    switchMap( () => this.eventsService.load() ),
    map( events => new LoadEventsSuccess( { events } ) ),
    catchError( (error, caught) => concat(of(new LoadEventsError( { error } )), caught) ),
  );

  @Effect({ dispatch: false })
  loadError$ = this.actions$.pipe(
    ofType<LoadEventsError>( EventsActionTypes.LoadEventsError ),
    tap( action => { console.error(action.payload.error); this.snackbar.show( { message: EventsEffects.messages.loadError, action: 'OK', isError: true } )} ),
  );

  @Effect()
  save$ = this.actions$.pipe(
    ofType<SaveEvent>( EventsActionTypes.SaveEvent ),
    switchMap( ({ payload: { event } }) => this.eventsService.save(event) ),
    map( () => new SaveEventSuccess() ),
    catchError( (error, caught) => concat(of(new SaveEventError( { error } )), caught) ),
  );

  @Effect({ dispatch: false })
  saveError$ = this.actions$.pipe(
    ofType<SaveEventError>( EventsActionTypes.SaveEventError ),
    tap( action => { console.error(action.payload.error); this.snackbar.show( { message: EventsEffects.messages.saveError, action: 'OK', isError: true } )} ),
  );

}
