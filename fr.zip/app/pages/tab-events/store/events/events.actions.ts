import { Action } from '@ngrx/store';
import { Events } from './events.model';

export enum EventsActionTypes {
  LoadEvents = '[Events] Load',
  LoadEventsSuccess = '[Events] LoadSuccess',
  LoadEventsError = '[Events] LoadError',
  SaveEvent = '[Events] Save',
  SaveEventSuccess = '[Events] SaveSuccess',
  SaveEventError = '[Events] SaveError',
}

export class LoadEvents implements Action {
  readonly type = EventsActionTypes.LoadEvents;
  constructor() {}
}

export class LoadEventsSuccess implements Action {
  readonly type = EventsActionTypes.LoadEventsSuccess;
  constructor( public payload: { events: Events[] } ) {}
}

export class LoadEventsError implements Action {
  readonly type = EventsActionTypes.LoadEventsError;
  constructor( public payload: { error: Error } ) {}
}

export class SaveEvent implements Action {
  readonly type = EventsActionTypes.SaveEvent;
  constructor(public payload: { event: Events }) {}
}

export class SaveEventSuccess implements Action {
  readonly type = EventsActionTypes.SaveEventSuccess;
  constructor() {}
}

export class SaveEventError implements Action {
  readonly type = EventsActionTypes.SaveEventError;
  constructor( public payload: { error: Error } ) {}
}

export type EventsActionUnion =
  | LoadEvents
  | LoadEventsSuccess
  | LoadEventsError
  | SaveEvent
  | SaveEventSuccess
  | SaveEventError
  ;
