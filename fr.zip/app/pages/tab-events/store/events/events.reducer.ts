import { EventsActionTypes, EventsActionUnion } from './events.actions';
import { EventsState } from './events.model';

export const eventsState: EventsState = {
  events: [],
  isLoading: false,
};

export function eventsReducer(
  state = eventsState,
  action: EventsActionUnion
): EventsState {

  switch( action.type ) {

    case EventsActionTypes.LoadEvents: {
      return {
        ...state,
        isLoading: true,
      };
    }
    case EventsActionTypes.LoadEventsError: {
      return {
        ...state,
        isLoading: false,
      };
    }
    // Optimistic save, assumes no change were done on the server between saves
    case EventsActionTypes.LoadEventsSuccess: {
      const { events } = action.payload;

      return {
        ...state,
        events,
        isLoading: false,
      };
    }

    default: {
      return state;
    }
  }
}
