import { AppState } from 'shared/models/state.model';
import { eventsReducer, eventsState } from '../events.reducer';

// necessary to avoid the error :
// Invalid module name in augmentation, module 'shared/models/state.model' cannot be found.
let happy_compiler: AppState; // tslint:disable-line

describe('Events Reducer', () => {

  describe('undefined action', () => {

    it('should return the default state', () => {
      const action = { type: null, payload: null };
      const state = eventsReducer( undefined, action );

      expect(state).toBe(eventsState);
    });

  });

} );
