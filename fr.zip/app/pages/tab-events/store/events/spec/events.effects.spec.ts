import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { configureTestSuite } from 'ng-bullet';
import { Observable } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { EventsEffects } from '../events.effects';
import { eventsState } from '../events.reducer';
import { EventsService } from '../events.service';

describe('Events Effects', () => {
  let service: EventsEffects;
  let actions: Observable<any>;
  let eventsServiceStub: jasmine.SpyObj<EventsService>;
  let messageHandlerStub: jasmine.SpyObj<MessageHandler>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule
      ],
      providers: [
        EventsEffects,
        provideMockActions(() => actions),
        provideMockStore<Partial<AppState>>({ initialState: { events: eventsState } }),
        { provide: EventsService, useFactory: () => jasmine.createSpyObj('EventsService', ['load', 'save'] as Array<keyof EventsService>) },
        { provide: MessageHandler, useFactory: () => jasmine.createSpyObj('MessageHandler', ['ngOnDestroy', 'show'] as Array<keyof MessageHandler>) },
      ]
    });
  } );

  beforeEach(() => {
    actions = null;
    eventsServiceStub = TestBed.get(EventsService);
    messageHandlerStub = TestBed.get(MessageHandler);
    service = TestBed.get(EventsEffects);
  });

  it('should work', () => {
    expect(service).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
} );
