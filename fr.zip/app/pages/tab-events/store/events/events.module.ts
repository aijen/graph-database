import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { EventsEffects } from './events.effects';
import { eventsReducer } from './events.reducer';

@NgModule({
  declarations: [],
  imports: [
    StoreModule.forFeature('events', eventsReducer),
    EffectsModule.forFeature([EventsEffects]),
  ]
})
export class EventsStoreModule { }
