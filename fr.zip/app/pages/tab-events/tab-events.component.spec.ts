import { Component, Input } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { ExcelService } from 'core/services/excel/excel.service';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { Observable } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { eventsState } from './store/events/events.reducer';
import { TabEventsComponent } from './tab-events.component';

@Component({
  selector: 'pit-events-list',
  template: '',
})
class PitEventsListStubComponent {
  @Input() events: any;
}

describe('TabEventsComponent', () => {
  let context: TestCtx<TabEventsComponent>;
  let actions: Observable<any>;
  let excelServiceStub: jasmine.SpyObj<ExcelService>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        MatProgressSpinnerModule,
        NoopAnimationsModule,
        RouterTestingModule,
      ],
      declarations: [
        TabEventsComponent,
        PitEventsListStubComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: {
          events: eventsState,
        } }),
        provideMockActions(() => actions),
        { provide: ExcelService, useFactory: () => jasmine.createSpyObj('ExcelService', ['saveAsExcel', 'fileToWorkbook', 'sheetToJson'] as Array<keyof ExcelService>) },
      ],
    })
  });

  beforeEach(async( async () => {
    actions = null;
    excelServiceStub = TestBed.get(ExcelService);
    context = await createStableTestContext(TabEventsComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
