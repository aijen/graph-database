import { NgModule } from '@angular/core';
import { MatDialogModule } from '@angular/material/dialog';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { SharedAdminModule } from 'shared/shared-admin.module';
import { EventsListComponent } from './components/events-list/events-list.component';
import { ImportBackupPopupComponent } from './components/import-backup-popup/import-backup-popup.component';
import { EventsStoreModule } from './store/events/events.module';
import { TabEventsComponent } from './tab-events.component';

@NgModule({
  declarations: [
    TabEventsComponent,
    EventsListComponent,
    ImportBackupPopupComponent,
  ],
  imports: [
    SharedAdminModule,
    EventsStoreModule,
    MatProgressSpinnerModule,
    MatDialogModule,
  ],
  entryComponents: [
    ImportBackupPopupComponent,
  ]
})

export class TabEventsModule { }
