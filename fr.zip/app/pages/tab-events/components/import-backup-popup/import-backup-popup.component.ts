import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { GET_ADMIN_IMPORT_FILE_URL } from 'core/services/http/http-client.service';
import { Events } from '../../store/events/events.model';

@Component({
  selector: 'pit-import-backup-popup',
  templateUrl: './import-backup-popup.component.html',
  styleUrls: ['./import-backup-popup.component.scss']
})
export class ImportBackupPopupComponent implements OnInit {

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: { event: Events },
    private dialogRef: MatDialogRef<ImportBackupPopupComponent>,
  ) { }

  ngOnInit() {
  }

  getFileUrl(fileName: string) {
    return `${GET_ADMIN_IMPORT_FILE_URL}?fileName=${fileName}`;
  }

  quit() {
    this.dialogRef.close();
  }

}
