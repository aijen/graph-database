import { async, TestBed } from '@angular/core/testing';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import moment from 'moment';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { Events } from '../../store/events/events.model';
import { ImportBackupPopupComponent } from './import-backup-popup.component';

const generateEvent = (event: Partial<Events>): Events => {
  return ({
    logDate: moment(),
    userId: 'userId',
    profiles: [],
    email: 'email',
    category: 'category',
    ...event,
  });
}

describe('ImportBackupPopupComponent', () => {
  let context: TestCtx<ImportBackupPopupComponent>;
  let matDialogRefStub: jasmine.SpyObj<MatDialogRef<ImportBackupPopupComponent>>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
      ],
      declarations: [
        ImportBackupPopupComponent,
      ],
      providers: [
        { provide: MatDialogRef, useFactory: () => jasmine.createSpyObj('MatDialogRef', ['close'] as Array<keyof MatDialogRef<ImportBackupPopupComponent>>) },
        { provide: MAT_DIALOG_DATA, useValue: { event: generateEvent({}) } },
      ],
    })
  });

  beforeEach(async( async () => {
    matDialogRefStub = TestBed.get(MatDialogRef);
    context = await createStableTestContext(ImportBackupPopupComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
