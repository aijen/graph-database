import { async, TestBed } from '@angular/core/testing';
import { MatDialog } from '@angular/material/dialog';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { EventsListComponent } from './events-list.component';

describe('EventsListComponent', () => {
  let context: TestCtx<EventsListComponent>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
      ],
      declarations: [
        EventsListComponent,
      ],
      providers: [
        { provide: MatDialog, useFactory: () => ({}) },
      ]
    })
  });

  beforeEach(async( async () => {
    context = await createStableTestContext(EventsListComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
