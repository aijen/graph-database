import { Component, Input, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { UserRole } from 'core/models/userRoles.model';
import { Moment } from 'moment';
import { Events } from '../../store/events/events.model';
import { ImportBackupPopupComponent } from '../import-backup-popup/import-backup-popup.component';

@Component({
  selector: 'pit-events-list',
  templateUrl: './events-list.component.html',
  styleUrls: ['./events-list.component.scss']
})
export class EventsListComponent implements OnInit {

  @Input()
  events: Events[];

  constructor(
    private dialog: MatDialog,
  ) { }

  ngOnInit() {
  }

  formatDate(date: Moment): string {
    return date.format('YYYY/MM/DD HH:mm:ss');
  }

  formatProfiles(profiles: UserRole[]): string {
    let str = '';

    for(let profile of profiles) {
      switch(profile) {
        case UserRole.PUBLIC:
          str = str.length > 0 ? str.concat(', Public') : 'Public';
          break;
        case UserRole.ADMIN:
          str = str.length > 0 ? str.concat(', Admin') : 'Admin';
          break;
        case UserRole.SUPER_ADMIN:
          str = str.length > 0 ? str.concat(', SuperAdmin') : 'SuperAdmin';
          break;
        case UserRole.GROUP_MANAGER:
        default:
          break;
      }
    }

    return str;
  }

  openBackupPopup(event: Events) {
    if(!event.baseFile || !event.importedFile)
      return;

    const config = new MatDialogConfig();
    config.data = { event };
    config.disableClose = true;
    config.minWidth = '40rem';
    config.width = '40rem';

    this.dialog.open(ImportBackupPopupComponent, config);
  }

}
