import { Component, Input } from '@angular/core';
import { async, TestBed } from '@angular/core/testing';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { configureTestSuite, createStableTestContext, TestCtx } from 'ng-bullet';
import { Observable } from 'rxjs';
import { AppState } from 'shared/models/state.model';
import { alertsFormState } from './store/alerts/alerts.form.reducer';
import { TabAlertsComponent } from './tab-alerts.component';

@Component({
  selector: 'cockpit-weekdays',
  template: '',
})
class CockpitWeekdaysStubComponent {}

@Component({
  selector: 'cockpit-contact',
  template: '',
})
class CockpitContactStubComponent {}

@Component({
  selector: 'cockpit-alarm-activation',
  template: '',
})
class CockpitAlarmActivationStubComponent {}

@Component({
  selector: 'cockpit-notif-mode',
  template: '',
})
class CockpitNotifModeStubComponent {}

@Component({
  selector: 'pit-leaves-by-node',
  template: '',
})
class PitLeavesByNodeStubComponent {
  @Input() leaves: any;
}

describe('TabAlertsComponent', () => {
  let context: TestCtx<TabAlertsComponent>;
  let actions: Observable<any>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        MatProgressSpinnerModule,
        NoopAnimationsModule,
      ],
      declarations: [
        TabAlertsComponent,
        CockpitWeekdaysStubComponent,
        CockpitContactStubComponent,
        CockpitAlarmActivationStubComponent,
        CockpitNotifModeStubComponent,
        PitLeavesByNodeStubComponent,
      ],
      providers: [
        provideMockStore<Partial<AppState>>({ initialState: { alertsForm: alertsFormState } }),
        provideMockActions(() => actions),
      ],
    })
  });

  beforeEach(async( async () => {
    context = await createStableTestContext(TabAlertsComponent);
  } ));

  it('should create', () => {
    expect(context.component).toBeTruthy();
  });


  /** prevent memory leaks by removing leftover styles in <head> */
  function cleanStylesFromDom(): void {
    const head = document.head;
    const styles = Array.from(head.querySelectorAll('style'));
    for( const style of styles ) head.removeChild( style );
  }
  afterAll(cleanStylesFromDom);
});
