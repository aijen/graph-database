import { leavesState } from 'core/store/leaves/leaves.model';
import { PopulatedMetasValue } from 'core/store/populated-metas/populated-metas.model';
import { createFormGroupState, createFormStateReducerWithUpdate, disable, enable, focus, FormControlState, FormGroupState, reset, setUserDefinedProperty, setValue, unfocus, updateArray, updateGroup, validate } from 'ngrx-forms';
import { email, equalTo, greaterThanOrEqualTo, lessThanOrEqualTo, maxLength, pattern, required } from 'ngrx-forms/validation';
import { AdminLeafMetaType, BANK } from 'shared/store/leaves/leaves.form.model';
import { formLeavesMetaDisabledUpdate, formLeavesMetaTypeUpdate, leavesUpdate } from 'shared/store/leaves/leaves.form.reducer';
import { AlertsFormActionTypes, AlertsFormActionUnion } from './alerts.form.actions';
import { AlertsFormContact, AlertsFormNotifType, AlertsFormState, AlertsFormValue, Weekday } from './alerts.form.model';

const FORM_ID = 'ADMIN_ALERTS_FORM';

const initialFormState = createFormGroupState<AlertsFormValue>(FORM_ID, {
  weekdays: {
    MON: { dayOfWeek: 'MON', start:  0, end:  0, enable: false },
    TUE: { dayOfWeek: 'TUE', start:  0, end:  0, enable: false },
    WED: { dayOfWeek: 'WED', start:  0, end:  0, enable: false },
    THU: { dayOfWeek: 'THU', start:  0, end:  0, enable: false },
    FRI: { dayOfWeek: 'FRI', start:  0, end:  0, enable: false },
    SAT: { dayOfWeek: 'SAT', start:  0, end:  0, enable: false },
    SUN: { dayOfWeek: 'SUN', start:  0, end:  0, enable: false },
  },
  contacts: [
    { email: '', tel: '', emailEnabled: false, telEnabled: false, },
    { email: '', tel: '', emailEnabled: false, telEnabled: false, },
  ],
  metas: {
    AVAILABILITY: { metaType: 'AVAILABILITY', enable: false, delay: null, },
    PERFORMANCE:  { metaType: 'PERFORMANCE',  enable: false, delay: null, },
    RISK:         { metaType: 'RISK',         enable: false, delay: null, },
    USER_XP:      { metaType: 'USER_XP',      enable: false, delay: null, },
  },
  leaves: leavesState,
  notification: {
    notificationType: AlertsFormNotifType.SCHEDULING,
    schedule: null,
  },
});

const isOverlapping = ( { start: ys, end: ye, enable: enabled }: Weekday, start: number ) => enabled && (ye <= ys && start < ye);

const disableIfOverlappingYesterday =
  ( siblingState: FormGroupState<Weekday>  ) =>
    ( state: FormGroupState<Weekday> ): FormGroupState<Weekday<any>>  =>
      isOverlapping(siblingState.value, state.value.start) ? setUserDefinedProperty(setValue(state, { ...state.value, enable: false, start: siblingState.value.end, end: 0 }), 'overlapping', true) : state;

const removeOverlappingFlagWhenEnabled =
  ( state: FormGroupState<Weekday> ): FormGroupState<Weekday<any>>  =>
    state.value.enable ? setUserDefinedProperty(state, 'overlapping', false) : state;

/** Helper that disable a `FormControlState` if its sibling `prop` is falsy */
const disableIfFalsySibling =
  <T>( prop: keysOfType<T, boolean> ) =>
    ( state: FormControlState<any>, parentState: FormGroupState<T> ) =>
      parentState.value[prop] ? parentState.controls[prop].isDirty ? focus(enable(state)) : enable(state) : unfocus(disable(state));

/** Toggle disabled state on FormControlState linked to FormControlState<boolean> */
const formUpdate = updateGroup<AlertsFormValue>({
  weekdays: updateGroup<AlertsFormValue['weekdays']>({
    MON: (state, parentState) => updateGroup<AlertsFormValue['weekdays']['MON']>(removeOverlappingFlagWhenEnabled(disableIfOverlappingYesterday(parentState.controls.SUN)(state)), { start: disableIfFalsySibling('enable'), end: disableIfFalsySibling('enable') }),
    TUE: (state, parentState) => updateGroup<AlertsFormValue['weekdays']['TUE']>(removeOverlappingFlagWhenEnabled(disableIfOverlappingYesterday(parentState.controls.MON)(state)), { start: disableIfFalsySibling('enable'), end: disableIfFalsySibling('enable') }),
    WED: (state, parentState) => updateGroup<AlertsFormValue['weekdays']['WED']>(removeOverlappingFlagWhenEnabled(disableIfOverlappingYesterday(parentState.controls.TUE)(state)), { start: disableIfFalsySibling('enable'), end: disableIfFalsySibling('enable') }),
    THU: (state, parentState) => updateGroup<AlertsFormValue['weekdays']['THU']>(removeOverlappingFlagWhenEnabled(disableIfOverlappingYesterday(parentState.controls.WED)(state)), { start: disableIfFalsySibling('enable'), end: disableIfFalsySibling('enable') }),
    FRI: (state, parentState) => updateGroup<AlertsFormValue['weekdays']['FRI']>(removeOverlappingFlagWhenEnabled(disableIfOverlappingYesterday(parentState.controls.THU)(state)), { start: disableIfFalsySibling('enable'), end: disableIfFalsySibling('enable') }),
    SAT: (state, parentState) => updateGroup<AlertsFormValue['weekdays']['SAT']>(removeOverlappingFlagWhenEnabled(disableIfOverlappingYesterday(parentState.controls.FRI)(state)), { start: disableIfFalsySibling('enable'), end: disableIfFalsySibling('enable') }),
    SUN: (state, parentState) => updateGroup<AlertsFormValue['weekdays']['SUN']>(removeOverlappingFlagWhenEnabled(disableIfOverlappingYesterday(parentState.controls.SAT)(state)), { start: disableIfFalsySibling('enable'), end: disableIfFalsySibling('enable') }),
  }),
  contacts: updateArray<AlertsFormContact>(updateGroup<AlertsFormContact>({
    email: disableIfFalsySibling('emailEnabled'),
    tel: disableIfFalsySibling('telEnabled'),
  })),
  metas: updateGroup<AlertsFormValue['metas']>({
    AVAILABILITY: updateGroup<AlertsFormValue['metas']['AVAILABILITY']>({ delay: disableIfFalsySibling('enable'), }),
    PERFORMANCE:  updateGroup<AlertsFormValue['metas']['PERFORMANCE' ]>({ delay: disableIfFalsySibling('enable'), }),
    RISK:         updateGroup<AlertsFormValue['metas']['RISK'        ]>({ delay: disableIfFalsySibling('enable'), }),
    USER_XP:      updateGroup<AlertsFormValue['metas']['USER_XP'     ]>({ delay: disableIfFalsySibling('enable'), }),
  }),
  leaves: leavesUpdate,
});

// TODO: REMOVE THIS UPDATE ONCE STREAMING MODE IS AVAILABLE
const disableNotificationType = updateGroup<AlertsFormValue>({
  notification: updateGroup<AlertsFormValue['notification']>({
    notificationType: ( notifType ) => disable(notifType),
  }),
});

const alertsFormLeavesMetaTypeUpdate = (form: FormGroupState<AlertsFormValue>, bank: BANK, meta: AdminLeafMetaType, checked: boolean) => updateGroup<AlertsFormValue>(form, {
  leaves: formLeavesMetaTypeUpdate(bank, meta, checked),
})

const alertsFormLeavesMetaDisabledUpdate = (form: FormGroupState<AlertsFormValue>, populatedMetas: PopulatedMetasValue[]) => updateGroup<AlertsFormValue>(form, {
  leaves: state => formLeavesMetaDisabledUpdate(state, populatedMetas),
})

/** Validate the form */
const formValidation = updateGroup<AlertsFormValue>({
  contacts: updateArray<AlertsFormContact>(updateGroup<AlertsFormContact>({
    email: validate(required, email, maxLength(64)),
    tel: validate(required, pattern(/^\d{10}$/)),
  })),
  metas: updateGroup<AlertsFormValue['metas']>({
    AVAILABILITY: updateGroup<AlertsFormValue['metas']['AVAILABILITY']>({ delay: validate(required, equalTo(15)) }),
    PERFORMANCE:  updateGroup<AlertsFormValue['metas']['PERFORMANCE' ]>({ delay: validate(required, equalTo(15)) }),
    RISK:         updateGroup<AlertsFormValue['metas']['RISK'        ]>({ delay: validate(required, equalTo(15)) }),
    USER_XP:      updateGroup<AlertsFormValue['metas']['USER_XP'     ]>({ delay: validate(required, equalTo(15)) }),
  }),
  notification: updateGroup<AlertsFormValue['notification']>({
    schedule: validate(required, greaterThanOrEqualTo(15), lessThanOrEqualTo(999)),
  }),
});

const updateAndValidate = ( form: FormGroupState<AlertsFormValue> ) => formValidation(formUpdate(disableNotificationType(form)));

const formReducer = createFormStateReducerWithUpdate(updateAndValidate);

export const alertsFormState: AlertsFormState = {
  form: updateAndValidate(initialFormState),
  defaultForm: initialFormState.value,
  isSaving: false,
  isLoading: false,
  populatedMetas: [],
};

export function alertsFormReducer(
  state = alertsFormState,
  action: AlertsFormActionUnion,
): AlertsFormState {

  const form = formReducer(state.form, action);

  if(form !== state.form) {
    state = { ...state, form };
  }

  switch( action.type ) {
    case AlertsFormActionTypes.ResetAlertsForm: {
      const defaultForm = action.payload && action.payload.form || state.defaultForm;
      const { populatedMetas } = state
      return {
        ...state,
        form: updateAndValidate(alertsFormLeavesMetaDisabledUpdate(reset(setValue(state.form, defaultForm)), populatedMetas)),
        defaultForm,
      }
    }
    case AlertsFormActionTypes.SaveAlertsForm: {
      return {
        ...state,
        form: disable(state.form),
        isSaving: true,
      };
    }
    case AlertsFormActionTypes.SaveAlertsFormError:
    case AlertsFormActionTypes.SaveAlertsFormSuccess: {
      return {
        ...state,
        form: disableNotificationType(enable(state.form)),
        isSaving: false,
      };
    }
    case AlertsFormActionTypes.LoadAlertsForm: {
      return {
        ...state,
        form: disable(state.form),
        isLoading: true,
      };
    }
    case AlertsFormActionTypes.LoadAlertsFormError: {
      return {
        ...state,
        isLoading: false,
      };
    }
    case AlertsFormActionTypes.LoadAlertsFormSuccess: {
      const { metas } = action.payload
      return {
        ...state,
        form: disableNotificationType(enable(state.form)),
        isLoading: false,
        populatedMetas: metas,
      };
    }
    case AlertsFormActionTypes.ToggleAlertsFormLeavesMetaType: {
      const { bank, meta, checked } = action.payload;
      return {
        ...state,
        form: alertsFormLeavesMetaTypeUpdate( state.form, bank, meta, checked ),
      }
    }
    default: {
      return state;
    }
  }

}
