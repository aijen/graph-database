import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { select, Store } from '@ngrx/store';
import { SaveEvent } from 'app/pages/tab-events/store/events/events.actions';
import { EventsService } from 'app/pages/tab-events/store/events/events.service';
import { LOAD_ADMIN_ALERTS_URL, SAVE_ADMIN_ALERTS_URL } from 'core/services/http/http-client.service';
import { getAuthState } from 'core/store/auth/auth.selectors';
import { sortByNameCaseInsensitive } from 'core/store/leaves/leaves.model';
import { PopulatedMetasService } from 'core/store/populated-metas/populated-metas.service';
import { combineLatest, of } from 'rxjs';
import { catchError, concatMap, map, mapTo, switchMap, tap, withLatestFrom } from 'rxjs/operators';
import { AppState } from 'shared/models/state.model';
import { MessageHandler } from 'shared/services/messageHandler.service';
import { AlertsFormActionTypes, LoadAlertsForm, LoadAlertsFormError, LoadAlertsFormSuccess, ResetAlertsForm, SaveAlertsForm, SaveAlertsFormError, SaveAlertsFormSuccess } from './alerts.form.actions';
import { AlertsFormContact, AlertsFormValue, AlertsFormValueDTO, Weekday } from './alerts.form.model';
import { getAlertsForm } from './alerts.form.selectors';

const confToJson = ( conf: AlertsFormValue ): AlertsFormValueDTO => {
  return {
    ...conf,
    weekdays: Object.values(conf.weekdays),
    metas: Object.values(conf.metas),
  }
}

const confFromJson = ( conf: AlertsFormValueDTO ): AlertsFormValue => {
  const weekdays: Partial<AlertsFormValue['weekdays']> = {};
  for(const weekday of conf.weekdays) weekdays[weekday.dayOfWeek] = { ...weekday, start: +weekday.start, end: +weekday.end } as Weekday<any>;

  const metas: Partial<AlertsFormValue['metas']> = {};
  for(const meta of conf.metas) metas[meta.metaType] = meta;

  const contacts: AlertsFormContact[] = conf.contacts.map( (contact) => ({
    tel: '',
    email: '',
    ...contact
  }) );

  Object.keys(conf.leaves).forEach(bank => {
    conf.leaves[bank].sort(sortByNameCaseInsensitive);
  });

  return {
    ...conf,
    weekdays: weekdays as Required<AlertsFormValue['weekdays']>,
    metas: metas as Required<AlertsFormValue['metas']>,
    contacts,
  }
}

@Injectable({providedIn: 'root'})
export class AlertsFormEffects {

  public static messages = {
    loadError: `
      Une erreur est survenue pendant le chargement de la configuration 'Alertes': Veuillez réessayer
    `,
    saveSuccess: `
      Configuration sauvegardée
    `,
    saveError: `
      Une erreur est survenue pendant la sauvegarde, veuillez réessayer ou contacter le support si le problème persiste
    `,
    saveConflict: `
      Une erreur est survenue pendant la sauvegarde, la clé d'au moins un noeud de rang 1 à été changée, veuillez recharger la page et refaire votre configuration
    `,
  }

  form$ = this.store$.pipe(
    select( getAlertsForm ),
  );

  auth$ = this.store$.select(getAuthState);

  constructor(
    private store$: Store<AppState>,
    private actions$: Actions,
    private http: HttpClient,
    private router: Router,
    private snackbar: MessageHandler,
    private populatedMetasService: PopulatedMetasService,
    private eventsService: EventsService,
  ) {}

  @Effect()
  load$ = this.actions$.pipe(
    ofType<LoadAlertsForm>( AlertsFormActionTypes.LoadAlertsForm ),
    switchMap( () => combineLatest(
      this.http.get(LOAD_ADMIN_ALERTS_URL).pipe(map( confFromJson )),
      this.populatedMetasService.populatedMetas$
    ) ),
    map( ([form, metas]) => new LoadAlertsFormSuccess( { form, metas } ) ),
    catchError( (error, caught) => (this.store$.dispatch(new LoadAlertsFormError( { error } )), caught) ),
  );

  @Effect()
  loadSuccess$ = this.actions$.pipe(
    ofType<LoadAlertsFormSuccess>( AlertsFormActionTypes.LoadAlertsFormSuccess ),
    map( success => success.payload.form ),
    map( form => new ResetAlertsForm( { form } ) ),
  );

  @Effect({ dispatch: false })
  loadError$ = this.actions$.pipe(
    ofType<LoadAlertsFormError>( AlertsFormActionTypes.LoadAlertsFormError ),
    tap( action => { console.error(action.payload.error); this.snackbar.show( { message: AlertsFormEffects.messages.loadError, action: 'OK', isError: true } )} ),
  );

  @Effect()
  save$ = this.actions$.pipe(
    ofType<SaveAlertsForm>( AlertsFormActionTypes.SaveAlertsForm ),
    withLatestFrom( this.form$ ),
    switchMap( ([action, _form]) => of(_form).pipe(
      map( (form) => form.value ),
      map( confToJson ),
      switchMap( form => this.http.put(SAVE_ADMIN_ALERTS_URL, form, { responseType: 'text' }).pipe( mapTo(form) ) ),
      map( confFromJson ),
      map( form => new SaveAlertsFormSuccess( { form } ) ),
      tap( () => action.payload.andQuit ? this.router.navigate(['/']) : null ),
      catchError( error => of(new SaveAlertsFormError( { error } )) ),
    ) ),
  );

  @Effect()
  saveSuccess$ = this.actions$.pipe(
    ofType<SaveAlertsFormSuccess>( AlertsFormActionTypes.SaveAlertsFormSuccess ),
    map( success => success.payload.form ),
    withLatestFrom(this.auth$),
    map(([form, auth]) => ({ form, event: this.eventsService.createEvent(auth, '[Alertes]') })),
    concatMap(({ form, event }) => [
      new SaveEvent({ event }),
      new ResetAlertsForm({ form }),
    ]),
    tap( () => this.snackbar.show( { message: AlertsFormEffects.messages.saveSuccess } ) ),
  );

  @Effect( { dispatch: false } )
  saveError$ = this.actions$.pipe(
    ofType<SaveAlertsFormError>( AlertsFormActionTypes.SaveAlertsFormError ),
    select(action => action.payload.error),
    tap( error => { console.error(error); this.snackbar.show( { message: error.status === 409 ? AlertsFormEffects.messages.saveConflict : AlertsFormEffects.messages.saveError, action: 'OK', isError: true } )} ),
  );

}
