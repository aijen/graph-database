import { createFeatureSelector, createSelector } from '@ngrx/store';
import { AlertsFormState } from './alerts.form.model';

export const alertsFormStateSelector = createFeatureSelector<AlertsFormState>(
  'alertsForm'
);

export const getAlertsForm = createSelector(
  alertsFormStateSelector,
  state => state.form,
);

export const isAlertsFormLoading = createSelector(
  alertsFormStateSelector,
  state => state.isLoading,
);

export const isAlertsFormLoadingOrSaving = createSelector(
  alertsFormStateSelector,
  state => state.isLoading || state.isSaving,
);
