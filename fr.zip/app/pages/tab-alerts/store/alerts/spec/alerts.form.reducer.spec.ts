import { AppState } from 'shared/models/state.model';
import { alertsFormReducer, alertsFormState } from '../alerts.form.reducer';

// necessary to avoid the error :
// Invalid module name in augmentation, module 'shared/models/state.model' cannot be found.
let happy_compiler: AppState; // tslint:disable-line

describe('AlertsForm Reducer', () => {

  describe('undefined action', () => {

    it('should return the default state', () => {
      const action = { type: null, payload: null };
      const state = alertsFormReducer( undefined, action );

      expect(state).toBe(alertsFormState);
    })

  });

} );
