import { LeavesState } from 'core/store/leaves/leaves.model';
import { PopulatedMetasValue } from 'core/store/populated-metas/populated-metas.model';
import { FormGroupState } from 'ngrx-forms';

declare module 'shared/models/state.model' {
  export interface AppState {
    readonly alertsForm: AlertsFormState;
  }
}

export type dayOfWeek =
 | 'MON'
 | 'TUE'
 | 'WED'
 | 'THU'
 | 'FRI'
 | 'SAT'
 | 'SUN';

export interface Weekday<T = dayOfWeek> {
  dayOfWeek: T;
  start: number;
  end: number;
  enable: boolean;
}

export interface AlertsFormContact {
  tel: string;
  email: string;

  telEnabled: boolean;
  emailEnabled: boolean;
}

export type AlertsFormContactDTO = Partial<Pick<AlertsFormContact, 'tel' | 'email'>> & Pick<AlertsFormContact, 'telEnabled' | 'emailEnabled'>;

export type AlertsFormMetaType =
  | 'AVAILABILITY'
  | 'PERFORMANCE'
  | 'RISK'
  | 'USER_XP'
  ;

export interface AlertsFormMeta {
  metaType: AlertsFormMetaType
  enable: boolean;
  delay: number;
}

export const enum AlertsFormNotifType {
  SCHEDULING = 'SCHEDULING',
  STREAMING = 'STREAMING',
}

export interface AlertsFormValue {

  weekdays: {
    MON: Weekday<'MON'>,
    TUE: Weekday<'TUE'>,
    WED: Weekday<'WED'>,
    THU: Weekday<'THU'>,
    FRI: Weekday<'FRI'>,
    SAT: Weekday<'SAT'>,
    SUN: Weekday<'SUN'>,
  };

  contacts: AlertsFormContact[];

  metas: {
    AVAILABILITY: AlertsFormMeta,
    PERFORMANCE: AlertsFormMeta,
    RISK: AlertsFormMeta,
    USER_XP: AlertsFormMeta,
  };

  leaves: LeavesState;

  notification: {
    notificationType: AlertsFormNotifType,
    schedule: number,
  };

}

export interface AlertsFormValueDTO extends Omit<AlertsFormValue, 'weekdays' | 'metas' | 'contacts'> {

  contacts: AlertsFormContactDTO[];
  weekdays: Weekday[];
  metas: AlertsFormMeta[];

}

export interface AlertsFormState {
  form: FormGroupState<AlertsFormValue>;
  defaultForm: AlertsFormValue;
  isSaving: boolean;
  isLoading: boolean;
  populatedMetas: PopulatedMetasValue[];
}
