import { HttpErrorResponse } from '@angular/common/http';
import { Action } from '@ngrx/store';
import { PopulatedMetasValue } from 'core/store/populated-metas/populated-metas.model';
import { AdminLeafMetaType, BANK } from 'shared/store/leaves/leaves.form.model';
import { AlertsFormValue } from './alerts.form.model';

export enum AlertsFormActionTypes {
  LoadAlertsForm = '[Admin] LoadAlertsForm',
  LoadAlertsFormSuccess = '[Admin] LoadAlertsFormSuccess',
  LoadAlertsFormError = '[Admin] LoadAlertsFormError',
  ResetAlertsForm = '[Admin] ResetAlertsForm',
  SaveAlertsForm = '[Admin] SaveAlertsForm',
  SaveAlertsFormSuccess = '[Admin] SaveAlertsFormSuccess',
  SaveAlertsFormError = '[Admin] SaveAlertsFormError',
  ToggleAlertsFormLeavesMetaType = '[Admin] ToggleAlertsLeavesMetaType',
}

export class LoadAlertsForm implements Action {
  readonly type = AlertsFormActionTypes.LoadAlertsForm;
  constructor() {}
}

export class LoadAlertsFormSuccess implements Action {
  readonly type = AlertsFormActionTypes.LoadAlertsFormSuccess;
  constructor( public payload: { form: AlertsFormValue, metas: PopulatedMetasValue[] } ) {}
}

export class LoadAlertsFormError implements Action {
  readonly type = AlertsFormActionTypes.LoadAlertsFormError;
  constructor( public payload: { error: HttpErrorResponse } ) {}
}

export class ResetAlertsForm implements Action {
  readonly type = AlertsFormActionTypes.ResetAlertsForm;
  constructor( public payload?: { form?: AlertsFormValue } ) {}
}

export class SaveAlertsForm implements Action {
  readonly type = AlertsFormActionTypes.SaveAlertsForm;
  constructor( public payload: { andQuit?: boolean } = {} ) {}
}

export class SaveAlertsFormSuccess implements Action {
  readonly type = AlertsFormActionTypes.SaveAlertsFormSuccess;
  constructor( public payload: { form: AlertsFormValue } ) {}
}

export class SaveAlertsFormError implements Action {
  readonly type = AlertsFormActionTypes.SaveAlertsFormError;
  constructor( public payload: { error: HttpErrorResponse } ) {}
}

export class ToggleAlertsFormLeavesMetaType implements Action {
  readonly type = AlertsFormActionTypes.ToggleAlertsFormLeavesMetaType;
  constructor( public payload: { bank: BANK, meta: AdminLeafMetaType, checked: boolean } ) {}
}

export type AlertsFormActionUnion =
  | LoadAlertsForm
  | LoadAlertsFormSuccess
  | LoadAlertsFormError
  | ResetAlertsForm
  | SaveAlertsForm
  | SaveAlertsFormSuccess
  | SaveAlertsFormError
  | ToggleAlertsFormLeavesMetaType
  ;
