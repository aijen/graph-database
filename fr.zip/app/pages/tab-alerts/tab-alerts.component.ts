import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Actions, ofType } from '@ngrx/effects';
import { select, Store } from '@ngrx/store';
import { fadeAnimation } from 'core/animations/animations';
import { AdminLeaf } from 'core/store/leaves/leaves.model';
import { canResetForm, canSaveForm, isFormPristine } from 'core/utils/forms.helpers';
import { sortStringCaseInsensitiveStrategy } from 'core/utils/sortStrategies';
import { FormArrayState } from 'ngrx-forms';
import { combineLatest, merge, of } from 'rxjs';
import { map, mapTo, switchMapTo, tap } from 'rxjs/operators';
import { ToggleEvent } from 'shared/components/leaves-by-node/leaves-by-node.component';
import { AppState } from 'shared/models/state.model';
import { CanComponentWithFormDeactivate } from 'shared/services/CanComponentWithFormDeactivate.interface';
import { BANK } from 'shared/store/leaves/leaves.form.model';
import { AlertsFormActionTypes, LoadAlertsForm, ResetAlertsForm, SaveAlertsForm, ToggleAlertsFormLeavesMetaType } from './store/alerts/alerts.form.actions';
import { getAlertsForm, isAlertsFormLoading, isAlertsFormLoadingOrSaving } from './store/alerts/alerts.form.selectors';

@Component({
  selector: 'cockpit-tab-alerts',
  templateUrl: './tab-alerts.component.html',
  styleUrls: ['./tab-alerts.component.scss'],
  animations: [fadeAnimation()],
})
export class TabAlertsComponent implements OnInit, CanComponentWithFormDeactivate {

  form$ = this.store$.pipe(
    select( getAlertsForm ),
  );

  loading$ = this.store$.pipe(
    select( isAlertsFormLoadingOrSaving ),
  );

  canSave$ = this.form$.pipe(
    canSaveForm
  );

  canReset$ = this.form$.pipe(
    canResetForm
  );

  isPristine$ = this.form$.pipe(
    isFormPristine
  );

  banks$ = this.form$.pipe(
    select( s => s.controls.leaves.controls ),
    map( (banks) => (Object.keys( banks ).sort(sortStringCaseInsensitiveStrategy) as BANK[]).map( bank => ({ name: bank, leaves: banks[bank] }) ) )
  );

  trackByName = ( index: number, { name }: {
    name: string;
    leaves: FormArrayState<AdminLeaf>;
  } ) => name;

  constructor(
    private store$: Store<AppState>,
    private actions$: Actions,
    private router: Router,
  ) { }

  ngOnInit() {
    this.store$.dispatch( new LoadAlertsForm() );
  }

  isModified() {
    return combineLatest(
      this.isPristine$,
      this.store$.select( isAlertsFormLoading ),
    ).pipe( map( ([pristine, loading]) => !(pristine || loading) ) );
  }

  getSaveAction() {
    const saveResult = merge(
      this.actions$.pipe( ofType( AlertsFormActionTypes.SaveAlertsFormSuccess ), mapTo(true) ),
      this.actions$.pipe( ofType( AlertsFormActionTypes.SaveAlertsFormError ), mapTo(false) ),
    );

    return of(null).pipe(
      tap( () => this.save() ),
      switchMapTo( saveResult ),
    );
  }

  canSave() {
    return this.canSave$;
  }

  save() {
    this.store$.dispatch( new SaveAlertsForm() );
  }

  saveAndQuit() {
    this.store$.dispatch( new SaveAlertsForm( { andQuit: true } ) );
  }

  reset() {
    this.store$.dispatch( new ResetAlertsForm() );
  }

  quit() {
    this.reset();
    this.router.navigateByUrl('/');
  }

  toggleMetaForBank( bank: BANK, { meta, checked }: ToggleEvent ) {
    this.store$.dispatch( new ToggleAlertsFormLeavesMetaType( {bank, meta, checked} ) );
  }

}
