import { Component, OnInit } from '@angular/core';
import { createSelector, select, Store } from '@ngrx/store';
import { FormGroupState } from 'ngrx-forms';
import { AppState } from 'shared/models/state.model';
import { AlertsFormContact } from '../../store/alerts/alerts.form.model';
import { getAlertsForm } from '../../store/alerts/alerts.form.selectors';

@Component({
  selector: 'cockpit-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.scss']
})
export class ContactComponent implements OnInit {

  contacts$ = this.store$.pipe(
    select(createSelector(
      getAlertsForm,
      s => s.controls.contacts.controls,
    )),
  );

  constructor(
    private store$: Store<AppState>,
  ) { }

  ngOnInit() {
  }

  trackById( index: number, s: FormGroupState<AlertsFormContact> ) {
    return s.id;
  }

}
