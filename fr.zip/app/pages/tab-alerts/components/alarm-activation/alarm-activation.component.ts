import { Component, OnInit } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { AppState } from 'shared/models/state.model';
import { getAlertsForm } from '../../store/alerts/alerts.form.selectors';

@Component({
  selector: 'cockpit-alarm-activation',
  templateUrl: './alarm-activation.component.html',
  styleUrls: ['./alarm-activation.component.scss']
})
export class AlarmActivationComponent implements OnInit {

  meta$ = this.store$.pipe(
    select( getAlertsForm ),
    select( s => s.controls.metas.controls ),
  );

  metas = [
    { name: 'Disponibilité', icon: 'availability', store: this.meta$.pipe( select( s => s.AVAILABILITY.controls ) ) },
    { name: 'Performance',   icon: 'performance',  store: this.meta$.pipe( select( s => s.PERFORMANCE.controls  ) ) },
    { name: 'Risque',        icon: 'risk',         store: this.meta$.pipe( select( s => s.RISK.controls         ) ) },
    { name: 'Ressenti',      icon: 'user',         store: this.meta$.pipe( select( s => s.USER_XP.controls         ) ) },
  ]

  constructor(
    private store$: Store<AppState>,
  ) { }

  ngOnInit() {
  }

}
