import { Component, OnInit } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { NgrxValueConverter } from 'ngrx-forms';
import { AppState } from 'shared/models/state.model';
import { AlertsFormNotifType } from '../../store/alerts/alerts.form.model';
import { getAlertsForm } from '../../store/alerts/alerts.form.selectors';

@Component({
  selector: 'cockpit-notif-mode',
  templateUrl: './notif-mode.component.html',
  styleUrls: ['./notif-mode.component.scss']
})
export class NotifModeComponent implements OnInit {

  notifs$ = this.store$.pipe(
    select( getAlertsForm ),
    select( s => s.controls.notification.controls ),
  );

  modeValueConverter: NgrxValueConverter<boolean, AlertsFormNotifType> = {
    convertStateToViewValue: (value) => value === AlertsFormNotifType.STREAMING,
    convertViewToStateValue: (value) => value ? AlertsFormNotifType.STREAMING : AlertsFormNotifType.SCHEDULING,
  };

  constructor(
    private store$: Store<AppState>,
  ) { }

  ngOnInit() {
  }

}
