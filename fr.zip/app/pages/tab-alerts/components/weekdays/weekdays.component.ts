import { animate, style, transition, trigger } from '@angular/animations';
import { Component, OnInit } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { AppState } from 'shared/models/state.model';
import { AlertsFormValue } from '../../store/alerts/alerts.form.model';
import { getAlertsForm } from '../../store/alerts/alerts.form.selectors';

@Component({
  selector: 'cockpit-weekdays',
  templateUrl: './weekdays.component.html',
  styleUrls: ['./weekdays.component.scss'],
  animations: [
    trigger('fadeIn', [
      transition( ':enter', [
        style({ opacity: 0 }),
        animate('200ms linear',
          style({ opacity: 1 })
        )
      ] ),
      transition( ':leave', [
        animate('100ms linear',
          style({ opacity: 0 })
        )
      ] )
    ])
  ],
})
export class WeekdaysComponent implements OnInit {


  weekdays$ = this.store$.pipe(
    select( getAlertsForm ),
    select( s => s.controls.weekdays.controls ),
  );

  weekdays_name = [
    { name: 'Lundi',    store: this.getStore('MON', 'SUN' ) },
    { name: 'Mardi',    store: this.getStore('TUE', 'MON' ) },
    { name: 'Mercredi', store: this.getStore('WED', 'TUE' ) },
    { name: 'Jeudi',    store: this.getStore('THU', 'WED' ) },
    { name: 'Vendredi', store: this.getStore('FRI', 'THU' ) },
    { name: 'Samedi',   store: this.getStore('SAT', 'FRI' ) },
    { name: 'Dimanche', store: this.getStore('SUN', 'SAT' ) },
  ];

  hours = [
    { label: '00:00', value:  0 }, { label: '01:00', value:  1 }, { label: '02:00', value:  2 },
    { label: '03:00', value:  3 }, { label: '04:00', value:  4 }, { label: '05:00', value:  5 },
    { label: '06:00', value:  6 }, { label: '07:00', value:  7 }, { label: '08:00', value:  8 },
    { label: '09:00', value:  9 }, { label: '10:00', value: 10 }, { label: '11:00', value: 11 },
    { label: '12:00', value: 12 }, { label: '13:00', value: 13 }, { label: '14:00', value: 14 },
    { label: '15:00', value: 15 }, { label: '16:00', value: 16 }, { label: '17:00', value: 17 },
    { label: '18:00', value: 18 }, { label: '19:00', value: 19 }, { label: '20:00', value: 20 },
    { label: '21:00', value: 21 }, { label: '22:00', value: 22 }, { label: '23:00', value: 23 },
  ];

  constructor(
    private store$: Store<AppState>,
  ) { }

  ngOnInit() {
  }

  private getStore( todayKey: keyof AlertsFormValue['weekdays'], yesterdayKey: keyof AlertsFormValue['weekdays'] ) {
    return this.weekdays$.pipe( select( s => {
      const today = s[todayKey];
      const yesterday = s[yesterdayKey];
      const { enable: yEnable, start: yStart, end: yEnd } = yesterday.value;
      return {
        start: today.controls.start,
        end: today.controls.end,
        enable: today.controls.enable,
        yesterdayEnd: yEnable && (yEnd <= yStart) ? yesterday.controls.end.value : 0,
        overlapping: today.userDefinedProperties.overlapping,
      }
    } ) );
  }

}
