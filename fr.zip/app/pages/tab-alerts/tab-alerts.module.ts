import { NgModule } from '@angular/core';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { NgrxFormsModule } from 'ngrx-forms';
import { LeavesByNodeModule } from 'shared/components/leaves-by-node/leaves-by-node.module';
import { SlideToggleModule } from 'shared/components/slide-toggle/slide-toggle.module';
import { SharedAdminModule } from 'shared/shared-admin.module';
import { AlarmActivationComponent } from './components/alarm-activation/alarm-activation.component';
import { ContactComponent } from './components/contact/contact.component';
import { NotifModeComponent } from './components/notif-mode/notif-mode.component';
import { WeekdaysComponent } from './components/weekdays/weekdays.component';
import { AlertsFormEffects } from './store/alerts/alerts.form.effects';
import { alertsFormReducer } from './store/alerts/alerts.form.reducer';
import { TabAlertsComponent } from './tab-alerts.component';

@NgModule({
  declarations: [
    TabAlertsComponent,
    WeekdaysComponent,
    ContactComponent,
    AlarmActivationComponent,
    NotifModeComponent,
  ],
  imports: [
    SharedAdminModule,
    LeavesByNodeModule,
    SlideToggleModule,
    MatCheckboxModule,
    MatSelectModule,
    MatProgressSpinnerModule,
    MatSnackBarModule,
    NgrxFormsModule,
    StoreModule.forFeature('alertsForm', alertsFormReducer),
    EffectsModule.forFeature([AlertsFormEffects]),
  ]
})
export class TabAlertsModule { }
